/* Pactweave hero: a long contract scroll unrolls across a dark desk under a warm key light.
   Shot 1 (0-9 s): the scroll unrolls and the clause lines drift into view, slow push-in.
   Shot 2 (9-18 s): three flagged clauses send threads up into an obligation calendar, quarter orbit.
   Shot 3 (18-27 s): a register of owners and due dates settles beside the calendar, pull back to the first frame.
   Scrolling holds the threaded state. Every clause, date and owner here is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(23);
const bg=new T.Color(colors.bg),paper=new T.Color(color("--pw-parchment","#f8f5ee")),ox=new T.Color(color("--pw-oxblood","#8c2f39")),rose=new T.Color(color("--pw-rose","#d9959c")),gray=new T.Color(color("--pw-gray","#e5e7eb"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),8,19);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xd8dce4,.55));
const key=new T.DirectionalLight(0xffe2b8,1.25);key.position.set(-4,7,4);root.add(key);
const rim=new T.DirectionalLight(ox.getHex(),.55);rim.position.set(5,2,-6);root.add(rim);
/* desk */
const desk=new T.Mesh(new T.PlaneGeometry(30,16),new T.MeshStandardMaterial({color:bg.clone().lerp(paper,.03),roughness:1}));desk.rotation.x=-Math.PI/2;desk.position.y=-.06;root.add(desk);
/* the scroll: a strip whose far end is wrapped around a shrinking roll */
const L=7,W=1.9,SX=small?90:150,X0=-L/2+.2,Z0=-.2,RR=.17;
const pos=new Float32Array((SX+1)*2*3),idx=[];for(let i=0;i<SX;i++){const a=i*2;idx.push(a,a+1,a+2,a+1,a+3,a+2)}
const sg=new T.BufferGeometry;sg.setAttribute("position",new T.BufferAttribute(pos,3));sg.setIndex(idx);
const sheet=new T.Mesh(sg,new T.MeshStandardMaterial({color:paper.clone(),emissive:paper.clone(),emissiveIntensity:.14,roughness:.85,side:T.DoubleSide}));root.add(sheet);
function at(u,U,out){if(u<=U){out.x=X0+u;out.y=0}else{const a=(u-U)/RR,r=Math.max(.05,RR-.006*a);out.x=X0+U+r*Math.sin(a);out.y=r*(1-Math.cos(a))}return out}
const tmp={x:0,y:0};
function roll(U){for(let i=0;i<=SX;i++){const u=i/SX*L;at(u,U,tmp);for(let s=0;s<2;s++){const k=(i*2+s)*3;pos[k]=tmp.x;pos[k+1]=tmp.y;pos[k+2]=Z0+(s?W/2:-W/2)}}sg.attributes.position.needsUpdate=!0;sg.computeVertexNormals()}
/* clause lines printed on the sheet */
const LINES=[],FLAG=[9,22,34];let n=0;
for(let c=0;c<14;c++){const u0=.35+c*.47;for(let l=0;l<3;l++){LINES.push({u:u0+l*.085,w:(l===2?.55:1)+R()*.3,z:Z0-W/2+.18,f:FLAG.includes(n)});n++}}
const lGeo=new T.BoxGeometry(1,.004,.024),lMat=new T.MeshStandardMaterial({color:0xffffff,roughness:.9}),lines=new T.InstancedMesh(lGeo,lMat,LINES.length),o=new T.Object3D,tc=new T.Color;root.add(lines);
const inkLine=bg.clone().lerp(paper,.38);
/* obligation calendar: 7 x 5 cells standing behind the desk */
const cal=new T.Group;cal.position.set(1.5,1.75,-2.6);cal.rotation.y=-.18;root.add(cal);
const cGeo=new T.BoxGeometry(.3,.3,.02),CELLS=[];
for(let r=0;r<5;r++)for(let q=0;q<7;q++){const m=new T.MeshStandardMaterial({color:gray.clone(),emissive:0x000000,roughness:.7,transparent:!0,opacity:.16});const c=new T.Mesh(cGeo,m);c.position.set((q-3)*.36,(2-r)*.36,0);cal.add(c);CELLS.push(c)}
const frame=new T.Mesh(new T.BoxGeometry(2.72,2.06,.01),new T.MeshStandardMaterial({color:bg.clone().lerp(paper,.1),roughness:.9}));frame.position.z=-.03;cal.add(frame);
const HIT=[10,19,30];
/* register rows beside the calendar */
const reg=new T.Group;reg.position.set(2.55,.85,-1.5);reg.rotation.y=-.2;root.add(reg);
const rGeo=new T.BoxGeometry(1.5,.16,.02),rows=[0,1,2,3].map(i=>{const m=new T.MeshStandardMaterial({color:paper.clone(),roughness:.8,transparent:!0,opacity:0});const b=new T.Mesh(rGeo,m);b.position.y=.6-i*.26;reg.add(b);return b});
const dGeo=new T.SphereGeometry(.04,10,8),dots=rows.map((b,i)=>{const m=new T.MeshBasicMaterial({color:(i<3?ox:gray).clone(),transparent:!0,opacity:0});const d=new T.Mesh(dGeo,m);d.position.set(-.6,b.position.y,.03);reg.add(d);return d});
/* threads: from a flagged line, up and across, into a calendar cell */
const v3=(x,y,z)=>new T.Vector3(x,y,z),wp=new T.Vector3,threads=[];
roll(L);root.updateMatrixWorld(!0);
FLAG.forEach((li,k)=>{const Ln=LINES[li],sx=X0+Ln.u,sz=Z0-W/2+.2+Ln.w;CELLS[HIT[k]].getWorldPosition(wp);
const curve=new T.CatmullRomCurve3([v3(sx,.01,sz),v3(sx+.2,.5+k*.15,sz+.25),v3(lerp(sx,wp.x,.5),1.6+k*.2,lerp(sz,wp.z,.5)+.4),v3(wp.x-.25,wp.y+.05,wp.z+.35),v3(wp.x,wp.y,wp.z+.02)]);
const g=new T.TubeGeometry(curve,small?60:110,.011,6,!1),m=new T.MeshStandardMaterial({color:rose.clone(),emissive:ox.clone(),emissiveIntensity:.6,roughness:.5});
const t=new T.Mesh(g,m);t.visible=!1;root.add(t);threads.push({t,g,count:g.index.count})});
/* signature stroke on the last clause */
const sigPts=[];for(let i=0;i<=40;i++){const s=i/40;sigPts.push(v3(X0+L-.75+s*.55,.006,Z0+.45+Math.sin(s*14)*.05*(1-s*.4)))}
const sig=new T.Line(new T.BufferGeometry().setFromPoints(sigPts),new T.LineBasicMaterial({color:inkLine.clone().lerp(bg,.4)}));sig.geometry.setDrawRange(0,0);root.add(sig);
camera.fov=40;camera.updateProjectionMatrix();
const A0=v3(-1.4,5.4,9.6),A1=v3(-.6,4.1,7.6),look=v3(.35,.7,-.9),lk=v3(),cp=v3(),wide={k:1};
function cam(c){let p;if(c<9){p=cp.copy(A0).lerp(A1,ease(c/9))}else if(c<18){const a=ease((c-9)/9)*.22;p=cp.set(A1.x*Math.cos(a)+A1.z*Math.sin(a)*.55,lerp(A1.y,3.9,ease((c-9)/9)),A1.z*Math.cos(a)-A1.x*Math.sin(a))}
else{const a=.22,e=ease((c-18)/9),P2=v3(A1.x*Math.cos(a)+A1.z*Math.sin(a)*.55,3.9,A1.z*Math.cos(a)-A1.x*Math.sin(a));p=cp.copy(P2).lerp(A0,e)}
p.multiplyScalar(wide.k);return p}
function frameFn(t,dt,p){const hold=clamp((p-.5)/.3),c0=t%27,c=hold>0?lerp(c0,15.5,ease(hold)):c0;
const back=c>24.6?ease((c-24.6)/2.4):0,U=lerp(1.1,L,ease(clamp(c/7.5)))*(1-back)+1.1*back;roll(U);
camera.position.copy(cam(c));camera.position.x+=pointer.x*.3;camera.position.y-=pointer.y*.15;lk.copy(look);lk.x+=pointer.x*.08;camera.lookAt(lk);
LINES.forEach((Ln,i)=>{const vis=clamp((U-Ln.u-.08)/.25),fl=Ln.f&&c>8.6&&c<25.5;o.position.set(X0+Ln.u,.006,Z0-W/2+.2+Ln.w/2);o.rotation.y=Math.PI/2;o.scale.set(Ln.w*vis,1,1);o.updateMatrix();lines.setMatrixAt(i,o.matrix);
tc.copy(inkLine);if(Ln.f)tc.lerp(ox,fl?1:.15);lines.setColorAt(i,tc)});lines.instanceMatrix.needsUpdate=!0;lines.instanceColor.needsUpdate=!0;
threads.forEach((th,k)=>{const e=clamp((c-9.6-k*1.3)/2.6)*(1-back);th.t.visible=e>.01;th.g.setDrawRange(0,Math.floor(th.count*e/3)*3);
const cell=CELLS[HIT[k]],on=clamp((c-12.1-k*1.3)/.4)*(1-back);cell.material.opacity=.16+on*.84;cell.material.color.copy(gray).lerp(ox,on);cell.material.emissive.copy(ox).multiplyScalar(on*.35)});
const rg=clamp((c-18.6)/2.4)*(1-back);rows.forEach((b,i)=>{const e=clamp(rg*1.6-i*.18);b.material.opacity=e*.9;b.position.x=(1-e)*.4;dots[i].material.opacity=e});
sig.geometry.setDrawRange(0,Math.floor(41*clamp((c-19.4)/1.4)*(1-back)))}
return{frame:frameFn,resize:(w,h)=>{wide.k=w/h<.6?1.35:w/h<1.2?1:.9},dispose:()=>{[sg,lGeo,cGeo,rGeo,dGeo,desk.geometry,frame.geometry,sig.geometry].concat(threads.map(x=>x.g)).forEach(g=>g.dispose())}}}
