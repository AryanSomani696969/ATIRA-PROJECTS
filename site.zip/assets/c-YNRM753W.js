/* Tutorcairn page tools, all offline in the browser, nothing is sent anywhere:
   ask   - the hint-ladder homework helper (hint, step, similar problem, check) for five topics, English and Spanish
   practice - short fraction practice sets with hints on the sample lesson
   sample   - language tabs on the sample lesson and sample report */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
function num(s){s=String(s).trim().toLowerCase().replace(/^[a-z]\s*=\s*/,"").replace(/\s+/g,"").replace(/(km\/h|km\/hr|mph|m\/s|mi\/h|km|m|mi|units?|unidades?|%)$/,"").replace(",",".");
const m=s.match(/^(-?\d+(?:\.\d+)?)\/(-?\d+(?:\.\d+)?)$/);if(m){const d=+m[2];return d?+m[1]/d:NaN}return/^-?\d+(?:\.\d+)?$/.test(s)?+s:NaN}
const near=(a,b)=>Math.abs(a-b)<.011;
const gcd=(a,b)=>b?gcd(b,a%b):Math.abs(a),lcm=(a,b)=>a/gcd(a,b)*b;
const fr=(n,d)=>{const g=gcd(n,d)||1;n/=g;d/=g;return d===1?String(n):n+"/"+d};
const dec=(x,l)=>{const s=String(Math.round(x*100)/100);return l==="es"?s.replace(".",","):s};
function rng(str){let h=2166136261;for(const c of str)h=Math.imul(h^c.charCodeAt(0),16777619);return()=>{h=Math.imul(h^h>>>15,2246822507)>>>0;h=Math.imul(h^h>>>13,3266489909)>>>0;return((h^=h>>>16)>>>0)/4294967296}}
const pick=(r,a)=>a[Math.floor(r()*a.length)];
const UI={en:{label:"Type your question",go:"Get a hint",replay:"Replay",or:"Or pick a sample question:",ph:"For example: 2x + 5 = 17",
empty:"Ask a question to get the first hint. The tutor gives a hint first, then a step, then a similar problem, and checks your answer instead of giving it.",
rungs:["Hint","Step","Similar problem","Check your answer"],rung:"Rung",tried:"I tried it. Show a step",showSim:"Show a similar problem",trySim:"Try this one on your own:",
check:"Check",checkOwn:"Now check my own answer",ownQ:"Now finish your own question. What did you get?",ans:"Your answer",okSim:"Right. You solved it yourself.",
noSim:"Not yet. Look at the step again and try once more.",okOwn:"Right. You worked it out on your own.",noOwn:"Not yet. Go back to the step and check each move.",
teacher:"Still stuck? Take this one to class. It is a good question for your teacher.",errEmpty:"Type a question or pick a sample first.",
unrec:"I cannot read that one yet. This free helper covers five topics: two-step equations, adding and subtracting fractions, percent of a number, speed, and right triangles. Try writing it like one of the samples.",
bad:"Type a number, such as 7, -3, 2.5 or 5/6.",photo:"Read from the sample photo",q:"Your question",std:"Standard"},
es:{label:"Escribe tu pregunta",go:"Dame una pista",replay:"Repetir",or:"O elige una pregunta de ejemplo:",ph:"Por ejemplo: 2x + 5 = 17",
empty:"Haz una pregunta para recibir la primera pista. El tutor da primero una pista, luego un paso y después un problema parecido, y revisa tu respuesta en lugar de dártela.",
rungs:["Pista","Paso","Problema parecido","Revisa tu respuesta"],rung:"Peldaño",tried:"Ya lo intenté. Muéstrame un paso",showSim:"Muéstrame un problema parecido",trySim:"Resuelve este por tu cuenta:",
check:"Comprobar",checkOwn:"Ahora revisa mi propia respuesta",ownQ:"Ahora termina tu pregunta. ¿Qué te dio?",ans:"Tu respuesta",okSim:"Correcto. Lo resolviste por tu cuenta.",
noSim:"Todavía no. Vuelve a mirar el paso e inténtalo otra vez.",okOwn:"Correcto. Lo resolviste por tu cuenta.",noOwn:"Todavía no. Vuelve al paso y revisa cada operación.",
teacher:"¿Todavía no sale? Lleva esta pregunta a clase: es una buena pregunta para tu maestra o maestro.",errEmpty:"Escribe una pregunta o elige un ejemplo primero.",
unrec:"Todavía no puedo leer esa pregunta. Esta ayuda gratuita cubre cinco temas: ecuaciones de dos pasos, suma y resta de fracciones, porcentaje de un número, rapidez y triángulos rectángulos. Prueba a escribirla como uno de los ejemplos.",
bad:"Escribe un número, por ejemplo 7, -3, 2,5 o 5/6.",photo:"Leído de la foto de ejemplo",q:"Tu pregunta",std:"Estándar"}};
/* ---------- the five topics */
function solve(raw){
const t=raw.toLowerCase().replace(/[¿?¡!]/g," ").replace(/[−–]/g,"-").replace(/×/g,"*").trim(),z=t.replace(/solve:?|resuelve:?/g,"").replace(/\s+/g,""),R=rng(t);let m;
if((m=z.match(/^(-?\d*)x([+-]\d+)=(-?\d+)$/))){const a=m[1]===""?1:m[1]==="-"?-1:+m[1],b=+m[2],c=+m[3];if(!a)return null;
const ub=b>0?"+ "+b:"- "+(-b),ax=a===1?"x":a===-1?"-x":a+"x",r=c-b;
const a2=pick(R,[2,3,4,5,6]),x2=pick(R,[2,3,4,5,7,8,9]),b2=(b>0?1:-1)*pick(R,[1,3,4,5,6,8]),c2=a2*x2+b2,q2=a2+"x "+(b2>0?"+ ":"- ")+Math.abs(b2)+" = "+c2;
return{tp:{en:"Two-step equation",es:"Ecuación de dos pasos"},std:"Common Core 8.EE.C.7",ans:r/a,
hint:{en:"What is being done to x? First undo the "+ub+(a!==1?", then undo the × "+a+".":"."),es:"¿Qué se le está haciendo a x? Primero deshaz el "+ub+(a!==1?" y después el × "+a+".":".")},
step:{en:(b>0?"Subtract "+b+" from":"Add "+(-b)+" to")+" both sides."+(a!==1?" That leaves "+ax+" = "+r+". What do you divide by now?":" What is left on the right side?"),
es:(b>0?"Resta "+b+" en":"Suma "+(-b)+" en")+" ambos lados."+(a!==1?" Queda "+ax+" = "+r+". ¿Entre qué número divides ahora?":" ¿Qué queda del lado derecho?")},
sim:{q:{en:q2,es:q2},ans:x2}}}
if((m=z.match(/^(\d+)\/(\d+)([+-])(\d+)\/(\d+)=?$/))){const n1=+m[1],d1=+m[2],op=m[3],n2=+m[4],d2=+m[5];if(!d1||!d2)return null;const L=lcm(d1,d2),a=n1*L/d1,b=n2*L/d2;
const P=[[1,3,1,4],[1,2,1,5],[2,3,1,4],[1,6,1,4],[3,4,1,6],[2,5,1,2]].filter(p=>p[1]!==d1||p[3]!==d2),p=pick(R,P),L2=lcm(p[1],p[3]);
return{tp:{en:"Adding and subtracting fractions",es:"Suma y resta de fracciones"},std:"Common Core 5.NF.A.1",ans:(op==="+"?a+b:a-b)/L,
hint:{en:"You can only "+(op==="+"?"add":"subtract")+" pieces of the same size. What number do "+d1+" and "+d2+" both go into?",es:"Solo puedes "+(op==="+"?"sumar":"restar")+" trozos del mismo tamaño. ¿En qué número caben "+d1+" y "+d2+"?"},
step:{en:"Use "+L+": "+n1+"/"+d1+" = "+a+"/"+L+" and "+n2+"/"+d2+" = "+b+"/"+L+". Now "+(op==="+"?"add":"subtract")+" the tops.",es:"Usa "+L+": "+n1+"/"+d1+" = "+a+"/"+L+" y "+n2+"/"+d2+" = "+b+"/"+L+". Ahora "+(op==="+"?"suma":"resta")+" los numeradores."},
sim:{q:{en:p[0]+"/"+p[1]+" + "+p[2]+"/"+p[3],es:p[0]+"/"+p[1]+" + "+p[2]+"/"+p[3]},ans:(p[0]*L2/p[1]+p[2]*L2/p[3])/L2}}}
const tp=t.replace(/por ?ciento|percent/g,"%").replace(/\s+/g,"");
if((m=tp.match(/(\d+(?:[.,]\d+)?)%(?:of|de|del)(\d+(?:[.,]\d+)?)/))){const p=+m[1].replace(",","."),n=+m[2].replace(",",".");
const p2=pick(R,[10,20,25,30,40,75].filter(v=>v!==p)),n2=pick(R,[40,60,80,120,200]);
return{tp:{en:"Percent of a number",es:"Porcentaje de un número"},std:"Common Core 6.RP.A.3c",ans:p*n/100,
hint:{en:'Percent means "out of 100". What is 1% of '+dec(n,"en")+"?",es:'Por ciento significa "de cada 100". ¿Cuánto es el 1 % de '+dec(n,"es")+"?"},
step:{en:"1% of "+dec(n,"en")+" is "+dec(n/100,"en")+". You need "+dec(p,"en")+" of those.",es:"El 1 % de "+dec(n,"es")+" es "+dec(n/100,"es")+". Necesitas "+dec(p,"es")+" de esos."},
sim:{q:{en:"What is "+p2+"% of "+n2+"?",es:"¿Cuánto es el "+p2+" % de "+n2+"?"},ans:p2*n2/100}}}
if((m=t.match(/(\d+(?:[.,]\d+)?)\s*(km|kilometers?|kilómetros?|miles?|mi|meters?|metros?|m)\b[^\d]*?(\d+(?:[.,]\d+)?)\s*(hours?|horas?|hrs?|h|minutes?|minutos?|min|seconds?|segundos?|s)\b/))){
const d=+m[1].replace(",","."),tt=+m[3].replace(",",".");if(!tt)return null;
const du=/^k/.test(m[2])?"km":/^m(i|ile)/.test(m[2])?"mi":"m",tu=/^(h|hr)/.test(m[4])?"h":/^min/.test(m[4])?"min":"s",TU={h:["hours","horas"],min:["minutes","minutos"],s:["seconds","segundos"]}[tu];
const s2=pick(R,[[90,3],[150,3],[240,4],[100,2],[300,5]].filter(v=>v[0]!==d));
return{tp:{en:"Speed (motion)",es:"Rapidez (movimiento)"},std:"Middle school physical science",ans:d/tt,
hint:{en:"Speed is how far you go in one unit of time. Which number is the distance, and which is the time?",es:"La rapidez es cuánta distancia recorres en una unidad de tiempo. ¿Qué número es la distancia y cuál es el tiempo?"},
step:{en:"Speed = distance ÷ time, so divide "+dec(d,"en")+" "+du+" by "+dec(tt,"en")+" "+TU[0]+". The answer is in "+du+" per "+TU[0].replace(/s$/,"")+".",
es:"Rapidez = distancia ÷ tiempo, así que divide "+dec(d,"es")+" "+du+" entre "+dec(tt,"es")+" "+TU[1]+". La respuesta queda en "+du+" por "+TU[1].replace(/s$/,"")+"."},
sim:{q:{en:"A cyclist rides "+s2[0]+" km in "+s2[1]+" hours. What is the speed in km per hour?",es:"Una ciclista recorre "+s2[0]+" km en "+s2[1]+" horas. ¿Cuál es su rapidez en km por hora?"},ans:s2[0]/s2[1]}}}
if(/hypotenuse|hipotenusa/.test(t)&&(m=t.match(/(\d+(?:[.,]\d+)?)\D+?(\d+(?:[.,]\d+)?)/))){const a=+m[1].replace(",","."),b=+m[2].replace(",","."),s=a*a+b*b;
const T2=pick(R,[[5,12],[8,15],[9,12],[3,4],[12,16]].filter(v=>v[0]!==a));
return{tp:{en:"Right triangles",es:"Triángulos rectángulos"},std:"Common Core 8.G.B.7",ans:Math.sqrt(s),
hint:{en:"In a right triangle, the squares of the two legs add up to the square of the longest side, the hypotenuse.",es:"En un triángulo rectángulo, los cuadrados de los dos catetos suman el cuadrado del lado más largo, la hipotenusa."},
step:{en:dec(a,"en")+"² + "+dec(b,"en")+"² = "+dec(a*a,"en")+" + "+dec(b*b,"en")+" = "+dec(s,"en")+". What number squared makes "+dec(s,"en")+"?",
es:dec(a,"es")+"² + "+dec(b,"es")+"² = "+dec(a*a,"es")+" + "+dec(b*b,"es")+" = "+dec(s,"es")+". ¿Qué número al cuadrado da "+dec(s,"es")+"?"},
sim:{q:{en:"A right triangle has legs "+T2[0]+" and "+T2[1]+". How long is the hypotenuse?",es:"Un triángulo rectángulo tiene catetos de "+T2[0]+" y "+T2[1]+". ¿Cuánto mide la hipotenusa?"},ans:Math.hypot(T2[0],T2[1])}}}
return null}
/* ---------- the hint ladder */
function ask(root){
let L="en",P=null,Q="",lvl=-1,cur=-1,tries=0,own=0,simOk=!1,photo=!1;
const ta=$("textarea",root),out=$("[data-ask-out]",root),R=$$(".tc-rung",root);
const u=()=>UI[L],press=x=>$$("[data-ask-sample],[data-ask-photo]",root).forEach(c=>c.setAttribute("aria-pressed",c===x));
function i18n(){$$("[data-i18n]",root).forEach(e=>{const k=e.dataset.i18n;if(u()[k])e.textContent=u()[k]});ta.placeholder=u().ph;
$$("[data-ask-lang]",root).forEach(b=>b.setAttribute("aria-pressed",b.dataset.askLang===L));R.forEach((b,i)=>{$(".tc-rung__t",b).textContent=u().rungs[i]})}
function rungs(){R.forEach((b,i)=>{b.disabled=i>lvl;b.classList.toggle("is-on",i<=lvl);b.classList.toggle("is-done",i===3&&own===2);if(i===cur)b.setAttribute("aria-current","step");else b.removeAttribute("aria-current")})}
function anim(){if(RM)return;root.classList.remove("is-anim");void root.offsetWidth;root.classList.add("is-anim")}
function head(i){return'<p class="tc-k">'+esc(u().rung)+" "+(i+1)+" · "+esc(u().rungs[i])+" · "+esc(P.tp[L])+"</p>"}
function tryBox(id,lab){return'<div class="tc-try"><label class="vh" for="'+id+'">'+esc(lab)+'</label><input class="tc-num" id="'+id+'" type="text" autocomplete="off" inputmode="text" placeholder="'+esc(u().ans)+'"><button type="button" class="tc-btn2" data-ask-check>'+esc(u().check)+"</button></div><div data-ask-fb></div>"}
function render(i){cur=i;rungs();let h="";
if(i===0)h=head(0)+"<h3>"+esc(P.hint[L])+'</h3><p class="tc-q">'+esc(Q)+"</p>"+(photo?'<p class="tc-mute">'+esc(u().photo)+"</p>":"")+'<p class="tc-mute">'+esc(u().std)+": "+esc(P.std)+'</p><button type="button" class="mv-btn mv-btn--acc tc-next-b" data-ask-next>'+esc(u().tried)+"</button>";
else if(i===1)h=head(1)+"<h3>"+esc(P.step[L])+'</h3><p class="tc-q">'+esc(Q)+'</p><button type="button" class="mv-btn mv-btn--acc tc-next-b" data-ask-next>'+esc(u().showSim)+"</button>";
else if(i===2)h=head(2)+"<h3>"+esc(u().trySim)+'</h3><p class="tc-q">'+esc(P.sim.q[L])+"</p>"+tryBox("ask-sim-"+root.dataset.n,u().ans)+(tries||simOk?'<button type="button" class="tc-btn2 tc-next-b" data-ask-next>'+esc(u().checkOwn)+"</button>":"");
else h=head(3)+"<h3>"+esc(u().ownQ)+'</h3><p class="tc-q">'+esc(Q)+"</p>"+tryBox("ask-own-"+root.dataset.n,u().ans);
out.innerHTML=h;anim()}
function msg(cls,t){out.innerHTML='<p class="'+cls+'" role="alert">'+esc(t)+"</p>";cur=-1;rungs()}
function start(q,ph){Q=q.trim();photo=!!ph;lvl=-1;tries=0;own=0;simOk=!1;ta.removeAttribute("aria-invalid");
if(!Q){P=null;ta.setAttribute("aria-invalid","true");msg("tc-err",u().errEmpty);ta.focus();return}
P=solve(Q);if(!P){msg("tc-err",u().unrec);return}lvl=0;render(0)}
function check(){const inp=$(".tc-num",out),fb=$("[data-ask-fb]",out),v=num(inp.value);
if(isNaN(v)){inp.setAttribute("aria-invalid","true");fb.innerHTML='<p class="tc-fb tc-fb--no">'+esc(u().bad)+"</p>";return}inp.removeAttribute("aria-invalid");
if(cur===2){tries++;const ok=near(v,P.sim.ans);simOk=simOk||ok;if(lvl<3)lvl=3;const keep=inp.value;render(2);$(".tc-num",out).value=keep;
$("[data-ask-fb]",out).innerHTML='<p class="tc-fb '+(ok?"tc-fb--ok":"tc-fb--no")+'">'+esc(ok?u().okSim:u().noSim)+"</p>"}
else{const ok=near(v,P.ans);if(ok)own=2;else own=own<1?1:own;tries++;rungs();
fb.innerHTML='<p class="tc-fb '+(ok?"tc-fb--ok":"tc-fb--no")+'">'+esc(ok?u().okOwn:u().noOwn)+"</p>"+(!ok&&tries>3?'<p class="tc-mute">'+esc(u().teacher)+"</p>":"")}}
root.addEventListener("click",e=>{const b=e.target.closest("button");if(!b||!root.contains(b))return;
if(b.matches("[data-ask-go]"))start(ta.value);
else if(b.dataset.askSample!=null){press(b);ta.value=b.dataset.askSample;start(b.dataset.askSample)}
else if(b.dataset.askPhoto!=null){press(b);ta.value=b.dataset.askPhoto;start(b.dataset.askPhoto,1)}
else if(b.matches("[data-ask-replay]")){press(null);if(!P){const s=$("[data-ask-sample]",root);ta.value=s.dataset.askSample}start(ta.value,photo)}
else if(b.dataset.askLang){L=b.dataset.askLang;i18n();if(P&&cur>=0)render(cur);else if(!P&&!out.querySelector(".tc-err"))out.innerHTML='<p class="tc-mute">'+esc(u().empty)+"</p>";else if(!P)start(ta.value)}
else if(b.matches("[data-ask-next]")){const n=Math.min(cur+1,3);if(n>lvl)lvl=n;render(n);const f=$(".tc-num",out);if(f)f.focus()}
else if(b.matches("[data-ask-check]"))check();
else if(b.classList.contains("tc-rung")&&!b.disabled)render(+b.dataset.rung)});
root.addEventListener("keydown",e=>{if(e.target.classList.contains("tc-num")&&e.key==="Enter"){e.preventDefault();check();return}
if(e.target===ta&&e.key==="Enter"&&!e.shiftKey){e.preventDefault();start(ta.value);return}
const b=e.target.closest(".tc-rung");if(!b)return;const i=+b.dataset.rung,k=e.key;let n=-1;
if(k==="ArrowUp"||k==="ArrowRight")n=i+1;else if(k==="ArrowDown"||k==="ArrowLeft")n=i-1;else return;e.preventDefault();
if(n>=0&&n<=lvl){render(n);R[n].focus()}});
i18n()}
/* ---------- practice set on the sample lesson */
function practice(root){const es=()=>root.dataset.plang==="es";
root.addEventListener("tc:lang",()=>{root.querySelectorAll("[data-en]").forEach(e=>{e.textContent=e.dataset[es()?"es":"en"]});root.lang=es()?"es":"en";$$(".tc-pq__o",root).forEach(o=>{o.textContent="";o.className="tc-pq__o"})});
$$(".tc-pq",root).forEach(li=>{const inp=$("input",li),o=$(".tc-pq__o",li),a=num(li.dataset.ans),hint=()=>li.dataset[es()?"hintEs":"hintEn"];
const say=(t,c)=>{o.textContent=t;o.className="tc-pq__o"+(c?" "+c:"")};
const go=()=>{const v=num(inp.value);if(isNaN(v)){inp.setAttribute("aria-invalid","true");say(es()?"Escribe una fracción, por ejemplo 5/12.":"Type a fraction, such as 5/12.","is-no");return}
inp.removeAttribute("aria-invalid");if(near(v,a))say(es()?"Correcto.":"Right.","is-ok");else say((es()?"Todavía no. Pista: ":"Not yet. Hint: ")+hint(),"is-no")};
$("[data-pq-check]",li).addEventListener("click",go);inp.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();go()}});
$("[data-pq-hint]",li).addEventListener("click",()=>say((es()?"Pista: ":"Hint: ")+hint()))})}
/* ---------- language tabs */
function sample(root){const t=$$("[role=tab]",root);function sel(i,f){t.forEach((b,j)=>{const on=j===i;b.setAttribute("aria-selected",on);b.tabIndex=on?0:-1;$("#"+b.getAttribute("aria-controls")).hidden=!on;if(on&&f)b.focus();if(on&&b.dataset.lang)$$("[data-tc=practice]",root).forEach(p=>{p.dataset.plang=b.dataset.lang;p.dispatchEvent(new Event("tc:lang"))})})}
t.forEach((b,i)=>{b.addEventListener("click",()=>sel(i));b.addEventListener("keydown",e=>{if(e.key==="ArrowRight"||e.key==="ArrowLeft"){e.preventDefault();sel((i+(e.key==="ArrowRight"?1:t.length-1))%t.length,1)}})})}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-tc=ask]").forEach((r,i)=>{r.dataset.n=i;ask(r)});$$("[data-tc=practice]").forEach(practice);$$("[data-tc=sample]").forEach(sample)}
