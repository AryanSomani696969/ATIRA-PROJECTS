/* Marks the step of the application the visitor is reading. */
(function () {
  'use strict';
  var items = [].slice.call(document.querySelectorAll('.ov-steps li'));
  var parts = ['ap-g1', 'ap-g2', 'ap-g3', 'ap-g4'].map(function (id) { return document.getElementById(id); });
  if (items.length < 4 || parts.some(function (p) { return !p; }) || !('IntersectionObserver' in window)) return;
  var seen = {};
  function mark(k) {
    items.forEach(function (li, i) {
      if (i === k) {
        li.classList.add('is-on');
        li.setAttribute('aria-current', 'step');
      } else {
        li.classList.remove('is-on');
        li.removeAttribute('aria-current');
      }
    });
  }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { seen[e.target.id] = e.isIntersecting ? e.intersectionRatio : 0; });
    var best = 0, at = -1;
    parts.forEach(function (p, i) {
      var v = seen[p.id] || 0;
      if (v > best) { best = v; at = i; }
    });
    if (at >= 0) mark(at);
  }, { rootMargin: '-15% 0px -45% 0px', threshold: [0, 0.1, 0.25, 0.5, 1] });
  parts.forEach(function (p) { io.observe(p); });
})();
