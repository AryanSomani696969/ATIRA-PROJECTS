/* Rfqsherpa page tools. Everything runs offline in the browser; nothing typed or clicked here leaves the page.
   [data-rq=qc]     Quote Comparer: two synthetic RFQs, three supplier quotes each, rates in, landed-cost ranking, flags and negotiation points out
   [data-rq=lc]     landed-cost calculator for one quote, Incoterm aware
   [data-rq=src]    source highlights: select an extracted value, see the line it came from
   [data-rq=morph]  messy quotes to one table (home and Collect Quotes)
   DATA is written by make.py from sample.py, the same synthetic figures the page copy uses. */
const DATA={"settings":{"fx":1.08,"coc":8.0,"outlier":25},"rfqs":[{"id":"RFQ-2611-014","title":"Bracket kit for a conveyor frame","commodity":"Fabricated metal parts","ship":"Plant 2, Dayton, Ohio","need":8,"lines":[["BRK-2210-A","Mounting bracket, laser cut, 3 mm A36, bent, powder coat black",2400,"ea"],["PLT-3302","Base plate, 10 mm A36, 4 holes 13 mm",600,"ea"],["PIN-0417","Hinge pin 12 x 80 mm, zinc plated",2400,"ea"],["GSK-118","EPDM gasket 2 mm, die cut",1200,"ea"]],"tooling_label":"Bend die for BRK-2210-A","quotes":[{"k":"A","sup":"Supplier A","where":"Fabricator, Ohio","fmt":"PDF","cur":"USD","inc":"FCA supplier dock","terms":30,"lead":6,"freight":640,"freight_note":"Freight estimate on the quote","duty":0,"tooling":2900,"p":{"BRK-2210-A":4.85,"PLT-3302":18.4,"PIN-0417":0.92,"GSK-118":0.38},"per":{},"raw":["QUOTATION Q-55817    Page 1 of 2","Item  Part no.      Qty    Unit   Price","10    BRK-2210-A    2400   EA     4.85","20    PLT-3302       600   EA    18.40","30    PIN-0417      2400   EA     0.92","40    GSK-118       1200   EA     0.38","Tooling (bend die), one time     2,900.00","FCA our dock. Freight est. 640.00 prepay and add.","Terms Net 30. Lead time 6 weeks ARO."]},{"k":"B","sup":"Supplier B","where":"Fabricator, Monterrey, Mexico","fmt":"Excel","cur":"USD","inc":"DAP Dayton","terms":60,"lead":7,"freight":0,"freight_note":"Included in DAP price","duty":2.5,"tooling":4800,"p":{"BRK-2210-A":412.0,"PLT-3302":16.9,"PIN-0417":68.0},"per":{"BRK-2210-A":100,"PIN-0417":100},"raw":[["Part","Qty","UoM","Price","Per"],["BRK-2210-A","2,400","PC","412.00","100"],["PLT-3302","600","PC","16.90","1"],["PIN-0417","2,400","PC","68.00","100"],["GSK-118","","","n/q",""],["Tooling","1","LOT","4,800.00","1"],["Incoterm","DAP Dayton","","",""],["Payment","Net 60","","",""]]},{"k":"C","sup":"Supplier C","where":"Fabricator, Baden-Wuerttemberg, Germany","fmt":"Email","cur":"EUR","inc":"EXW","terms":30,"lead":10,"freight":3950,"freight_note":"Your estimate: export clearance, ocean LCL, inland","duty":3.0,"tooling":1500,"p":{"BRK-2210-A":3.7,"PLT-3302":15.2,"PIN-0417":0.64,"GSK-118":0.31},"per":{},"raw":["Hello, thank you for the RFQ, here our offer:","BRK-2210-A  2.400 Stk.  3,70 EUR/Stk.","PLT-3302  600 Stk.  15,20 EUR","PIN-0417  2.400 Stk.  0,64 EUR","GSK-118  1.200 Stk.  0,31 EUR","Biegewerkzeug (bend die) 1.500,00 EUR einmalig","Delivery EXW our works, approx. 10 weeks.","Payment 30 days net. Best regards"]}]},{"id":"RFQ-2611-021","title":"Machined housings, 6061-T6 aluminum","commodity":"Machined components","ship":"Plant 1, Greenville, South Carolina","need":10,"lines":[["HSG-5520","Housing, CNC 6061-T6, clear anodize Type II",800,"ea"],["CVR-5521","Cover plate, CNC 6061-T6, clear anodize Type II",800,"ea"],["INS-0904","Threaded insert M6, stainless",3200,"ea"]],"tooling_label":"Fixtures and programming (NRE)","quotes":[{"k":"A","sup":"Supplier A","where":"Machine shop, Michigan","fmt":"Excel","cur":"USD","inc":"FCA supplier dock","terms":45,"lead":5,"freight":420,"freight_note":"Freight estimate on the quote","duty":0,"tooling":1200,"p":{"HSG-5520":38.5,"CVR-5521":9.2,"INS-0904":0.42},"per":{},"raw":[["Part","Qty","UoM","Price","Per"],["HSG-5520","800","EA","38.50","1"],["CVR-5521","800","EA","9.20","1"],["INS-0904","3,200","EA","0.42","1"],["NRE","1","LOT","1,200.00","1"],["Freight est.","","","420.00",""],["Terms","Net 45","","",""]]},{"k":"B","sup":"Supplier B","where":"Machining plant, Taichung, Taiwan","fmt":"PDF","cur":"USD","inc":"FOB Taichung port","terms":30,"lead":9,"freight":2600,"freight_note":"Your estimate: ocean LCL, customs entry, inland","duty":2.5,"tooling":2400,"p":{"HSG-5520":29.8,"CVR-5521":7.1,"INS-0904":310.0},"per":{"INS-0904":1000},"raw":["PROFORMA QUOTATION  No. TQ-2611-338","HSG-5520   800 PCS   USD 29.80","CVR-5521   800 PCS   USD 7.10","INS-0904   3,200 PCS   USD 310.00 / 1000 PCS","Fixture and CNC program charge  USD 2,400","Price term FOB Taichung. T/T 30 days after B/L.","Lead time 9 weeks after drawing approval."]},{"k":"C","sup":"Supplier C","where":"Machine shop, Texas","fmt":"Email","cur":"USD","inc":"DAP Greenville","terms":30,"lead":6,"freight":0,"freight_note":"Included in DAP price","duty":0,"tooling":900,"dev":{"HSG-5520":"Quoted without anodize","CVR-5521":"Quoted without anodize"},"p":{"HSG-5520":34.6,"CVR-5521":8.8,"INS-0904":0.45},"per":{},"raw":["Hi, pricing below for your housings.","HSG-5520 x800 @ $34.60 (as machined, anodize by others)","CVR-5521 x800 @ $8.80 (same)","INS-0904 x3200 @ $0.45 installed","Fixture charge $900 one time.","Delivered to Greenville, 6 weeks. Net 30."]}]}]};
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const RM=matchMedia("(prefers-reduced-motion: reduce)");
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const usd=(v,d=0)=>{if(Math.abs(v)<.005)v=0;return(v<0?"-$":"$")+Math.abs(v).toLocaleString("en-US",{minimumFractionDigits:d,maximumFractionDigits:d})};
function num(s){s=String(s).trim().replace(/\s/g,"");if(!s)return NaN;
 if(/^\d{1,3}(,\d{3})+(\.\d+)?$/.test(s))s=s.replace(/,/g,"");else if(/^\d+,\d{1,2}$/.test(s))s=s.replace(",",".");
 return /^-?\d*\.?\d+$/.test(s)?Number(s):NaN}
const median=a=>{a=[...a].sort((x,y)=>x-y);const n=a.length;return n%2?a[(n-1)/2]:(a[n/2-1]+a[n/2])/2};
const pct=v=>Math.round(v)+"%";

/* ---------- landed cost, same rules as sample.py */
function landed(rfq,o){
 const rate=q=>q.cur==="EUR"?o.fx:1,unit={};
 rfq.quotes.forEach(q=>rfq.lines.forEach(([pn])=>{if(pn in q.p)unit[q.k+pn]=q.p[pn]/(q.per[pn]||1)*rate(q)}));
 const tools=rfq.quotes.map(q=>q.tooling*rate(q)),tm=median(tools);
 return rfq.quotes.map((q,i)=>{let goods=0,miss=0;const missing=[],outl=[];
  rfq.lines.forEach(([pn,desc,qty])=>{const u=unit[q.k+pn],others=rfq.quotes.filter(x=>x.k!==q.k&&(x.k+pn) in unit).map(x=>unit[x.k+pn]);
   if(u===undefined){const f=others.length?Math.max(...others)*qty:0;miss+=f;missing.push([pn,f]);return}
   goods+=u*qty;const all=rfq.quotes.filter(x=>(x.k+pn) in unit).map(x=>unit[x.k+pn]),m=median(all);
   if(all.length>2&&m&&(u-m)/m*100>o.out)outl.push([pn,u,m])});
  const tool=tools[i],duty=goods*o.duty[i]/100,freight=o.freight[i],terms=-goods*o.coc/100*(q.terms-30)/365;
  return{q,goods,duty,tool,tm,toolOut:tm?(tool-tm)/tm*100>o.out:false,freight,terms,miss,missing,outl,total:goods+duty+tool+freight+terms+miss,late:q.lead>rfq.need,unit}})}

function points(rfq,res,o){const out=[];const maxT=Math.max(...res.map(r=>r.q.terms));
 res.forEach(r=>{const s=r.q.sup;
  if(r.toolOut)out.push([s,`Tooling ${usd(r.tool)} is ${pct((r.tool-r.tm)/r.tm*100)} above the median of the quotes (${usd(r.tm)}). Ask for a cost breakdown, or for it to be amortized into the piece price.`]);
  r.missing.forEach(([pn,f])=>out.push([s,`${pn} was not quoted. Ask for a price or a written no-quote. The comparison carries ${usd(f)} until then.`]));
  r.outl.forEach(([pn,u,m])=>out.push([s,`${pn} at ${usd(u,2)} is ${pct((u-m)/m*100)} above the median of ${usd(m,2)}. Ask whether the spec was read the same way, and quote the median back.`]));
  if(r.q.dev)Object.entries(r.q.dev).forEach(([pn,t])=>out.push([s,`${pn}: ${t.toLowerCase()}. The price is not like for like. Ask for the full spec price, or have engineering accept the change before award.`]));
  if(r.q.terms<maxT){const w=res.find(x=>x.q.terms===maxT);out.push([s,`Net ${r.q.terms} against Net ${maxT} from ${w.q.sup}. Net ${maxT} on these goods is worth ${usd(r.goods*o.coc/100*(maxT-r.q.terms)/365)} at ${o.coc}% cost of capital.`])}
  if(r.late)out.push([s,`Lead time ${r.q.lead} weeks against a need of ${rfq.need} weeks. Ask for a split first shipment or an earlier production slot.`]);
  if(r.q.inc==="EXW")out.push([s,`EXW price. Ask for FCA or DAP so the supplier quotes the freight and export clearance.`])});
 return out}

/* ---------- Quote Comparer */
function qc(root){
 const sel=$('[data-qc="rfq"]',root),tabs=$("[data-qc-tabs]",root),doc=$("[data-qc-doc]",root),duty=$("[data-qc-duty]",root),err=$("[data-qc-err]",root),
  empty=$("[data-qc-empty]",root),res=$("[data-qc-res]",root),go=$("[data-qc-go]",root);
 let open=0,done=false;
 const rfq=()=>DATA.rfqs[+sel.value||0];
 function drawTabs(){const r=rfq();tabs.innerHTML=r.quotes.map((q,i)=>`<button type="button" class="rq-qtab" data-i="${i}" aria-pressed="${i===open}"><b>${esc(q.sup)}</b><span>${esc(q.fmt)} · ${esc(q.cur)} · ${esc(q.inc)}</span></button>`).join("");
  $$(".rq-qtab",tabs).forEach(b=>b.addEventListener("click",()=>{open=+b.dataset.i;drawTabs();drawDoc()}))}
 function drawDoc(){const q=rfq().quotes[open];let body;
  if(q.fmt==="Excel")body=`<div class="rq-xlw"><table class="rq-xl" aria-label="Spreadsheet quote from ${esc(q.sup)}">${q.raw.map(r=>"<tr>"+r.map(c=>`<td>${esc(c)}</td>`).join("")+"</tr>").join("")}</table></div>`;
  else body=`<div class="rq-doc__mono${q.fmt==="Email"?" rq-doc__mono--em":""}">${q.raw.map(t=>`<span>${esc(t)}</span>`).join("")}</div>`;
  doc.innerHTML=`<article class="rq-doc rq-doc--${{PDF:"pdf",Excel:"xl",Email:"em"}[q.fmt]}"><p class="rq-doc__h"><b>${esc(q.fmt)}</b>${esc(q.sup)} · ${esc(q.where)} · Synthetic</p>${body}</article>`}
 function drawDuty(){const r=rfq();duty.innerHTML=`<p class="rq-qc__ti">Freight and duty per supplier<span>Sample rates</span></p><div class="rq-qc__dg">`+r.quotes.map((q,i)=>{
   const inPrice=/^DAP|^DDP/.test(q.inc);
   return `<div class="rq-qc__dr"><p><b>${esc(q.sup)}</b><span>${esc(q.inc)} · Net ${q.terms} · ${q.lead} weeks</span></p>
   <div class="fld"><label for="qc-fr-${i}">Freight you pay</label><div class="rq-inp"><input class="inp" id="qc-fr-${i}" type="text" inputmode="decimal" value="${q.freight}" data-qc-fr="${i}"${inPrice?" disabled":""} aria-describedby="qc-err qc-fr-${i}-h"><span>USD</span></div><p class="rq-hint" id="qc-fr-${i}-h">${esc(q.freight_note)}</p></div>
   <div class="fld"><label for="qc-du-${i}">Duty rate</label><div class="rq-inp"><input class="inp" id="qc-du-${i}" type="text" inputmode="decimal" value="${q.duty}" data-qc-du="${i}" aria-describedby="qc-err"><span>%</span></div></div></div>`}).join("")+"</div>";
  $$("input",duty).forEach(x=>x.addEventListener("input",live))}
 function read(){const bad=[];const get=(el,lo,hi,name)=>{const v=num(el.value);const ok=!isNaN(v)&&v>=lo&&v<=hi;el.setAttribute("aria-invalid",ok?"false":"true");if(!ok)bad.push(name);return v};
  const o={fx:get($('[data-qc="fx"]',root),.2,5,"EUR to USD rate (0.2 to 5)"),coc:get($('[data-qc="coc"]',root),0,40,"cost of capital (0 to 40%)"),out:get($('[data-qc="out"]',root),1,300,"outlier threshold (1 to 300%)"),freight:[],duty:[]};
  rfq().quotes.forEach((q,i)=>{o.freight.push(get($(`[data-qc-fr="${i}"]`,duty),0,1e6,`freight for ${q.sup}`));o.duty.push(get($(`[data-qc-du="${i}"]`,duty),0,100,`duty rate for ${q.sup} (0 to 100%)`))});
  return bad.length?{bad}:o}
 function compare(anim){const o=read();
  if(o.bad){err.textContent="Check "+o.bad.join(", ")+". Use numbers only, for example 1.08 or 2,400.";res.hidden=true;empty.hidden=false;
   empty.innerHTML="<p><b>Nothing compared.</b> Fix the highlighted inputs and press Compare again.</p>";return}
  err.textContent="";const r=rfq(),R=landed(r,o),order=R.map((x,i)=>i).sort((a,b)=>R[a].total-R[b].total),w=order[0];
  const cheapU=R.map((x,i)=>i).sort((a,b)=>(R[a].goods+R[a].miss)-(R[b].goods+R[b].miss))[0],flags=R.reduce((n,x)=>n+x.missing.length+x.outl.length+(x.toolOut?1:0)+(x.late?1:0)+(x.q.dev?Object.keys(x.q.dev).length:0),0);
  const cell=(f,cls="")=>R.map((x,i)=>`<td class="rq-num${i===w?" is-win":""}${cls}">${f(x,i)}</td>`).join("");
  const fl=t=>`<span class="rq-flag rq-flag--warn">${esc(t)}</span>`;
  const rows=[["Goods, quoted lines",cell(x=>usd(x.goods))],
   ["Missing lines, carried",cell(x=>x.missing.length?usd(x.miss)+" "+fl("Missing "+x.missing.map(m=>m[0]).join(", ")):"$0")],
   ["Duty on goods",cell((x,i)=>`${usd(x.duty)} <small>${o.duty[i]}%</small>`)],
   ["Tooling, one time",cell(x=>usd(x.tool)+(x.toolOut?" "+fl(pct((x.tool-x.tm)/x.tm*100)+" over median"):""))],
   ["Freight you pay",cell(x=>usd(x.freight))],
   ["Payment terms vs Net 30",cell(x=>`${usd(x.terms)} <small>Net ${x.q.terms}</small>`)],
   ["Landed cost",cell(x=>`<b>${usd(x.total)}</b>`),"rq-tot"],
   ["Rank",cell((x,i)=>(order.indexOf(i)+1)+(i===w?' <span class="rq-summit">Lowest landed cost</span>':""))],
   [`Lead time <small>need ${r.need} weeks</small>`,cell(x=>x.q.lead+" weeks"+(x.late?" "+fl("Past need date"):""))],
   ["Line flags",cell(x=>{const a=x.outl.map(([pn,u,m])=>fl(pn+" "+pct((u-m)/m*100)+" over median"));if(x.q.dev)Object.keys(x.q.dev).forEach(pn=>a.push(fl(pn+" deviation")));return a.join(" ")||"None"})]];
  const head=R.map((x,i)=>`<th scope="col" class="${i===w?"is-win":""}"><span>${esc(x.q.sup)}</span><small>${esc(x.q.fmt)} · ${esc(x.q.inc)}</small></th>`).join("");
  const lines=r.lines.map(([pn,d,qty])=>`<tr><th scope="row"><span class="rq-pn">${pn}</span><small>${esc(d)} · ${qty.toLocaleString("en-US")} ea</small></th>${R.map((x,i)=>{const u=x.unit[x.q.k+pn];return `<td class="rq-num${i===w?" is-win":""}">${u===undefined?fl("not quoted"):usd(u,2)}</td>`}).join("")}</tr>`).join("");
  const pts=points(r,R,o);
  const diff=R[order[1]].total-R[w].total;
  res.innerHTML=`<p class="rq-qc__sum"><b>${esc(R[w].q.sup)}</b> has the lowest landed cost, ${usd(R[w].total)}, ${usd(diff)} below ${esc(R[order[1]].q.sup)}. ${cheapU!==w?`The lowest unit prices came from ${esc(R[cheapU].q.sup)}.`:"It also has the lowest unit prices."} ${flags} flag${flags===1?"":"s"} to resolve.</p>
  <div class="mv-pscroll rq-tw" role="region" aria-label="Aligned line items" tabindex="0"><table class="rq-tab rq-tab--lines"><caption>Lines aligned, USD per each</caption><thead><tr><th scope="col">Line</th>${head}</tr></thead><tbody>${lines}</tbody></table></div>
  <div class="mv-pscroll rq-tw" role="region" aria-label="Landed-cost comparison" tabindex="0"><table class="rq-tab rq-tab--lc"><caption>Landed cost, USD</caption><thead><tr><th scope="col">Cost row</th>${head}</tr></thead><tbody>${rows.map(([a,b,c])=>`<tr class="${c||""}"><th scope="row">${a}</th>${b}</tr>`).join("")}</tbody></table></div>
  <div class="rq-nego rq-nego--tool"><p class="rq-qc__ti">Negotiation points<span>Drafted from the figures above</span></p><ol class="rq-nego__l">${pts.map(([s,t])=>`<li><b>${esc(s)}</b><p>${esc(t)}</p></li>`).join("")}</ol></div>`;
  empty.hidden=true;res.hidden=false;done=true;
  if(anim&&!RM.matches){$$("tbody tr",res).forEach((tr,i)=>{tr.classList.add("rq-in");tr.style.animationDelay=(i*45)+"ms"})}}
 function live(){if(done)compare(false)}
 function reset(){sel.value="0";$('[data-qc="fx"]',root).value="1.08";$('[data-qc="coc"]',root).value="8";$('[data-qc="out"]',root).value="25";open=0;done=false;
  $$("[aria-invalid]",root).forEach(x=>x.setAttribute("aria-invalid","false"));err.textContent="";res.hidden=true;empty.hidden=false;
  empty.innerHTML="<p><b>No comparison yet.</b> Open the quotes if you like, then press Compare. Lines are aligned, freight, duty and terms are added and flags are raised.</p>";drawTabs();drawDoc();drawDuty()}
 sel.addEventListener("change",()=>{open=0;drawTabs();drawDoc();drawDuty();live()});
 $$('[data-qc="fx"],[data-qc="coc"],[data-qc="out"]',root).forEach(x=>x.addEventListener("input",live));
 go.addEventListener("click",()=>compare(true));$("[data-qc-reset]",root).addEventListener("click",reset);
 drawTabs();drawDoc();drawDuty()}

/* ---------- landed-cost calculator */
const INC={EXW:["You pay export clearance, main freight, import entry, duty and delivery.",1,1],FCA:["You pay main freight from the named place, import entry, duty and delivery.",1,1],
 FOB:["You pay ocean freight from the port of loading, import entry, duty and delivery.",1,1],CIF:["You pay unloading and on-carriage from the destination port, import entry and duty.",1,1],
 DAP:["The supplier delivers to your site. You pay unloading, import entry and duty.",0,1],DDP:["The supplier delivers duty paid. You pay unloading only.",0,0],DOM:["Domestic supplier, delivered. No import entry or duty.",0,0]};
function lc(root){const f=k=>$(`[data-lc="${k}"]`,root),rows=$("[data-lc-rows]",root),err=$("[data-lc-err]",root),unit=$("[data-lc-unit]",root),share=$("[data-lc-share]",root),ih=$("[data-lc-inc-h]",root);
 const DEF={qty:"2,400",price:"4.85",per:"1",cur:"USD",fx:"1.08",inc:"FCA",freight:"640",duty:"0",broker:"0",tool:"2,900",terms:"30",coc:"8"};
 function run(){const inc=INC[f("inc").value];ih.textContent=inc[0];
  f("freight").disabled=!inc[1];f("duty").disabled=!inc[2];f("broker").disabled=!inc[2];f("fx").disabled=f("cur").value!=="EUR";
  const bad=[],g=(k,lo,hi,n)=>{const el=f(k);if(el.disabled){el.setAttribute("aria-invalid","false");return 0}const v=num(el.value),ok=!isNaN(v)&&v>=lo&&v<=hi;el.setAttribute("aria-invalid",ok?"false":"true");if(!ok)bad.push(n);return v};
  const qty=g("qty",1,1e8,"quantity (at least 1)"),price=g("price",0,1e7,"quoted price"),fx=f("cur").value==="EUR"?g("fx",.2,5,"EUR to USD rate"):1,fr=g("freight",0,1e7,"freight"),du=g("duty",0,100,"duty rate (0 to 100%)"),
   br=g("broker",0,1e6,"broker fees"),tool=g("tool",0,1e7,"tooling"),days=g("terms",0,365,"payment terms (0 to 365 days)"),coc=g("coc",0,40,"cost of capital (0 to 40%)");
  if(bad.length){err.textContent="Check "+bad.join(", ")+".";rows.innerHTML="";unit.textContent="-";share.textContent="";return}
  err.textContent="";const per=+f("per").value,goods=qty*price/per*fx,duty=goods*du/100,terms=-goods*coc/100*(days-30)/365,total=goods+fr+duty+br+tool+terms;
  const R=[["Goods",goods,`${qty.toLocaleString("en-US")} x ${price} per ${per===1?"each":per.toLocaleString("en-US")}${fx!==1?" x "+fx:""}`],["Freight you pay",fr,inc[1]?"Your estimate":"In the price"],
   ["Duty",duty,inc[2]?du+"% of goods value":"Not yours under this term"],["Customs entry and broker",br,inc[2]?"Your estimate":"Not yours under this term"],["Tooling, one time",tool,"Spread over this order"],
   ["Payment terms vs Net 30",terms,`Net ${days} at ${coc}%`]];
  rows.innerHTML=R.map(([a,v,n])=>`<tr><th scope="row">${a}</th><td class="rq-num">${usd(v)}</td><td>${esc(n)}</td></tr>`).join("")+`<tr class="rq-tot"><th scope="row">Landed cost</th><td class="rq-num"><b>${usd(total)}</b></td><td>Sum of the rows</td></tr>`;
  unit.textContent=usd(total/qty,2);share.textContent=goods>0?`Added costs are ${((total-goods)/goods*100).toFixed(1)}% on top of the quoted price of ${usd(goods/qty,2)} per piece.`:"Enter a price above zero to see the share of added cost."}
 $$("input,select",root).forEach(x=>x.addEventListener(x.tagName==="SELECT"?"change":"input",run));
 $("[data-lc-reset]",root).addEventListener("click",()=>{Object.entries(DEF).forEach(([k,v])=>f(k).value=v);run()});run()}

/* ---------- source highlights */
function src(root){const st=$("[data-src-status]",root);
 $$(".rq-val",root).forEach(b=>b.addEventListener("click",()=>{const on=b.getAttribute("aria-pressed")!=="true";
  $$(".rq-val",root).forEach(x=>x.setAttribute("aria-pressed","false"));$$(".rq-src__ln",root).forEach(l=>l.classList.remove("is-on"));
  if(on){b.setAttribute("aria-pressed","true");const ln=$(`[data-src-line="${b.dataset.src}"]`,root);ln.classList.add("is-on");
   st.textContent=`${b.textContent} was read from line ${+b.dataset.src+1}: "${ln.textContent.replace(/^\d+/,"")}"`}else st.textContent="Select a value to see the line it came from."}))}

/* ---------- messy quotes to one table */
function morph(root){const b=$("[data-morph-btn]",root),lab=$("span",b);
 b.addEventListener("click",()=>{const n=root.dataset.state!=="norm";root.dataset.state=n?"norm":"raw";b.setAttribute("aria-pressed",String(n));lab.textContent=n?"Show the raw quotes":"Line them up"})}

export function boot(){
$$('[data-rq="qc"]').forEach(qc);
$$('[data-rq="lc"]').forEach(lc);
$$('[data-rq="src"]').forEach(src);
$$('[data-rq="morph"]').forEach(morph);
$$(".mv-pscroll").forEach(el=>{const f=()=>{const s=el.scrollWidth>el.clientWidth+2;s?el.setAttribute("tabindex","0"):el.removeAttribute("tabindex")};f();addEventListener("resize",f)});
}
