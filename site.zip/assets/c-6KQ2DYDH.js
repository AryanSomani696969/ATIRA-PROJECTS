/* Caseherald page tools. Everything runs in the browser against a bundled sample corpus of 25 public opinions;
   nothing typed here leaves the page.
   [data-ch=check]  Citation Checker: case name and/or citation -> verified, partly verified or not found, with court,
                    date, opinion author, a short summary and the treatment line
   [data-ch=draft]  Verify a draft: finds every citation in pasted text, checks each one and any quotation before it
   [data-ch=tabs]   sample answer: switch between the opened sources (arrow keys) */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const SC="Supreme Court of the United States",NY="Court of Appeals of New York",C2="U.S. Court of Appeals for the Second Circuit";
/* name, volume, reporter, page, year, court, opinion author, summary, treatment [label, by], passage [pin, text] */
const CASES=[
["Marbury v. Madison",5,"U.S.",137,1803,SC,"Marshall, C.J.","Held that federal courts may review acts of Congress and decline to give effect to those that conflict with the Constitution.",["Followed",""],[177,"It is emphatically the province and duty of the judicial department to say what the law is."]],
["Brown v. Board of Education",347,"U.S.",483,1954,SC,"Warren, C.J.","Held that state laws segregating public schools by race violate the Equal Protection Clause of the Fourteenth Amendment.",["Followed",""],[495,"Separate educational facilities are inherently unequal."]],
["Plessy v. Ferguson",163,"U.S.",537,1896,SC,"Brown, J.","Upheld a state law requiring racially segregated railway cars under the doctrine of separate but equal.",["Overruled","Brown v. Board of Education, 347 U.S. 483 (1954)"]],
["Miranda v. Arizona",384,"U.S.",436,1966,SC,"Warren, C.J.","Held that statements from custodial interrogation are inadmissible unless the suspect was first warned of the right to remain silent and the right to counsel.",["Followed","Dickerson v. United States, 530 U.S. 428 (2000)"]],
["Gideon v. Wainwright",372,"U.S.",335,1963,SC,"Black, J.","Held that the Sixth Amendment right to counsel applies to the states and requires counsel for indigent defendants charged with felonies.",["Followed",""]],
["Betts v. Brady",316,"U.S.",455,1942,SC,"Roberts, J.","Held that due process did not require states to appoint counsel for every indigent felony defendant.",["Overruled","Gideon v. Wainwright, 372 U.S. 335 (1963)"]],
["Roe v. Wade",410,"U.S.",113,1973,SC,"Blackmun, J.","Recognized a constitutional right to choose to have an abortion, subject to state regulation by trimester.",["Overruled","Dobbs v. Jackson Women's Health Organization, 597 U.S. 215 (2022)"]],
["Dobbs v. Jackson Women's Health Organization",597,"U.S.",215,2022,SC,"Alito, J.","Held that the Constitution does not confer a right to abortion and returned the question to the states.",["No negative treatment in the sample set",""]],
["Chevron U.S.A. Inc. v. Natural Resources Defense Council, Inc.",467,"U.S.",837,1984,SC,"Stevens, J.","Held that courts defer to an agency's reasonable reading of an ambiguous statute it administers.",["Overruled","Loper Bright Enterprises v. Raimondo, 603 U.S. 369 (2024)"]],
["Loper Bright Enterprises v. Raimondo",603,"U.S.",369,2024,SC,"Roberts, C.J.","Held that courts must use independent judgment to decide whether an agency acted within its statutory authority, and overruled Chevron.",["No negative treatment in the sample set",""]],
["Mapp v. Ohio",367,"U.S.",643,1961,SC,"Clark, J.","Held that evidence obtained in violation of the Fourth Amendment is inadmissible in state courts.",["Followed",""]],
["Terry v. Ohio",392,"U.S.",1,1968,SC,"Warren, C.J.","Held that an officer may briefly stop a person on reasonable suspicion of crime and pat down outer clothing for weapons if the person may be armed and dangerous.",["Followed","Minnesota v. Dickerson, 508 U.S. 366 (1993)"],[30,"where a police officer observes unusual conduct which leads him reasonably to conclude in light of his experience that criminal activity may be afoot and that the persons with whom he is dealing may be armed and presently dangerous"]],
["Minnesota v. Dickerson",508,"U.S.",366,1993,SC,"White, J.","Held that an officer may seize contraband felt during a lawful pat-down if its identity is immediately apparent.",["No negative treatment in the sample set",""]],
["Illinois v. Wardlow",528,"U.S.",119,2000,SC,"Rehnquist, C.J.","Held that unprovoked flight on noticing the police, in an area of heavy narcotics trafficking, can support reasonable suspicion for a stop.",["No negative treatment in the sample set",""]],
["New York Times Co. v. Sullivan",376,"U.S.",254,1964,SC,"Brennan, J.","Held that a public official suing for defamation over official conduct must prove actual malice.",["Followed",""],[280,"with knowledge that it was false or with reckless disregard of whether it was false or not"]],
["Erie Railroad Co. v. Tompkins",304,"U.S.",64,1938,SC,"Brandeis, J.","Held that federal courts hearing state-law claims apply state substantive law, including the decisions of state courts.",["Followed",""]],
["Swift v. Tyson",41,"U.S.",1,1842,SC,"Story, J.","Held that federal courts could apply general commercial law rather than state court decisions.",["Overruled","Erie Railroad Co. v. Tompkins, 304 U.S. 64 (1938)"]],
["Bowers v. Hardwick",478,"U.S.",186,1986,SC,"White, J.","Upheld a state law criminalizing private consensual sodomy against a due process challenge.",["Overruled","Lawrence v. Texas, 539 U.S. 558 (2003)"]],
["Lawrence v. Texas",539,"U.S.",558,2003,SC,"Kennedy, J.","Held that a state law criminalizing private consensual intimacy between adults of the same sex violates due process.",["Followed",""]],
["Celotex Corp. v. Catrett",477,"U.S.",317,1986,SC,"Rehnquist, J.","Held that a party moving for summary judgment need not negate the other side's claim and may point to an absence of evidence.",["Followed",""]],
["Bell Atlantic Corp. v. Twombly",550,"U.S.",544,2007,SC,"Souter, J.","Held that a complaint must plead enough facts to state a plausible claim, retiring the no-set-of-facts language of Conley.",["Followed",""]],
["Conley v. Gibson",355,"U.S.",41,1957,SC,"Black, J.","Stated that a complaint should not be dismissed unless no set of facts could support the claim.",["Doubted","Bell Atlantic Corp. v. Twombly, 550 U.S. 544 (2007)"]],
["Palsgraf v. Long Island Railroad Co.",248,"N.Y.",339,1928,NY,"Cardozo, C.J.","Held that a duty of care is owed only to plaintiffs within the range of foreseeable harm.",["Followed",""],[344,"The risk reasonably to be perceived defines the duty to be obeyed"]],
["MacPherson v. Buick Motor Co.",217,"N.Y.",382,1916,NY,"Cardozo, J.","Held that a manufacturer owes a duty of care to foreseeable users of a product that is dangerous if negligently made, without privity of contract.",["Followed",""]],
["United States v. Carroll Towing Co.",159,"F.2d",169,1947,C2,"L. Hand, J.","Framed negligence as a comparison of the burden of precautions against the probability and gravity of harm.",["Followed",""]]
].map(a=>({name:a[0],vol:a[1],rep:a[2],page:a[3],year:a[4],court:a[5],judge:a[6],sum:a[7],treat:a[8],pass:a[9]||null}));
const STOP=new Set(["v","vs","versus","the","of","inc","co","corp","corporation","company","ltd","llc","and","a","an","in","re","ex","rel","et","al","united","states","us","for"]);
const norm=s=>s.toLowerCase().replace(/[‘’]/g,"'").replace(/\bversus\b|\bvs\.?(?=\s)/g,"v.").replace(/[^a-z0-9' ]+/g," ").replace(/\s+/g," ").trim();
const toks=s=>norm(s).split(" ").filter(w=>w&&!STOP.has(w)&&!/^\d+$/.test(w));
const REP=/(\d{1,4})\s+(U\.?\s?S\.?|F\.?\s?(?:2d|3d|4th)|F\.?|N\.?\s?Y\.?(?:\s?[23]d)?|Cal\.?(?:\s?[2-5]th)?|S\.?\s?Ct\.?|L\.?\s?Ed\.?(?:\s?2d)?)\s+(\d{1,5})(?:\s*,\s*(\d{1,5}))?/i;
const repKey=r=>r.toUpperCase().replace(/[\s.]/g,"");
function parse(raw){const s=raw.trim(),m=s.match(REP),y=s.match(/\((?:[^()]*\s)?(\d{4})\)|\b(1[789]\d\d|20\d\d)\b(?!.*\d{4})/);
const name=(m?s.slice(0,m.index):s).replace(/[,\s]+$/,"").replace(/^(see also|see|cf\.|but see|accord|e\.g\.,?)\s+/i,"");
return{raw:s,name:/[a-z]/i.test(name)?name:"",cite:m?{vol:+m[1],rep:repKey(m[2]),page:+m[3],pin:m[4]?+m[4]:null,text:m[0]}:null,year:y?+(y[1]||y[2]):null}}
function nameScore(n,c){const a=toks(n),b=new Set(toks(c.name));if(!a.length||!b.size)return 0;let hit=0;a.forEach(w=>{if(b.has(w))hit++});
const parts=norm(n).split(" v ");const first=toks(parts[0]||""),firstHit=first.length&&first.some(w=>b.has(w));return hit/Math.max(a.length,1)*(firstHit?1:.6)}
const full=c=>c.name+", "+c.vol+" "+c.rep+" "+c.page+" ("+(c.court===C2?"2d Cir. ":c.court===NY?"N.Y. ":"")+c.year+")";
function check(raw){const q=parse(raw);if(!q.raw)return{kind:"empty"};if(q.raw.replace(/[^a-z0-9]/gi,"").length<3)return{kind:"short"};
const byCite=q.cite?CASES.find(c=>c.vol===q.cite.vol&&repKey(c.rep)===q.cite.rep&&c.page===q.cite.page):null;
let byName=null,best=0;if(q.name)CASES.forEach(c=>{const s=nameScore(q.name,c);if(s>best){best=s;byName=c}});if(best<.5)byName=null;
const notes=[];let st,c=null;
if(byCite&&(!q.name||byName===byCite||nameScore(q.name,byCite)>=.5)){c=byCite;st="ok";if(q.year&&q.year!==c.year){st="part";notes.push("The year is "+c.year+", not "+q.year+".")}
if(q.cite.pin&&q.cite.pin<c.page){st="part";notes.push("Pinpoint page "+q.cite.pin+" comes before the first page of the opinion ("+c.page+").")}}
else if(byCite&&q.name){c=byCite;st="part";notes.push("This citation belongs to "+c.name+", not to the case name typed.")}
else if(byName&&q.cite){c=byName;st="part";notes.push("The case is real, but the citation is "+c.vol+" "+c.rep+" "+c.page+", not "+q.cite.vol+" "+q.cite.rep.replace("US","U.S.")+" "+q.cite.page+".")}
else if(byName){c=byName;st=q.year&&q.year!==c.year?"part":"ok";if(st==="part")notes.push("The year is "+c.year+", not "+q.year+".")}
else{const outside=q.cite&&!/^(US|F2D|NY)$/.test(q.cite.rep)?"The reporter "+esc(q.cite.text.replace(/^\d+\s+|\s+\d+.*$/g,""))+" is outside the sample corpus.":"";
return{kind:"none",q,outside}}
return{kind:st,c,q,notes}}
const SEAL=s=>'<svg class="ch-seal ch-seal--'+s+'" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path class="ch-seal__r" d="'+ROS+'"/><path class="ch-seal__k" d="'+(s==="ok"?"M7.6 12.3l3 3 5.8-6.4":s==="part"?"M8 12h8":"M9 9l6 6M15 9l-6 6")+'"/></svg>';
const ROS=(()=>{let p=[];for(let i=0;i<28;i++){const a=Math.PI*i/14-Math.PI/2,r=i%2?9.6:11;p.push((12+r*Math.cos(a)).toFixed(1)+" "+(12+r*Math.sin(a)).toFixed(1))}return"M"+p.join("L")+"Z"})();
const LAB={ok:"Verified",part:"Partly verified",none:"Not found"};
function treatHTML(c){const t=c.treat,bad=t[0]==="Overruled"||t[0]==="Doubted";
return'<p class="ch-res__tr'+(bad?" is-bad":"")+'"><span class="ch-lab ch-lab--'+(t[0]==="Overruled"?"bad":bad?"part":"ok")+'">'+esc(t[0])+"</span>"+(t[1]?esc((t[0]==="Followed"?"Applied in ":"By ")+t[1]):"")+
(t[0]==="Overruled"?" <b>Real, but no longer good law.</b>":t[0]==="Doubted"?" <b>Questioned by a later court; read the citing passage.</b>":"")+"</p>"}
function resultHTML(r){if(r.kind==="empty")return'<div class="ch-err" role="alert"><b>Type a case name or a citation.</b> For example: Terry v. Ohio, 392 U.S. 1 (1968).</div>';
if(r.kind==="short")return'<div class="ch-err" role="alert"><b>That is too short to check.</b> Type at least a party name or a volume, reporter and page.</div>';
if(r.kind==="none")return'<div class="ch-res ch-res--none">'+SEAL("no")+'<div><p class="ch-res__s">Not found</p><p class="ch-res__c">'+esc(r.q.raw)+'</p><p>No opinion in the sample corpus matches this case name or citation. '+(r.outside||"")+' Caseherald does not guess a likely case in its place.</p><p class="ch-res__m">If you found this citation in AI-generated text, treat it as unverified until you have read the opinion.</p></div></div>';
const c=r.c;return'<div class="ch-res ch-res--'+r.kind+'">'+SEAL(r.kind)+'<div><p class="ch-res__s">'+LAB[r.kind]+'</p><p class="ch-res__c">'+esc(full(c))+"</p>"+
(r.notes.length?'<ul class="ch-res__n">'+r.notes.map(n=>"<li>"+esc(n)+"</li>").join("")+"</ul>":"")+
'<dl class="ch-res__d"><div><dt>Court</dt><dd>'+esc(c.court)+'</dd></div><div><dt>Decided</dt><dd>'+c.year+'</dd></div><div><dt>Opinion by</dt><dd>'+esc(c.judge)+"</dd></div></dl>"+
'<p class="ch-res__sum">'+esc(c.sum)+"</p>"+treatHTML(c)+"</div></div>"}
function checker(root){const inp=$(".ch-ck__f",root),out=$("[data-ck-out]",root);
const go=()=>{out.innerHTML=resultHTML(check(inp.value));out.classList.remove("is-in");void out.offsetWidth;out.classList.add("is-in")};
$("[data-ck-go]",root).addEventListener("click",go);inp.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();go()}});
$$("[data-ex]",root).forEach(b=>b.addEventListener("click",()=>{inp.value=b.dataset.ex;go();inp.focus()}))}
/* ---------- draft verifier */
const NAMEB=/((?:[A-Z][\w.'&-]*|of|the|and|for|ex|rel|&)(?:,?\s+(?:[A-Z][\w.'&-]*,?|of|the|and|for|&))*\s+v\.\s+(?:[A-Z][\w.'&-]*|of|the)(?:,?\s+(?:[A-Z][\w.'&-]*,?|of|the|and|for|&))*)\s*,?\s*$/;
const qn=s=>s.toLowerCase().replace(/[“”"]/g,"").replace(/[^a-z0-9 ]+/g," ").replace(/\s+/g," ").trim();
function findCites(text){const re=new RegExp(REP.source,"gi"),out=[];let m,last=0;
while((m=re.exec(text))){const before=text.slice(last,m.index),nm=before.match(NAMEB);let name=nm?nm[1].replace(/^(See also|See|Cf\.|But see|Accord|E\.g\.,?)\s+/,"").replace(/,\s*$/,""):"";
const tail=text.slice(m.index+m[0].length).match(/^\s*\(([^)]*)\)/),raw=(name?name+", ":"")+m[0]+(tail?" ("+tail[1]+")":"");
const qs=[...before.matchAll(/[“"]([^”"]{6,})[”"]/g)].map(x=>x[1]);out.push({raw,quote:qs.length?qs[qs.length-1]:null,pin:m[4]?+m[4]:null});
last=m.index+m[0].length+(tail?tail[0].length:0)}return out}
function draft(root){const ta=$(".ch-dr__t",root),out=$("[data-dr-out]",root),orig=ta.value;
const run=()=>{const cs=findCites(ta.value);if(!ta.value.trim()){out.innerHTML='<div class="ch-err" role="alert"><b>The draft is empty.</b> Paste a paragraph with at least one citation, or restore the sample paragraph.</div>';return}
if(!cs.length){out.innerHTML='<div class="ch-empty"><b>No citations found.</b><p>Citations are found by volume, reporter and page, such as 392 U.S. 1 or 159 F.2d 169.</p></div>';return}
let n={ok:0,part:0,none:0,bad:0};const rows=cs.map(x=>{const r=check(x.raw);let k=r.kind,why=[];
if(r.c){why=r.notes.slice();if(x.quote){if(r.c.pass&&qn(r.c.pass[1]).includes(qn(x.quote)))why.push("Quote matches the opinion at page "+r.c.pass[0]+".");else if(r.c.pass){k="part";why.push("The quoted words are not in the stored passage at page "+r.c.pass[0]+".")}else why.push("Quote not checked: the sample corpus holds no passage for this opinion.")}
if(r.c.treat[0]==="Overruled"){why.push("Overruled by "+r.c.treat[1]+".")}}else why.push("No opinion in the sample corpus matches. Nothing is guessed in its place.");if(r.c&&r.c.treat[0]==="Overruled")n.bad++;else n[k]++;
return'<li class="ch-drl ch-drl--'+k+(r.c&&r.c.treat[0]==="Overruled"?" is-bad":"")+'">'+SEAL(k==="none"?"no":k)+'<div><p class="ch-drl__c">'+esc(x.raw)+'</p><p class="ch-drl__s">'+LAB[k]+(r.c&&r.c.treat[0]==="Overruled"?" · Not good law":"")+'</p><ul>'+why.map(w=>"<li>"+esc(w)+"</li>").join("")+"</ul></div></li>"});
out.innerHTML='<div class="ch-kpis"><div><span>Citations found</span><b>'+cs.length+'</b></div><div><span>Verified</span><b>'+n.ok+'</b></div><div><span>To fix</span><b>'+(n.part+n.none+n.bad)+'</b></div></div><ol class="ch-drls">'+rows.join("")+"</ol>"};
$("[data-dr-go]",root).addEventListener("click",run);$("[data-dr-reset]",root).addEventListener("click",()=>{ta.value=orig;out.innerHTML='<div class="ch-empty"><b>Sample paragraph restored.</b><p>Press Verify the draft to check it.</p></div>';ta.focus()})}
/* ---------- tabs */
function tabs(root){const t=$$("[role=tab]",root);function pick(i,f){t.forEach((b,j)=>{const on=j===i;b.setAttribute("aria-selected",on);b.tabIndex=on?0:-1;$("#"+b.getAttribute("aria-controls")).hidden=!on;if(on&&f)b.focus()})}
t.forEach((b,i)=>{b.addEventListener("click",()=>pick(i));b.addEventListener("keydown",e=>{if(e.key==="ArrowRight"||e.key==="ArrowLeft"){e.preventDefault();pick((i+(e.key==="ArrowRight"?1:t.length-1))%t.length,1)}})})}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-ch=check]").forEach(checker);$$("[data-ch=draft]").forEach(draft);$$("[data-ch=tabs]").forEach(tabs)}
