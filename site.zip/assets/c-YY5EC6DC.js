/* Evalweave hero: a lab bench on ink where trace threads (warp) and evaluator threads (weft) are woven into a grid.
   Each crossing is a cell: lilac when not scored, lime when it passed, red when it failed. Every 10 seconds one pulse
   runs along a weft thread; when it reaches the failing cell the cell turns lime and the regression gate at the end of
   the row turns from red to lime. Slow 20 second dolly, no shake. Scrolling holds the settled (passing) state. Synthetic. */
export default function({THREE:T,scene,camera,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const ink=new T.Color(color("--ew-ink","#14121f")),lil=new T.Color(color("--ew-lilac","#f3f0fb")),lime=new T.Color(color("--ew-lime","#a3e635")),red=new T.Color(color("--ew-red","#f0616d")),bench=new T.Color(color("--ew-bench","#221f33"));
scene.background=ink.clone();scene.fog=new T.Fog(ink.getHex(),9,19);
const root=new T.Group;root.position.set(-.05,-.1,.2);scene.add(root);const geos=[];const G=g=>(geos.push(g),g);
root.add(new T.AmbientLight(0xeceaf6,1.05));
const key=new T.DirectionalLight(0xfff1dc,1.15);key.position.set(-4,7,5);root.add(key);
const rim=new T.DirectionalLight(lime.getHex(),.35);rim.position.set(5,2,-5);root.add(rim);
const M=(c,o={})=>new T.MeshStandardMaterial(Object.assign({color:c,roughness:.72,metalness:0},o));
/* bench */
const top=new T.Mesh(G(new T.BoxGeometry(6.6,.14,4.4)),M(bench.clone(),{roughness:.9}));top.position.y=-.08;root.add(top);
const edge=new T.Mesh(G(new T.BoxGeometry(6.6,.02,.02)),new T.MeshBasicMaterial({color:lil.clone().lerp(ink,.55)}));edge.position.set(0,0,2.2);root.add(edge);
/* weave */
const C=small?7:9,R=small?5:6,S=.6,X0=-(C-1)*S/2,Z0=-(R-1)*S/2,o=new T.Object3D,cl=new T.Color;
const warpG=G(new T.BoxGeometry(.035,.035,(R-1)*S+.9)),warp=new T.InstancedMesh(warpG,M(lil.clone().lerp(ink,.25),{emissive:lil.clone(),emissiveIntensity:.08}),C);
for(let c=0;c<C;c++){o.position.set(X0+c*S,.07,0);o.updateMatrix();warp.setMatrixAt(c,o.matrix)}root.add(warp);
const segG=G(new T.BoxGeometry(S*.72,.03,.03)),NS=R*(C+1),weft=new T.InstancedMesh(segG,M(lil.clone().lerp(ink,.4)),NS);let k=0;
for(let r=0;r<R;r++)for(let c=-1;c<C;c++){const up=(r+c)%2===0;o.position.set(X0+(c+.5)*S,up?.12:.04,Z0+r*S);o.updateMatrix();weft.setMatrixAt(k++,o.matrix)}root.add(weft);
const cellG=G(new T.BoxGeometry(.24,.04,.24)),cells=new T.InstancedMesh(cellG,M(lil.clone(),{roughness:.5,emissive:lil.clone(),emissiveIntensity:.18}),C*R);
const kind=[];for(let r=0;r<R;r++)for(let c=0;c<C;c++){const v=(r*7+c*13+5+r*c)%11;kind.push(v===3?2:[0,5,8,9].includes(v)?1:0);o.position.set(X0+c*S,.15,Z0+r*S);o.updateMatrix();cells.setMatrixAt(r*C+c,o.matrix)}
root.add(cells);
const PR=Math.min(3,R-1),PC=C-3,FI=PR*C+PC;kind[FI]=2;
const base=k=>k===1?lime.clone().lerp(ink,.18):k===2?red.clone():lil.clone().lerp(ink,.62);
/* regression gate at the end of the pulse row */
const gate=new T.Group;gate.position.set(X0+(C-1)*S+.75,0,Z0+PR*S);root.add(gate);
const gm=M(red.clone(),{emissive:red.clone(),emissiveIntensity:.35});const postG=G(new T.BoxGeometry(.06,.7,.06));
[-.28,.28].forEach(z=>{const p=new T.Mesh(postG,gm);p.position.set(0,.35,z);gate.add(p)});const lin=new T.Mesh(G(new T.BoxGeometry(.06,.06,.62)),gm);lin.position.y=.7;gate.add(lin);
/* the pulse */
const pulse=new T.Mesh(G(new T.SphereGeometry(.07,16,12)),new T.MeshBasicMaterial({color:lime.clone(),transparent:!0,opacity:0}));root.add(pulse);
const halo=new T.Mesh(G(new T.SphereGeometry(.18,16,12)),new T.MeshBasicMaterial({color:lime.clone(),transparent:!0,opacity:0,depthWrite:!1,blending:T.AdditiveBlending}));root.add(halo);
const C0=new T.Vector3(-.5,4.9,7.6),look=new T.Vector3(.05,-.45,0),lk=new T.Vector3;camera.fov=38;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const xs=X0-.6,xe=X0+(C-1)*S+.75,hitX=X0+PC*S;
function frame(t,dt,p){
const hold=clamp((p-.45)/.3),c0=t%10,c=hold>0?lerp(c0,4.2,ease(hold)):c0;
const run=clamp((c-1)/2.6),px=lerp(xs,xe,ease(run)),on=c>1&&c<3.8?1:0,fade=c>8.6?ease((c-8.6)/1.2):0;
const passed=clamp((px-hitX)/.25)*(1-fade);
const dolly=Math.sin(t/20*Math.PI*2);camera.position.set(C0.x+dolly*.55+pointer.x*.25,C0.y-pointer.y*.15,C0.z+Math.cos(t/20*Math.PI*2)*.25);lk.copy(look);lk.x+=pointer.x*.06;camera.lookAt(lk);
pulse.position.set(px,.2,Z0+PR*S);halo.position.copy(pulse.position);pulse.material.opacity=on*(1-clamp((run-.96)/.04));halo.material.opacity=pulse.material.opacity*.28;
for(let i=0;i<kind.length;i++){const r=Math.floor(i/C),cc=i%C;let col=base(kind[i]);
if(i===FI)col=red.clone().lerp(lime,passed);
if(r===PR&&on){const d=Math.abs(X0+cc*S-px);if(d<.4)col.lerp(lil,(1-d/.4)*.5)}
cells.setColorAt(i,cl.copy(col))}
if(cells.instanceColor)cells.instanceColor.needsUpdate=!0;
gm.color.copy(red).lerp(lime,passed);gm.emissive.copy(gm.color);}
return{frame,resize:(w,h)=>{const a=w/h,k=a<.8?0:a<1.3?1:2;C0.set([-.3,-.4,-.5][k],[7.2,6.4,4.9][k],[7.4,6.4,7.4][k]);root.scale.setScalar([.6,.74,.92][k]);look.set(.05,[-.2,-.3,-.45][k],.3)},dispose:()=>geos.forEach(g=>g.dispose())}}
