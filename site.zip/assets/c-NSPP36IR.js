/* Evalweave page tools. Everything runs in this browser; nothing is sent anywhere.
   data-ew=judge     Judge Playground: a rubric judge (rules written out below) scores each example, shows reasons per
                     criterion and compares its verdicts with your labels (agreement, Cohen's kappa, confusion matrix).
   data-ew=traces    trace list filter (user, version, status, text).
   data-ew=estimate  plan estimator (events, eval runs, seats). Limits are sample limits, confirmed at launch. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const STOP=new Set("a an the and or but so to of in on at for with is am are was were be been being i you he she it we they my your his her our their me him them this that these those there here as by from do does did can could will would should may might have has had not no yes if then than how what when where which who why about into over after before up out any all some most just also only very more much each per its it's i'm you're we're".split(" "));
const stem=w=>{w=w.replace(/'s$/,"");if(w.length>5&&w.endsWith("ing"))w=w.slice(0,-3);else if(w.length>4&&w.endsWith("ed"))w=w.slice(0,-2);else if(w.length>4&&w.endsWith("es"))w=w.slice(0,-2);else if(w.length>3&&w.endsWith("s"))w=w.slice(0,-1);return w.replace(/e$/,"")};
const toks=t=>(String(t).toLowerCase().replace(/\[[^\]]*\]/g," ").match(/[a-z][a-z']*/g)||[]).filter(w=>!STOP.has(w)).map(stem);
const nums=t=>String(t).replace(/\[[^\]]*\]/g," ").match(/\d+(?:\.\d+)?/g)||[];
const sents=t=>String(t).split(/(?<=[.!?])\s+/).map(s=>s.trim()).filter(Boolean);
const COURT=/\b(sorry|thanks|thank you|happy to help|hello|hi there|apologi[sz]e)\b/i;
const STRICT={lenient:{ov:.4,sup:.5,ans:.3},standard:{ov:.5,sup:1,ans:.4},strict:{ov:.7,sup:1,ans:.6}};
const CRIT={
grounded:{name:"Grounded in the sources",run(e,k){const ctx=new Set(toks(e.ctx)),cn=new Set(nums(e.ctx)),ss=sents(e.out);let n=0,ok=0,bad=[],skip=0;
 ss.forEach(s=>{if(COURT.test(s)&&!nums(s).length){skip++;return}n++;const w=toks(s),hit=w.filter(x=>ctx.has(x)).length/Math.max(w.length,1),miss=nums(s).filter(x=>!cn.has(x));
 if(hit>=k.ov&&!miss.length)ok++;else bad.push(miss.length?"“"+s+"” gives "+miss.join(", ")+", which is not in the sources":"“"+s+"” shares "+Math.round(hit*100)+"% of its words with the sources")});
 if(!n)return{s:0,p:!1,r:"No sentence to check."};const sc=ok/n;return{s:sc,p:sc>=k.sup,r:bad.length?bad[0]+".":(n>1?"All "+n+" checked sentences are":"The one checked sentence is")+" supported"+(skip?", "+skip+" courtesy sentence skipped":"")+"."}}},
answers:{name:"Answers the question asked",run(e,k){const q=[...new Set(toks(e.q))],o=new Set(toks(e.out));if(!q.length)return{s:0,p:!1,r:"The question is empty."};const got=q.filter(x=>o.has(x)),sc=got.length/q.length;
 return{s:sc,p:sc>=k.ans,r:sc>=k.ans?"Covers "+got.length+" of "+q.length+" key terms from the question.":"Covers "+got.length+" of "+q.length+" key terms; missing “"+q.filter(x=>!o.has(x)).slice(0,3).join("”, “")+"”."}}},
cites:{name:"Cites a source by id",run(e){const m=e.out.match(/\[[a-z]+-\d+\]/gi)||[],ids=new Set((e.ctx.match(/\[[a-z]+-\d+\]/gi)||[]).map(x=>x.toLowerCase())),real=m.filter(x=>ids.has(x.toLowerCase()));
 return real.length?{s:1,p:!0,r:"Cites "+[...new Set(real)].join(" ")+"."}:{s:0,p:!1,r:m.length?"Cites "+m[0]+", which is not one of the sources.":"No source id such as [doc-12] in the answer."}}},
concise:{name:"Under 60 words",run(e){const n=(e.out.match(/\S+/g)||[]).length;return{s:n<=60?1:Math.max(0,1-(n-60)/60),p:n<=60,r:n+" words."}}},
tone:{name:"Polite, no blame",run(e){const m=e.out.match(/\b(calm down|as i said|obviously|you should have|that's not my problem|read the policy)\b/i);return m?{s:0,p:!1,r:"Contains “"+m[0]+"”."}:{s:1,p:!0,r:"No blaming or dismissive phrases found."}}},
handoff:{name:"Hands off when a person is asked for",run(e){const ask=/\b(person|human|agent|someone|manager|specialist)\b/i.test(e.q);if(!ask)return{s:1,p:!0,r:"No hand-off asked for."};
 const did=/\b(specialist|teammate|colleague|passed this|transfer|connect you|hand you)\b/i.test(e.out);return did?{s:1,p:!0,r:"Asked for a person, and the answer hands off."}:{s:0,p:!1,r:"Asked for a person, but the answer does not hand off."}}}};
const PRESETS={rag:["grounded","answers","cites","concise"],support:["grounded","answers","tone","handoff","concise"]};
const SAMPLE=[
{id:"ex-01",q:"How long do I have to return a jacket?",ctx:"[doc-12] Most items can be returned within 30 days of delivery. [doc-14] Final-sale items cannot be returned.",out:"You can return the jacket within 30 days of delivery [doc-12].",label:"pass"},
{id:"ex-02",q:"Can I return a final-sale item?",ctx:"[doc-14] Final-sale items cannot be returned. [doc-12] Most items can be returned within 30 days of delivery.",out:"Yes, final-sale items can be returned within 60 days [doc-14].",label:"fail"},
{id:"ex-03",q:"Do you ship to Canada?",ctx:"[doc-31] We ship to the United States and Canada. Delivery to Canada takes 5 to 9 business days.",out:"We ship to Canada, and delivery usually takes 5 to 9 business days.",label:"pass"},
{id:"ex-04",q:"What is the refund method?",ctx:"[doc-18] Refunds go back to the original payment method within 5 business days of the return being received.",out:"Refunds go to your original payment method within 5 business days after we receive the return [doc-18].",label:"pass"},
{id:"ex-05",q:"Can I exchange shoes for another size?",ctx:"[doc-22] Exchanges for a different size are free for shoes and clothing. Start an exchange from the order page.",out:"Our store has a great selection of shoes. You might also like the new running collection [doc-22].",label:"fail"},
{id:"ex-06",q:"How do I start a return?",ctx:"[doc-09] Start a return from the order page and print the prepaid label.",out:"Go to the order page, choose Start a return and print the prepaid label [doc-09]. Drop it at any carrier location within 14 days.",label:""},
{id:"ex-07",q:"This is the second broken order. Can I talk to a person?",ctx:"[doc-40] Customers can ask for a support specialist at any time. Specialists reply by email within one business day.",out:"I am sorry about the broken order. I have passed this to a support specialist, who will email you within one business day [doc-40].",label:"pass"}];
const clone=a=>a.map(x=>Object.assign({},x));
function parseCSV(t){const rows=[];let row=[],f="",q=!1;for(let i=0;i<t.length;i++){const c=t[i];if(q){if(c=='"'){if(t[i+1]=='"'){f+='"';i++}else q=!1}else f+=c}else if(c=='"')q=!0;else if(c==","){row.push(f);f=""}else if(c=="\n"||c=="\r"){if(c=="\r"&&t[i+1]=="\n")i++;row.push(f);rows.push(row);row=[];f=""}else f+=c}
 if(f||row.length){row.push(f);rows.push(row)}const h=(rows.shift()||[]).map(x=>x.trim().toLowerCase());return rows.filter(r=>r.some(x=>x.trim())).map(r=>Object.fromEntries(h.map((k,i)=>[k,r[i]||""])))}
function judge(root){
const st={ex:clone(SAMPLE),sel:0,preset:"rag",crit:PRESETS.rag.slice(),custom:[],strict:"standard",run:0};
const list=$("[data-jp-list]",root),critL=$("[data-jp-crit]",root),sum=$("[data-jp-sum]",root),det=$("[data-jp-detail]",root),msg=$("[data-jp-msg]",root);
const fq=$("#jp-q",root),fc=$("#jp-ctx",root),fo=$("#jp-out",root),fl=$("#jp-label",root),preset=$("#jp-preset",root),runN=$("[data-jp-runs]",root);
const say=(t,bad)=>{msg.textContent=t;msg.classList.toggle("is-bad",!!bad)};
const active=()=>st.crit.map(k=>Object.assign({k},CRIT[k])).concat(st.custom.map((c,i)=>({k:"c"+i,name:(c.not?"Never mentions ":"Mentions ")+"“"+c.term+"”",run(e){const has=e.out.toLowerCase().includes(c.term.toLowerCase());const p=c.not?!has:has;return{s:p?1:0,p,r:p?(c.not?"Does not mention it.":"Mentions it."):(c.not?"Mentions it.":"Does not mention it.")}}})));
const score=e=>{const k=STRICT[st.strict];if(!e.out.trim())return{err:"No output to judge yet. Paste the model's answer."};const rs=active().map(c=>Object.assign({name:c.name},c.run(e,k)));if(!rs.length)return{err:"Turn on at least one criterion."};return{rs,p:rs.every(r=>r.p),s:rs.reduce((a,r)=>a+r.s,0)/rs.length}};
function drawCrit(){const all=PRESETS[st.preset].concat(Object.keys(CRIT).filter(k=>!PRESETS[st.preset].includes(k)));
 critL.innerHTML=all.map(k=>'<li><input type="checkbox" id="jp-c-'+k+'" data-ck="'+k+'"'+(st.crit.includes(k)?" checked":"")+'><label for="jp-c-'+k+'">'+esc(CRIT[k].name)+'</label></li>').join("")+
 st.custom.map((c,i)=>'<li class="is-custom"><span>'+esc((c.not?"Never mentions ":"Mentions ")+"“"+c.term+"”")+'</span><button type="button" class="ew-x" data-rm="'+i+'" aria-label="Remove criterion: '+esc(c.term)+'">Remove</button></li>').join("")}
function drawList(){list.innerHTML=st.ex.map((e,i)=>{const r=score(e),v=r.err?"none":r.p?"pass":"fail";return '<button type="button" class="ew-ex'+(i===st.sel?" is-on":"")+'" data-i="'+i+'" aria-pressed="'+(i===st.sel)+'" tabindex="'+(i===st.sel?0:-1)+'"><span class="ew-ex__id">'+esc(e.id)+'</span><span class="ew-ex__q">'+esc(e.q||"Untitled example")+'</span><span class="ew-ex__v"><i class="ew-v ew-v--'+v+'">'+(v==="none"?"Not run":"Judge "+v)+'</i><i class="ew-v ew-v--h'+(e.label||"none")+'">'+(e.label?"You: "+e.label:"Unlabeled")+'</i></span></button>'}).join("")}
function drawEd(){const e=st.ex[st.sel];if(!e)return;fq.value=e.q;fc.value=e.ctx;fo.value=e.out;fl.value=e.label}
function drawDet(){const e=st.ex[st.sel];if(!e){det.innerHTML='<p class="ew-mute">Add an example to see the judge\'s reasons.</p>';return}const r=score(e);
 if(r.err){det.innerHTML='<p class="ew-det__h"><b>'+esc(e.id)+'</b></p><p class="ew-err">'+esc(r.err)+'</p>';return}
 det.innerHTML='<p class="ew-det__h"><b>'+esc(e.id)+'</b><span class="ew-v ew-v--'+(r.p?"pass":"fail")+'">Judge '+(r.p?"pass":"fail")+' · '+r.s.toFixed(2)+'</span></p><ol class="ew-rs">'+r.rs.map(x=>'<li class="'+(x.p?"is-p":"is-f")+'"><span class="ew-rs__s">'+x.s.toFixed(2)+'</span><div><b>'+esc(x.name)+'</b><small>'+esc(x.r)+'</small></div></li>').join("")+'</ol>'+
 (e.label&&(e.label==="pass")!==r.p?'<p class="ew-dis">You labeled this <b>'+e.label+'</b>. Read the reasons above: either the rubric needs a change or the label does.</p>':"")}
function drawSum(){const L=st.ex.map(e=>({h:e.label,r:score(e)})).filter(x=>x.h&&!x.r.err),n=L.length;
 if(n<2){sum.innerHTML='<p class="ew-mute">Label at least two examples as pass or fail to see how often the judge agrees with you.</p>';return}
 let a=0,b=0,c=0,d=0;L.forEach(x=>{const j=x.r.p,h=x.h==="pass";if(j&&h)a++;else if(j&&!h)b++;else if(!j&&h)c++;else d++});
 const po=(a+d)/n,pj=(a+b)/n,ph=(a+c)/n,pe=pj*ph+(1-pj)*(1-ph),kap=pe>=1?1:(po-pe)/(1-pe);
 const word=kap>=.8?"strong":kap>=.6?"substantial":kap>=.4?"moderate":kap>=.2?"fair":"weak";
 sum.innerHTML='<div class="ew-sum__k"><div><span>Agreement</span><b>'+Math.round(po*100)+'%</b><em>'+(a+d)+' of '+n+' labeled</em></div><div><span>Cohen’s kappa</span><b>'+kap.toFixed(2)+'</b><em>'+word+', corrected for chance</em></div></div>'+
 '<table class="ew-cm"><caption>Judge against your labels</caption><thead><tr><th scope="col"><span class="vh">Judge</span></th><th scope="col">You: pass</th><th scope="col">You: fail</th></tr></thead><tbody><tr><th scope="row">Judge pass</th><td>'+a+'</td><td class="'+(b?"is-off":"")+'">'+b+'</td></tr><tr><th scope="row">Judge fail</th><td class="'+(c?"is-off":"")+'">'+c+'</td><td>'+d+'</td></tr></tbody></table>'+
 '<p class="ew-mute">'+(n<20?"With "+n+" labels this is a rough read. Label 20 or more before you rely on it.":"Enough labels for a first read. Recheck after every rubric change.")+'</p>'}
const all=()=>{drawList();drawDet();drawSum();runN.textContent="Run "+st.run+" · "+st.ex.length+" examples · "+st.strict};
function run(){st.run++;all()}
function pick(i,focus){st.sel=Math.max(0,Math.min(st.ex.length-1,i));drawEd();all();if(focus){const b=$('[data-i="'+st.sel+'"]',list);b&&b.focus()}}
list.addEventListener("click",e=>{const b=e.target.closest("[data-i]");b&&pick(+b.dataset.i)});
list.addEventListener("keydown",e=>{const m={ArrowDown:1,ArrowRight:1,ArrowUp:-1,ArrowLeft:-1}[e.key];if(m){e.preventDefault();pick(st.sel+m,!0)}else if(e.key==="Home"){e.preventDefault();pick(0,!0)}else if(e.key==="End"){e.preventDefault();pick(st.ex.length-1,!0)}});
critL.addEventListener("change",e=>{const k=e.target.dataset.ck;if(!k)return;st.crit=e.target.checked?st.crit.concat(k):st.crit.filter(x=>x!==k);run()});
critL.addEventListener("click",e=>{const b=e.target.closest("[data-rm]");if(b){st.custom.splice(+b.dataset.rm,1);drawCrit();run();say("Criterion removed.")}});
preset.addEventListener("change",()=>{st.preset=preset.value;st.crit=PRESETS[st.preset].slice();drawCrit();run();say("Rubric set to "+preset.options[preset.selectedIndex].text+".")});
$$('input[name="jp-strict"]',root).forEach(r=>r.addEventListener("change",()=>{st.strict=r.value;run()}));
$("[data-jp-add]",root).addEventListener("click",()=>{const t=$("#jp-cterm",root),v=t.value.trim();if(!v){say("Type a word or phrase for the new criterion.",!0);t.focus();return}if(v.length>40){say("Keep the phrase under 40 characters.",!0);return}
 st.custom.push({term:v,not:$("#jp-ctype",root).value==="not"});t.value="";drawCrit();run();say("Criterion added.")});
const upd=()=>{const e=st.ex[st.sel];if(!e)return;e.q=fq.value;e.ctx=fc.value;e.out=fo.value;e.label=fl.value;all()};
[fq,fc,fo].forEach(f=>f.addEventListener("input",upd));fl.addEventListener("change",upd);
$("[data-jp-run]",root).addEventListener("click",()=>{run();say("Judged "+st.ex.length+" examples.")});
$("[data-jp-new]",root).addEventListener("click",()=>{if(st.ex.length>=50){say("This page holds up to 50 examples.",!0);return}st.ex.push({id:"ex-"+String(st.ex.length+1).padStart(2,"0"),q:"",ctx:"",out:"",label:""});pick(st.ex.length-1);fq.focus();say("New example added. Paste a question, its sources and the output.")});
$("[data-jp-del]",root).addEventListener("click",()=>{if(st.ex.length<=1){say("Keep at least one example.",!0);return}const id=st.ex[st.sel].id;st.ex.splice(st.sel,1);pick(st.sel);say(id+" removed.")});
$("[data-jp-replay]",root).addEventListener("click",()=>{st.ex=clone(SAMPLE);st.custom=[];st.preset=preset.value="rag";st.crit=PRESETS.rag.slice();st.strict="standard";$('input[name="jp-strict"][value="standard"]',root).checked=!0;st.sel=0;drawCrit();drawEd();run();say("Back to the synthetic sample set.")});
$("#jp-file",root).addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;if(f.size>512e3){say("That file is over 500 KB. Try a smaller sample.",!0);return}
 const rd=new FileReader;rd.onload=()=>{let rows=[];try{rows=/\.csv$/i.test(f.name)?parseCSV(rd.result):rd.result.split(/\r?\n/).filter(l=>l.trim()).map(l=>JSON.parse(l))}catch(x){say("Could not read the file. Use JSON Lines or CSV with question, sources, output and label.",!0);return}
 const ex=rows.slice(0,50).map((r,i)=>({id:"up-"+String(i+1).padStart(2,"0"),q:String(r.question||r.input||""),ctx:String(r.sources||r.context||""),out:String(r.output||r.answer||""),label:/^(pass|fail)$/i.test(r.label||"")?r.label.toLowerCase():""})).filter(r=>r.out||r.q);
 if(!ex.length){say("No rows with a question or output were found.",!0);return}st.ex=ex;st.sel=0;drawEd();run();say("Loaded "+ex.length+" examples from "+f.name+". They stay in this browser.")};rd.readAsText(f);e.target.value=""});
drawCrit();drawEd();run()}
function traces(root){const rows=$$("tbody tr",root),f=$$("[data-tf]",root),out=$("[data-tf-n]",root),q=$("[data-tf-q]",root);
 const apply=()=>{const v=Object.fromEntries(f.map(s=>[s.dataset.tf,s.value])),t=q.value.trim().toLowerCase();let n=0;
 rows.forEach(r=>{const ok=Object.entries(v).every(([k,x])=>!x||r.dataset[k]===x)&&(!t||r.textContent.toLowerCase().includes(t));r.hidden=!ok;if(ok)n++});
 out.textContent=n?n+" of "+rows.length+" traces":"No traces match. Clear a filter to see more.";root.classList.toggle("is-empty",!n)};
 f.forEach(s=>s.addEventListener("change",apply));q.addEventListener("input",apply);$("[data-tf-clear]",root).addEventListener("click",()=>{f.forEach(s=>s.value="");q.value="";apply();out.textContent="Filters cleared · "+rows.length+" traces"});apply()}
function estimate(root){const ev=$("#es-ev",root),ru=$("#es-ru",root),se=$("#es-se",root),o=$("[data-es-out]",root),fmt=n=>n.toLocaleString("en-US");
 const LIM={free:{ev:5e4,ru:200,se:1},team:{ev:2e6,ru:5e3,se:25}};
 const go=()=>{const E=Math.max(0,+ev.value||0),R=Math.max(0,+ru.value||0),S=Math.max(1,+se.value||1);
 if([ev,ru,se].some(x=>x.value!==""&&+x.value<0)){o.innerHTML='<p class="ew-err">Use numbers of zero or more.</p>';return}
 const plan=E<=LIM.free.ev&&R<=LIM.free.ru&&S<=LIM.free.se?"Free":E<=LIM.team.ev&&R<=LIM.team.ru&&S<=LIM.team.se?"Team":"Enterprise";
 const why=plan==="Free"?"One developer, inside the free limits.":plan==="Team"?(S>1?S+" seats":"Volume above the free limits")+", inside the Team limits. Review queue and CI gates included.":"Above the Team limits"+(S>25?" on seats":E>LIM.team.ev?" on traced events":" on eval runs")+". Talk to us about volume pricing or self-hosting.";
 const over=plan==="Team"?Math.max(0,E-1e6):0;
 o.innerHTML='<p class="ew-es__p"><span>Estimated plan</span><b>'+plan+'</b></p><p class="ew-mute">'+why+'</p><dl class="ew-es__d"><div><dt>Traced events a month</dt><dd>'+fmt(E)+'</dd></div><div><dt>Eval runs a month</dt><dd>'+fmt(R)+'</dd></div><div><dt>Seats</dt><dd>'+S+'</dd></div>'+(plan==="Team"?'<div><dt>Events above the 1M included</dt><dd>'+fmt(over)+'</dd></div>':"")+'</dl>'};
 [ev,ru,se].forEach(x=>x.addEventListener("input",go));$$("[data-es-p]",root).forEach(b=>b.addEventListener("click",()=>{const[a,c,d]=b.dataset.esP.split(",");ev.value=a;ru.value=c;se.value=d;$$("[data-es-p]",root).forEach(x=>x.setAttribute("aria-pressed",x===b));go()}));go()}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
function copy(){$$("[data-ew-copy]").forEach(b=>b.addEventListener("click",()=>{const c=$(b.dataset.ewCopy);if(!c)return;const t=c.textContent,done=()=>{b.textContent="Copied";setTimeout(()=>b.textContent="Copy",1600)};
 navigator.clipboard?navigator.clipboard.writeText(t).then(done,()=>{b.textContent="Select and copy";}):(b.textContent="Select and copy")}))}
function tabs(root){const t=$$('[role=tab]',root),p=t.map(x=>document.getElementById(x.getAttribute("aria-controls")));
 const go=(i,f)=>{t.forEach((x,k)=>{const on=k===i;x.setAttribute("aria-selected",on);x.tabIndex=on?0:-1;p[k].hidden=!on});f&&t[i].focus()};
 t.forEach((x,i)=>{x.addEventListener("click",()=>go(i));x.addEventListener("keydown",e=>{const m={ArrowRight:1,ArrowLeft:-1}[e.key];if(m){e.preventDefault();go((i+m+t.length)%t.length,!0)}else if(e.key==="Home"){e.preventDefault();go(0,!0)}else if(e.key==="End"){e.preventDefault();go(t.length-1,!0)}})})}
export function boot(){scrollers();copy();$$("[data-ew=tabs]").forEach(tabs);$$("[data-ew=judge]").forEach(judge);$$("[data-ew=traces]").forEach(traces);$$("[data-ew=estimate]").forEach(estimate)}
