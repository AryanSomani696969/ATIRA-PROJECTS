/* Energy Choice Calculator: a low and a high annual saving, and the charges that move it most. */
(function () {
  'use strict';
  var form = document.getElementById('cc-form');
  if (!form) return;

  var state = document.getElementById('cc-state');
  var util = document.getElementById('cc-util');
  var inputs = {
    peak: document.getElementById('cc-peak'),
    use: document.getElementById('cc-use'),
    rate: document.getElementById('cc-rate')
  };
  var out = [document.getElementById('cc-o1'), document.getElementById('cc-o2'), document.getElementById('cc-o3')];
  var chip = document.getElementById('cc-chip');
  var note = 'Typical charge levels for the territory; confirm against your bills.';

  // Typical shares of the all-in rate for a commercial or industrial site, by state, and how each
  // territory sits against them: [transmission, delivery] multipliers.
  var RULES = {
    'Ohio': {
      cap: 0.11653, tra: 0.13555, del: 0.17479, oth: 0.0059,
      u: { 'AEP Ohio': [1, 1], 'AES Ohio': [0.92, 1.06], 'Duke Energy Ohio': [0.9, 0.97], 'FirstEnergy Ohio': [1.04, 1.02] }
    },
    'Pennsylvania': {
      cap: 0.108, tra: 0.101, del: 0.152, oth: 0.006,
      u: { 'PECO': [1, 1], 'PPL Electric': [0.96, 1.05], 'Duquesne Light': [1.08, 0.94], 'FirstEnergy Pennsylvania': [1.02, 1.03] }
    }
  };
  // How far each charge moves with the site's own peak, so the list is ordered by what a buyer can change.
  var WEIGHT = { Transmission: 1, Delivery: 0.55, Capacity: 0.8 };
  var DEFAULTS = { state: 'Ohio', util: 'AEP Ohio', peak: 3100, use: 18400, rate: 84.1 };

  function num(v) {
    var n = parseFloat(String(v).replace(/[,\s$]/g, ''));
    return isFinite(n) ? n : NaN;
  }
  function money(n) {
    if (n >= 1e6) return '$' + (Math.round(n / 1e5) / 10).toFixed(1).replace(/\.0$/, '') + 'M';
    if (n >= 1e3) return '$' + Math.round(n / 1e3) + 'K';
    return '$' + Math.round(n);
  }
  function one(n) {
    return (Math.round(n * 10) / 10).toFixed(1);
  }

  function estimate(st, ut, kw, mwh, rate) {
    var r = RULES[st] || RULES.Ohio;
    var m = r.u[ut] || [1, 1];
    var cap = r.cap, tra = r.tra * m[0], del = r.del * m[1];
    var sup = 1 - cap - tra - del - r.oth;
    var cost = mwh * rate;
    var lf = (mwh * 1000) / (kw * 8760);
    var f = Math.min(1.6, Math.max(0.5, (1 - lf) / 0.3224));
    var peakPart = cap + tra;
    var low = cost * (sup * 0.005 + peakPart * 0.04 * f);
    var high = cost * (sup * 0.08 + peakPart * 0.287 * f);
    var charges = [
      { n: 'Transmission', v: tra * rate },
      { n: 'Delivery', v: del * rate },
      { n: 'Capacity', v: cap * rate }
    ];
    charges.sort(function (a, b) { return b.v * WEIGHT[b.n] - a.v * WEIGHT[a.n]; });
    return { low: low, high: high, charges: charges };
  }

  function fill(sel, st) {
    var names = Object.keys(RULES[st].u);
    sel.innerHTML = '';
    names.forEach(function (n) {
      var o = document.createElement('option');
      o.textContent = n;
      sel.appendChild(o);
    });
  }

  function clearErrors() {
    Object.keys(inputs).forEach(function (k) {
      var el = inputs[k];
      var e = document.getElementById(el.id + '-err');
      if (e) e.remove();
      el.removeAttribute('aria-invalid');
      el.removeAttribute('aria-describedby');
    });
  }
  function complain(el, msg) {
    var e = document.createElement('p');
    e.className = 'err';
    e.id = el.id + '-err';
    e.setAttribute('role', 'alert');
    e.textContent = msg;
    el.parentNode.appendChild(e);
    el.setAttribute('aria-invalid', 'true');
    el.setAttribute('aria-describedby', e.id);
  }

  function read(show) {
    clearErrors();
    var kw = num(inputs.peak.value), mwh = num(inputs.use.value), rate = num(inputs.rate.value);
    var bad = null;
    function fail(el, msg) {
      if (show) complain(el, msg);
      if (!bad) bad = el;
    }
    if (!(kw >= 50)) fail(inputs.peak, 'Enter the peak demand in kW, at least 50.');
    if (!(mwh >= 100)) fail(inputs.use, 'Enter the annual use in MWh, at least 100.');
    if (!(rate >= 20 && rate <= 500)) fail(inputs.rate, 'Enter the all-in rate in $/MWh, between 20 and 500.');
    if (!bad && (mwh * 1000) / (kw * 8760) > 1) {
      fail(inputs.use, 'That use is more than the peak demand could supply in a year. Check the kW and MWh figures.');
    }
    if (bad) {
      if (show) bad.focus();
      return null;
    }
    return { kw: kw, mwh: mwh, rate: rate };
  }

  function render(fromUser) {
    var v = read(fromUser);
    if (!v) return;
    var r = estimate(state.value, util.value, v.kw, v.mwh, v.rate);
    var lo = money(r.low), hi = money(r.high);
    out[0].textContent = lo === hi ? 'About ' + hi : lo + ' to ' + hi;
    var c = r.charges;
    out[1].textContent = c[0].n + ', ' + one(c[0].v);
    out[2].textContent = c[1].n + ' ' + one(c[1].v) + ', ' + c[2].n.toLowerCase() + ' ' + one(c[2].v);
    var same = state.value === DEFAULTS.state && util.value === DEFAULTS.util && v.kw === DEFAULTS.peak && v.mwh === DEFAULTS.use && v.rate === DEFAULTS.rate;
    if (chip) chip.textContent = (same ? 'Sample inputs. ' : 'Your inputs. ') + note;
  }

  state.addEventListener('change', function () {
    fill(util, state.value);
    render(false);
  });
  util.addEventListener('change', function () { render(false); });
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    render(true);
  });
})();
