/* Tutorcairn hero: a sunlit study desk on deep blue. An open notebook sits on the desk and a step ladder floats beside it.
   A question card breaks into three step cards; each card rises to a rung and lights it yellow, and the notebook fills in line by line.
   12 second cycle. Scrolling holds the lit state and folds the right page over, like a report folded into a summary. Synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const bg=new T.Color(colors.bg),chalk=new T.Color(color("--tc-chalk","#fffdf7")),sun=new T.Color(color("--tc-sun","#f4b400")),leaf=new T.Color(color("--tc-leaf","#43a047"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),8,18);
const root=new T.Group;scene.add(root);const geos=[];const G=g=>(geos.push(g),g);
root.add(new T.AmbientLight(0xdfe7f2,.75));
const key=new T.DirectionalLight(0xfff0d0,1.15);key.position.set(-4,6,4);root.add(key);
const rim=new T.DirectionalLight(sun.getHex(),.35);rim.position.set(5,2,-4);root.add(rim);
const M=(c,o={})=>new T.MeshStandardMaterial(Object.assign({color:c,roughness:.75,metalness:0},o));
/* window and sun, far back */
const sunD=new T.Mesh(G(new T.CylinderGeometry(.28,.28,.02,small?24:40)),new T.MeshBasicMaterial({color:sun}));sunD.rotation.x=Math.PI/2;sunD.position.set(-.3,3.15,-3.15);root.add(sunD);
const wl=[],WX0=-1.1,WX1=1.7,WY0=1.4,WY1=3.7;[[WX0,WY0,WX1,WY0],[WX1,WY0,WX1,WY1],[WX1,WY1,WX0,WY1],[WX0,WY1,WX0,WY0],[(WX0+WX1)/2,WY0,(WX0+WX1)/2,WY1],[WX0,(WY0+WY1)/2,WX1,(WY0+WY1)/2]].forEach(([a,b,c,d])=>wl.push(a,b,-3.14,c,d,-3.14));const wg=G(new T.BufferGeometry);wg.setAttribute("position",new T.Float32BufferAttribute(wl,3));
root.add(new T.LineSegments(wg,new T.LineBasicMaterial({color:bg.clone().lerp(chalk,.4)})));
/* desk */
const desk=new T.Mesh(G(new T.BoxGeometry(9,.12,4.2)),new T.MeshBasicMaterial({color:bg.clone().lerp(chalk,.025)}));desk.position.set(.6,-.08,.3);root.add(desk);
const eg=G(new T.BufferGeometry);eg.setAttribute("position",new T.Float32BufferAttribute([-3.9,-.015,-1.8,5.1,-.015,-1.8],3));root.add(new T.LineSegments(eg,new T.LineBasicMaterial({color:bg.clone().lerp(chalk,.5)})));
/* notebook: left page fixed, right page hinged on the spine */
const PW=1.5,PD=2,pageGeo=G(new T.BoxGeometry(PW,.02,PD)),pageMat=M(chalk.clone(),{roughness:.9});
const book=new T.Group;book.position.set(.75,.02,.95);book.rotation.y=.12;root.add(book);
const left=new T.Mesh(pageGeo,pageMat);left.position.x=-PW/2;left.rotation.z=.04;book.add(left);
const hinge=new T.Group;book.add(hinge);const right=new T.Mesh(pageGeo,pageMat);right.position.x=PW/2;hinge.add(right);hinge.rotation.z=-.04;
const ROWS=8,lineGeo=G(new T.BoxGeometry(1,.006,.035)),ruleMat=new T.MeshBasicMaterial({color:chalk.clone().lerp(bg,.18)}),inkMat=M(bg.clone().lerp(chalk,.2));
const rules=new T.InstancedMesh(lineGeo,ruleMat,ROWS*2),o=new T.Object3D;book.add(rules);
const leftInk=new T.InstancedMesh(lineGeo,inkMat,ROWS),rightInk=new T.InstancedMesh(lineGeo,inkMat,ROWS);left.add(leftInk);right.add(rightInk);
const W=[];for(let k=0;k<ROWS*2;k++)W.push(.55+((k*37)%40)/100);
for(let s=0;s<2;s++)for(let i=0;i<ROWS;i++){const z=-PD/2+.32+i*(PD-.5)/(ROWS-1);o.position.set(s?PW/2:-PW/2,.026,z);o.scale.set(PW-.24,1,.5);o.rotation.set(0,0,0);o.updateMatrix();rules.setMatrixAt(s*ROWS+i,o.matrix)}
function fill(n){[leftInk,rightInk].forEach((m,s)=>{for(let i=0;i<ROWS;i++){const k=s*ROWS+i,f=clamp(n*ROWS*2-k),w=(PW-.5)*W[k]*f;const z=-PD/2+.32+i*(PD-.5)/(ROWS-1)-.05;
o.position.set(-PW/2+.3+w/2,.018,z);o.scale.set(Math.max(w,.001),1.6,1.2);o.updateMatrix();m.setMatrixAt(i,o.matrix)}m.instanceMatrix.needsUpdate=!0})}
/* ladder */
const lad=new T.Group;lad.position.set(2.55,.9,-.4);lad.rotation.set(0,-.3,-.1);root.add(lad);
const railGeo=G(new T.CylinderGeometry(.03,.03,3.2,8)),railMat=M(chalk.clone(),{roughness:.5});[-.42,.42].forEach(x=>{const r=new T.Mesh(railGeo,railMat);r.position.set(x,1.1,0);lad.add(r)});
const rungGeo=G(new T.CylinderGeometry(.028,.028,.84,8)),RN=5,rungs=[];
for(let i=0;i<RN;i++){const m=M(chalk.clone().lerp(bg,.45),{emissive:sun.clone(),emissiveIntensity:0,roughness:.45});const r=new T.Mesh(rungGeo,m);r.rotation.z=Math.PI/2;r.position.set(0,-.2+i*.55,0);lad.add(r);rungs.push(r)}
/* the question card and its three step cards */
const cardGeo=G(new T.BoxGeometry(.5,.3,.02)),cards=[0,1,2].map(i=>{const m=M(chalk.clone(),{emissive:sun.clone(),emissiveIntensity:0,transparent:!0,opacity:0});const c=new T.Mesh(cardGeo,m);root.add(c);return c});
const qCard=new T.Mesh(G(new T.BoxGeometry(1.1,.42,.02)),M(chalk.clone(),{transparent:!0,opacity:0}));root.add(qCard);
const Q0=new T.Vector3(1,2.1,.7),tmp=new T.Vector3,rw=new T.Vector3;
/* progress stars */
const starGeo=G(new T.IcosahedronGeometry(.09,0)),stars=[0,1,2].map(i=>{const s=new T.Mesh(starGeo,M(i===1?leaf.clone():sun.clone(),{emissive:i===1?leaf.clone():sun.clone(),emissiveIntensity:.3,transparent:!0,opacity:0}));root.add(s);return s});
const C0=new T.Vector3(1.6,3.3,6.4),look=new T.Vector3(1.45,1,0),lk=new T.Vector3;camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
function rungWorld(i){rw.set(.62,-.2+i*.55,0);return lad.localToWorld(rw)}
function frame(t,dt,p){
const hold=clamp((p-.56)/.28),c0=t%12,c=hold>0?lerp(c0,10.4,ease(hold)):c0,reset=c>11.2?ease((c-11.2)/.8):0;
camera.position.set(C0.x+Math.sin(t/12*Math.PI*2)*.3+pointer.x*.28,C0.y-pointer.y*.16,C0.z);lk.copy(look);lk.x+=pointer.x*.08;camera.lookAt(lk);
lad.position.y=.9+Math.sin(t*.8)*.05;lad.updateMatrixWorld();
const appear=ease(clamp(c/.8)),split=ease(clamp((c-1.2)/1.4));
qCard.material.opacity=appear*(1-split);qCard.position.copy(Q0);qCard.position.y+=Math.sin(t*1.1)*.03;qCard.lookAt(camera.position);
let lit=0;
cards.forEach((cd,i)=>{const t0=3+i*2,rise=ease(clamp((c-t0)/1.6));const base=tmp.copy(Q0);base.x+=(i-1)*.56*split;base.y-=.05*split;
const target=rungWorld(i+1);cd.position.lerpVectors(base,target,rise);cd.position.x+=.32*rise;cd.lookAt(camera.position);
cd.material.opacity=split*(1-reset);cd.material.emissiveIntensity=rise>.98?.25:0;if(rise>.98)lit=i+2});
if(c>.9)lit=Math.max(lit,1);if(c>9.4)lit=Math.max(lit,5);if(reset)lit=0;
rungs.forEach((r,i)=>{const on=i<lit;r.material.color.copy(on?sun:chalk.clone().lerp(bg,.45));r.material.emissiveIntensity=on?.35:0});
fill(clamp(lit/5)*(1-reset)*.9+hold*.1);
hinge.rotation.z=-.04-hold*Math.PI*.92;
stars.forEach((s,i)=>{const e=ease(clamp((c-9.6-i*.25)/.6))*(1-reset);s.material.opacity=e;s.position.set(2.9+(i-1)*.35,3.35+e*.25+(i===1?.15:0),-.1);s.rotation.y=t*.8+i;s.scale.setScalar(.6+e*.4)})}
return{frame,resize:(w,h)=>{C0.z=w/h<.8?9.5:6.4;look.x=w/h<.8?1.5:1.45},dispose:()=>geos.forEach(g=>g.dispose())}}
