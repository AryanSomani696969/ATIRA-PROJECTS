/* Print and read-aloud for the sample document checklist. */
(function () {
  'use strict';
  var list = document.getElementById('checklist');
  if (!list) return;
  var root = document.documentElement;
  var pr = document.querySelector('[data-bc-print]');
  var hr = document.querySelector('[data-bc-hear]');

  if (pr) {
    pr.addEventListener('click', function () {
      function done() {
        root.classList.remove('bc-print-only');
        window.removeEventListener('afterprint', done);
        window.removeEventListener('focus', done);
      }
      root.classList.add('bc-print-only');
      window.addEventListener('afterprint', done);
      window.addEventListener('focus', done);
      window.print();
    });
  }

  if (hr) {
    var synth = window.speechSynthesis;
    if (!synth || typeof window.SpeechSynthesisUtterance !== 'function') {
      hr.hidden = true;
      return;
    }
    var label = hr.querySelector('[data-lbl]');
    var idle = label ? label.textContent : '';
    var on = false;

    function lines() {
      var out = [];
      var head = list.querySelector('.tc-eb');
      if (head) out.push((head.textContent || '').replace(/\s*\/\s*/g, '. '));
      [].slice.call(list.querySelectorAll('li')).forEach(function (li, i) {
        var t = [].slice.call(li.childNodes).filter(function (n) { return n.nodeType === 3; })
          .map(function (n) { return n.textContent; }).join('').trim();
        if (t) out.push((i + 1) + '. ' + t);
      });
      return out;
    }
    function reset() {
      on = false;
      hr.setAttribute('aria-pressed', 'false');
      if (label) label.textContent = idle;
    }
    hr.setAttribute('aria-pressed', 'false');
    hr.addEventListener('click', function () {
      if (on) {
        synth.cancel();
        reset();
        return;
      }
      synth.cancel();
      on = true;
      hr.setAttribute('aria-pressed', 'true');
      if (label) label.textContent = 'Stop reading';
      var ls = lines();
      ls.forEach(function (t, i) {
        var u = new window.SpeechSynthesisUtterance(t);
        u.lang = root.lang || 'en';
        u.rate = 0.95;
        if (i === ls.length - 1) u.onend = reset;
        u.onerror = function () { if (on) reset(); };
        synth.speak(u);
      });
    });
    window.addEventListener('pagehide', function () { synth.cancel(); });
  }
})();
