/* Fakeprism page tools. Everything runs in the browser on four drawn samples; nothing is uploaded or fetched.
   [data-fp=check]  media check: choose a labelled sample, optionally recompress it, press Check, read the range,
                    the highlights on the file, provenance, limits and the report (also as JSON)
   [data-fp=mini]   home live meter: recompression quality widens the range on sample SMP-01
   [data-fp=bench]  benchmark table filter: media type and failure cases */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches,f2=v=>v.toFixed(2);
/* ---------- the samples (synthetic; the drawings are in the page) */
const NOPROV=["Earlier copies","Search not run on samples","mute"];
const SMP={
"SMP-01":{name:"Generated face",type:"Image, PNG, 1024 × 1024",kind:"image",lo:.82,hi:.93,pt:.88,model:"fp-img-2026.11",hash:"9f3c…a71e",
 arts:[{id:"A1",h:"Corneal reflections disagree",p:"The highlight sits upper left in one eye and lower right in the other. One light source would put them in the same place.",k:"Pixels",w:.31,a:0},
  {id:"A2",h:"Hairline dissolves into the background",p:"Strands fade into texture with no edge where hair meets wall.",k:"Pixels",w:.24,a:1},
  {id:"A3",h:"Earrings do not match",p:"A hoop on one ear and a stud on the other. Weak on its own: people do wear odd pairs.",k:"Pixels",w:.09,a:2},
  {id:"A4",h:"Peaks on an 8-pixel grid",p:"The background spectrum repeats every 8 pixels, a trace left by upsampling layers.",k:"Frequency",w:.22,a:3}],
 prov:[["Content credentials","No C2PA manifest found","mute"],["Camera metadata","None, stripped or never written","warn"],["Compression history","One save, PNG","ok"],NOPROV],
 lim:["Face crop 1024 px, inside the tested range.","A generator newer than the model could score lower."],flags:[]},
"SMP-02":{name:"Camera original, street scene",type:"Image, JPEG, 2048 × 1536",kind:"image",lo:.04,hi:.15,pt:.08,model:"fp-img-2026.11",hash:"2b81…04cd",
 arts:[{id:"N1",h:"Sensor noise is consistent",p:"The grain is the same in the sky, the walls and the road, as one camera sensor produces. Applies to the whole frame.",k:"Pixels",w:.03,a:null}],
 prov:[["Content credentials","C2PA manifest present, signature valid","ok"],["Camera metadata","Present, consistent with the noise","ok"],["Compression history","One JPEG save, quality 92","ok"],NOPROV],
 lim:["A camera original can still be staged or misleadingly framed. This check looks for synthesis, not for context."],flags:[]},
"SMP-03":{name:"Cloned voice, call clip",type:"Audio, 12.4 s, 8 kHz",kind:"audio",lo:.68,hi:.88,pt:.78,model:"fp-voice-2026.10",hash:"c47e…19b0",
 arts:[{id:"A1",h:"No breath between phrases",p:"At 00:02.1 two phrases join with no intake of breath and no room noise.",k:"Voice",w:.21,a:0},
  {id:"A2",h:"Pitch contour too smooth",p:"From 00:05.2 the pitch moves in even steps, without the small wobble of a speaking voice.",k:"Voice",w:.27,a:1},
  {id:"A3",h:"Spectral seam at a phrase boundary",p:"At 00:09.0 the energy pattern changes abruptly between two words.",k:"Frequency",w:.24,a:2}],
 prov:[["Content credentials","Not used for call recordings","mute"],["File metadata","Phone system export","ok"],["Compression history","Telephone codec, 8 kHz","warn"],NOPROV],
 lim:["Telephone audio above 4 kHz is cut off, so part of the evidence is missing.","Speaker identity is not checked; only whether the voice is synthetic."],flags:["Telephone line, 8 kHz: range wider than for studio audio"]},
"SMP-04":{name:"Re-encoded short clip",type:"Video, 2.8 s, 480p",kind:"video",lo:.31,hi:.72,pt:.52,model:"fp-vid-2026.11",hash:"7da0…e3f2",
 arts:[{id:"A1",h:"Blocking hides the face edge",p:"Compression blocks cover the jaw and collar, where a swap would usually show.",k:"Pixels",w:.12,a:null},
  {id:"A2",h:"Too few frames to compare",p:"Under 3 seconds of video gives the timeline only a few segments to score.",k:"Time",w:.08,a:null}],
 prov:[["Content credentials","No C2PA manifest found","mute"],["File metadata","Platform export, original stripped","warn"],["Compression history","Re-encoded at least three times","warn"],NOPROV],
 lim:["Find the original upload and check it instead.","Ask the sender where the clip came from before relying on any result."],flags:["Clip under 3 seconds","Re-encoded at least three times"]}};
const REQ=[{w:0,p:0,t:"As received"},{w:.06,p:.15,t:"Recompressed once at medium quality"},{w:.13,p:.35,t:"Recompressed twice at low quality"}];
/* ---------- engine: recompression pulls the estimate towards 0.5 and widens the range */
function adjust(s,w,p){const pt=s.pt+(.5-s.pt)*p,lo=Math.max(0,Math.min(pt,s.lo+(.5-s.lo)*p)-w),hi=Math.min(1,Math.max(pt,s.hi+(.5-s.hi)*p)+w);return{lo,hi,pt}}
function band(r,kind){return r.lo>=.65?"Leans synthetic":r.hi<=.35?(kind==="audio"?"Leans real recording":"Leans camera original"):"Inconclusive"}
function gauge(r){const P=(v,R)=>{const a=Math.PI*(1-v);return[120+R*Math.cos(a),116-R*Math.sin(a)]},arc=(a,b,R)=>{const[x1,y1]=P(a,R),[x2,y2]=P(b,R);return`M${x1.toFixed(1)} ${y1.toFixed(1)} A${R} ${R} 0 0 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`};
const k=r.lo>=.65?"syn":r.hi<=.35?"auth":"inc",[tx,ty]=P(r.pt,70),[tx2,ty2]=P(r.pt,102);
return`<svg class="fp-gauge" viewBox="0 0 240 132" aria-hidden="true" focusable="false"><path class="fp-g-z1" d="${arc(0,.35,90)}"/><path class="fp-g-z2" d="${arc(.35,.65,90)}"/><path class="fp-g-z3" d="${arc(.65,1,90)}"/><path class="fp-g-r fp-g-r--${k}" d="${arc(r.lo,Math.max(r.hi,r.lo+.004),90)}"/><line class="fp-g-pt" x1="${tx.toFixed(1)}" y1="${ty.toFixed(1)}" x2="${tx2.toFixed(1)}" y2="${ty2.toFixed(1)}"/><text class="fp-g-ax" x="14" y="130">0</text><text class="fp-g-ax" x="220" y="130">1</text></svg>`}
function gblock(r,v,cls=""){return`<div class="fp-gb ${cls}">${gauge(r)}<div class="fp-gb__t"><p class="mv-mi">Likelihood of synthesis</p><p class="fp-gb__r"><b>${f2(r.lo)}</b> to <b>${f2(r.hi)}</b></p><p class="fp-gb__v">${esc(v)}</p></div></div>`}
const TAG={ok:"Consistent",warn:"Weak or missing",mute:"Not found"};
/* ---------- media check */
function check(root){const sel=$("[data-mc-s]",root),q=$("[data-mc-q]",root),go=$("[data-mc-go]",root),rs=$("[data-mc-reset]",root),err=$("[data-mc-err]",root),
out=$("[data-mc-out]",root),live=$("[data-mc-live]",root),heat=$("[data-mc-heat]",root),stage=$("[data-mc-stage]",root),steps=$$("[data-mc-steps] li",root),
list=$("[data-mc-arts]",root),name=$("[data-mc-name]",root),empty=out.innerHTML;let cur=null,timer=null,n=410;
function show(id){$$("[data-smp]",stage).forEach(m=>m.hidden=m.dataset.smp!==(id||"SMP-01"));const s=SMP[id];name.textContent=s?`${id} · ${s.name} · Synthetic`:"No sample chosen";
stage.classList.toggle("is-dim",!s);stage.classList.remove("is-heat");heat.disabled=!0;heat.setAttribute("aria-pressed","false");heat.textContent="Show heatmap";list.innerHTML="";ring(null);steps.forEach(l=>l.className="")}
function ring(a){$$("[data-a]",stage).forEach(e=>e.classList.toggle("is-on",a!==null&&+e.dataset.a===a))}
function stop(){clearTimeout(timer);timer=null;root.classList.remove("is-busy");go.disabled=!1}
function reset(){stop();sel.value="";q.value="0";err.hidden=!0;out.innerHTML=empty;cur=null;show("");live.textContent="Cleared. Choose a sample and press Check."}
function result(id){const s=SMP[id],lv=REQ[+q.value],r=adjust(s,lv.w,lv.p),v=band(r,s.kind),flags=[...s.flags];if(+q.value)flags.push(`${lv.t}: fewer details to read, confidence lowered`);
const rid="FP-R-0"+(n++),js={report_id:rid,sample:id,media_type:s.kind,synthetic_sample:!0,likelihood:{low:+f2(r.lo),high:+f2(r.hi),estimate:+f2(r.pt)},verdict_band:v.toLowerCase().replace(/ /g,"_"),
flags,highlights:s.arts.map(a=>({id:a.id,note:a.h,signal:a.k,contributes:a.w})),provenance:Object.fromEntries(s.prov.map(p=>[p[0].toLowerCase().replace(/ /g,"_"),p[1]])),model:s.model,
custody:[{step:"received",sha256:s.hash},{step:"checked",model:s.model},{step:"report",id:rid}],note:"Synthetic sample. A probabilistic signal for review, not proof."};
const summary=v==="Inconclusive"?"The evidence is mixed or thin. Do not rely on this result: find the original, check provenance and ask a person.":v==="Leans synthetic"?"The file shows several signs of synthesis. Treat this as a signal for review, not proof.":"No strong sign of synthesis was found. A clear result still needs your usual checks.";
out.innerHTML=`<div class="fp-res__g">${gblock(r,v)}<div class="fp-res__s"><p class="fp-res__sum">${esc(summary)}</p>${flags.length?`<ul class="fp-flags">${flags.map(f=>`<li>${esc(f)}</li>`).join("")}</ul>`:`<p class="fp-mute">No confidence flags for this file.</p>`}</div></div>
<div class="fp-res__p"><p class="mv-mi">Provenance</p><ul class="fp-prov__l">${s.prov.map(p=>`<li><span>${esc(p[0])}</span><b>${esc(p[1])}</b><span class="mv-tag mv-tag--${p[2]}">${/not run/i.test(p[1])?"Not run":/not used/i.test(p[1])?"Not applicable":TAG[p[2]]}</span></li>`).join("")}</ul></div>
<div class="fp-res__p"><p class="mv-mi">Limits</p><ul class="fp-lims">${s.lim.map(l=>`<li>${esc(l)}</li>`).join("")}</ul></div>
<div class="fp-res__rep"><div class="fp-res__rh"><p class="fp-mono">Evidence report · ${rid} · Synthetic</p><button type="button" class="fp-btn2" data-mc-json aria-pressed="false" aria-controls="mc-json">Show as JSON</button></div>
<p class="fp-res__rl">${esc(id)} · ${esc(s.type)} · model ${esc(s.model)} · ${s.arts.length} highlight${s.arts.length>1?"s":""}</p><pre class="fp-pre" id="mc-json" hidden><code>${esc(JSON.stringify(js,null,2))}</code></pre></div>`;
$("[data-mc-json]",out).addEventListener("click",e=>{const b=e.currentTarget,on=b.getAttribute("aria-pressed")!=="true";b.setAttribute("aria-pressed",String(on));b.textContent=on?"Hide JSON":"Show as JSON";$("#mc-json",out).hidden=!on});
list.innerHTML=`<p class="mv-mi">Highlights · select one to ring it on the file</p><ul>${s.arts.map((a,i)=>`<li><button type="button" class="fp-art" data-i="${i}" aria-pressed="false"><span class="fp-mono">${a.id}</span><b>${esc(a.h)}</b><small>${esc(a.p)} ${a.k} · contributes ${f2(a.w)}${a.a===null?" · whole file":""}</small></button></li>`).join("")}</ul>`;
$$(".fp-art",list).forEach(b=>b.addEventListener("click",()=>{const on=b.getAttribute("aria-pressed")!=="true";$$(".fp-art",list).forEach(x=>x.setAttribute("aria-pressed","false"));b.setAttribute("aria-pressed",String(on));
const a=s.arts[+b.dataset.i].a;ring(on?a:null);if(on&&a!==null&&!stage.classList.contains("is-heat"))toggleHeat(!0);live.textContent=on?(a===null?`${s.arts[+b.dataset.i].h}: applies to the whole file.`:`${s.arts[+b.dataset.i].h}: ringed on the file.`):"Highlight cleared."}));
heat.disabled=!1;toggleHeat(!0);out.classList.remove("is-in");void out.offsetWidth;out.classList.add("is-in");
live.textContent=`${id} checked. ${v}. Likelihood ${f2(r.lo)} to ${f2(r.hi)}.${flags.length?" "+flags.length+" confidence flag"+(flags.length>1?"s":"")+".":""}`}
function toggleHeat(on){stage.classList.toggle("is-heat",on);heat.setAttribute("aria-pressed",String(on));heat.textContent=on?"Hide heatmap":"Show heatmap"}
function run(){err.hidden=!0;const id=sel.value;if(!SMP[id]){err.textContent="Choose a sample first. Four labelled samples are in the list.";err.hidden=!1;sel.focus();live.textContent="";return}
stop();show(id);cur=id;out.innerHTML=`<div class="fp-empty"><p class="mv-h3">Checking ${esc(id)}.</p><p class="mv-p">Decoding, reading the signals and calibrating the range.</p></div>`;
if(RM){steps.forEach(l=>l.className="is-done");result(id);return}
root.classList.add("is-busy");go.disabled=!0;let i=0;const tick=()=>{steps.forEach((l,j)=>l.className=j<i?"is-done":j===i?"is-on":"");if(i>=steps.length){stop();result(id);go.focus();return}i++;timer=setTimeout(tick,230)};tick()}
sel.addEventListener("change",()=>{err.hidden=!0;if(!timer){show(sel.value);if(cur){out.innerHTML=empty;cur=null}}});
q.addEventListener("change",()=>{if(timer)return;if(cur){result(cur);return}const lv=REQ[+q.value];out.innerHTML=`<div class="fp-empty"><p class="mv-h3">${+q.value?esc(lv.t)+" before the check.":"The file will be checked as received."}</p><p class="mv-p">${+q.value?"A worse copy carries less evidence, so expect a wider range and a confidence flag.":"Choose a sample and press Check."}</p></div>`;live.textContent=lv.t});
go.addEventListener("click",run);rs.addEventListener("click",reset);
heat.addEventListener("click",()=>toggleHeat(heat.getAttribute("aria-pressed")!=="true"));show("")}
/* ---------- home live meter */
function mini(root){const s=$("input[type=range]",root),o=$("output",root),out=$("[data-mini-out]",root),b=SMP["SMP-01"];
const draw=()=>{const qv=+s.value,f=(100-qv)/70,r=adjust(b,.13*f,.35*f);o.textContent=qv>=100?"As received":"Quality "+qv;out.innerHTML=gblock(r,band(r,"image"))+(qv<100?`<p class="fp-flag">Recompressed to quality ${qv}: confidence lowered.</p>`:`<p class="fp-mute">No confidence flags.</p>`)};
s.addEventListener("input",draw);draw()}
/* ---------- benchmark filter */
function bench(root){const m=$("[data-bt-m]",root),f=$("[data-bt-f]",root),sum=$("[data-bt-sum]",root),em=$("[data-bt-empty]",root),rows=$$("tbody tr",root);
const go=()=>{let n=0;rows.forEach(r=>{const ok=(!m.value||r.dataset.m===m.value)&&(!f.checked||r.dataset.st==="fail");r.hidden=!ok;n+=ok});sum.textContent=`${n} condition${n===1?"":"s"} shown`;em.hidden=n>0};
m.addEventListener("change",go);f.addEventListener("change",go);go()}
function scrollers(){$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}})}
export function boot(){scrollers();addEventListener("resize",scrollers);$$("[data-fp=check]").forEach(check);$$("[data-fp=mini]").forEach(mini);$$("[data-fp=bench]").forEach(bench)}
