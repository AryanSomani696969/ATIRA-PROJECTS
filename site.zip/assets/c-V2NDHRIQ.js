import{B as Torus}from"./c-5CYXJTUX.js";
/* Cohortsherpa hero: a lattice of de-identified patient dots on a deep green floor.
   Two criteria rings sweep the lattice in turn; dots that fail a criterion dim, dots that pass stay lit.
   The five strongest matches rise into a ranked list of cards. 12 second cycle; scrolling holds the ranked state
   and opens the first card. Everything here is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(41);
const bg=new T.Color(colors.bg),ink=new T.Color(colors.ink),orange=new T.Color(color("--mv-signal","#f28c28")),mint=new T.Color(color("--cs-mint","#ddebdd"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),7,17);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xcfe0d4,.8));
const key=new T.DirectionalLight(0xfff1dd,1);key.position.set(-3,7,5);root.add(key);
const rim=new T.DirectionalLight(orange.getHex(),.3);rim.position.set(6,2,-5);root.add(rim);
/* lattice */
const CX=small?15:22,CZ=small?10:14,G=.42,N=CX*CZ,D=[];
for(let j=0;j<CZ;j++)for(let i=0;i<CX;i++){const x=(i-(CX-1)/2)*G+(R()-.5)*.05,z=(j-(CZ-1)/2)*G+(R()-.5)*.05;D.push({x,z,a:R()<.62,b:R()<.58,s:R(),m:0})}
const pool=D.map((d,i)=>[d,i]).filter(([d])=>d.a&&d.b).sort((p,q)=>q[0].s-p[0].s),TOP=pool.slice(0,5).map(([,i])=>i);TOP.forEach((i,r)=>{D[i].m=r+1});
const dGeo=new T.SphereGeometry(.05,10,8),dMat=new T.MeshStandardMaterial({color:0xffffff,roughness:.5,metalness:0,emissive:0x000000}),
inst=new T.InstancedMesh(dGeo,dMat,N),o=new T.Object3D,tc=new T.Color;root.add(inst);
const grid=[];for(let i=0;i<CX;i++){const x=(i-(CX-1)/2)*G;grid.push(x,-.06,-(CZ-1)/2*G,x,-.06,(CZ-1)/2*G)}for(let j=0;j<CZ;j++){const z=(j-(CZ-1)/2)*G;grid.push(-(CX-1)/2*G,-.06,z,(CX-1)/2*G,-.06,z)}
const gg=new T.BufferGeometry;gg.setAttribute("position",new T.Float32BufferAttribute(grid,3));root.add(new T.LineSegments(gg,new T.LineBasicMaterial({color:ink.clone().lerp(bg,.8),transparent:!0,opacity:.5})));
/* criteria rings, lying flat */
const mk=(r,c)=>{const m=new T.MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:.35,roughness:.4,metalness:.2,transparent:!0,opacity:.95});const t=new T.Mesh(new Torus(r,.026,10,small?48:80),m);t.rotation.x=Math.PI/2;t.position.y=.02;root.add(t);return t};
const RA=1.25,RB=.95,ringA=mk(RA,ink.clone()),ringB=mk(RB,orange.clone());
/* ranked cards */
const cardGeo=new T.BoxGeometry(1.7,.3,.02),cards=TOP.map((_,r)=>{const m=new T.MeshStandardMaterial({color:ink.clone(),emissive:ink.clone(),emissiveIntensity:.15,roughness:.8,transparent:!0,opacity:0});const c=new T.Mesh(cardGeo,m);c.position.set(3.35,2.25-r*.42,.6);root.add(c);return c});
const gapGeo=new T.BoxGeometry(.22,.06,.03),gap=new T.Mesh(gapGeo,new T.MeshBasicMaterial({color:orange.clone(),transparent:!0,opacity:0}));gap.position.set(3.95,2.25,.62);root.add(gap);
const C0=new T.Vector3(.2,4.1,7.4),look=new T.Vector3(.9,.55,0),lk=new T.Vector3;camera.fov=38;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const dim=bg.clone().lerp(ink,.2),base=ink.clone().lerp(bg,.25);
function sweep(c,t0,t1){return lerp(-(CX/2)*G-1.6,(CX/2)*G+1.6,ease(clamp((c-t0)/(t1-t0))))}
function frame(t,dt,p){
const hold=clamp((p-.56)/.28),c0=t%12,c=hold>0?lerp(c0,9.6,ease(hold)):c0;
const turn=Math.sin(t/12*Math.PI*2)*.35;
camera.position.set(C0.x+turn+pointer.x*.25,C0.y-pointer.y*.15,C0.z);lk.copy(look);lk.x+=pointer.x*.08;camera.lookAt(lk);
const ax=sweep(c,.4,4),bx=sweep(c,3.6,7.2),rise=ease(clamp((c-7.2)/1.8)),reset=c>11?ease((c-11)):0;
ringA.position.x=ax;ringB.position.x=bx;ringA.material.opacity=c<4.3?.95:Math.max(0,.95-(c-4.3)*1.5);ringB.material.opacity=c>3.4&&c<7.6?.95:Math.max(0,c<3.4?0:.95-(c-7.6)*1.5);
for(let k=0;k<N;k++){const d=D[k],ka=ax>d.x+.1?1:0,kb=bx>d.x+.1?1:0,out=(ka&&!d.a)||(kb&&!d.b);
let y=0,x=d.x,z=d.z,s=1;tc.copy(base);
if(out)tc.copy(dim);else if(ka&&kb)tc.copy(base).lerp(mint,.6);
if(d.m){const e=rise*(1-reset),slot=cards[d.m-1].position;x=lerp(d.x,slot.x-.7,e);y=lerp(0,slot.y,e);z=lerp(d.z,slot.z+.04,e);s=1+e*.6;if(kb)tc.copy(mint).lerp(orange,e)}
if(reset&&!d.m)tc.lerp(base,reset);
o.position.set(x,y,z);o.scale.setScalar(s);o.updateMatrix();inst.setMatrixAt(k,o.matrix);inst.setColorAt(k,tc)}
inst.instanceMatrix.needsUpdate=!0;inst.instanceColor.needsUpdate=!0;
cards.forEach((cd,r)=>{const e=clamp(rise*1.4-r*.12)*(1-reset);cd.material.opacity=e*.92;cd.scale.x=r===0?1+hold*.25:1;cd.position.y=2.25-r*.42+(r===0?0:-hold*.12)});
gap.material.opacity=hold*.9*(1-reset);gap.position.x=3.95+hold*.2}
return{frame,resize:(w,h)=>{C0.z=w/h<.8?10.5:7.4;look.x=w/h<.8?1.6:.9},dispose:()=>{[dGeo,gg,ringA.geometry,ringB.geometry,cardGeo,gapGeo].forEach(g=>g.dispose())}}}
