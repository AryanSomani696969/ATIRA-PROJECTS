/* Closesherpa page tools. Everything runs in the browser on sample data for SHOP-14, a synthetic homewares shop;
   nothing typed here leaves the page.
   [data-cl=runway]  Runway Calculator: cash, monthly flows, big payments -> runway, low point, 13-week curve (arrow keys read each week)
   [data-cl=mini]    the same engine with one slider (home page)
   [data-cl=whatif]  sample 13-week forecast with three what-if scenarios
   [data-cl=ask]     sample questions answered with the entries behind them, one with missing data
   [data-cl=ledger]  review queue: approve or recode six bank lines, lowest confidence first */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const usd=v=>(v<0?"-":"")+"$"+Math.round(Math.abs(v)).toLocaleString("en-US"),k=v=>(v<0?"-":"")+"$"+(Math.abs(v)/1000).toFixed(1)+"k";
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches,WK=12/52;
const num=s=>{const t=String(s).replace(/[$,\s]/g,"");if(t==="")return null;const v=Number(t);return isFinite(v)?v:NaN};
/* ---------- engine: weekly balances for 13 weeks, then the runway at the same rate */
function project(cash,inM,outM,pays){const net=(inM-outM)*WK,b=[cash];let x=cash,out=null;
for(let w=1;w<=13;w++){x+=net-pays.filter(p=>p.w===w).reduce((s,p)=>s+p.a,0);b.push(x);if(out===null&&x<0)out=w}
let run=out;if(run===null){if(net>=0)run=Infinity;else{run=13+Math.floor(x/-net)+1}}
let lo=0;b.forEach((v,i)=>{if(v<b[lo])lo=i});return{b,net,run,lo}}
/* ---------- chart: a ledger line for the week behind, the forecast after, payments as ticks, the low point in saffron */
function chart(b,o={}){const W=640,Hh=230,L=46,Rr=620,T=18,B=190,mx=Math.max(...b,...(o.base||[]),1),mn=Math.min(0,...b,...(o.base||[])),
X=i=>L+(Rr-L)*i/13,Y=v=>B-(B-T)*(v-mn)/(mx-mn||1);
const path=a=>a.map((v,i)=>(i?"L":"M")+X(i).toFixed(1)+" "+Y(v).toFixed(1)).join(" ");
let g=`<line class="cl-ch-base" x1="${L}" y1="${Y(0).toFixed(1)}" x2="${Rr}" y2="${Y(0).toFixed(1)}"/>`;
if(o.buffer!=null&&o.buffer<mx)g+=`<line class="cl-ch-buf" x1="${L}" y1="${Y(o.buffer).toFixed(1)}" x2="${Rr}" y2="${Y(o.buffer).toFixed(1)}"/><text class="cl-ax" x="${Rr}" y="${(Y(o.buffer)-6).toFixed(1)}" text-anchor="end">Buffer ${k(o.buffer)}</text>`;
g+=`<text class="cl-ax" x="${L-8}" y="${(Y(mx)+4).toFixed(1)}" text-anchor="end">${k(mx)}</text><text class="cl-ax" x="${L-8}" y="${(Y(0)+4).toFixed(1)}" text-anchor="end">$0</text>`;
(o.pays||[]).forEach(p=>{g+=`<line class="cl-ch-due" x1="${X(p.w).toFixed(1)}" y1="${T}" x2="${X(p.w).toFixed(1)}" y2="${B}"/>`});
for(let i=0;i<=13;i+=1)g+=`<text class="cl-ax" x="${X(i).toFixed(1)}" y="${B+22}" text-anchor="middle">${i===0?"Now":i%2?"":"W"+i}</text>`;
if(o.base)g+=`<path class="cl-ch-alt" d="${path(o.base)}"/>`;
g+=`<path class="cl-ch-line${o.anim?" is-anim":""}" pathLength="1" d="${path(b)}"/><circle class="cl-ch-low" cx="${X(o.lo).toFixed(1)}" cy="${Y(b[o.lo]).toFixed(1)}" r="6"/>`;
g+=`<g class="cl-ch-cur" data-cur hidden><line x1="0" y1="${T}" x2="0" y2="${B}"/><circle r="5" cy="0"/></g>`;
return{svg:`<svg class="cl-chart" viewBox="0 0 ${W} ${Hh}" aria-hidden="true" focusable="false">${g}</svg>`,X,Y}}
/* a chart the keyboard can read: role=slider over the 14 points */
function readable(host,b,geo,label){const box=$(".cl-chartw",host),cur=$("[data-cur]",host),rd=$("[data-read]",host);if(!box)return;let i=0;
const show=n=>{i=Math.max(0,Math.min(13,n));const t=(i?"Week "+i:"Now")+": "+usd(b[i]);box.setAttribute("aria-valuenow",i);box.setAttribute("aria-valuetext",t);
cur.hidden=!1;cur.setAttribute("transform",`translate(${geo.X(i).toFixed(1)} 0)`);$("circle",cur).setAttribute("cy",geo.Y(b[i]).toFixed(1));rd.textContent=t};
box.addEventListener("keydown",e=>{const m={ArrowRight:1,ArrowUp:1,ArrowLeft:-1,ArrowDown:-1}[e.key];if(m){e.preventDefault();show(i+m)}else if(e.key==="Home"){e.preventDefault();show(0)}else if(e.key==="End"){e.preventDefault();show(13)}});
box.addEventListener("focus",()=>show(i));box.addEventListener("pointermove",e=>{const r=box.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*640;show(Math.round((x-46)/(574)*13))});
box.addEventListener("click",e=>{const r=box.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*640;show(Math.round((x-46)/(574)*13))});box.setAttribute("aria-label",label)}
function chartBox(svg,label){return`<div class="cl-chartw" tabindex="0" role="slider" aria-valuemin="0" aria-valuemax="13" aria-valuenow="0" aria-label="${esc(label)}">${svg}</div><p class="cl-read" data-read>Use the arrow keys or point at the chart to read each week.</p>`}
function runText(r){return r.run===Infinity?"Cash grows at this rate":r.run>156?"More than 3 years":r.run+" weeks"}
/* ---------- Runway Calculator */
const SAMPLE={cash:"48,200",in:"88,000",out:"91,500",pays:[["Holiday restock",3,"18,000"],["Sales tax payment",7,"7,400"],["Equipment lease renewal",10,"4,800"]]};
function runway(root){const f=$("[data-rw-form]",root),out=$("[data-rw-out]",root),live=$("[data-rw-live]",root),F={cash:$("#rw-cash"),in:$("#rw-in"),out:$("#rw-out")};
const rows=$$(".cl-pay",root);let anim=!RM;
function err(inp,msg){const id=inp.id+"-err";let p=document.getElementById(id);if(msg){if(!p){p=document.createElement("p");p.className="err";p.id=id;inp.closest(".fld,.cl-pay").append(p)}p.textContent=msg;inp.setAttribute("aria-invalid","true")}else{p&&p.remove();inp.removeAttribute("aria-invalid")}}
function calc(){const v={},bad=[];for(const key of["cash","in","out"]){const x=num(F[key].value);v[key]=x;if(Number.isNaN(x)||(x!==null&&x<0)){err(F[key],"Enter an amount in dollars, like 48,200.");bad.push(key)}else err(F[key],"")}
const pays=[];rows.forEach(r=>{const a=$("[data-rw-pa]",r),x=num(a.value);if(Number.isNaN(x)||(x!==null&&x<0)){err(a,"Enter an amount, or leave it empty.");bad.push("p")}else{err(a,"");if(x)pays.push({w:+$("[data-rw-pw]",r).value,a:x,l:$("[data-rw-pl]",r).value.trim()||"Payment"})}});
if(bad.length){out.innerHTML=`<div class="cl-err" role="alert"><b>Check the highlighted ${bad.length>1?"fields":"field"}.</b> Amounts are in US dollars, without letters. Commas are fine.</div>`;live.textContent="Check the highlighted fields.";return}
if(v.cash===null||v.in===null||v.out===null){const pl0=pays.length?`<p class="cl-read">Big payments entered so far</p><ul class="cl-plist">${pays.slice().sort((a,b)=>a.w-b.w).map(p=>`<li><span class="cl-mono">Week ${p.w}</span><span>${esc(p.l)}</span><b class="cl-mono">${usd(-p.a)}</b></li>`).join("")}</ul>`:"";out.innerHTML=`<div class="cl-empty"><b>Enter your numbers to see your runway.</b><p>Cash in the bank today, plus your average money in and out each month. Or load the sample data.</p></div>`+pl0;live.textContent="Waiting for cash balance and monthly figures.";return}
const r=project(v.cash,v.in,v.out,pays),geo=chart(r.b,{lo:r.lo,pays,anim});anim=!1;
const pl=pays.length?`<ul class="cl-plist">${pays.slice().sort((a,b)=>a.w-b.w).map(p=>`<li><span class="cl-mono">Week ${p.w}</span><span>${esc(p.l)}</span><b class="cl-mono">${usd(-p.a)}</b></li>`).join("")}</ul>`:"";
out.innerHTML=`<div class="cl-kpis"><div><span>Runway</span><b>${runText(r)}</b></div><div><span>Lowest balance, 13 weeks</span><b>${usd(r.b[r.lo])}</b><small>${r.lo?"Week "+r.lo:"Now"}</small></div><div><span>Change each week</span><b>${usd(r.net)}</b><small>before big payments</small></div></div>`+
(r.b[r.lo]<0?`<p class="cl-gap">Cash goes below zero in week ${r.b.findIndex(x=>x<0)}. Move a payment, chase a receivable or line up credit before then.</p>`:r.run!==Infinity&&r.run<=26?`<p class="cl-gap">At this rate cash runs out in about ${r.run} weeks. The fuller report shows which receivables and bills move that date.</p>`:`<p class="cl-gap cl-gap--ok">No week in the next 13 goes below zero at these figures.</p>`)+
chartBox(geo.svg,"13-week cash forecast")+pl;
readable(out,r.b,geo,"13-week cash forecast. Use the arrow keys to read each week.");
live.textContent=`Runway: ${runText(r)}. Lowest balance ${usd(r.b[r.lo])} ${r.lo?"in week "+r.lo:"now"}.`}
f.addEventListener("input",calc);f.addEventListener("change",calc);
$("[data-rw-replay]",root).addEventListener("click",()=>{anim=!RM;calc();const rd=$("[data-read]",out);if(rd)rd.textContent="Redrawn from today's balance. Use the arrow keys to read each week.";else{const e=$(".cl-empty p",out);e&&(e.textContent="There is nothing to draw yet. Enter your cash balance and monthly figures first.")}});
$("[data-rw-clear]",root).addEventListener("click",()=>{Object.values(F).forEach(i=>i.value="");calc();F.cash.focus()});
$("[data-rw-sample]",root).addEventListener("click",()=>{F.cash.value=SAMPLE.cash;F.in.value=SAMPLE.in;F.out.value=SAMPLE.out;rows.forEach((r,i)=>{const s=SAMPLE.pays[i];$("[data-rw-pl]",r).value=s[0];$("[data-rw-pw]",r).value=s[1];$("[data-rw-pa]",r).value=s[2]});anim=!RM;calc()});
calc()}
/* ---------- home mini */
function mini(root){const s=$("input[type=range]",root),o=$("output",root),out=$("[data-mini-out]",root),pays=[{w:3,a:18000},{w:7,a:7400},{w:10,a:4800}];
const go=()=>{const v=+s.value;o.textContent=usd(v);const r=project(48200,88000,v,pays),geo=chart(r.b,{lo:r.lo,pays});
out.innerHTML=`<div class="cl-kpis cl-kpis--s"><div><span>Runway</span><b>${runText(r)}</b></div><div><span>Low point</span><b>${usd(r.b[r.lo])}</b><small>${r.lo?"Week "+r.lo:"Now"}</small></div></div><div class="cl-minichart">${geo.svg}</div>`};
s.addEventListener("input",go);go()}
/* ---------- what-if forecast for SHOP-14 */
function whatif(root){const out=$("[data-wi-out]",root),live=$("[data-wi-live]",root),btns=$$("[data-wi]",root),BUF=10000;
const base=()=>{const inW=Array(14).fill(88000*WK),outW=Array(14).fill(91500*WK);outW[3]+=18000;outW[7]+=7400;outW[10]+=4800;inW[0]=outW[0]=0;return{inW,outW}};
const SC={late:f=>{f.inW[4]-=12400;f.inW[7]+=12400},bulk:f=>{f.outW[6]+=15000},hire:f=>{for(let w=5;w<=13;w++)f.outW[w]+=4300*WK}};
const run=f=>{const b=[48200];for(let w=1;w<=13;w++)b.push(b[w-1]+f.inW[w]-f.outW[w]);return b};
const ref=run(base());
function go(anim){const on=btns.filter(x=>x.getAttribute("aria-pressed")==="true").map(x=>x.dataset.wi),f=base();on.forEach(s=>SC[s](f));const b=run(f);let lo=0;b.forEach((v,i)=>{if(v<b[lo])lo=i});
const below=b.filter((v,i)=>i&&v<BUF).length,geo=chart(b,{lo,buffer:BUF,base:on.length?ref:null,pays:[{w:3},{w:7},{w:10}],anim});
out.innerHTML=`<div class="cl-kpis"><div><span>Low point</span><b>${usd(b[lo])}</b><small>${lo?"Week "+lo:"Now"}</small></div><div><span>Weeks below the $10,000 buffer</span><b>${below}</b></div><div><span>Cash in week 13</span><b>${usd(b[13])}</b></div></div>`+
(b[lo]<0?`<p class="cl-gap">With ${on.length>1?"these scenarios":"this scenario"} cash goes below zero in week ${b.findIndex(x=>x<0)}.</p>`:on.length?`<p class="cl-gap">${on.length} scenario${on.length>1?"s":""} on. The dashed line is the forecast without ${on.length>1?"them":"it"}.</p>`:`<p class="cl-gap cl-gap--ok">Base forecast: three large payments in weeks 3, 7 and 10. Turn on a scenario to compare.</p>`)+
chartBox(geo.svg,"Sample 13-week forecast");readable(out,b,geo,"Sample 13-week forecast. Use the arrow keys to read each week.");
live.textContent=`Low point ${usd(b[lo])} ${lo?"in week "+lo:"now"}. ${below} weeks below the buffer.`}
btns.forEach(x=>x.addEventListener("click",()=>{x.setAttribute("aria-pressed",x.getAttribute("aria-pressed")==="true"?"false":"true");go(!RM)}));
$("[data-wi-reset]",root).addEventListener("click",()=>{btns.forEach(x=>x.setAttribute("aria-pressed","false"));go(!RM)});go(!1)}
/* ---------- sample answers */
const ANS={margin:{q:"Why did gross margin fall in October?",meta:"Answered from 412 entries",a:"Gross margin fell from <b>46.7%</b> in September to <b>42.4%</b> in October. Three entries explain most of the 4.3 point drop, and a better sales mix won back 0.8 points.",
h:["Entry","Date","What it is","Amount","Effect"],r:[["JE-1042","Oct 06","Freight carrier invoice 3317, coded to freight in","$2,140","-2.5 pts"],["JE-1031","Oct 03","Cookware restock at the new unit cost, up 9%","$14,620","-1.4 pts"],["JE-1077","Oct 24","Weekend sale, 15% off two ranges","$1,900","-1.2 pts"],["Mix","Oct","More sales in higher-margin lines","","+0.8 pts"]],
f:"Computed from the ledger: revenue $86,400, cost of goods $49,800. Last month: $81,200 and $43,300."},
owes:{q:"Who owes us the most?",meta:"Receivables aging, Nov 27",a:"Wholesale account <b>W-07</b> owes the most: <b>$12,400</b>, invoiced 41 days ago and 11 days past its 30-day terms. Three accounts owe $21,530 in all.",
h:["Invoice","Date","Account","Amount","Age"],r:[["INV-2207","Oct 17","Wholesale account W-07","$12,400","41 days"],["INV-2213","Oct 25","Wholesale account W-02","$6,150","33 days"],["INV-2231","Nov 09","Trade account T-11","$2,980","18 days"]],
f:"From the open invoices in the ledger. Card settlements due in the next two days are left out."},
restock:{q:"Can we afford the holiday restock?",meta:"13-week forecast",a:"Yes, if nothing else changes. After the <b>$18,000</b> restock in week 3, cash stays above zero, but falls to <b>$7,500</b> by week 13, under the $10,000 buffer from week 10.",
h:["Week","Item","Source","Amount","Balance after"],r:[["W3","Holiday restock","Purchase order 0412","-$18,000","$27,777"],["W7","Sales tax payment","Sales tax liability account","-$7,400","$17,146"],["W10","Equipment lease renewal","Recurring bill","-$4,800","$9,923"],["Each week","Money in less money out","Monthly averages","-$808",""]],
f:"From the forecast: opening cash $48,200, money in $88,000 and out $91,500 a month, spread across weeks."},
software:{q:"What did we spend on software last quarter?",meta:"Data missing",miss:1,a:"I cannot give a total from these books. There is <b>no software category</b>, so subscriptions are mixed into office expenses. Fourteen entries from August to October look like software, adding up to <b>$1,246</b>. Confirm them and I will answer.",
h:["Entry","Date","Bank line","Amount","Coded to"],r:[["JE-0912","Aug 18","SUBSCRIPTION 22 MONTHLY","$89","Office expenses"],["JE-0967","Sep 02","ANNUAL PLAN 7781","$468","Office expenses"],["JE-1088","Oct 18","SUBSCRIPTION 22 MONTHLY","$89","Office expenses"],["11 more","Aug to Oct","Similar lines","$600","Office expenses"]],
f:"Nothing was added up or guessed. Ask your accountant to add a software category, or recode these lines in Books."}};
function ansHTML(x){return`<figure class="mv-panel cl-ans${x.miss?" cl-ans--miss":""}" aria-label="A traceable answer"><div class="mv-panel__h mv-panel__h--mi"><span>Ask / SHOP-14</span><b>${esc(x.meta)}</b></div><p class="cl-ans__q"><span class="mv-mi">Question</span>${esc(x.q)}</p><div class="cl-ans__a"><p>${x.a}</p></div>`+
`<div class="mv-pscroll" data-label="Entries behind the answer"><table class="mv-ptable"><thead><tr>${x.h.map(h=>`<th scope="col">${h}</th>`).join("")}</tr></thead><tbody>${x.r.map(r=>`<tr>${r.map((c,i)=>`<td${i===0||i>2?' class="cl-mono"':""}>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div><p class="cl-ans__f">${esc(x.f)}</p><span class="mv-sample">Sample data</span></figure>`}
function ask(root){const tabs=$$("[role=tab]",root),out=$("[data-ak-out]",root);
const sel=(t,focus)=>{tabs.forEach(x=>{const on=x===t;x.setAttribute("aria-selected",on);x.tabIndex=on?0:-1});out.setAttribute("aria-labelledby",t.id);out.innerHTML=ansHTML(ANS[t.dataset.ak]);out.classList.remove("is-in");void out.offsetWidth;out.classList.add("is-in");scrollers();focus&&t.focus()};
tabs.forEach((t,i)=>{t.addEventListener("click",()=>sel(t));t.addEventListener("keydown",e=>{const m={ArrowRight:1,ArrowDown:1,ArrowLeft:-1,ArrowUp:-1}[e.key];if(m){e.preventDefault();sel(tabs[(i+m+tabs.length)%tabs.length],1)}else if(e.key==="Home"){e.preventDefault();sel(tabs[0],1)}else if(e.key==="End"){e.preventDefault();sel(tabs[tabs.length-1],1)}})});
out.setAttribute("aria-labelledby",tabs[0].id)}
/* ---------- review queue */
const CATS=["Sales: card","Cost of goods: inventory","Cost of goods: freight in","Payroll: wages","Payroll tax deposit","Office expenses","Software subscriptions","Transfer (not an expense)"];
const LEDGER=[["Sales: card",.98],["Cost of goods: inventory",.94],["Cost of goods: freight in",.71],["Payroll: wages",.99],["Payroll tax deposit",.92],["Office expenses",.54]];
function ledger(root){const list=$(".cl-lg__l",root),sum=$("[data-lg-sum]",root),learn=$("[data-lg-learn]",root),rows=$$(".cl-lr",root);
rows.sort((a,b)=>LEDGER[a.dataset.i][1]-LEDGER[b.dataset.i][1]).forEach(r=>list.append(r));
const st=rows.map(()=>({ok:!1,cat:null}));
function paint(){let n=0;rows.forEach(r=>{const i=+r.dataset.i,s=st[i],sel=$("[data-lg-cat]",r),c=$("[data-lg-conf]",r),b=$("[data-lg-ok]",r),[cat,conf]=LEDGER[i];
if(!sel.options.length)sel.innerHTML=CATS.map(x=>`<option>${esc(x)}</option>`).join("");sel.value=s.cat||cat;
const changed=s.cat&&s.cat!==cat;c.textContent=changed?"Set by you":conf.toFixed(2);c.className="cl-conf"+(changed?" is-you":conf<.8?" is-lo":"");
r.classList.toggle("is-ok",s.ok);b.textContent=s.ok?"Undo":"Approve";b.setAttribute("aria-label",(s.ok?"Undo approval for ":"Approve ")+$("b",r).textContent);if(s.ok)n++});
sum.textContent=n===rows.length?"All 6 lines approved. Ready to post.":`${n} of ${rows.length} approved · ${rows.length-n} to review`}
rows.forEach(r=>{const i=+r.dataset.i;$("[data-lg-cat]",r).addEventListener("change",e=>{st[i].cat=e.target.value;st[i].ok=!1;const p=$("b",r).textContent.split(" ").slice(0,2).join(" ");
learn.textContent=e.target.value===LEDGER[i][0]?"":`Learned: lines from ${p} will be suggested as ${e.target.value} next time.`;paint()});
$("[data-lg-ok]",r).addEventListener("click",()=>{st[i].ok=!st[i].ok;paint()})});
$("[data-lg-reset]",root).addEventListener("click",()=>{st.forEach(s=>{s.ok=!1;s.cat=null});learn.textContent="Queue reset: every line is back to its suggested category, nothing approved.";paint()});paint()}
function scrollers(){$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}})}
export function boot(){scrollers();addEventListener("resize",scrollers);$$("[data-cl=runway]").forEach(runway);$$("[data-cl=mini]").forEach(mini);$$("[data-cl=whatif]").forEach(whatif);$$("[data-cl=ask]").forEach(ask);$$("[data-cl=ledger]").forEach(ledger)}
