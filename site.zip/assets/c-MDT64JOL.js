/* Creditcairn page tools. Run offline in the browser; nothing changed here leaves the page.
   [data-cc=explorer]  Cash-Flow Explorer: synthetic business + inflow level, seasonal swing, customer share, opening balance
                       -> cash-flow features, score 1-100 with band, five reasons by impact, sample lender policy check
   [data-cc=mini]      the same engine on four synthetic businesses (home page) */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),sum=a=>a.reduce((x,y)=>x+y,0),mean=a=>sum(a)/a.length;
const MON=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const fmtK=v=>(v<0?"-$":"$")+Math.abs(Math.round(v)).toLocaleString("en-US")+"K";
/* feature weights: they sum to 1, and each subscore only rises as the feature improves (monotonic) */
const W={buf:.27,stab:.2,mar:.2,con:.2,sea:.13};
const NAME={stab:["CF01","Inflow stability"],buf:["CF02","Cash buffer"],mar:["CF03","Net margin"],sea:["CF04","Seasonality"],con:["CF05","Customer concentration"]};
function readBiz(el){return{id:el.dataset.id,sector:el.dataset.sector,inf:el.dataset.in.split(",").map(Number),out:el.dataset.out.split(",").map(Number),top:+el.dataset.top,open:+el.dataset.open}}
function compute(b,o){
const level=o.level||0,season=o.season==null?100:o.season,top=(o.top==null?b.top:o.top)/100,open=o.open==null?b.open:o.open;
const m0=mean(b.inf),inf=b.inf.map(v=>Math.max(0,(m0+(v-m0)*season/100)*(1+level/100))),out=b.out;
const mi=mean(inf),sd=Math.sqrt(mean(inf.map(v=>(v-mi)**2))),cv=mi?sd/mi:1;
let bal=open;const bals=inf.map((v,i)=>bal+=v-out[i]);
const neg=bals.filter(v=>v<0).length,days=Math.max(0,mean(bals)/(mean(out)/30));
const margin=sum(inf)?(sum(inf)-sum(out))/sum(inf):-1,ratio=Math.max(...inf)?Math.min(...inf)/Math.max(...inf):0;
const s={stab:clamp((.45-cv)/.4),buf:clamp(days/60)*Math.max(0,1-neg*.25),mar:clamp((margin+.05)/.2),sea:clamp((ratio-.15)/.75),con:clamp((.75-top)/.65)};
const score=Math.round(1+99*Object.keys(W).reduce((a,k)=>a+W[k]*s[k],0));
const band=score>=80?["A","low risk"]:score>=65?["B","moderate risk"]:score>=50?["C","elevated risk"]:score>=35?["D","high risk"]:["E","very high risk"];
const f={cv,days,neg,margin,ratio,top};
const pct=v=>Math.round(v*100)+"%";
const txt={stab:s.stab>=.75?`Monthly inflows vary by ${pct(cv)} around the average, which is steady.`:`Monthly inflows vary by ${pct(cv)} around the average, so income is hard to predict.`,
buf:neg?`The balance went below zero in ${neg} month${neg>1?"s":""}${days>=1?`, and the average balance covers ${Math.round(days)} days of costs`:", so there is no cash cushion"}.`:`The average balance covers ${Math.round(days)} days of costs${days<20?", a thin cushion if sales slow":""}.`,
mar:margin<0?`Outflows were larger than inflows over the year, by ${pct(-margin)} of inflows.`:`The business keeps ${pct(margin)} of what comes in after costs${margin<.08?", which leaves little room if sales fall":""}.`,
sea:`The weakest month brings in ${pct(ratio)} of the strongest${ratio<.4?", so repayments must be planned around the trough":""}.`,
con:`One customer pays ${pct(top)} of all inflows${top>.3?". Losing that customer would cut income sharply":""}.`};
const reasons=Object.keys(W).map(k=>({k,code:NAME[k][0],name:NAME[k][1],lost:W[k]*(1-s[k])*99,s:s[k],text:txt[k]})).sort((a,b)=>b.lost-a.lost);
const rules=[["Cash-flow score","60 or above",score>=60,String(score)],["Cash buffer","20 days or more",days>=20,Math.round(days)+" days"],["Largest customer","50% of inflows or less",top<=.5,pct(top)],["Months below zero","None in 12 months",neg===0,String(neg)]];
const fails=rules.filter(r=>!r[2]).length;
const policy=fails===0?["ok","Within policy","Goes to a credit officer for review."]:fails===1?["warn","Refer","One rule not met. A credit officer decides with a logged reason."]:["bad","Outside policy",`${fails} rules not met under this sample policy.`];
return{inf,out,bals,s,f,score,band,reasons,rules,policy}}
const dir=s=>s>=.75?["Supports","ok"]:s>=.5?["Lowers slightly","warn"]:["Lowers","bad"];
function scoreHtml(b,r){return`<div class="cc-res" data-score="${r.score}"><p class="mv-mi">${esc(b.id)} · ${esc(b.sector)}</p><p class="cc-res__n mv-num">${r.score}<small>/100</small></p><p class="cc-res__b">Band ${r.band[0]} · ${r.band[1]}</p></div>`}
function reasonsHtml(r,n){return`<div class="cc-rs"><p class="mv-mi">${n===5?"Five reasons, most impact first":"Top reasons"}</p><ol class="cc-rc">${r.reasons.slice(0,n).map(x=>{const d=dir(x.s);
return`<li><span class="cc-rc__c">${x.code}</span><div><b>${esc(x.name)}</b><p>${esc(x.text)}</p></div><span class="mv-tag mv-tag--${d[1]}">${d[0]}</span></li>`}).join("")}</ol></div>`}
function policyHtml(r){return`<div class="cc-pol"><div class="cc-pol__h"><p class="mv-mi">Sample lender policy</p><span class="cc-pol__r cc-pol__r--${r.policy[0]}">${r.policy[1]}</span></div><p class="cc-pol__t">${esc(r.policy[2])}</p>
<ul class="cc-pol__l">${r.rules.map(x=>`<li class="${x[2]?"":"is-fail"}"><span>${esc(x[0])}</span><span>${esc(x[1])}</span><b>${esc(x[3])} · ${x[2]?"met":"not met"}</b></li>`).join("")}</ul></div>`}
/* cairn: five feature stones, wider when the feature is stronger; weak ones in coral; the score stone on top in gold */
function cairnSvg(r){const order=["buf","stab","mar","sea","con"].sort((x,y)=>r.s[y]-r.s[x]);let y=212,o="";
order.forEach((k,i)=>{const v=r.s[k],w=60+120*v,h=24+10*v;y-=h*.5;const cx=120+((i%2)*2-1)*4;
o+=`<ellipse class="cc-st${v<.5?" cc-st--hurt":""}" style="--d:${i*70}ms" cx="${cx}" cy="${y.toFixed(1)}" rx="${(w/2).toFixed(1)}" ry="${(h/2).toFixed(1)}" transform="rotate(${(i%2?-1.5:1.5)} ${cx} ${y.toFixed(1)})"><title>${NAME[k][1]}</title></ellipse>`;y-=h*.42});
y-=14;o+=`<ellipse class="cc-st cc-st--top" style="--d:350ms" cx="120" cy="${y.toFixed(1)}" rx="30" ry="13"/>`;
return`<svg class="cc-cairn" viewBox="0 0 240 230" aria-hidden="true" focusable="false"><path class="cc-ground" d="M30 214h180"/>${o}</svg>`}
function chartSvg(r){const W0=560,H0=200,pad=28,all=[...r.inf,...r.out,...r.bals,0],mx=Math.max(...all),mn=Math.min(...all),Y=v=>pad+(H0-pad*2)*(1-(v-mn)/((mx-mn)||1)),bw=(W0-pad*2)/12;
let bars="",lo="",lb="";r.inf.forEach((v,i)=>{const x=pad+i*bw;bars+=`<rect class="cc-cb" x="${(x+5).toFixed(1)}" y="${Y(v).toFixed(1)}" width="${(bw-10).toFixed(1)}" height="${Math.max(1,Y(0)-Y(v)).toFixed(1)}" rx="2"/><text class="cc-cl" x="${(x+bw/2).toFixed(1)}" y="${H0-8}" text-anchor="middle">${MON[i][0]}</text>`;
lo+=(i?"L":"M")+(x+bw/2).toFixed(1)+" "+Y(r.out[i]).toFixed(1);lb+=(i?"L":"M")+(x+bw/2).toFixed(1)+" "+Y(r.bals[i]).toFixed(1)});
return`<svg viewBox="0 0 ${W0} ${H0}" class="cc-chart__s" aria-hidden="true" focusable="false"><path class="cc-c0" d="M${pad} ${Y(0).toFixed(1)}H${W0-pad}"/>${bars}<path class="cc-co" d="${lo}"/><path class="cc-cbal" d="${lb}"/></svg>
<p class="cc-chart__k"><span><i class="cc-k cc-k--in"></i>Inflows</span><span><i class="cc-k cc-k--out"></i>Outflows</span><span><i class="cc-k cc-k--bal"></i>Month-end balance</span></p>`}
function tableHtml(r){return`<table class="mv-ptable"><caption class="vh">Monthly inflows, outflows and month-end balance, thousands of US dollars, synthetic</caption><thead><tr><th scope="col">Month</th><th scope="col">Inflows</th><th scope="col">Outflows</th><th scope="col">Balance</th></tr></thead><tbody>${
r.inf.map((v,i)=>`<tr><th scope="row">${MON[i]}</th><td>${fmtK(v)}</td><td>${fmtK(r.out[i])}</td><td>${fmtK(r.bals[i])}</td></tr>`).join("")}</tbody></table>`}
function explorer(root){
const picks=$$("input[name=cx-biz]",root),sls=$("[data-cx-sls]",root),ranges=$$("input[type=range]",root),open=$("[data-cx-open]",root),errEl=$("[data-cx-err]",root),
reset=$("[data-cx-reset]",root),scoreEl=$("[data-cx-score]",root),cairnEl=$("[data-cx-cairn]",root),svgEl=$("[data-cx-svg]",root),tbl=$("[data-cx-table]",root),
rsEl=$("[data-cx-reasons]",root),polEl=$("[data-cx-policy]",root),replay=$("[data-cx-replay]",root);
let biz=null;const bump=()=>{root.dataset.n=(+root.dataset.n||0)+1};
const outFor=i=>$(`[data-out="${i.id}"]`,root);
const val=k=>+($(`[data-k="cx-${k}"]`,root)||{}).value;
const setOut=()=>ranges.forEach(i=>{const o=outFor(i);if(o)o.textContent=(i.dataset.k==="cx-level"&&+i.value>0?"+":"")+i.value+"%";i.setAttribute("aria-valuetext",o?o.textContent:i.value)});
const readOpen=()=>{const t=open.value.trim().replace(/[$,\s]/g,"").replace(/k$/i,"");if(!t)return{err:"Enter an opening balance, in thousands of US dollars."};const v=Number(t);
if(!isFinite(v))return{err:"Use digits only, for example 96."};if(v<0||v>5000)return{err:"Enter a balance between 0 and 5,000 (thousands of US dollars)."};return{v}};
const run=(anim)=>{bump();if(!biz)return;setOut();const ob=readOpen();
if(ob.err){errEl.textContent=ob.err;errEl.hidden=!1;open.setAttribute("aria-invalid","true");scoreEl.innerHTML=`<div class="cc-res cc-res--err" role="alert"><p class="mv-mi">Score paused</p><p class="cc-empty">${esc(ob.err)}</p></div>`;root.classList.add("is-err");return}
errEl.hidden=!0;errEl.textContent="";open.setAttribute("aria-invalid","false");root.classList.remove("is-err");
const r=compute(biz,{level:val("level"),season:val("season"),top:val("top"),open:ob.v});
scoreEl.innerHTML=scoreHtml(biz,r);cairnEl.innerHTML=cairnSvg(r);svgEl.innerHTML=chartSvg(r);tbl.innerHTML=tableHtml(r);rsEl.innerHTML=reasonsHtml(r,5);polEl.innerHTML=policyHtml(r);
root.dataset.score=r.score;if(anim){cairnEl.classList.remove("is-drop");void cairnEl.offsetWidth;cairnEl.classList.add("is-drop")}};
const load=el=>{biz=readBiz(el);sls.disabled=!1;reset.disabled=!1;ranges.forEach(i=>{i.value=i.dataset.k==="cx-top"?biz.top:i.dataset.k==="cx-season"?100:0});open.value=biz.open;root.dataset.biz=el.value;run(!0)};
picks.forEach(p=>{p.addEventListener("change",()=>load(p));p.addEventListener("click",()=>{if(biz&&root.dataset.biz===p.value)bump()})});
ranges.forEach(i=>{i.addEventListener("input",()=>run(!1));i.addEventListener("click",bump)});
open.addEventListener("input",()=>run(!1));
reset.addEventListener("click",()=>{const p=picks.find(x=>x.checked);if(p)load(p);else bump()});
replay.addEventListener("click",()=>{if(!biz){picks[0].checked=!0;load(picks[0]);return}bump();cairnEl.classList.remove("is-drop");void cairnEl.offsetWidth;cairnEl.classList.add("is-drop")});
const q=new URLSearchParams(location.search).get("business");if(q){const p=picks.find(x=>x.value===q);if(p){p.checked=!0;load(p)}}}
function mini(root){
const tabs=$$("[role=tab]",root),out=$("[data-mini-out]",root);
const show=i=>{root.dataset.n=(+root.dataset.n||0)+1;tabs.forEach((t,j)=>{t.setAttribute("aria-selected",j===i);t.tabIndex=j===i?0:-1});const b=readBiz(tabs[i]),r=compute(b,{});
out.innerHTML=`<div class="cc-mini__g"><div class="cc-mini__s">${cairnSvg(r)}${scoreHtml(b,r)}</div>${reasonsHtml(r,3)}</div><p class="cc-mini__p"><span class="cc-pol__r cc-pol__r--${r.policy[0]}">${r.policy[1]}</span>${esc(r.policy[2])}</p>`};
tabs.forEach((t,i)=>{t.addEventListener("click",()=>show(i));t.addEventListener("keydown",e=>{const d=e.key==="ArrowRight"?1:e.key==="ArrowLeft"?-1:0;if(d){e.preventDefault();const k=(i+d+tabs.length)%tabs.length;tabs[k].focus();show(k)}})});show(0)}
/* scroll regions get keyboard focus only when they actually scroll */
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-cc=explorer]").forEach(explorer);$$("[data-cc=mini]").forEach(mini)}
export{compute};
