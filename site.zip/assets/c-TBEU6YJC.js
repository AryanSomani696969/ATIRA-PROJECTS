/* Mrvloop page tools. Everything runs in this browser; nothing is sent anywhere.
   data-mr=est     Credit Estimator. Practice, region, enrolled acres, share already practising, baseline, evidence and years
                   give a range of potential reductions in tCO2e with its uncertainty, a conservative figure after a sample
                   holdback, bars for the three evidence levels and a loop diagram (Capture, Verify, Report) with Replay.
                   Coefficients are sample values written for this page. data-compact: the smaller home version.
   data-mr=case    one-case stepper on Home (previous and next).
   data-mr=audit   sample dossier audit trail, filter chips that toggle (event, field).
   data-mr=checks  field guide pre-sync checklist. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const fmt=n=>Math.round(n).toLocaleString("en-US"),r10=n=>n<100?Math.round(n):Math.round(n/10)*10;
/* sample coefficients: tCO2e per newly practising acre per season, central value, and relative uncertainty with records only */
const PR={tillage:{n:"Reduced tillage or no-till",c:.22,u:.55},cover:{n:"Cover crops",c:.36,u:.45},awd:{n:"Rice: alternate wetting and drying",c:1.1,u:.35}};
const RG={cornbelt:{n:"Corn Belt",m:1,rice:!1},plains:{n:"Plains",m:.7,rice:!1},valley:{n:"California's Central Valley",m:.9,rice:!0},delta:{n:"Southeast and Delta",m:1.05,rice:!0}};
const BL={cons:{n:"Conservative baseline",m:.85},central:{n:"Central baseline",m:1}};
const EV={rec:{n:"Practice records only",k:1},sat:{n:"Records and satellite checks",k:.72},soil:{n:"Records, satellite and soil sampling",k:.5}};
const HOLD=.15;
function calc(i){const p=PR[i.pr],g=RG[i.rg],b=BL[i.bl],e=EV[i.ev];const na=i.ac*(1-i.sh/100),c=na*p.c*g.m*b.m,u=p.u*e.k,lo=c*(1-u),hi=c*(1+u),cons=lo*(1-HOLD);
 return{na,c,u,lo,hi,cons,per:na?c/i.ac:0,yr:i.yr,p,g,b,e}}
function est(root){const C=root.hasAttribute("data-compact"),q=k=>$('[data-e="'+k+'"]',root);
 const out=$("[data-e-out]",root),bars=$("[data-e-bars]",root),msg=$("[data-e-msg]",root),st=$("[data-e-st]",root),acv=$("[data-e-acv]",root),shv=$("[data-e-shv]",root),coef=$("[data-e-coef]",root);
 const ctl=["pr","rg","ac","acr","sh","bl","ev","yr"].map(q).filter(Boolean);
 function read(){return{pr:q("pr").value,rg:q("rg")?q("rg").value:"cornbelt",ac:q("ac")?+q("ac").value:+q("acr").value,sh:q("sh")?+q("sh").value:20,bl:q("bl")?q("bl").value:"central",ev:q("ev").value,yr:q("yr")?+q("yr").value:1}}
 function changed(){return ctl.filter(e=>String(e.value)!==String(e.tagName==="SELECT"?[...e.options].find(o=>o.defaultSelected)?.value??e.options[0].value:e.defaultValue)).length}
 function bar(i){const lv=["rec","sat","soil"].map(k=>[k,calc(Object.assign({},i,{ev:k}))]),mx=Math.max(...lv.map(x=>x[1].hi))||1;
  return '<ul class="mr-bars" aria-label="Range for each evidence level">'+lv.map(([k,r])=>'<li class="'+(k===i.ev?"is-on":"")+'"><span class="mr-bars__l">'+EV[k].n+'</span><span class="mr-bars__t" aria-hidden="true"><i style="left:'+(r.lo/mx*100).toFixed(1)+"%;width:"+((r.hi-r.lo)/mx*100).toFixed(1)+'%"></i><b style="left:'+(r.c/mx*100).toFixed(1)+'%"></b></span><span class="mr-bars__v">'+fmt(r10(r.lo))+" to "+fmt(r10(r.hi))+"</span></li>").join("")+"</ul>"}
 function err(t){out.innerHTML='<div class="mr-res mr-res--err"><p class="mr-res__s">No estimate yet</p><p class="mr-res__r">'+t+"</p></div>";bars.innerHTML="";if(msg)msg.textContent=t}
 let last=null;
 function render(){const i=read();if(acv)acv.textContent=fmt(i.ac)+" acres";if(shv)shv.textContent=i.sh+"%";
  const n=changed();st.textContent=n?n+(n===1?" input":" inputs")+" changed from the defaults.":C?"Default inputs. Region Corn Belt, central baseline.":"Default inputs.";
  if(q("ac")){const a=q("ac");if(a.value===""){a.setAttribute("aria-invalid","true");last=null;return err("Enter the enrolled acres to see a range.")}
   if(!(i.ac>=10&&i.ac<=200000)){a.setAttribute("aria-invalid","true");last=null;return err("Enrolled acres must be between 10 and 200,000.")}a.setAttribute("aria-invalid","false")}
  if(i.pr==="awd"&&!RG[i.rg].rice){last=null;return err("Alternate wetting and drying applies to flooded rice. Choose California's Central Valley or the Southeast and Delta.")}
  const r=calc(i);last={i,r};if(msg)msg.textContent="";
  out.innerHTML='<div class="mr-res"><p class="mr-res__k">Potential, per season</p><p class="mr-res__v"><b>'+fmt(r10(r.lo))+"</b><span>to</span><b>"+fmt(r10(r.hi))+'</b><small>tCO2e</small></p>'+
   '<dl class="mr-res__d"><div><dt>Central</dt><dd>'+fmt(r10(r.c))+" tCO2e</dd></div><div><dt>Uncertainty</dt><dd>±"+Math.round(r.u*100)+"%</dd></div>"+
   (C?"":"<div><dt>Newly practising acres</dt><dd>"+fmt(r.na)+"</dd></div><div><dt>Per enrolled acre</dt><dd>"+r.per.toFixed(2)+" tCO2e</dd></div>")+
   "<div><dt>Conservative, after "+HOLD*100+"% holdback</dt><dd>"+fmt(r10(r.cons))+" tCO2e"+(r.yr>1?" a season, "+fmt(r10(r.cons*r.yr))+" over "+r.yr+" seasons":"")+"</dd></div></dl></div>";
  bars.innerHTML=bar(i);
  if(coef)coef.innerHTML='<thead><tr><th scope="col">Input</th><th scope="col">Value used</th></tr></thead><tbody><tr><td>'+r.p.n+"</td><td>"+r.p.c+" tCO2e per new acre, ±"+Math.round(r.p.u*100)+"% on records only</td></tr><tr><td>"+r.g.n+"</td><td>× "+r.g.m+"</td></tr><tr><td>"+r.b.n+"</td><td>× "+r.b.m+"</td></tr><tr><td>"+r.e.n+"</td><td>uncertainty × "+r.e.k+"</td></tr><tr><td>Holdback</td><td>"+HOLD*100+"% of the low end</td></tr></tbody>";
  if(stage>=0)showStage(stage)}
 ctl.forEach(e=>{e.addEventListener("input",render);e.addEventListener("change",render)});
 const rs=$("[data-e-reset]",root);if(rs)rs.addEventListener("click",()=>{ctl.forEach(e=>{if(e.tagName==="SELECT"){[...e.options].forEach(o=>o.selected=o.defaultSelected)}else e.value=e.defaultValue});render();if(msg)msg.textContent="Inputs reset to the defaults."});
 /* loop diagram */
 const svg=$("[data-e-loop]",root),sb=$$("[data-stage]",root),stx=$("[data-e-stage]",root);let stage=-1,tm=0;
 const N=[[60,150,"Field"],[250,52,"Satellite"],[250,180,"Ledger"]];
 if(svg){svg.innerHTML='<rect class="mr-lp__bg" width="320" height="230" rx="14"/><path class="mr-lp__p" d="M60 150C40 80 160 30 250 52C320 70 320 170 250 180C190 190 90 210 60 150Z"/>'+
  N.map((n,k)=>'<g class="mr-lp__n" data-n="'+k+'"><circle cx="'+n[0]+'" cy="'+n[1]+'" r="16"/><text x="'+n[0]+'" y="'+(n[1]+(k===1?-26:34))+'" text-anchor="middle">'+n[2]+"</text></g>").join("")+'<circle class="mr-lp__d" r="7" cx="60" cy="150"/>'}
 const path=svg&&$(".mr-lp__p",svg),dot=svg&&$(".mr-lp__d",svg);
 function place(f){if(!path)return;const L=path.getTotalLength(),pt=path.getPointAtLength(L*f);dot.setAttribute("cx",pt.x.toFixed(1));dot.setAttribute("cy",pt.y.toFixed(1))}
 const SF=[0,.33,.62];
 function showStage(k){stage=k;sb.forEach((b,j)=>b.setAttribute("aria-pressed",String(j===k)));if(svg)$$(".mr-lp__n",svg).forEach((g,j)=>g.classList.toggle("is-on",j===k));place(SF[k]);
  if(!last){stx.textContent="Fix the inputs first: the loop needs a valid estimate.";return}const{i,r}=last;
  stx.textContent=k===0?"Capture: records for "+fmt(i.ac)+" enrolled acres of "+r.p.n.toLowerCase()+", with dates, photos and geotags. "+fmt(r.na)+" acres are new to the practice and count toward the estimate.":
   k===1?"Verify: with "+r.e.n.toLowerCase()+" the uncertainty is ±"+Math.round(r.u*100)+"%. Satellite checks and soil sampling narrow it, which raises the conservative figure without adding acres.":
   "Report: the conservative figure is "+fmt(r10(r.cons))+" tCO2e a season, the low end of the range less the "+HOLD*100+"% holdback. The protocol and the verifier decide what is issued."}
 sb.forEach((b,j)=>{b.addEventListener("click",()=>showStage(j));b.addEventListener("keydown",e=>{let n=-1;if(e.key==="ArrowRight"||e.key==="ArrowDown")n=(j+1)%sb.length;else if(e.key==="ArrowLeft"||e.key==="ArrowUp")n=(j-1+sb.length)%sb.length;else if(e.key==="Home")n=0;else if(e.key==="End")n=sb.length-1;
  if(n>=0){e.preventDefault();sb[n].focus();showStage(n)}})});
 const rp=$("[data-e-replay]",root);if(rp)rp.addEventListener("click",()=>{clearTimeout(tm);if(RM){showStage(2);stx.textContent="Replay: capture, then verify, then report. "+stx.textContent;return}
  let k=0;const go=()=>{showStage(k);k++;if(k<3)tm=setTimeout(go,1100)};stx.textContent="Replaying the loop.";tm=setTimeout(go,60)});
 render();if(path)place(0)}
function kase(root){const tpl=$$("template[data-case]",root.parentElement),pane=$("[data-case-pane]",root),pv=$("[data-case-prev]",root),nx=$("[data-case-next]",root),cnt=$("[data-case-count]",root),li=$$("[data-case-i]",root);let i=0;
 function go(k){i=Math.max(0,Math.min(tpl.length-1,k));pane.innerHTML="";pane.appendChild(tpl[i].content.cloneNode(!0));pv.disabled=i===0;nx.disabled=i===tpl.length-1;cnt.textContent="Step "+(i+1)+" of "+tpl.length;
  li.forEach((l,j)=>{l.classList.toggle("is-on",j===i);l.classList.toggle("is-done",j<i);if(j===i)l.setAttribute("aria-current","step");else l.removeAttribute("aria-current")})}
 pv.addEventListener("click",()=>go(i-1));nx.addEventListener("click",()=>go(i+1))}
function audit(root){const ev=$$("[data-af]",root),fl=$$("[data-aff]",root),rows=$$("tbody tr",root),c=$("[data-a-count]",root),em=$("[data-a-empty]",root);let fe="",ff="";
 function apply(){let n=0;rows.forEach(r=>{const ok=(!fe||r.dataset.k===fe)&&(!ff||r.dataset.f===ff||r.dataset.f==="all");r.hidden=!ok;if(ok)n++});
  ev.forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.af===fe)));fl.forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.aff===ff)));
  c.textContent=(fe||ff)?"Showing "+n+" of "+rows.length+" entries"+(ff?" for "+ff:""):"Showing all "+rows.length+" entries";em.hidden=n>0}
 ev.forEach(b=>b.addEventListener("click",()=>{fe=fe===b.dataset.af?"":b.dataset.af;apply()}));fl.forEach(b=>b.addEventListener("click",()=>{ff=ff===b.dataset.aff?"":b.dataset.aff;apply()}));apply()}
function checks(root){const b=$$("[data-ck]",root),p=$("[data-ck-p]",root),rs=$("[data-ck-reset]",root);
 function up(){const n=b.filter(x=>x.checked).length;p.textContent=n===b.length?"All "+n+" checked. Ready to sync.":n+" of "+b.length+" checked";b.forEach(x=>x.closest("label").classList.toggle("is-on",x.checked))}
 b.forEach(x=>x.addEventListener("change",up));rs.addEventListener("click",()=>{b.forEach(x=>x.checked=!1);up();p.textContent="List cleared. 0 of "+b.length+" checked"});up()}
export function boot(){$$("[data-mr=est]").forEach(est);$$("[data-mr=case]").forEach(kase);$$("[data-mr=audit]").forEach(audit);$$("[data-mr=checks]").forEach(checks);
 $$(".mv-pscroll").forEach(el=>{const f=()=>{if(el.scrollWidth>el.clientWidth+2){el.tabIndex=0;el.setAttribute("role","region");el.setAttribute("aria-label",el.dataset.label||"Scrollable table")}else{el.removeAttribute("tabindex")}};f();addEventListener("resize",f)})}
