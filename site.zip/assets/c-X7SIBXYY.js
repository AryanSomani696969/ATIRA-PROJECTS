/* Freightvane page tools. Everything runs in the browser; nothing chosen or typed here leaves the page.
   [data-fv=eta]    ETA Explorer: three synthetic lanes, events stepped by Play, buttons or arrow keys; the ETA window,
                    the status against the appointment, a GPS drop and the idling exception are computed on each step
   [data-fv=queue]  exception queue filter by severity (buttons with aria-pressed)
   .mv-pscroll      wide tables become focusable scroll regions only when they overflow */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const NS="http://www.w3.org/2000/svg";
const DAYS=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];

/* lanes: start day (0 Mon) and minute of day, consignee time zone, appointment (minutes after departure), load id, route path,
   events [t minutes after departure, p share of route, source, text, lo, hi (window, minutes after departure), extra]
   extra: {stop:1} a stop starts; {idle:n} idle minutes seen at this event; {arr:1} arrival; {lbl:"..."} map label */
const LANES={
chi:{id:"LD-20418",tz:"CT",day:1,min:240,appt:1710,from:"Joliet IL",to:"Dallas TX",place:"near Purcell OK",gps:[1,2],
 d:"M40 52 C150 58 190 120 262 140 S380 170 430 200 S520 262 604 296",
 ev:[[0,0,"Geofence","Departs the Joliet IL yard",1590,1830,{lbl:"Joliet"}],
     [295,.2,"Traffic","I-270 work zone, St. Louis MO, about 20 minutes",1610,1820,{lbl:"St. Louis"}],
     [470,.36,"ELD","30-minute break near Rolla MO",1610,1790],
     [605,.52,"Toll read","Will Rogers Turnpike, Vinita OK, PikePass",1620,1770,{lbl:"Vinita"}],
     [690,.6,"ELD","10-hour off-duty period starts, Tulsa OK",1625,1745,{lbl:"Tulsa"}],
     [1290,.6,"ELD","Driving resumes after 10 hours off duty",1620,1720],
     [1385,.72,"Toll read","Turner Turnpike, Oklahoma City, PikePass",1620,1700,{lbl:"OKC"}],
     [1420,.78,"GPS","Stopped at a fuel plaza near Purcell OK, not in the trip plan",1640,1710,{stop:1}],
     [1472,.78,"GPS","Still stopped, 52 minutes idle",1670,1750,{idle:52}],
     [1481,.79,"ELD","Driving resumes after a 61-minute stop",1680,1725,{idle:61}],
     [1555,.9,"Traffic","I-35E incident near Denton TX, about 15 minutes",1685,1720,{lbl:"Denton"}],
     [1702,1,"Geofence","Arrives at the Dallas DC yard",1702,1702,{arr:1,lbl:"Dallas"}]]},
atl:{id:"LD-20422",tz:"ET",day:3,min:780,appt:1560,from:"Atlanta GA",to:"Medley FL",place:"at a Florida's Turnpike service plaza",gps:[2,3],
 d:"M60 40 C110 90 150 120 210 150 S300 190 360 220 S470 250 520 280 S590 300 610 306",
 ev:[[0,0,"Geofence","Departs the Atlanta GA cold store",1470,1710,{lbl:"Atlanta"}],
     [95,.1,"Traffic","I-75 southbound near Macon GA, about 25 minutes",1490,1710,{lbl:"Macon"}],
     [330,.32,"Geofence","Crosses into Florida on I-75",1480,1680,{lbl:"FL line"}],
     [420,.38,"ELD","30-minute break, Lake City FL",1490,1660],
     [600,.52,"ELD","10-hour off-duty period starts, Wildwood FL",1500,1650,{lbl:"Wildwood"}],
     [1200,.52,"ELD","Driving resumes after 10 hours off duty",1500,1620],
     [1320,.74,"Toll read","Florida's Turnpike gantry, Osceola County, SunPass",1510,1590,{lbl:"Turnpike"}],
     [1350,.78,"GPS","Stopped at a Turnpike service plaza, not in the trip plan",1520,1610,{stop:1}],
     [1388,.78,"GPS","Still stopped, 38 minutes idle",1540,1630,{idle:38}],
     [1394,.79,"Driver app","Driver checks in: fuel and break, moving again",1535,1585,{idle:44}],
     [1470,.92,"Traffic","Heavy traffic in Miami-Dade, about 15 minutes",1545,1575],
     [1562,1,"Geofence","Arrives at the Medley FL cross-dock",1562,1562,{arr:1,lbl:"Medley"}]]},
lax:{id:"LD-20431",tz:"MST",day:0,min:390,appt:495,from:"Vernon CA",to:"Tolleson AZ",place:"at Quartzsite AZ",gps:[1,2],
 d:"M36 210 C110 200 150 170 220 172 S330 196 390 186 S500 150 560 140 S600 136 610 134",
 ev:[[0,0,"Geofence","Departs the Vernon CA DC",390,540,{lbl:"Vernon"}],
     [45,.08,"Traffic","I-10 eastbound, Pomona to Redlands, about 35 minutes",420,550],
     [190,.36,"Geofence","Planned fuel stop, Indio CA",420,520,{lbl:"Indio"}],
     [245,.48,"GPS","Last GPS fix east of Desert Center CA, ELD pings only",410,550,{nogps:1}],
     [290,.6,"GPS","GPS back at Blythe CA, agrees with ELD within a mile",430,490,{lbl:"Blythe"}],
     [310,.63,"Geofence","Crosses into Arizona at Ehrenberg",435,485],
     [340,.68,"GPS","Stopped at Quartzsite AZ, not in the trip plan",450,510,{stop:1,lbl:"Quartzsite"}],
     [378,.68,"GPS","Driving again after 38 minutes idle",465,500,{idle:38}],
     [450,.93,"Traffic","I-10 west valley, Phoenix, about 10 minutes",475,490],
     [481,1,"Geofence","Arrives at the Tolleson AZ DC",481,481,{arr:1,lbl:"Tolleson"}]]}};

const pad=n=>String(n).padStart(2,"0");
function clock(L,m,withDay){const a=L.min+Math.round(m),d=(L.day+Math.floor(a/1440))%7,mm=((a%1440)+1440)%1440;return (withDay?DAYS[d]+" ":"")+pad(Math.floor(mm/60))+":"+pad(mm%60)}
function dur(m){m=Math.round(m);return m>=60?Math.floor(m/60)+" h "+pad(m%60)+" min":m+" min"}

function eta(root){
  const sel=$("[data-eta-lane]",root),thr=$("[data-eta-thr]",root),gps=$("[data-eta-gps]",root),err=$("[data-eta-err]",root),
        play=$("[data-eta-play]",root),prev=$("[data-eta-prev]",root),next=$("[data-eta-next]",root),rep=$("[data-eta-replay]",root),
        stage=$("[data-eta-stage]",root),svg=$("[data-eta-svg]",root),win=$("[data-eta-win]",root),band=$("[data-eta-band]",root),apm=$("[data-eta-appt]",root),
        st=$("[data-eta-status]",root),apt=$("[data-eta-appttxt]",root),log=$("[data-eta-log]",root),exc=$("[data-eta-exc]",root);
  log.removeAttribute("aria-live");
  const live=document.createElement("p");live.className="fv-vh";live.setAttribute("aria-live","polite");root.appendChild(live);
  let L=LANES[sel.value],i=-1,timer=0,T=45,path,done,truck,len=0;

  function draw(){
    svg.innerHTML="";
    const g=(tag,attrs)=>{const e=document.createElementNS(NS,tag);for(const k in attrs)e.setAttribute(k,attrs[k]);svg.appendChild(e);return e};
    g("rect",{class:"fv-bg",width:640,height:340});
    for(let x=40;x<640;x+=40)g("path",{class:"fv-grid",d:"M"+x+" 0 V340"});
    for(let y=40;y<340;y+=40)g("path",{class:"fv-grid",d:"M0 "+y+" H640"});
    path=g("path",{class:"fv-road fv-road--dim",d:L.d});len=path.getTotalLength();
    done=g("path",{class:"fv-road fv-road--done",d:L.d,"stroke-dasharray":len+" "+len,"stroke-dashoffset":len});
    L.ev.forEach((e,k)=>{const pt=path.getPointAtLength(len*e[1]);const c=g("circle",{class:"fv-cp",cx:pt.x.toFixed(1),cy:pt.y.toFixed(1),r:k===L.ev.length-1?7:5,"data-k":k});
      if(k===L.ev.length-1)c.classList.add("fv-cp--o");
      const x=e[6]||{};if(x.lbl){const last=k===L.ev.length-1,t=g("text",{class:"fv-lbl",x:(pt.x+(pt.x>560?-14:10)).toFixed(1),y:(pt.y+(last&&pt.y<300?24:-12)).toFixed(1),"text-anchor":pt.x>560?"end":"start","data-k":k});t.textContent=x.lbl}});
    {const a=len*L.ev[L.gps[0]][1],b=len*L.ev[Math.min(L.ev.length-1,L.gps[1]+1)][1];
     g("path",{class:"fv-gpsseg",d:L.d,"stroke-dasharray":"0 "+a.toFixed(1)+" "+(b-a).toFixed(1)+" "+len.toFixed(1)})}
    truck=g("g",{class:"fv-truck"});
    truck.innerHTML='<g class="fv-vane"><path class="fv-vane__s" d="M-20 0 H14"/><path class="fv-vane__h" d="M22 0 L9 -8 L12 0 L9 8 Z"/><path class="fv-vane__t" d="M-20 0 L-28 -8 M-20 0 L-28 8 M-13 0 L-21 -8 M-13 0 L-21 8"/></g>';
    place(0);
  }
  function place(p){const a=path.getPointAtLength(len*p),b=path.getPointAtLength(Math.min(len,len*p+2)),c=path.getPointAtLength(Math.max(0,len*p-2));
    const ang=Math.atan2(b.y-c.y,b.x-c.x)*180/Math.PI;truck.setAttribute("transform","translate("+a.x.toFixed(1)+" "+a.y.toFixed(1)+") rotate("+ang.toFixed(1)+")");
    done.setAttribute("stroke-dashoffset",(len*(1-p)).toFixed(1))}
  function gpsOff(k){return (gps.checked&&L.gps.includes(k))||!!((L.ev[k][6]||{}).nogps)}
  function windowAt(k){const e=L.ev[k];let lo=e[4],hi=e[5];
    if(gpsOff(k)){const c=(lo+hi)/2,h=(hi-lo)/2*1.6+10;lo=c-h;hi=c+h}
    else if(k>0&&gpsOff(k-1)&&!(e[6]||{}).arr){const c=(lo+hi)/2,h=(hi-lo)/2*1.2;lo=c-h;hi=c+h}
    return [Math.round(lo/5)*5,Math.round(hi/5)*5]}
  function excAt(k){/* first event at or before k where idle seen is above the threshold */
    let s=-1;for(let j=0;j<=k;j++){const x=L.ev[j][6]||{};if(x.stop)s=j;if(s>=0&&x.idle&&x.idle>T)return {j,s,idle:x.idle}}return null}
  function status(k,lo,hi){const e=L.ev[k];if((e[6]||{}).arr){const late=e[4]-L.appt;return late>0?["Arrived "+late+" min after the appointment","warn"]:["Arrived on time","ok"]}
    return hi<=L.appt?["On time","ok"]:lo>L.appt?["Late","bad"]:["At risk","warn"]}
  function render(){
    $$(".fv-cp",svg).forEach(c=>{const k=+c.dataset.k;c.classList.toggle("is-past",k<i);c.classList.toggle("is-now",k===i)});
    $$(".fv-lbl",svg).forEach(t=>t.classList.toggle("fv-lbl--on",+t.dataset.k<=i));
    prev.disabled=i<=0;next.disabled=i>=L.ev.length-1;
    if(i<0){place(0);win.textContent="Press Play";band.style.width="0";st.textContent="Not started";st.className="mv-tag mv-tag--mute";
      apt.textContent="Appointment "+clock(L,L.appt,true)+" "+L.tz;log.innerHTML='<li class="fv-log__e">No events yet. Press Play, click the map or use the arrow keys.</li>';exc.innerHTML="";return}
    const e=L.ev[i],[lo,hi]=windowAt(i),x=e[6]||{};place(e[1]);
    const sameDay=clock(L,lo,true).slice(0,3)===clock(L,hi,true).slice(0,3);
    win.textContent=x.arr?"Arrived "+clock(L,e[4],true)+" "+L.tz:clock(L,lo,true)+" to "+(sameDay?clock(L,hi):clock(L,hi,true))+" "+L.tz;
    const D0=L.appt-300,D1=L.appt+180,pc=v=>Math.max(0,Math.min(100,(v-D0)/(D1-D0)*100));
    const s=status(i,lo,hi);band.style.left=pc(lo)+"%";band.style.width=Math.max(1.2,pc(hi)-pc(lo))+"%";band.className="fv-axis__w"+(s[1]==="warn"?" is-risk":s[1]==="bad"?" is-late":"");
    apm.style.left=pc(L.appt)+"%";st.textContent=s[0];st.className="mv-tag mv-tag--"+s[1];
    apt.textContent="Appointment "+clock(L,L.appt,true)+" "+L.tz+(x.arr?"":" · width "+dur(hi-lo));
    let h="";for(let j=0;j<=i;j++){const ej=L.ev[j],off=gpsOff(j);
      h+='<li class="'+(j===i?"is-now ":"")+(off?"is-gps":"")+'"><span class="fv-id">'+esc(clock(L,ej[0],true))+'</span><div><b>'+esc(ej[2])+'</b> '+esc(ej[3])+(off&&!(ej[6]||{}).nogps?'<small>GPS dropped: position from ELD and toll reads only</small>':(ej[6]||{}).nogps?'<small>No GPS fix: the window widens</small>':'')+'</div></li>'}
    log.innerHTML=h;log.scrollTop=log.scrollHeight;
    const X=excAt(i);
    if(X){const [elo,ehi]=windowAt(X.j),hi2=ehi>L.appt;
      exc.innerHTML='<div class="fv-xcard" role="status"><span class="fv-sev fv-sev--'+(hi2?"hi":"md")+'">'+(hi2?"High":"Medium")+'</span><h3>Exception: idling past threshold</h3>'+
        '<p><span class="fv-id">'+L.id+'</span> idle '+X.idle+' min '+esc(L.place)+', threshold '+T+' min. Opened '+clock(L,L.ev[X.j][0],true)+' '+L.tz+'. Owner: dispatch.</p>'+
        '<p>Next: call the driver, then confirm the new window with the consignee.</p><div class="fv-note__m"><p class="fv-note__f">Draft update to the consignee</p><p>Load '+L.id+' to '+esc(L.to)+': new arrival window '+clock(L,elo)+' to '+clock(L,ehi)+' '+L.tz+'. Your appointment is '+clock(L,L.appt)+'.</p></div></div>'}
    else{const st0=L.ev.findIndex(v=>(v[6]||{}).stop);let m=0;if(st0>=0)for(let j=st0;j<=i;j++)m=Math.max(m,(L.ev[j][6]||{}).idle||0);
      const going=st0>=0&&i>=st0&&i+1<L.ev.length&&(L.ev[i+1][6]||{}).idle;
      exc.innerHTML=(st0>=0&&i>=st0)?'<div class="fv-xcard fv-xcard--ok"><h3>No exception</h3><p>'+(going?(m?"Stopped "+m+" min so far.":"The truck is stopped.")+" An exception opens if idling passes "+T+" min.":"The stop lasted "+m+" min, under your "+T+"-minute idling threshold.")+'</p></div>':""}
    live.textContent=clock(L,e[0],true)+". "+e[2]+": "+e[3]+". "+win.textContent+". "+s[0]+"."+(X&&X.j===i?" Exception opened: idling past threshold.":"");
  }
  function stop(){clearInterval(timer);timer=0;play.textContent="Play";play.setAttribute("aria-pressed","false")}
  function go(k){i=Math.max(-1,Math.min(L.ev.length-1,k));render();if(i>=L.ev.length-1)stop()}
  function start(){if(i>=L.ev.length-1)i=-1;play.textContent="Pause";play.setAttribute("aria-pressed","true");go(i+1);timer=setInterval(()=>go(i+1),RM?2200:1500)}
  play.addEventListener("click",()=>timer?stop():start());
  prev.addEventListener("click",()=>{stop();go(i-1)});
  next.addEventListener("click",()=>{stop();go(i+1)});
  rep.addEventListener("click",()=>{stop();i=-1;render();start()});
  sel.addEventListener("change",()=>{stop();L=LANES[sel.value];i=-1;draw();svg.classList.toggle("is-gps",gps.checked);render()});
  const leg=document.createElement("p");leg.className="fv-legend";leg.hidden=true;leg.textContent="Shaded: the stretch where GPS is dropped. Position comes from ELD and toll reads.";stage.insertBefore(leg,svg.nextSibling);
  const gpsv=()=>{svg.classList.toggle("is-gps",gps.checked);leg.hidden=!gps.checked;root.classList.toggle("is-gps",gps.checked);render()};
  gps.addEventListener("change",gpsv);
  stage.addEventListener("click",()=>{stop();go(i>=L.ev.length-1?0:i+1)});
  thr.addEventListener("input",()=>{const v=thr.value.trim(),n=Number(v);
    if(v===""||!Number.isInteger(n)||n<15||n>180){err.hidden=false;err.textContent="Enter a whole number of minutes from 15 to 180. Using "+T+" minutes until then.";thr.setAttribute("aria-invalid","true");return}
    err.hidden=true;thr.removeAttribute("aria-invalid");T=n;render()});
  stage.addEventListener("keydown",ev=>{const k=ev.key;if(k==="ArrowRight"||k==="ArrowDown"){ev.preventDefault();stop();go(i+1)}else if(k==="ArrowLeft"||k==="ArrowUp"){ev.preventDefault();stop();go(i-1)}
    else if(k==="Home"){ev.preventDefault();stop();go(0)}else if(k==="End"){ev.preventDefault();stop();go(L.ev.length-1)}});
  draw();render();
}

function queue(root){
  const bs=$$("[data-q]",root),items=$$(".fv-ex",root),empty=$("[data-q-empty]",root),live=$("[data-q-live]",root);
  bs.forEach(b=>b.addEventListener("click",()=>{const q=b.dataset.q;bs.forEach(x=>x.setAttribute("aria-pressed",String(x===b)));let n=0;
    items.forEach(li=>{const on=q==="all"||li.dataset.sev===q;li.hidden=!on;if(on)n++});if(empty)empty.hidden=n>0;
    if(live)live.textContent=n+" exception"+(n===1?"":"s")+" shown"}));
}

function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}

export function boot(){scrollers();$$("[data-fv=eta]").forEach(eta);$$("[data-fv=queue]").forEach(queue)}
