/* Pactweave page tools. Everything runs in the browser; nothing typed, pasted or opened here leaves the page.
   [data-pw=check]  Contract Check: paste text, open a .txt or .docx file, or load a synthetic sample; pick a side;
                    get a risk map, flagged clauses with plain-language notes, missing clauses and questions to send back
   [data-pw=mini]   the same engine on the synthetic MSA, home page size, with the side switch
   [data-pw=tabs]   tab sets (sample review flags, sample register views) with arrow-key movement */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const MON=["January","February","March","April","May","June","July","August","September","October","November","December"];
const fmtD=d=>MON[d.getUTCMonth()]+" "+d.getUTCDate()+", "+d.getUTCFullYear();

/* ---------- synthetic samples (no real party, deal or person) */
const SAMPLES={
nda:{name:"Mutual NDA · synthetic",text:`MUTUAL NON-DISCLOSURE AGREEMENT (SYNTHETIC SAMPLE)
Effective Date: January 4, 2027. Between Party A and Party B.

1. Purpose. The parties wish to evaluate a possible commercial relationship (the "Purpose") and may disclose Confidential Information to each other for that Purpose.

2. Confidential Information. "Confidential Information" means any non-public information disclosed by one party to the other, in any form, that is marked as confidential or would reasonably be understood to be confidential.

3. Obligations. The Recipient shall use Confidential Information only for the Purpose and shall protect it with at least reasonable care.

4. Residuals. Either party may use any information retained in the unaided memory of its personnel, including ideas, concepts and know-how, for any purpose.

5. Term. This Agreement remains in effect for one (1) year from the Effective Date, and the obligations in Section 3 survive for one (1) year after it ends.

6. Non-solicitation. During the term and for twenty-four (24) months after it ends, neither party shall solicit for employment any employee of the other party.

7. Remedies. Each party agrees that a breach may cause irreparable harm and that the other party may seek injunctive relief.

8. Governing law. This Agreement is governed by the laws of the State of New York. Any dispute shall be brought exclusively in the state or federal courts located in Wilmington, Delaware.`},
msa:{name:"Master services agreement · synthetic",text:`MASTER SERVICES AGREEMENT (SYNTHETIC SAMPLE)
Effective Date: January 4, 2027. Between Provider and Customer.

1. Services. Provider will make the Platform available to Customer as described in Order Form 1.

2. Fees and payment. Customer shall pay all fees within fifteen (15) days of the invoice date. Late amounts accrue interest at 1.5% per month.

3. Term and renewal. The initial term is twelve (12) months. This Agreement renews automatically for successive twelve (12) month terms unless either party gives written notice of non-renewal at least ninety (90) days before the end of the then-current term.

4. Termination. Provider may terminate this Agreement for convenience on thirty (30) days' written notice. Either party may terminate for material breach not cured within thirty (30) days.

5. Intellectual property. All right, title and interest in any work product, including configurations and reports created for Customer, vest in Provider.

6. Confidentiality. Each party shall keep the other party's Confidential Information confidential for three (3) years after disclosure.

7. Indemnity. Customer shall indemnify, defend and hold harmless Provider against any claim arising from Customer's use of the Platform.

8. Limitation of liability. Provider's total liability under this Agreement shall not exceed the fees paid by Customer in the three (3) months preceding the claim.

9. Assignment. Provider may assign this Agreement without Customer's consent.

10. Governing law. This Agreement is governed by the laws of the State of California, and disputes shall be heard in the courts located in San Francisco County, California.`}};

/* ---------- engine */
const KINDS=[["liab","Limitation of liability",/liabilit/i],["indem","Indemnity",/indemnif/i],["renew","Term and renewal",/renew/i],["termn","Termination",/terminat/i],
["pay","Fees and payment",/invoice|\bfees\b|payment/i],["law","Governing law",/governed by|governing law/i],["ip","Intellectual property",/intellectual property|work product|right, title/i],
["resid","Residuals",/residual|unaided memory/i],["conf","Confidentiality",/confidential/i],["term","Term",/\bterm\b|remains? in effect|survive/i],["assign","Assignment",/\bassign/i],
["nonsol","Non-solicitation",/solicit/i],["purpose","Purpose",/purpose/i]];
const num=s=>{const m=/\(?(\d+(?:\.\d+)?)\)?/.exec(s);return m?+m[1]:null};
function segments(text){const t=text.replace(/\r/g,"").trim(),out=[];
const parts=t.split(/\n\s*\n|\n(?=\s*\d{1,2}(?:\.\d+)*[.)]\s)/).map(s=>s.replace(/\s+/g," ").trim()).filter(Boolean);
parts.forEach((p,i)=>{const m=/^(\d{1,2}(?:\.\d+)*)[.)]\s+([^.]{2,60})\.\s*(.*)$/.exec(p);
const head=m?m[2]:"",body=m?m[3]:p,ref=m?"§"+m[1]:"¶"+(i+1);
const kinds=KINDS.filter(k=>k[2].test(head)).map(k=>k[0]),kb=KINDS.filter(k=>k[2].test(body)).map(k=>k[0]);
out.push({i,ref,head:head||p.slice(0,48)+(p.length>48?"...":""),text:m?body:p,kinds:kinds.length?kinds:kb,lv:0})});return out}
function analyze(text,role){const segs=segments(text),flags=[],B=role==="buyer",lower=text.toLowerCase();
const isNda=/non-disclosure|confidentiality agreement|\bnda\b/i.test(text.slice(0,300));
const add=(s,lv,title,why,ask,hit)=>{flags.push({s,lv,title,why,ask,hit});s.lv=Math.max(s.lv,lv)};
const eff=(/Effective Date[:\s]+([A-Z][a-z]+ \d{1,2}, \d{4})/.exec(text)||[])[1];
let law=null,venue=null;
for(const s of segs){const t=s.text,k=s.kinds;
if(k.includes("liab")){if(/unlimited|shall not be limited/i.test(t))add(s,3,"Liability is uncapped","No ceiling on what either side can owe. Most negotiated agreements cap liability at a multiple of annual fees, with named exceptions.","Can we agree a cap, for example twelve months of fees, with carve-outs for confidentiality and data breaches?",/unlimited|shall not be limited/i);
else{const m=/(\(?\d+\)?)\s*months?/i.exec(t),mo=m?num(m[1]):null;
if(mo!==null&&B&&mo<12)add(s,3,"Liability cap of "+mo+" months of fees","The other side's total liability stops at "+mo+" months of fees. If something goes wrong in month eleven, that may not cover your loss. A common starting position is twelve months.","Will you raise the cap to fees paid or payable in the twelve months before the claim?",m[0]);
else if(mo!==null&&!B&&mo>24)add(s,2,"Cap above two years of fees","Your exposure runs to "+mo+" months of fees. Sellers usually hold the cap at twelve months.","Can the cap be set at fees paid in the twelve months before the claim?",m[0]);
else if(mo===null&&!/fees/i.test(t))add(s,1,"Cap not stated as an amount","The clause limits liability but gives no figure, which leaves the ceiling open to argument.","What figure should the cap be?",/liabilit\w*/i)}}
if(k.includes("indem")){const mutual=/each party shall indemnify|mutual/i.test(t),cust=/(customer|buyer|recipient|client) shall indemnify/i.test(t),prov=/(provider|vendor|supplier|seller) shall indemnify/i.test(t);
if(!mutual&&cust&&B)add(s,3,"One-sided indemnity","Only you indemnify. You would cover the other side's legal costs for claims linked to your use, with no matching promise from them.","Can the indemnity be mutual, with the provider covering third-party IP infringement claims?",/shall indemnify[^.]*/i);
if(!mutual&&prov&&!B)add(s,2,"You carry the indemnity","Only you indemnify. Check that it sits inside the liability cap and is limited to third-party claims.","Can the indemnity be limited to third-party IP claims and capped?",/shall indemnify[^.]*/i)}
if(k.includes("renew")&&/automatic/i.test(t)){const m=/(\(?\d+\)?)\s*days/i.exec(t),d=m?num(m[1]):null;
if(B&&d!==null&&d>=60)add(s,2,"Auto-renewal with a "+d+"-day notice window","The agreement renews by itself unless you give notice "+d+" days before the term ends. Miss that date and you are committed for another term.","Can the notice period be thirty days, and will you send a reminder sixty days before renewal?",m[0]);
else if(B)add(s,1,"Automatic renewal","The agreement renews by itself. Put the notice date in the calendar on the day you sign.","Can renewal require written confirmation from both sides?",/renews? automatically|automatically renew\w*/i);
s.notice=d}
if(k.includes("pay")){const m=/within\s+[a-z\- ]*(\(?\d+\)?)\s*days/i.exec(t),d=m?num(m[1]):null;
if(d!==null&&B&&d<30)add(s,2,"Payment due in "+d+" days","Your accounts team may need thirty days or more to approve and pay an invoice. Late payment here starts interest running.","Can payment terms be net thirty days from receipt of a correct invoice?",m[0]);
if(d!==null&&!B&&d>45)add(s,2,"Payment due in "+d+" days","You wait "+d+" days for cash after each invoice.","Can payment terms be net thirty?",m[0]);
const r=/(\d+(?:\.\d+)?)%\s*per\s*month/i.exec(t);if(r&&B&&+r[1]>=1)add(s,1,"Late interest of "+r[1]+"% a month","That is about "+Math.round(r[1]*12)+"% a year. Many US states cap interest; check the rate for the governing law.","Can late interest be 0.5% a month, starting after written notice?",r[0])}
if(k.includes("termn")){const one=/(provider|vendor|supplier|customer|buyer) may terminate[^.]*for convenience/i.exec(t);
if(one){const who=one[1].toLowerCase(),them=B?/provider|vendor|supplier/.test(who):/customer|buyer/.test(who);
if(them)add(s,2,"Only the other side can leave early","They may end the agreement for convenience; you cannot. You could lose the service at "+(num((/(\(?\d+\)?)\s*days/i.exec(t)||[,""])[1])||"short")+" days' notice.","Can either party terminate for convenience on the same notice, with a refund of prepaid fees?",one[0])}}
if(k.includes("ip")&&/vest in (provider|vendor|supplier)/i.test(t)&&B)add(s,2,"Work made for you belongs to them","Reports and configurations created for you would be owned by the provider. You may need a licence to keep using them.","Can deliverables created for us be assigned to us, with the provider keeping its pre-existing tools?",/vest in \w+/i);
if(k.includes("ip")&&/vest in (customer|buyer|client)/i.test(t)&&!B)add(s,2,"Your work product passes to the customer","Check that your pre-existing tools and know-how are excluded.","Can pre-existing materials and general know-how be carved out?",/vest in \w+/i);
if(k.includes("resid"))add(s,3,"Residuals clause","Anything a person remembers can be used for any purpose. In practice this can undo the confidentiality promise for ideas and know-how.","Can the residuals clause be deleted, or limited to general skills and excluding trade secrets?",/unaided memory[^.]*/i);
if((k.includes("term")||k.includes("conf"))&&!k.includes("renew")){const m=/(\(?\d+\)?)\s*years?/i.exec(t),y=m?num(m[1]):null;
if(y!==null&&y<2)add(s,2,"Confidentiality lasts "+y+" year","Protection ends quickly. Two to five years is common, with trade secrets protected for as long as they stay secret.","Can confidentiality survive three years after the agreement ends, and indefinitely for trade secrets?",m[0])}
if(k.includes("nonsol")){const m=/(\(?\d+\)?)\s*months/i.exec(t),mo=m?num(m[1]):null;if(mo!==null&&mo>12)add(s,1,"Non-solicitation for "+mo+" months","A long restriction on hiring. Twelve months is usual, and general job adverts are normally excluded.","Can it be twelve months, excluding general advertising?",m[0])}
const asg=/(provider|vendor|supplier|customer|buyer)\s+may assign[^.]*without/i.exec(t);if(k.includes("assign")&&asg&&!/each party|either party/i.test(t)&&(B?/provider|vendor|supplier/i:/customer|buyer/i).test(asg[1]))add(s,1,"One-sided assignment","The other side can transfer the agreement to someone else without asking you.","Can assignment need consent, except to a successor in a merger?",/may assign[^.]*/i);
if(k.includes("law")){law=(/laws of the state of ([a-z ]+?)(?:[.,]|$)/i.exec(t)||[])[1];venue=(/courts? located in ([a-z ,]+?)(?:\.|$)/i.exec(t)||[])[1];
if(law&&venue&&!new RegExp(law.trim(),"i").test(venue))add(s,1,"Law and venue in different states",law.trim()+" law, but disputes go to courts in "+venue.trim()+". Arguing one state's law in another state's courts adds cost.","Can disputes be heard in the courts of the state whose law applies?",/courts? located in[^.]*/i)}}
const need=isNda?[["conf","Confidentiality",/confidential/],["law","Governing law",/governed by|governing law/],["return","Return or destruction of information",/return or destr|destroy/],["term","Term",/\bterm\b|remains? in effect/]]
:[["liab","Limitation of liability",/liabilit/],["indem","Indemnity",/indemnif/],["termn","Termination",/terminat/],["law","Governing law",/governed by|governing law/],["conf","Confidentiality",/confidential/],["data","Data protection and security",/personal data|data protection|security/]];
const missing=need.filter(n=>!n[2].test(lower)).map(n=>n[1]);
flags.sort((a,b)=>b.lv-a.lv||a.s.i-b.s.i);
let reminder=null;const rs=segs.find(s=>s.notice);if(eff&&rs){const tm=num((/initial term is[^.]*?(\(?\d+\)?)\s*months/i.exec(rs.text)||[,"12"])[1])||12,e=new Date(eff+" UTC");
if(!isNaN(e)){const end=new Date(Date.UTC(e.getUTCFullYear(),e.getUTCMonth()+tm,e.getUTCDate())),nd=new Date(end-rs.notice*864e5);reminder={end,nd,ref:rs.ref,d:rs.notice}}}
return{isNda,segs,flags,missing,reminder,eff}}

const LV=["","Low","Medium","High"],LK=["","lo","md","hi"];
function mark(t,re){if(!re)return esc(t);const r=typeof re==="string"?new RegExp(re.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),"i"):re,m=r.exec(t);if(!m)return esc(t);
return esc(t.slice(0,m.index))+"<mark>"+esc(m[0])+"</mark>"+esc(t.slice(m.index+m[0].length))}

/* ---------- full check */
function check(root){const ta=$("#cc-text",root),out=$("[data-cc-out]",root),live=$("[data-cc-live]",root),file=$("#cc-file",root),msg=$("[data-cc-msg]",root);let R=null,sel=0,runs=0;
const role=()=>($("input[name=cc-role]:checked",root)||{}).value||"buyer";
function err(h,p){out.innerHTML='<div class="pw-err" role="alert"><b>'+esc(h)+'</b><p>'+esc(p)+"</p></div>";live.textContent=h}
function empty(){out.innerHTML='<div class="pw-empty"><b>No contract yet.</b><p>Paste the text, open a .txt or .docx file, or load one of the synthetic samples. Then run the check.</p></div>'}
function run(){const t=ta.value.trim();
if(!t){err("Nothing to check yet.","Paste contract text or load a sample first.");ta.focus();return}
if(t.length<160){err("That is too short to review.","Paste the full agreement, including the numbered clauses.");return}
R=analyze(t,role());if(R.segs.length<2){err("No clauses found.","The check looks for numbered clauses such as 7. Indemnity. Paste the agreement with its numbering.");return}
sel=0;runs++;draw();const c=[3,2,1].map(l=>R.flags.filter(f=>f.lv===l).length);
live.textContent="Check "+runs+" complete: "+R.flags.length+" flags, "+c[0]+" high, "+c[1]+" medium, "+c[2]+" low. "+R.missing.length+" missing clauses."}
function draw(){const F=R.flags,c=[3,2,1].map(l=>F.filter(f=>f.lv===l).length),tot=R.segs.reduce((a,s)=>a+s.text.length,0);
const map=R.segs.map(s=>'<button type="button" class="pw-map__b pw-lv-'+(LK[s.lv]||"ok")+'" style="--h:'+Math.max(4,Math.round(s.text.length/tot*100))+'" data-cc-seg="'+s.i+'" aria-label="'+esc(s.ref+" "+s.head+": "+(s.lv?LV[s.lv]+" risk":"no flag"))+'"><span>'+esc(s.ref)+"</span></button>").join("");
const list=F.length?F.map((f,i)=>'<li role="option" id="cc-o'+i+'" aria-selected="'+(i===sel)+'" data-cc-i="'+i+'"><span class="pw-lv pw-lv-'+LK[f.lv]+'">'+LV[f.lv]+'</span><span><b>'+esc(f.title)+"</b><small>"+esc(f.s.ref+" "+f.s.head)+"</small></span></li>").join(""):"";
out.innerHTML='<div class="pw-res is-anim"><p class="pw-run">Check '+runs+' · '+(R.isNda?"NDA":"Agreement")+' · '+(role()==="buyer"?"buyer side":"seller side")+'</p><div class="pw-kpis"><div><span>Flags</span><b>'+F.length+'</b></div><div><span>High</span><b>'+c[0]+'</b></div><div><span>Medium</span><b>'+c[1]+'</b></div><div><span>Missing</span><b>'+R.missing.length+"</b></div></div>"+
'<p class="pw-sum">'+esc(summary())+"</p>"+
'<div class="pw-res__g"><div><p class="mv-mi">Risk map · '+R.segs.length+' clauses</p><div class="pw-map" role="group" aria-label="Risk map, one block per clause">'+map+'</div><p class="pw-key"><i class="pw-lv-hi"></i>High <i class="pw-lv-md"></i>Medium <i class="pw-lv-lo"></i>Low <i class="pw-lv-ok"></i>No flag</p></div>'+
'<div><p class="mv-mi" id="cc-fl">Flagged clauses · '+(role()==="buyer"?"you are the buyer":"you are the seller")+"</p>"+(F.length?'<ul class="pw-flags" role="listbox" tabindex="0" aria-labelledby="cc-fl" aria-activedescendant="cc-o'+sel+'">'+list+'</ul><div class="pw-det" data-cc-det></div>':'<div class="pw-empty"><b>No flags for this side.</b><p>Nothing in this draft departs from the starting positions the check uses. A lawyer should still read it.</p></div>')+"</div></div>"+
'<div class="pw-res__g pw-res__g--2"><div><p class="mv-mi">Missing clauses</p>'+(R.missing.length?'<ul class="pw-miss">'+R.missing.map(m=>"<li>"+esc(m)+"</li>").join("")+"</ul>":'<p class="pw-mute">None of the clauses we look for are missing.</p>')+
(R.reminder?'<p class="mv-mi" style="margin-top:20px">Reminder the register would set</p><p class="pw-rem"><b>'+esc(fmtD(R.reminder.nd))+"</b> Last day to give notice of non-renewal ("+esc(R.reminder.ref)+", "+R.reminder.d+" days before the term ends on "+esc(fmtD(R.reminder.end))+").</p>":"")+
'</div><div><p class="mv-mi">Questions to send back</p>'+(F.length?'<ol class="pw-qs">'+F.map(f=>"<li>"+esc(f.ask)+" <small>("+esc(f.s.ref)+")</small></li>").join("")+"</ol>":'<p class="pw-mute">No questions from this check.</p>')+"</div></div></div>";
F.length&&detail();
$$("[data-cc-seg]",out).forEach(b=>b.addEventListener("click",()=>{const i=F.findIndex(f=>f.s.i===+b.dataset.ccSeg);if(i>=0){sel=i;pick()}else{live.textContent=b.getAttribute("aria-label")}}));
const lb=$(".pw-flags",out);if(lb){$$("li",lb).forEach(li=>li.addEventListener("click",()=>{sel=+li.dataset.ccI;pick()}));
lb.addEventListener("keydown",e=>{const n=F.length;if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();sel=(sel+(e.key==="ArrowDown"?1:n-1))%n;pick()}else if(e.key==="Home"){e.preventDefault();sel=0;pick()}else if(e.key==="End"){e.preventDefault();sel=n-1;pick()}})}}
function pick(){const lb=$(".pw-flags",out);$$("li",lb).forEach((li,i)=>li.setAttribute("aria-selected",i===sel));lb.setAttribute("aria-activedescendant","cc-o"+sel);detail();live.textContent=R.flags[sel].title}
function detail(){const f=R.flags[sel],d=$("[data-cc-det]",out);d.innerHTML='<p class="pw-det__r">'+esc(f.s.ref+" "+f.s.head)+'</p><blockquote class="pw-quote">'+mark(f.s.text,f.hit)+'</blockquote><p><b>What it means.</b> '+esc(f.why)+'</p><p><b>Ask.</b> '+esc(f.ask)+"</p>"}
function summary(){const F=R.flags,top=F[0],nc=R.segs.filter(x=>x.ref[0]==="§").length||R.segs.length;if(!F.length)return(R.isNda?"Mutual NDA":"Agreement")+" with "+nc+" clauses and no flags for your side."+(R.missing.length?" "+R.missing.length+" expected clauses are missing.":"");
return(R.isNda?"A mutual NDA":"An agreement")+" with "+nc+" clauses. The most important point for you: "+top.title.toLowerCase()+" ("+top.s.ref+")."+(R.missing.length?" It does not cover "+R.missing.join(", ").toLowerCase()+".":"")}
$$("[data-cc-sample]",root).forEach(b=>b.addEventListener("click",()=>{ta.value=SAMPLES[b.dataset.ccSample].text;msg.textContent="Loaded: "+SAMPLES[b.dataset.ccSample].name+".";run()}));
$("[data-cc-run]",root).addEventListener("click",run);
$("[data-cc-clear]",root).addEventListener("click",()=>{ta.value="";file.value="";msg.textContent="";R=null;empty();live.textContent="Cleared.";ta.focus()});
$$("input[name=cc-role]",root).forEach(r=>r.addEventListener("change",()=>{if(R)run()}));
file.addEventListener("change",async()=>{const f=file.files[0];if(!f)return;
if(f.size>5e6){err("That file is over 5 MB.","Use a smaller file or paste the text.");return}
try{let t;if(/\.docx$/i.test(f.name))t=await docx(await f.arrayBuffer());else if(/\.(txt|md|text)$/i.test(f.name)||f.type.startsWith("text/"))t=await f.text();
else{err("This check reads .txt and .docx files.","For a PDF or a scan, copy the text into the box. The full product reads PDFs and scanned documents.");return}
ta.value=t.trim();msg.textContent="Opened "+f.name+" in this browser. Nothing was uploaded.";run()}catch(e){err("We could not read that file.","Try saving it again as .docx or .txt, or paste the text.")}});
empty()}

async function docx(buf){const v=new DataView(buf),u8=new Uint8Array(buf);let e=-1;for(let i=u8.length-22;i>=0&&i>u8.length-66000;i--)if(v.getUint32(i,!0)===0x06054b50){e=i;break}
if(e<0)throw Error("zip");let n=v.getUint16(e+10,!0),p=v.getUint32(e+16,!0);const td=new TextDecoder;
for(let k=0;k<n;k++){const m=v.getUint16(p+10,!0),cs=v.getUint32(p+20,!0),fl=v.getUint16(p+28,!0),xl=v.getUint16(p+30,!0),cl=v.getUint16(p+32,!0),off=v.getUint32(p+42,!0),name=td.decode(u8.subarray(p+46,p+46+fl));
if(name==="word/document.xml"){const s=off+30+v.getUint16(off+26,!0)+v.getUint16(off+28,!0),data=u8.subarray(s,s+cs);
const x=m===0?data:new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer());
return td.decode(x).replace(/<\/w:p>/g,"\n\n").replace(/<w:tab\/>/g," ").replace(/<[^>]+>/g,"").replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&apos;/g,"'")}
p+=46+fl+xl+cl}throw Error("no document")}

/* ---------- home: the same engine on the synthetic MSA */
function mini(root){const out=$("[data-mini-out]",root);
function run(){const role=($("input[name=mini-role]:checked",root)||{}).value||"buyer",R=analyze(SAMPLES.msa.text,role),F=R.flags.slice(0,3);
out.innerHTML='<p class="pw-sum"><b>'+R.flags.length+" flags</b> for the "+role+", "+R.flags.filter(f=>f.lv===3).length+" high.</p>"+(F.length?'<ul class="pw-mflags">'+F.map(f=>'<li><span class="pw-lv pw-lv-'+LK[f.lv]+'">'+LV[f.lv]+"</span><span><b>"+esc(f.title)+"</b><small>"+esc(f.s.ref+" "+f.s.head)+"</small></span></li>").join("")+"</ul>":'<p class="pw-mute">This draft favours the provider, so the seller side has no flags.</p>')+
(R.reminder&&role==="buyer"?'<p class="pw-rem"><b>'+esc(fmtD(R.reminder.nd))+"</b> Notice deadline before auto-renewal ("+esc(R.reminder.ref)+").</p>":"")}
$$("input[name=mini-role]",root).forEach(r=>r.addEventListener("change",run));run()}

/* ---------- tabs */
function tabs(root){const t=$$("[role=tab]",root);function pick(i,f){t.forEach((b,j)=>{const on=j===i;b.setAttribute("aria-selected",on);b.tabIndex=on?0:-1;$("#"+b.getAttribute("aria-controls")).hidden=!on;if(on&&f)b.focus()})}
t.forEach((b,i)=>{b.addEventListener("click",()=>pick(i));b.addEventListener("keydown",e=>{if(e.key==="ArrowRight"||e.key==="ArrowLeft"){e.preventDefault();pick((i+(e.key==="ArrowRight"?1:t.length-1))%t.length,1)}})})}
function scrollers(){const set=()=>$$(".mv-pscroll,.pw-doc").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2||e.scrollHeight>e.clientHeight+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-pw=check]").forEach(check);$$("[data-pw=mini]").forEach(mini);$$("[data-pw=tabs]").forEach(tabs)}
