/* Caseherald hero: a quiet law-library rotunda of glass opinion cards on three tiers, under a ring of columns.
   12 second cycle: a question at the centre lights up, then sends light along five citation threads in turn to the
   passages that support it. Each card the light reaches shows its passage line in brass and takes a seal that stamps
   in brass and settles to verified green. The rotunda turns slowly and the camera rises over the cycle.
   Scrolling holds the verified state. All content is sample data. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(23);
const bg=new T.Color(colors.bg),ink=new T.Color(colors.ink),brass=new T.Color(color("--ch-brass","#b88a2b")),green=new T.Color(color("--ch-green","#2f8f5b"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),11,24);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xdfe3f2,.75));
const key=new T.DirectionalLight(0xfff0d8,1.05);key.position.set(-4,7,6);root.add(key);
const rim=new T.DirectionalLight(brass.getHex(),.35);rim.position.set(5,3,-6);root.add(rim);
/* rotunda: cards on three tiers facing the centre */
const RAD=3.3,TIERS=3,PER=small?12:16,CW=.56,CH=.74,o=new T.Object3D,cards=[];
for(let t=0;t<TIERS;t++)for(let i=0;i<PER;i++){const a=(i+(t%2)*.5)/PER*Math.PI*2,y=.35+t*.95;cards.push({a,y,t,i})}
const N=cards.length,cGeo=new T.PlaneGeometry(CW,CH),cMat=new T.MeshStandardMaterial({color:ink.clone(),transparent:!0,opacity:.1,roughness:.2,metalness:.1,side:T.DoubleSide,depthWrite:!1}),
inst=new T.InstancedMesh(cGeo,cMat,N);root.add(inst);
const P=[],L=[],v=new T.Vector3,M=[];
const seg=(m,x1,y1,x2,y2,arr)=>{v.set(x1,y1,0).applyMatrix4(m);arr.push(v.x,v.y,v.z);v.set(x2,y2,0).applyMatrix4(m);arr.push(v.x,v.y,v.z)};
cards.forEach((c,k)=>{o.position.set(Math.sin(c.a)*RAD,c.y,Math.cos(c.a)*RAD);o.rotation.set(0,c.a+Math.PI,0);o.updateMatrix();inst.setMatrixAt(k,o.matrix);
const m=o.matrix.clone();M.push(m);const w=CW/2,h=CH/2;seg(m,-w,-h,w,-h,P);seg(m,w,-h,w,h,P);seg(m,w,h,-w,h,P);seg(m,-w,h,-w,-h,P);
seg(m,-w*.76,h*.72,w*.1,h*.72,L);for(let j=0;j<4;j++){const y=h*(.42-j*.3);seg(m,-w*.76,y,w*(j%3?.52:.3),y,L)}});
inst.instanceMatrix.needsUpdate=!0;
const lineObj=(arr,c,op)=>{const g=new T.BufferGeometry;g.setAttribute("position",new T.Float32BufferAttribute(arr,3));const l=new T.LineSegments(g,new T.LineBasicMaterial({color:c,transparent:!0,opacity:op}));root.add(l);return l};
const edges=lineObj(P,ink.clone(),.5),text=lineObj(L,ink.clone(),.28);
/* floor rings, spokes and columns */
const F=[];for(let r=1;r<=5;r++){const rr=r*.78,n=72;for(let s=0;s<n;s++){const a1=s/n*Math.PI*2,a2=(s+1)/n*Math.PI*2;F.push(Math.sin(a1)*rr,-.25,Math.cos(a1)*rr,Math.sin(a2)*rr,-.25,Math.cos(a2)*rr)}}
for(let s=0;s<12;s++){const a=s/12*Math.PI*2;F.push(0,-.25,0,Math.sin(a)*3.9,-.25,Math.cos(a)*3.9)}
const COL=small?8:12;for(let s=0;s<COL;s++){const a=(s+.5)/COL*Math.PI*2,x=Math.sin(a)*4.3,z=Math.cos(a)*4.3;F.push(x,-.25,z,x,3.3,z)}
for(let s=0;s<72;s++){const a1=s/72*Math.PI*2,a2=(s+1)/72*Math.PI*2;F.push(Math.sin(a1)*4.3,3.3,Math.cos(a1)*4.3,Math.sin(a2)*4.3,3.3,Math.cos(a2)*4.3)}
const floor=lineObj(F,ink.clone().lerp(bg,.55),.45);
/* the question and five threads */
const Q=new T.Vector3(0,1.3,0),qMat=new T.MeshStandardMaterial({color:brass.clone(),emissive:brass.clone(),emissiveIntensity:.4,roughness:.4}),
qm=new T.Mesh(new T.SphereGeometry(.09,20,14),qMat);qm.position.copy(Q);root.add(qm);
const HIT=[2,PER+7,PER*2+12,5,PER+13].map(k=>k%N),th=[],pulseGeo=new T.SphereGeometry(.045,12,10);
HIT.forEach((k,n)=>{const c=cards[k],end=new T.Vector3(Math.sin(c.a)*(RAD-.04),c.y+.05,Math.cos(c.a)*(RAD-.04)),mid=Q.clone().lerp(end,.5);mid.y+=.9;
const curve=new T.CatmullRomCurve3([Q.clone(),mid,end]),pts=curve.getPoints(48),g=new T.BufferGeometry().setFromPoints(pts),
line=new T.Line(g,new T.LineBasicMaterial({color:brass.clone(),transparent:!0,opacity:0}));root.add(line);
const pulse=new T.Mesh(pulseGeo,new T.MeshBasicMaterial({color:brass.clone(),transparent:!0,opacity:0}));root.add(pulse);
/* passage highlight and seal ride on a holder that carries the card's own transform */
const hold=new T.Group;hold.matrixAutoUpdate=!1;hold.matrix.copy(M[k]);root.add(hold);
const hl=new T.Mesh(new T.PlaneGeometry(CW*.64,.035),new T.MeshBasicMaterial({color:brass.clone(),transparent:!0,opacity:0,side:T.DoubleSide}));hl.position.set(-CW*.06,CH/2*.12,.01);
const sl=new T.Mesh(new T.CylinderGeometry(.075,.075,.01,small?16:24),new T.MeshStandardMaterial({color:brass.clone(),emissive:brass.clone(),emissiveIntensity:.3,roughness:.5,transparent:!0,opacity:0}));
sl.position.set(CW*.3,CH*.32,.014);sl.rotation.x=Math.PI/2;hold.add(hl,sl);
th.push({curve,line,pulse,hl,sl,t0:1+n*1.25})});
const C0=new T.Vector3(0,4.3,13.6),look=new T.Vector3(0,1.15,0),lk=new T.Vector3;camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const tc=new T.Color;
function frame(t,dt,p){
const hd=clamp((p-.56)/.28),c0=t%12,c=hd>0?lerp(c0,9.4,ease(hd)):c0;
root.rotation.y=t*.035+pointer.x*.06;
const rise=ease(clamp(c/10))*.5;
camera.position.set(C0.x+pointer.x*.3,C0.y+rise-pointer.y*.15,C0.z);lk.copy(look);lk.y+=rise*.4;camera.lookAt(lk);
const reset=c>10.6?ease(clamp((c-10.6)/1.2)):0,qOn=ease(clamp(c/.8))*(1-reset);
qMat.emissiveIntensity=.3+qOn*.9;qm.scale.setScalar(1+qOn*.35+Math.sin(t*2.4)*.04*qOn);
th.forEach(h=>{const u=clamp((c-h.t0)/1.1),e=ease(u),arr=clamp((c-h.t0-1.1)/.5),stamp=clamp((c-h.t0-1.2)/.6);
h.line.material.opacity=(.15+e*.55)*(1-reset)*(c>h.t0?1:0);
h.pulse.material.opacity=u>0&&u<1?.95:0;h.curve.getPoint(e,h.pulse.position);
h.hl.material.opacity=arr*.9*(1-reset);
const s=stamp>0?1+(1-ease(stamp))*.6:1;h.sl.material.opacity=Math.min(1,stamp*2)*(1-reset);
tc.copy(brass).lerp(green,ease(clamp((stamp-.35)/.65)));h.sl.material.color.copy(tc);h.sl.material.emissive.copy(tc);
h.sl.scale.set(s,1,s)});
edges.material.opacity=.42+qOn*.12}
return{frame,resize:(w,h)=>{const n=w/h<.8;C0.z=n?16:13.6;C0.y=n?4.8:4.3;look.y=n?1.5:1.15},
dispose:()=>{[cGeo,edges.geometry,text.geometry,floor.geometry,qm.geometry,pulseGeo].forEach(g=>g.dispose());th.forEach(h=>{h.line.geometry.dispose();h.hl.geometry.dispose();h.sl.geometry.dispose()})}}}
