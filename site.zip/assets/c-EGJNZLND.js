/* Creditcairn hero chamber: a calm river of cash-flow lines through a bank-vault corridor.
   Three streams (bank, tax, invoices) run out of the dark, braid together and pass two policy gates,
   then come to rest at a cairn of five stones whose top stone is gold. Every 10 seconds one pulse of light
   travels the braid and the top stone answers it once. The camera dollies over 20 seconds.
   Scroll: the streams pull tighter and the top stone settles onto the cairn. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(11);
const bg=new T.Color(colors.bg),ink=new T.Color(colors.ink),gold=new T.Color(color("--cc-gold","#c9a227")),coral=new T.Color(color("--cc-coral","#d9644a"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),5,18);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xc8d6c8,.7));
const key=new T.DirectionalLight(0xfff0d8,1.1);key.position.set(-3,6,5);root.add(key);
const rim=new T.DirectionalLight(gold.getHex(),.45);rim.position.set(5,2,-6);root.add(rim);
const floor=new T.Mesh(new T.PlaneGeometry(40,40),new T.MeshBasicMaterial({color:bg.clone().lerp(ink,.03)}));floor.rotation.x=-Math.PI/2;floor.position.y=-1.2;root.add(floor);
/* vault corridor: round-topped arches receding into the fog */
const NA=small?7:10,seg=[],AW=2.6,AH=1.9;
for(let i=0;i<NA;i++){const z=1.5-i*1.55;const P=(x,y)=>[x,y,z];
seg.push(...P(-AW,-1.2),...P(-AW,AH-AW*.0));seg.push(...P(AW,-1.2),...P(AW,AH));
const S=18;for(let k=0;k<S;k++){const a0=Math.PI-k/S*Math.PI,a1=Math.PI-(k+1)/S*Math.PI;seg.push(AW*Math.cos(a0),AH+AW*.42*Math.sin(a0),z,AW*Math.cos(a1),AH+AW*.42*Math.sin(a1),z)}
seg.push(...P(-AW,-1.2),...P(-AW-.25,-1.2),...P(AW,-1.2),...P(AW+.25,-1.2))}
const ag=new T.BufferGeometry;ag.setAttribute("position",new T.Float32BufferAttribute(seg,3));
root.add(new T.LineSegments(ag,new T.LineBasicMaterial({color:ink.clone().lerp(bg,.62),transparent:!0,opacity:.7})));
/* three streams: control points from the back of the vault to the foot of the cairn */
const CAIRN=new T.Vector3(1.25,-1.2,1.1);
const mk=(dx,dy)=>new T.CatmullRomCurve3([new T.Vector3(dx*1.6,-.55+dy,-13),new T.Vector3(dx*1.2,-.7+dy*.6,-8),new T.Vector3(dx*.45,-.82+dy*.3,-4.6),
new T.Vector3(.15+dx*.16,-.9,-2),new T.Vector3(.55+dx*.08,-.98,-.2),new T.Vector3(CAIRN.x-.35+dx*.05,-1.08,CAIRN.z-.1)]);
const curves=[mk(-1,.18),mk(0,0),mk(1,.1)],cols=[ink.clone(),ink.clone().lerp(bg,.25),gold.clone()];
const tubes=curves.map((c,i)=>{const m=new T.Mesh(new T.TubeGeometry(c,small?80:140,.016,6,!1),new T.MeshBasicMaterial({color:cols[i],transparent:!0,opacity:i===2?.85:.6}));root.add(m);return m});
/* drifting particles along each stream: the calm river */
const PN=small?60:130,pp=new Float32Array(PN*3),pu=[],pc=[],tmp=new T.Vector3;
for(let i=0;i<PN;i++){pu.push(R());pc.push(i%3)}
const pg=new T.BufferGeometry;pg.setAttribute("position",new T.BufferAttribute(pp,3));
const pts=new T.Points(pg,new T.PointsMaterial({color:ink.clone().lerp(gold,.3),size:.035,transparent:!0,opacity:.7,depthWrite:!1}));root.add(pts);
/* policy gates: two thin frames the braid passes through */
const gateMat=new T.MeshStandardMaterial({color:gold.clone().lerp(bg,.35),emissive:gold.clone(),emissiveIntensity:.08,roughness:.5,metalness:.3});
const gates=[[-4.6,.9],[-2,.62]].map(([z,s])=>{const g=new T.Group,w=1.5*s,h=.9*s,t=.025,bars=[[w,t,t,0,h],[w,t,t,0,0],[t,h,t,-w/2,h/2],[t,h,t,w/2,h/2]];
bars.forEach(([a,b,c,x,y])=>{const m=new T.Mesh(new T.BoxGeometry(a,b,c),gateMat);m.position.set(x,y,0);g.add(m)});
const p=curves[1].getPointAt(clamp((z+13)/14.1));g.position.set(p.x,-1.08,z);root.add(g);return g});
/* the cairn: five flattened stones, the top one gold */
const cairn=new T.Group;cairn.position.copy(CAIRN);root.add(cairn);
const stoneGeo=new T.SphereGeometry(1,small?18:28,small?12:18),stones=[],W=[.62,.52,.42,.33,.25];let y=0;
W.forEach((w,i)=>{const h=w*.36,top=i===W.length-1;const m=new T.Mesh(stoneGeo,new T.MeshStandardMaterial({color:top?gold.clone():ink.clone().lerp(bg,.12+i*.03),emissive:top?gold.clone():bg.clone(),emissiveIntensity:top?.12:0,roughness:.85,metalness:top?.25:0}));
y+=h*.92;m.scale.set(w,h,w*.82);m.rotation.y=R()*3;m.position.set((R()-.5)*.06,y,(R()-.5)*.05);cairn.add(m);stones.push({m,y,w});y+=h*.8});
/* the pulse */
const dot=new T.Mesh(new T.SphereGeometry(.05,12,10),new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:0}));root.add(dot);
const halo=new T.Mesh(new T.SphereGeometry(.16,12,10),new T.MeshBasicMaterial({color:gold,transparent:!0,opacity:0,depthWrite:!1}));root.add(halo);
const C0=new T.Vector3(2.9,1.35,6.4),look=new T.Vector3(.3,-.55,-1.8),lk=new T.Vector3;camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const top=stones[stones.length-1];
function frame(t,dt,p){
const d=ease(.5-.5*Math.cos(t/20*Math.PI*2));
camera.position.set(C0.x-.45*d+pointer.x*.22,C0.y-.1*d-pointer.y*.12,C0.z-.9*d);lk.copy(look);lk.x+=pointer.x*.08;camera.lookAt(lk);
/* river particles drift toward the cairn */
const a=pg.attributes.position.array;
for(let i=0;i<PN;i++){pu[i]=(pu[i]+dt*.018*(1+(i%5)*.12))%1;curves[pc[i]].getPointAt(pu[i],tmp);a[i*3]=tmp.x;a[i*3+1]=tmp.y+.03+Math.sin(t+i)*.01;a[i*3+2]=tmp.z}
pg.attributes.position.needsUpdate=!0;
/* pulse: 10 s cycle, 4 s along the middle stream, then the top stone answers once */
const c=t%10,u=clamp(c/4),vis=c<4.2?Math.min(1,c*3,(4.2-c)*3):0;
curves[1].getPointAt(ease(u)*.999,tmp);dot.position.copy(tmp);dot.position.y+=.04;halo.position.copy(dot.position);dot.material.opacity=vis*.95;halo.material.opacity=vis*.18;
const glow=c>4&&c<5.6?Math.sin((c-4)/1.6*Math.PI):0;top.m.material.emissiveIntensity=.12+glow*.35;
gateMat.emissiveIntensity=.08+(Math.abs(tmp.z+4.6)<.5||Math.abs(tmp.z+2)<.5?vis*.5:0);
/* scroll: the top stone settles, the braid tightens */
const s=ease(clamp((p-.55)/.3));
top.m.position.y=top.y+.22*(1-s);top.m.rotation.z=(1-s)*.18;
tubes.forEach((m,i)=>{m.scale.x=1-s*.05*(i-1)});
cairn.rotation.y=Math.sin(t*.12)*.05}
return{frame,resize:(w,h)=>{C0.z=6.4+(w/h<.8?2.2:0);C0.x=w/h<.8?1.6:2.9},dispose:()=>{[ag,pg,stoneGeo,floor.geometry,dot.geometry,halo.geometry].concat(tubes.map(m=>m.geometry)).forEach(g=>g.dispose())}}}
