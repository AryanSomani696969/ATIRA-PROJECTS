/* Filingquill hero: a quiet reading room of stacked filing pages in paper tones on five depth planes, 12-second loop.
   Beat 1 (0-3 s): the stacks rest; on the front page a line in the debt note takes an amber highlight.
   Beat 2 (3-7 s): one figure cell lifts out of the maturity table, turning slowly as it rises toward the right.
   Beat 3 (6-9 s): a citation-blue thread traces the figure back to its line on the page.
   Beat 4 (8-12 s): three peer comparison bars rise beside the cited figure, the scene settles, then eases back.
   Pointer and scroll move the planes by a few pixels each. Scrolling holds the settled state. Everything here is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(15);
const bg=new T.Color(colors.bg),paper=new T.Color(color("--fq-paper","#f5f3ee")),amber=new T.Color(color("--fq-amber","#d9822b")),blue=new T.Color(color("--fq-blue","#2f6fb3"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),6,16);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xe8e4da,.75));
const key=new T.DirectionalLight(0xffe2bd,1.05);key.position.set(-3,5,6);root.add(key);
const rim=new T.DirectionalLight(amber.getHex(),.45);rim.position.set(4,-1,-3);root.add(rim);
const v3=(x,y,z)=>new T.Vector3(x,y,z);
/* five depth planes: four of stacked sheets, the fifth holds the front page */
const planes=[],sheetGeo=new T.BoxGeometry(1,1.32,.012),sheetMat=new T.MeshStandardMaterial({color:paper.clone(),roughness:.95,metalness:0,emissive:new T.Color(0x24304a),emissiveIntensity:.5});
const stacksPer=small?3:5,perStack=small?5:8,total=4*stacksPer*perStack,inst=new T.InstancedMesh(sheetGeo,sheetMat,total),o=new T.Object3D,tc=new T.Color;let n=0;
for(let pl=0;pl<4;pl++){const z=-7+pl*1.35,g={z,k:.12+pl*.07,items:[]};
for(let s=0;s<stacksPer;s++){const x=(s-(stacksPer-1)/2)*2.3+(R()-.5)*.8+(pl%2?.9:-.4),y=(R()-.5)*1.6+(pl===3?-.3:.2),sc=.75+R()*.5;
for(let j=0;j<perStack;j++){g.items.push({i:n,p:v3(x+(R()-.5)*.05,y+j*.02,z+j*.016),r:(R()-.5)*.14,sc});n++}}planes.push(g)}
root.add(inst);
const dim=pl=>bg.clone().lerp(paper,.16+pl*.11);
/* the front page */
const front=new T.Group;front.position.set(-.55,.05,-.4);front.rotation.set(-.06,.22,.015);root.add(front);
const fp=new T.Mesh(new T.BoxGeometry(2,2.6,.02),new T.MeshStandardMaterial({color:paper.clone(),roughness:.9,emissive:paper.clone(),emissiveIntensity:.42}));front.add(fp);
const lineMat=new T.MeshBasicMaterial({color:bg.clone().lerp(paper,.62)}),lines=[];
const LN=[[1.1,1.02],[1.5,.9],[1.42,.8],[1.32,.7],[.9,.6],[1.5,.42],[1.38,.32],[1.46,.22]];
LN.forEach(([w,y],i)=>{const m=new T.Mesh(new T.BoxGeometry(w,.035,.004),i===0?new T.MeshBasicMaterial({color:bg.clone().lerp(paper,.35)}):lineMat);m.position.set(-.78+w/2,y,.013);front.add(m);lines.push(m)});
const hl=new T.Mesh(new T.BoxGeometry(1.4,.085,.003),new T.MeshBasicMaterial({color:amber.clone(),transparent:!0,opacity:0}));hl.position.set(-.78+.7-.03,.7,.0115);front.add(hl);
/* the maturity table: 6 rows x 2 columns */
const tp=[],tx0=-.78,tx1=.78,ty0=.06,rh=.16,rows=6;
for(let r=0;r<=rows;r++)tp.push(v3(tx0,ty0-r*rh,.013),v3(tx1,ty0-r*rh,.013));
[tx0,.2,tx1].forEach(x=>tp.push(v3(x,ty0,.013),v3(x,ty0-rows*rh,.013)));
front.add(new T.LineSegments(new T.BufferGeometry().setFromPoints(tp),new T.LineBasicMaterial({color:bg.clone().lerp(paper,.55)})));
const cellMat=new T.MeshBasicMaterial({color:bg.clone().lerp(paper,.7)});
for(let r=0;r<rows;r++){const a=new T.Mesh(new T.BoxGeometry(.34,.03,.004),cellMat);a.position.set(tx0+.25,ty0-r*rh-rh/2,.014);front.add(a);
const b=new T.Mesh(new T.BoxGeometry(.3,.03,.004),cellMat);b.position.set(tx1-.22,ty0-r*rh-rh/2,.014);front.add(b)}
const slot=new T.Mesh(new T.BoxGeometry(.56,.15,.004),new T.MeshBasicMaterial({color:amber.clone(),transparent:!0,opacity:0}));slot.position.set(.49,ty0-5*rh-rh/2,.0125);front.add(slot);
const pno=new T.Mesh(new T.BoxGeometry(.16,.03,.004),lineMat);pno.position.set(0,-1.17,.013);front.add(pno);
/* the lifted figure: a thin amber-edged card */
const fig=new T.Group;root.add(fig);
const figCard=new T.Mesh(new T.BoxGeometry(.66,.26,.04),new T.MeshStandardMaterial({color:paper.clone(),roughness:.6,emissive:amber.clone(),emissiveIntensity:.05}));fig.add(figCard);
const edgeG=new T.BufferGeometry().setFromPoints([[-1,-1],[1,-1],[1,-1],[1,1],[1,1],[-1,1],[-1,1],[-1,-1]].map(([x,y])=>new T.Vector3(x*.33,y*.13,.021))),edge=new T.LineSegments(edgeG,new T.LineBasicMaterial({color:amber.clone()}));fig.add(edge);
for(let k=0;k<4;k++){const d=new T.Mesh(new T.BoxGeometry(.07,.11,.006),new T.MeshBasicMaterial({color:bg.clone()}));d.position.set(-.18+k*.11,0,.024);fig.add(d)}
const chip=new T.Mesh(new T.BoxGeometry(.26,.09,.01),new T.MeshBasicMaterial({color:blue.clone(),transparent:!0,opacity:0}));chip.position.set(-.2,-.21,.02);fig.add(chip);
/* peer bars */
const bars=[.62,.92,.46].map((h,i)=>{const m=new T.Mesh(new T.BoxGeometry(.13,1,.13),new T.MeshStandardMaterial({color:i===0?amber.clone():paper.clone().lerp(bg,.25),roughness:.7}));m.userData.h=h;m.scale.y=.001;root.add(m);return m});
const base=new T.Mesh(new T.BoxGeometry(.9,.01,.16),new T.MeshBasicMaterial({color:paper.clone().lerp(bg,.4)}));root.add(base);
/* thread geometry is rebuilt each frame from the page line to the figure (cheap: 1 tube, 48 segments) */
const tMat=new T.MeshBasicMaterial({color:new T.Color(color("--fq-blue-lt","#8db8e8"))});let tube=null;
const wa=new T.Vector3,wb=new T.Vector3;
camera.fov=38;camera.updateProjectionMatrix();
const P0=v3(.2,.15,6.6),P1=v3(.45,.05,5.6),look=v3(.15,-.05,-1),lk=v3(),wide={k:1},F0=v3(.18,-.82,-.3),F1=v3(1.3,.22,.35);
function frameFn(t,dt,p){const hold=clamp((p-.42)/.3),c0=t%12,c=hold>0?lerp(c0,10.4,ease(hold)):c0,back=c>11?ease((c-11)/1):0;
const cp=P0.clone().lerp(P1,ease(clamp((c-1)/7))*(1-back));cp.multiplyScalar(wide.k);camera.position.copy(cp);camera.position.x+=pointer.x*.18;camera.position.y-=pointer.y*.1;
lk.copy(look);camera.lookAt(lk);
/* planes: a few pixels of parallax each, scroll pushes them apart slightly */
planes.forEach((g,pl)=>{const px=pointer.x*g.k*.35,py=-pointer.y*g.k*.2;g.items.forEach(it=>{o.position.set(it.p.x+px,it.p.y+py+p*.25*(pl-1.5)*.2,it.p.z);o.rotation.set(-.08,0,it.r);o.scale.set(it.sc,it.sc,1);o.updateMatrix();inst.setMatrixAt(it.i,o.matrix);inst.setColorAt(it.i,tc.copy(dim(pl)))})});
inst.instanceMatrix.needsUpdate=!0;if(inst.instanceColor)inst.instanceColor.needsUpdate=!0;
front.position.x=-.55+pointer.x*.06;front.position.y=.05-pointer.y*.04;
const h=ease(clamp((c-1.2)/1.2))*(1-back);hl.material.opacity=h*.85;hl.scale.x=Math.max(.01,h);hl.position.x=-.78+.7*h-.03;
const lift=ease(clamp((c-3)/4))*(1-back);slot.material.opacity=clamp((c-2.6)/.6)*(1-back)*.55;
front.updateMatrixWorld(!0);slot.getWorldPosition(wa);
const fpos=wa.clone().lerp(F1,lift);fpos.y+=Math.sin(lift*Math.PI)*.25;fig.position.copy(fpos);fig.rotation.y=lerp(.22,-.35,lift)+Math.sin(t*.52)*.05*lift;fig.rotation.x=lerp(-.06,.04,lift);
fig.scale.setScalar(lerp(.82,1.12,lift));fig.visible=lift>.01||c<3.2&&c>2.6;
chip.material.opacity=clamp((c-7.4)/.6)*(1-back);
/* thread: from the highlighted line back to the figure */
const th=ease(clamp((c-6)/2.6))*(1-back);if(tube){root.remove(tube);tube.geometry.dispose();tube=null}
if(th>.01&&lift>.5){hl.getWorldPosition(wb);wb.x+=.55;const a=fig.position.clone().add(v3(-.36,0,0)),m1=v3(a.x-.5,a.y,a.z),m2=v3(wb.x+.4,wb.y,wb.z+.1);
const curve=new T.CatmullRomCurve3([a,m1,m2,wb.clone().add(v3(0,0,.03))],!1,"centripetal");const g=new T.TubeGeometry(curve,small?24:48,.017,6,!1);g.setDrawRange(0,Math.floor(g.index.count*th/3)*3);tube=new T.Mesh(g,tMat);root.add(tube)}
/* bars rise beside the figure */
base.position.set(F1.x+.05,F1.y-1.25,F1.z);bars.forEach((b,i)=>{const e=ease(clamp((c-7.2-i*.3)/1))*(1-back),hh=b.userData.h*e+.001;b.scale.y=hh;b.position.set(F1.x-.25+i*.3,F1.y-1.25+hh/2,F1.z)})}
return{frame:frameFn,resize:(w,h)=>{wide.k=w/h<.6?1.6:w/h<1.2?1.18:1},dispose:()=>{[sheetGeo,fp.geometry,figCard.geometry,edgeG,base.geometry].forEach(g=>g.dispose());if(tube)tube.geometry.dispose()}}}
