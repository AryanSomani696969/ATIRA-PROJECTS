import{B as Torus,G as PLight}from"./c-5CYXJTUX.js";
/* Chronicward hero: a warm split scene. A home table (phone, cup) on the left and a clinic desk (screen, risk ladder of
   patient dots) on the right, joined by a daily rhythm arc. 14 s loop, three beats:
   0-5 s  establish: reading bubbles enter from the edges, a reminder chime rings at the phone;
   5-10 s process: bubbles travel the arc and patient dots climb or fall on the ladder;
   10-14 s outcome: the three dots highest on the ladder turn tomato (today's calls), then everything eases back.
   Scroll tilts the camera a little toward the desk. Instanced and small: well under 120K triangles. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(5);
const bg=new T.Color(colors.bg),oat=new T.Color(color("--cw-oat","#f5efe3")),tom=new T.Color(color("--cw-tomato","#e4572e")),lav=new T.Color(color("--cw-lav","#e7e2f2"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),9,22);
const root=new T.Group;scene.add(root);
root.add(new T.HemisphereLight(0xfff4e6,bg.getHex(),.9));
const key=new T.DirectionalLight(0xffe7cc,1.1);key.position.set(-4,7,5);root.add(key);
const rim=new T.DirectionalLight(tom.getHex(),.35);rim.position.set(6,3,-5);root.add(rim);
const wood=new T.MeshStandardMaterial({color:oat.clone().lerp(bg,.18),roughness:.85,metalness:0}),paper=new T.MeshStandardMaterial({color:oat,roughness:.7});
const G=[];const box=(w,h,d,m,x,y,z,g=root)=>{const ge=new T.BoxGeometry(w,h,d);G.push(ge);const me=new T.Mesh(ge,m);me.position.set(x,y,z);g.add(me);return me};
/* home table, left */
const home=new T.Group;home.position.set(-3.1,0,0);root.add(home);
box(2.4,.08,1.3,wood,0,-.2,0,home);[[-1.05,-.5],[1.05,-.5],[-1.05,.5],[1.05,.5]].forEach(([x,z])=>box(.07,1.1,.07,wood,x,-.79,z,home));
const phone=box(.36,.04,.66,new T.MeshStandardMaterial({color:bg.clone().lerp(oat,.12),roughness:.4}),-.35,-.14,.1,home);phone.rotation.y=.25;
const scr=box(.3,.01,.56,new T.MeshBasicMaterial({color:lav}),-.35,-.115,.1,home);scr.rotation.y=.25;
const cupG=new T.CylinderGeometry(.16,.13,.34,24);G.push(cupG);const cup=new T.Mesh(cupG,paper);cup.position.set(.55,.01,-.15);home.add(cup);
/* clinic desk, right, with a screen and the risk ladder */
const desk=new T.Group;desk.position.set(3.1,0,-.4);root.add(desk);
box(2.6,.08,1.3,wood,0,-.2,0,desk);[[-1.15,-.5],[1.15,-.5],[-1.15,.5],[1.15,.5]].forEach(([x,z])=>box(.07,1.1,.07,wood,x,-.79,z,desk));
box(1.5,.95,.06,new T.MeshStandardMaterial({color:bg.clone().lerp(new T.Color(0),.25),roughness:.5}),-.15,.5,-.35,desk);box(.08,.36,.08,wood,-.15,-.02,-.35,desk);
const LAD=7,ladX=.95,rungM=new T.MeshBasicMaterial({color:oat.clone().lerp(bg,.45)});
for(let i=0;i<LAD;i++)box(.5,.015,.015,rungM,ladX,-.05+i*.32,-.2,desk);box(.015,2.1,.015,rungM,ladX-.25,.92,-.2,desk);box(.015,2.1,.015,rungM,ladX+.25,.92,-.2,desk);
/* patient dots on the ladder (instanced) */
const PN=small?9:14,dotG=new T.SphereGeometry(.075,16,12);G.push(dotG);const dots=new T.InstancedMesh(dotG,new T.MeshStandardMaterial({color:0xffffff,roughness:.5}),PN);
const P=[];for(let i=0;i<PN;i++){P.push({x:ladX+lerp(-.2,.2,R()),z:-.2+lerp(-.08,.08,R()),a:R()*1.6,b:R()*6.28,top:0})}
[2,5,9].forEach(i=>{if(P[i])P[i].top=1});desk.add(dots);
const halo=[];for(let k=0;k<3;k++){const tg=new Torus(.13,.012,8,40);G.push(tg);const h=new T.Mesh(tg,new T.MeshBasicMaterial({color:tom,transparent:!0,opacity:0}));desk.add(h);halo.push(h)}
/* the daily rhythm arc, phone to screen */
const arcC=new T.CatmullRomCurve3([new T.Vector3(-3.45,-.08,.15),new T.Vector3(-2.2,1.9,.4),new T.Vector3(0,2.7,.3),new T.Vector3(2.1,2.1,-.2),new T.Vector3(2.95,.75,-.72)]);
const arcG=new T.TubeGeometry(arcC,120,.014,6,!1);G.push(arcG);root.add(new T.Mesh(arcG,new T.MeshBasicMaterial({color:lav,transparent:!0,opacity:.55})));
/* reading bubbles: flattened rounded spheres that travel the arc */
const BN=small?5:8,bubG=new T.SphereGeometry(.17,20,14);G.push(bubG);const bubs=new T.InstancedMesh(bubG,new T.MeshStandardMaterial({color:0xffffff,roughness:.35,transparent:!0,opacity:.92}),BN);root.add(bubs);
const B=[];for(let i=0;i<BN;i++)B.push({off:i/BN,side:R()<.5?-1:1,y:lerp(.4,2.2,R())});
/* reminder chime: two rings that pulse at the phone */
const chimes=[0,1].map(()=>{const tg=new Torus(.22,.01,6,48);G.push(tg);const m=new T.Mesh(tg,new T.MeshBasicMaterial({color:lav,transparent:!0,opacity:0}));m.rotation.x=Math.PI/2;m.position.set(-3.45,-.1,.12);root.add(m);return m});
const pl=new PLight(0xffd9c4,0,3,2);desk.add(pl);
/* soft dust */
const DN=small?40:90,dp=new Float32Array(DN*3);for(let i=0;i<DN;i++){dp[i*3]=lerp(-6,6,R());dp[i*3+1]=lerp(-.6,3.2,R());dp[i*3+2]=lerp(-4,2,R())}
const dg=new T.BufferGeometry;dg.setAttribute("position",new T.BufferAttribute(dp,3));root.add(new T.Points(dg,new T.PointsMaterial({color:oat,size:.018,transparent:!0,opacity:.3,depthWrite:!1})));
const C0=new T.Vector3(0,1.6,8.4),look=new T.Vector3(0,.7,0),lk=new T.Vector3;camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const o=new T.Object3D,tc=new T.Color,io=c=>c<.5?4*c*c*c:1-Math.pow(-2*c+2,3)/2;
function frame(t,dt,p){
const c=t%14,b1=clamp(c/5),b2=clamp((c-5)/5),b3=clamp((c-10)/4),back=c>12?io(clamp((c-12)/2)):0;
/* camera: slow eased drift, scroll leans toward the desk */
const d=io(.5-.5*Math.cos(t/14*Math.PI*2)),s=clamp((p-.5)/.45);
camera.position.set(C0.x+.6*d+s*.8+pointer.x*.25,C0.y+.15*d-pointer.y*.12,C0.z-.5*d-s*.6);lk.copy(look);lk.x+=s*.6+pointer.x*.08;camera.lookAt(lk);
/* chime at beat 1 */
chimes.forEach((m,k)=>{const u=clamp((c-.4-k*.35)/1.4),v=u>0&&u<1?Math.sin(u*Math.PI):0;m.scale.setScalar(1+u*1.6);m.material.opacity=v*.7});
/* bubbles: enter from the edges in beat 1, ride the arc in beat 2, fade in beat 3 */
for(let i=0;i<BN;i++){const q=B[i];let x,y,z,sc=1,op;
 if(c<5){const e=io(clamp(b1*1.3-q.off*.3));x=lerp(q.side*7,-3.45+q.off*.4,e);y=lerp(q.y,-.02+q.off*.12,e);z=lerp(1.5,.15,e);sc=.6+.4*e}
 else{const u=clamp(b2*1.15-q.off*.15),pt=arcC.getPointAt(Math.min(.999,io(u)));x=pt.x;y=pt.y+.02;z=pt.z;sc=1-.35*clamp((u-.85)/.15)}
 op=c>10?1-b3:1;o.position.set(x,y,z);o.scale.set(sc*1.3*op+.001,sc*.82*op+.001,sc*.5*op+.001);o.rotation.set(0,0,0);o.updateMatrix();bubs.setMatrixAt(i,o.matrix);
 tc.copy(i%3?oat:lav);bubs.setColorAt(i,tc)}
bubs.instanceMatrix.needsUpdate=!0;bubs.instanceColor.needsUpdate=!0;
/* dots climb or fall in beat 2; the three call-today dots settle at the top in beat 3 */
let h=0;for(let i=0;i<PN;i++){const q=P[i],base=q.a,move=Math.sin(q.b+t*.6)*.25*b2*(1-back),goal=q.top?1.75+h*.0:base;
 const y=lerp(base+move,goal,q.top?io(clamp(b2*1.2))*(1-back):0)-.02;o.position.set(q.x,y,q.z);o.scale.setScalar(1);o.updateMatrix();dots.setMatrixAt(i,o.matrix);
 const hot=q.top?io(b3>0?clamp(b3*2):0)*(1-back):0;tc.copy(oat).lerp(tom,hot);dots.setColorAt(i,tc);
 if(q.top&&halo[h]){halo[h].position.set(q.x,y,q.z+.02);halo[h].material.opacity=hot*.9;halo[h].scale.setScalar(1+.15*Math.sin(t*3+h));h++}}
dots.instanceMatrix.needsUpdate=!0;dots.instanceColor.needsUpdate=!0;
pl.position.set(ladX,1.8,.4);pl.intensity=(c>10?Math.sin(b3*Math.PI):0)*1.6;
const a=dg.attributes.position.array;for(let i=0;i<DN;i++)a[i*3+1]+=Math.sin(t*.25+i)*2.5e-4;dg.attributes.position.needsUpdate=!0}
return{frame,resize:(w,h)=>{C0.z=w/h<.8?12:8.4},dispose:()=>{G.forEach(g=>g.dispose());dg.dispose()}}}
