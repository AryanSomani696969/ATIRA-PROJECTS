/* Scamvane page tools: the scam message checker and the pattern library filter.
   Everything runs in the browser with written rules; nothing is sent anywhere and nothing is stored. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const E=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

/* ------------------------------------------------------------ sample messages (synthetic; links are written with [.] so they cannot be opened) */
const SAMPLES={
 parcel:{from:"unknown",t:"Parcel notice: your package is held at our depot because the address is incomplete. Pay the $1.99 redelivery fee within 24 hours or it will be returned to sender: parcel-redelivery-help[.]top/fee"},
 bank:{from:"unknown",t:"ALERT: Unusual sign-in on your bank account. Your card has been locked. Verify your identity now at secure-bank-verify[.]info/login or call 555-0142. Do not tell anyone about this message."},
 job:{from:"unknown",t:"Hi! We found your resume online. Remote part-time job, earn $300 per day, no experience needed. The training kit is $49 and refundable. Reply YES and our recruiter will message you on a chat app."},
 refund:{from:"unknown",t:"Hi, so sorry, I sent you $250 by mistake on the payment app. It was meant for my landlord. Can you please send it back today? Thank you!"},
 dentist:{from:"short",t:"Northside Dental: reminder of your cleaning on Thu, Dec 4 at 3:40 PM. Reply C to confirm or R to reschedule. Reply STOP to opt out."},
 code:{from:"short",t:"Your sign-in code is 482913. It expires in 10 minutes. Never share this code. We will never call or text you to ask for it."}};

/* ------------------------------------------------------------ rules: each sign has a weight, a plain label, why it matters and a kind used for the next steps */
const SHORT=["bit.ly","tinyurl.com","t.co","rb.gy","is.gd","cutt.ly","shorturl.at","ow.ly","tiny.cc","s.id","t.ly"];
const ODD=["top","xyz","icu","click","info","live","shop","vip","buzz","cyou","sbs","cfd","rest","support","online","site","club","win","loan","work"];
const LOOK=/(deliver|parcel|package|track|secure|verify|account|login|signin|support|refund|billing|update|alert|bank|pay|toll|claim|wallet)/;
const R=(src)=>new RegExp(src,"i");
const SIGNS=[
 {id:"urgent",w:2,k:"any",l:"Pressure to act fast",y:"A short deadline is there to stop you from checking. Real organizations give you time.",
  rx:R("\\b(urgent(?:ly)?|immediately|right away|within (?:\\d+|one|two|24|48) (?:hours?|minutes?|days?)|today only|final (?:notice|warning|attempt)|act now|expires? (?:today|soon|tonight)|last chance|as soon as possible|asap|send it back today)\\b")},
 {id:"threat",w:2,k:"any",l:"A threat if you do not act",y:"Saying an account is locked or a fine is due makes people anxious enough to tap without thinking.",
  rx:R("\\b(suspend(?:ed)?|locked|disabled|frozen|terminated|arrest(?:ed)?|warrant|legal action|penalt(?:y|ies)|late fee|collections|returned to sender)\\b")},
 {id:"pay",w:2,k:"any",l:"Asks for money or a fee",y:"A small fee is a common way to get your card details. The fee is rarely the real target.",
  rx:R("(\\$\\s?\\d[\\d.,]*|\\b(?:fee|pay(?:ment)? (?:now|due|required)|deposit|balance due|outstanding balance|training kit)\\b)")},
 {id:"oddpay",w:3,k:"pay",l:"A payment that is hard to reverse",y:"Gift cards, crypto, wire transfers and payment apps work like cash. Once sent, the money is hard to get back.",
  rx:R("\\b(gift ?cards?|wire transfer|bitcoin|crypto(?:currency)?|usdt|money ?order|payment app|cash ?app|zelle|venmo)\\b")},
 {id:"secret",w:3,k:"bank",l:"Asks for codes or account details",y:"Banks and services do not ask for a PIN, password, card number or one-time code by text.",
  rx:R("\\b(one[- ]time (?:code|password|passcode|pin)|verification code|security code|passcode|pin number|your pin|password|social security|ssn|card number|cvv|login details|bank details|routing number)\\b")},
 {id:"verify",w:2,k:"bank",l:"Asks you to confirm your details",y:"\"Verify your identity\" links usually lead to a copy of a real sign-in page that records what you type.",
  rx:R("\\b(verify|confirm|update|validate|re-?activate|unlock) (?:your |the )?(?:account|identity|details|information|card|payment|billing|address)\\b")},
 {id:"prize",w:2,k:"prize",l:"A prize you did not enter for",y:"You cannot win a draw you never entered. Claim fees and \"shipping\" charges are the trick.",
  rx:R("\\b(congratulations|you(?:'ve| have)? won|winner|prize|free gift|you have been selected|claim (?:your|now))\\b")},
 {id:"job",w:2,k:"job",l:"A job offer out of nowhere",y:"Real employers do not hire by surprise text, and they never ask you to pay for training or equipment.",
  rx:R("\\b(remote (?:job|position|work)|work from home|part[- ]time job|(?:earn|make) \\$?\\d+|per day|daily pay|recruiter|no experience needed|we found your resume)\\b")},
 {id:"invest",w:2,k:"invest",l:"Promised returns",y:"Nobody can guarantee investment returns. Strangers who offer a sure thing are usually after a deposit.",
  rx:R("\\b(guaranteed (?:returns?|profits?)|double your (?:money|investment)|trading (?:platform|signals?)|returns? of \\d+ ?%|investment opportunity|crypto mentor)\\b")},
 {id:"refund",w:3,k:"refund",l:"The send-money-back trick",y:"The first payment is often from a stolen card or never arrives. If you send money back, you lose your own.",
  rx:R("\\b(sent (?:it |you |the money |you \\$?\\d+ )?(?:by mistake|by accident)|by mistake on the payment app|accidentally sent|wrong (?:person|account)|send (?:it|the money) back)\\b")},
 {id:"generic",w:1,k:"any",l:"A greeting with no name",y:"\"Dear customer\" means the sender may not know who you are.",
  rx:R("\\b(dear (?:customer|user|client|member|sir|madam|account holder)|valued customer)\\b")},
 {id:"secrecy",w:3,k:"any",l:"Asks you to keep it quiet",y:"Being told not to tell anyone, or not to call your bank, is a strong sign. Talking to someone is the best defence.",
  rx:R("\\b(do(?:n't| not) tell (?:anyone|anybody|your)|tell no one|keep (?:this|it) (?:between us|private|secret)|do(?:n't| not) (?:call|contact) (?:your )?(?:bank|anyone)|stay on the line)\\b")},
 {id:"authority",w:2,k:"authority",l:"Claims to be a government office",y:"Government offices do not demand payment by text, and they do not threaten arrest in a message.",
  rx:R("\\b(irs|tax (?:office|refund)|social security administration|medicare|police|sheriff|court|customs|immigration office)\\b")},
 {id:"delivery",w:1,k:"delivery",l:"A delivery story",y:"Fake parcel and unpaid-toll texts are among the most common scams. They work because most of us are waiting for something.",
  rx:R("\\b(package|parcel|redeliver\\w*|shipment|courier|tracking number|address (?:is )?incomplete|could not be delivered|unpaid toll|toll balance)\\b")},
 {id:"wrongnum",w:2,k:"wrongnum",l:"A friendly wrong-number opener",y:"A chatty message to the wrong person is how long investment and romance scams often begin.",
  rx:R("(^\\s*(?:hi|hello|hey)[,!. ]+(?:is this|are you) |\\bwrong number\\b|sorry,? (?:i|we) (?:have|got) the wrong)")},
 {id:"chatapp",w:2,k:"any",l:"Wants to move you to another app",y:"Moving the chat to another app takes you away from the phone company's spam filters and the record of what was said.",
  rx:R("\\b(message you on|chat app|move (?:this|the chat) to|text me on|add me on)\\b")},
 {id:"otpask",w:5,k:"otp",l:"Asks you to pass on a code",y:"A code sent to your phone is a key to your account. Anyone who asks you for it is trying to sign in as you.",
  rx:R("\\b(?:send|share|tell|give|read)(?: me| us)?(?: the| that| your| this)? ?(?:\\d-digit )?code\\b")},
 {id:"callnum",w:2,k:"any",l:"Gives a number to call back",y:"A number inside a suspicious message goes to the sender. Call the number you look up yourself.",
  rx:R("\\b(?:call|text|contact)(?: us)?(?: now| back)? (?:at |on )?\\+?\\d[\\d\\s().-]{6,}\\d")}];
const GOOD=[
 {id:"noshare",w:-3,l:"Tells you never to share the code",y:"Genuine sign-in messages warn you not to share the code, and they ask you for nothing.",rx:R("\\b(?:do not|don't|never) share\\b")},
 {id:"optout",w:-1,l:"Offers a plain way to opt out",y:"Real reminder services say how to stop messages. On its own this does not prove a message is genuine.",rx:R("\\breply stop\\b")}];

const STEPS={
 base:{scam:["Do not tap the link, reply, or call any number in the message.","Delete it. Most US carriers also accept spam texts forwarded to 7726, which helps them block the sender.","If someone you look out for got the same message, tell them. A Family Circle does this for you."],
  suspicious:["Do not tap yet. Check through the official app, or a website or number you look up yourself.","If it seems to come from someone you know, call them on the number you already have.","Still unsure? Wait. A genuine message will still be genuine tomorrow."],
  safe:["We did not find common warning signs in these words. That is not a promise: scams change.","If a later message asks you to pay, sign in or share a code, check it again.","When in doubt, contact the sender through a channel you already use."]},
 delivery:"Track the parcel in the carrier's own app, or on the website you type yourself, with the number from your order email.",
 bank:"Call the number on the back of your card, or open your bank's own app. Your bank will not ask for a PIN or code by text.",
 job:"Do not pay for training, equipment or a starter kit. Look up the company yourself before you reply.",
 invest:"Do not move money to a platform someone found for you. Talk it over with someone you trust first.",
 refund:"Do not send money back. Ask your payment app or bank to look at the payment; if it was a real mistake, they can return it.",
 authority:"Look up the office's number yourself. Government offices do not take payment by gift card, crypto or text link.",
 prize:"Do not pay a fee to claim a prize. You cannot win something you did not enter.",
 wrongnum:"You do not need to reply. If you already are chatting, do not move to another app and do not talk about money.",
 otp:"Never pass on a code someone asks for. If you already did, change your password and call the service.",
 pay:"If you paid, call your bank or card company now. The sooner they hear, the more they can do."};

function hostsOf(t){
 const out=[];const rx=/\b((?:https?:\/\/)?(?:www\.)?((?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+([a-z]{2,24})|\d{1,3}(?:\.\d{1,3}){3}))(\/[^\s]*)?/gi;let m;
 while((m=rx.exec(t))){const host=m[2].toLowerCase(),tld=(m[3]||"").toLowerCase();
  if(/^\d+(\.\d+)?$/.test(host))continue;               /* prices and times such as 1.99 */
  if(!m[3]&&!/^\d{1,3}(\.\d{1,3}){3}$/.test(host))continue;
  out.push({raw:m[0],host,tld,http:/^http:\/\//i.test(m[1]),ip:/^\d{1,3}(\.\d{1,3}){3}$/.test(host)})}
 return out}

export function analyse(text,from){
 const t=text.replace(/hxxps?/gi,m=>m.replace(/xx/i,"tt")).replace(/\[\.\]|\(\.\)|\[dot\]/gi,".");
 const found=[];const kinds=new Set();let score=0;
 const add=(id,w,l,y,snip,k)=>{found.push({id,w,l,y,snip});score+=w;if(k&&k!=="any")kinds.add(k)};
 const links=hostsOf(t);
 if(links.length){const L=links[0];
  add("link",1,"Has a link","Scam texts almost always want a tap. Open the official app, or type the address you already know.",L.raw,"any");
  if(links.some(x=>SHORT.includes(x.host)))add("short",2,"A shortened link","Short links hide where they really go.",links.find(x=>SHORT.includes(x.host)).raw);
  const odd=links.find(x=>ODD.includes(x.tld));if(odd)add("tld",2,"An unusual web address ending","Endings such as ."+odd.tld+" are cheap to register and common in scam links. Big organizations rarely use them for messages.",odd.raw);
  const lk=links.find(x=>x.host.includes("-")&&LOOK.test(x.host));if(lk)add("look",2,"A look-alike web address","The address is built from words like secure, verify or delivery to look official. It does not belong to the company it names.",lk.raw);
  const ip=links.find(x=>x.ip);if(ip)add("ip",3,"A link made of numbers","Genuine services use a name, not a string of numbers, for their web address.",ip.raw);
  const h=links.find(x=>x.http);if(h)add("http",1,"A link without https","The link would open without a secure connection.",h.raw)}
 const no=R("\\b(?:do not|don't|never) share\\b").test(t);
 SIGNS.forEach(s=>{if(s.id==="otpask"&&no)return;const m=t.match(s.rx);if(m)add(s.id,s.w,s.l,s.y,m[0],s.k)});
 if(found.some(f=>f.id==="pay")&&found.some(f=>f.id==="delivery"||f.id==="look"))kinds.add("delivery");
 if(found.some(f=>f.id==="oddpay"||f.id==="pay"))kinds.add("pay");
 const neg=[];
 GOOD.forEach(g=>{const m=t.match(g.rx);if(m&&!links.length&&!found.some(f=>f.id==="oddpay"||f.id==="secret"||f.id==="refund")){neg.push({id:g.id,l:g.l,y:g.y,snip:m[0]});score+=g.w}});
 if(from==="unknown"&&found.length)score+=1;
 const known=from==="known";if(known&&score>0)score-=1;
 const v=score>=6?"scam":score>=3?"suspicious":"safe";
 const conf=v==="scam"?(score>=9?"High":"Medium"):v==="suspicious"?(score>=5?"Medium":"Low"):(found.length>=2||t.length<40?"Low":"Medium");
 const steps=[...STEPS.base[v]];
 if(v!=="safe"){["otp","refund","bank","delivery","job","invest","authority","prize","wrongnum"].forEach(k=>{if(kinds.has(k)&&steps.length<6)steps.splice(1,0,STEPS[k])})}
 if(v!=="safe"&&kinds.has("pay"))steps.push(STEPS.pay);
 found.sort((a,b)=>b.w-a.w);
 return {v,score,conf,signs:found,good:neg,steps,known}}

const LINKIDS=["link","short","tld","look","ip","http"];
const VT={scam:"Likely scam",suspicious:"Suspicious",safe:"No common warning signs"};
const SUM={scam:"This message has several signs that scams use. Treat it as a scam unless you can confirm it through an official channel.",
 suspicious:"Some signs here are common in scams. It may be genuine, so check it another way before you act.",
 safe:"We did not find the usual warning signs in these words. This check reads only the text, so stay careful with links and payment requests."};

function checker(root){
 const ta=$("[data-ck-msg]",root),from=$("[data-ck-from]",root),go=$("[data-ck-go]",root),clr=$("[data-ck-clear]",root),err=$("[data-ck-err]",root),
  empty=$("[data-ck-empty]",root),card=$("[data-ck-card]",root),cnt=$("[data-ck-count]",root),picks=$$("[data-sample]",root),warn=$("[data-ck-warn]",root);
 const MAX=+ta.getAttribute("maxlength")||2000,fnote=$("[data-ck-fromnote]",root),runl=$("[data-ck-run]",root);let runs=0;
 const FN={unknown:"Unknown numbers add a little weight when other signs are present.",known:"Contacts can be hacked, so the same signs still count. The verdict is softened only slightly.",short:"Short codes are used by real services and by scammers alike, so they change nothing on their own.",unsure:"No weight either way. The words of the message decide."};
 const count=()=>{cnt.textContent=ta.value.length+" / "+MAX;
  const risky=/\b\d{4,8}\b/.test(ta.value)&&/\b(code|pin|password)\b/i.test(ta.value)&&!/never share|do not share|don't share/i.test(ta.value);
  warn.hidden=!risky};
 function show(r){
  card.hidden=!1;empty.hidden=!0;err.hidden=!0;card.dataset.v=r.v;runs++;runl.textContent="Check "+runs+" on this page";
  $("[data-ck-v]",card).textContent=VT[r.v];$("[data-ck-conf]",card).textContent="Confidence: "+r.conf;$("[data-ck-sum]",card).textContent=SUM[r.v];
  const sg=$("[data-ck-signs]",card);
  sg.innerHTML=r.signs.length?r.signs.slice(0,6).map(s=>(LINKIDS.includes(s.id)?{...s,snip:s.snip.replace(/\.([a-z]{2,24})(?=\/|$)/i,"[.]$1")}:s)).map(s=>'<li class="sk-sg sk-sg--w'+Math.min(3,s.w)+'"><div><b>'+E(s.l)+'</b><span>'+E(s.y)+'</span></div><q>'+E(s.snip.length>64?s.snip.slice(0,62)+"…":s.snip)+'</q></li>').join(""):
   '<li class="sk-sg sk-sg--none"><div><b>No warning signs found in the text</b><span>The message does not ask for money, codes or a tap on a link.</span></div></li>';
  sg.innerHTML+=r.good.map(g=>'<li class="sk-sg sk-sg--good"><div><b>'+E(g.l)+'</b><span>'+E(g.y)+'</span></div><q>'+E(g.snip)+'</q></li>').join("");
  $("[data-ck-nsigns]",card).textContent=r.signs.length===1?"1 sign found":r.signs.length+" signs found";
  $("[data-ck-steps]",card).innerHTML=r.steps.map(s=>"<li>"+E(s)+"</li>").join("");
  $("[data-ck-known]",card).hidden=!(r.known&&r.v!=="safe");
  card.classList.remove("is-closed");void card.offsetWidth;card.classList.add("is-closed")}
 function run(){
  const t=ta.value.trim();
  if(!t){card.hidden=!0;empty.hidden=!1;err.hidden=!1;err.textContent="Paste a message first, or pick one of the samples.";ta.focus();return}
  if(t.length<12){card.hidden=!0;empty.hidden=!1;err.hidden=!1;err.textContent="That is too short to check. Paste the whole message, including any link.";ta.focus();return}
  show(analyse(t,from.value))}
 picks.forEach(b=>b.addEventListener("click",()=>{const s=SAMPLES[b.dataset.sample];ta.value=s.t;from.value=s.from;picks.forEach(x=>x.setAttribute("aria-pressed",String(x===b)));count();run()}));
 go.addEventListener("click",run);
 from.addEventListener("change",()=>{fnote.textContent=FN[from.value]||"";if(!card.hidden&&ta.value.trim().length>=12)run()});
 ta.addEventListener("keydown",e=>{if(e.key==="Enter"&&(e.ctrlKey||e.metaKey)){e.preventDefault();run()}});
 ta.addEventListener("input",()=>{picks.forEach(x=>x.setAttribute("aria-pressed","false"));count()});
 clr.addEventListener("click",()=>{ta.value="";from.value="unknown";picks.forEach(x=>x.setAttribute("aria-pressed","false"));card.hidden=!0;empty.hidden=!1;err.hidden=!0;count();ta.focus()});
 count()}

/* ------------------------------------------------------------ pattern library filter */
function patterns(root){
 const bs=$$("[data-pf]",root),items=$$("[data-pk]",root),cnt=$("[data-pf-count]",root);
 const apply=k=>{let n=0;items.forEach(i=>{const ok=k==="all"||i.dataset.pk===k;i.hidden=!ok;if(ok)n++});cnt.textContent=n===1?"1 pattern":n+" patterns";bs.forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.pf===k)))};
 bs.forEach(b=>b.addEventListener("click",()=>apply(b.dataset.pf)));apply("all")}

export function boot(){
 $$('[data-sk="checker"]').forEach(checker);
 $$('[data-sk="patterns"]').forEach(patterns);
 $$(".mv-pscroll").forEach(el=>{const f=()=>{const s=el.scrollWidth>el.clientWidth+2;s?el.setAttribute("tabindex","0"):el.removeAttribute("tabindex")};f();addEventListener("resize",f)});
}
