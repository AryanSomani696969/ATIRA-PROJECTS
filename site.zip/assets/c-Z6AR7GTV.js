/* Routekeel hero: a switching yard of request lines at night. 14 s loop, three beats:
   0-5 s requests enter from the left edges and run along one keel line; 5-10 s at the switch each request is
   classified onto one of four tracks, track 3 fails (caution orange) and its traffic reroutes onto track 2;
   10-14 s a cost and quality dial settles in the green, the failed track recovers and the frame eases back. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(21);
const bg=new T.Color(colors.bg),ink=new T.Color(colors.ink),green=new T.Color(color("--rk-green","#2dd4a7")),orange=new T.Color(color("--rk-orange","#ff8a3d"));
const dim=ink.clone().lerp(bg,.62),faint=ink.clone().lerp(bg,.86);
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),8,19);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xbfd0e0,.75));
const key=new T.DirectionalLight(0xfff1e0,.85);key.position.set(-4,5,6);root.add(key);
const rim=new T.DirectionalLight(green.getHex(),.5);rim.position.set(5,1,-5);root.add(rim);
const geos=[],mats=[];const G=g=>(geos.push(g),g),M=m=>(mats.push(m),m);
const V=(x,y,z=0)=>new T.Vector3(x,y,z);
const lineOf=(curve,n,c,o)=>{const g=G(new T.BufferGeometry().setFromPoints(curve.getPoints(n)));const m=M(new T.LineBasicMaterial({color:c.clone(),transparent:!0,opacity:o}));const l=new T.Line(g,m);root.add(l);return{l,m}};
/* the yard: faint parallel rails behind everything */
const rails=[];for(let i=0;i<9;i++){const y=-3.2+i*.8,c=new T.CatmullRomCurve3([V(-9,y,-3),V(9,y,-3)]);rails.push(lineOf(c,2,faint,.5))}
/* keel line and feeders that enter from the top and bottom edges */
const SW=V(-.4,-.55,0);
const keel=new T.CatmullRomCurve3([V(-8.5,-.55,0),V(-4,-.55,0),SW]);
const feedA=new T.CatmullRomCurve3([V(-7.5,3.4,-.5),V(-4.6,1.2,-.2),V(-2.6,-.45,0),SW]);
const feedB=new T.CatmullRomCurve3([V(-7.2,-3.8,-.5),V(-4.4,-2,-.2),V(-2.4,-.65,0),SW]);
const feeds=[keel,feedA,feedB].map((c,i)=>({c,v:lineOf(c,i?40:8,i?dim:ink,i?.35:.8)}));
/* four tracks from the switch to four model nodes */
const NX=3.1,NY=[1.55,.6,-.35,-1.3];
const tracks=NY.map(y=>new T.CatmullRomCurve3([SW,V(.6,-.55+(y+.55)*.2,0),V(1.7,y,0),V(NX-.75,y,0)]));
const tl=tracks.map((c,i)=>lineOf(c,48,i===1?green:dim,.0));
const re=new T.CatmullRomCurve3([SW,V(.6,-.5,0),V(1.45,-.3,0),V(2,.45,0),V(NX-.75,NY[1],0)]);const rl=lineOf(re,48,orange,0);
/* model nodes: glass cards with an edge and a status dot */
const cardGeo=G(new T.BoxGeometry(1.3,.38,.05)),dotGeo=G(new T.SphereGeometry(.045,12,12)),barGeo=G(new T.PlaneGeometry(1,.04));
const nodes=NY.map((y,i)=>{const g=new T.Group;g.position.set(NX,y,0);
 const bm=M(new T.MeshStandardMaterial({color:ink,transparent:!0,opacity:.08,roughness:.3,metalness:.1,emissive:i===1?green:ink,emissiveIntensity:.05,depthWrite:!1}));g.add(new T.Mesh(cardGeo,bm));
 const eg=G(new T.BufferGeometry().setFromPoints([V(-.65,-.19),V(.65,-.19),V(.65,.19),V(-.65,.19),V(-.65,-.19)]));const em=M(new T.LineBasicMaterial({color:dim.clone(),transparent:!0,opacity:.8}));g.add(new T.Line(eg,em));
 const dm=M(new T.MeshBasicMaterial({color:i===1?green.clone():dim.clone(),transparent:!0,opacity:1}));const d=new T.Mesh(dotGeo,dm);d.position.set(-.5,0,.04);g.add(d);
 const b1m=M(new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:.5})),b1=new T.Mesh(barGeo,b1m);b1.scale.x=.62-i*.06;b1.position.set(-.36+b1.scale.x/2,.05,.03);g.add(b1);
 const b2m=M(new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:.22})),b2=new T.Mesh(barGeo,b2m);b2.scale.x=.4;b2.position.set(-.36+.2,-.06,.03);g.add(b2);
 root.add(g);return{g,bm,em,dm,b1m,b2m}});
/* cost and quality dial below the nodes: a track arc, a value arc and a needle */
const DC=V(1.15,-2.05,0),DR=.62;const arc=(a0,a1,n=40)=>{const p=[];for(let k=0;k<=n;k++){const a=lerp(a0,a1,k/n);p.push(V(DC.x+Math.cos(a)*DR,DC.y+Math.sin(a)*DR,0))}return p};
const dialT=new T.Line(G(new T.BufferGeometry().setFromPoints(arc(Math.PI,0))),M(new T.LineBasicMaterial({color:dim.clone(),transparent:!0,opacity:0})));root.add(dialT);
const dvGeo=G(new T.BufferGeometry().setFromPoints(arc(Math.PI,0,60)));const dialV=new T.Line(dvGeo,M(new T.LineBasicMaterial({color:green.clone(),transparent:!0,opacity:0})));root.add(dialV);
const needle=new T.Line(G(new T.BufferGeometry().setFromPoints([V(0,0),V(DR*.86,0)])),M(new T.LineBasicMaterial({color:ink.clone(),transparent:!0,opacity:0})));needle.position.copy(DC);root.add(needle);
/* requests: instanced spheres. route: 0..3 track, 4 reroute; src: 0 keel, 1/2 feeders */
const NR=small?36:84,reqGeo=G(new T.SphereGeometry(.04,10,10)),reqMat=M(new T.MeshBasicMaterial({color:0xffffff,transparent:!0,opacity:.95}));
const inst=new T.InstancedMesh(reqGeo,reqMat,NR);root.add(inst);const o3=new T.Object3D,col=new T.Color;
const SH=[.18,.34,.31,.17];const pick=()=>{let r=R(),k=0;while(k<3&&r>SH[k]){r-=SH[k];k++}return k};
const reqs=[];for(let i=0;i<NR;i++)reqs.push({born:i/NR*14,src:i%5===1?1:(i%5===3?2:0),route:pick(),sp:.85+R()*.3});
const hide=()=>{o3.position.set(0,0,-40);o3.scale.setScalar(.001);o3.updateMatrix()};
camera.fov=40;camera.updateProjectionMatrix();
const C0=V(.2,.1,8.6),look=V(.7,-.15,0),lk=V(0,0,0),off=V(0,0,0);camera.position.copy(C0);camera.lookAt(look);
const io=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
function frame(t,dt,p){
const c=t%14,tilt=(clamp(p)-.5)*.3;
/* beat 1: tracks, nodes and dial frame fade in; beat 3 end: everything eases back */
const fin=io(clamp((c-1.2)/3)),fout=io(clamp((c-13.1)/.9));
tl.forEach((v,i)=>{v.m.opacity=(i===1?.85:.5)*fin*(1-fout*.6)});
feeds.forEach((f,i)=>{f.v.m.opacity=(i?.32:.8)*(.4+.6*io(clamp(c/1.5)))});
/* beat 2: track 3 fails at 6.2 s, recovers at 11.6 s */
const fail=clamp((c-6.2)/.6)*(1-clamp((c-11.6)/1)),failOn=c>6.2&&c<11.6;
tl[2].m.color.copy(dim).lerp(orange,fail);rl.m.opacity=.7*fail;
nodes.forEach((n,i)=>{const vis=fin*(1-fout*.5);n.bm.opacity=.1*vis;n.em.opacity=.8*vis;n.b1m.opacity=.5*vis;n.b2m.opacity=.22*vis;n.dm.opacity=vis;
 if(i===2){n.em.color.copy(dim).lerp(orange,fail);n.dm.color.copy(dim).lerp(orange,fail)}
 n.g.position.y=NY[i]+tilt*(i-1.5)*.12;n.g.rotation.y=-.12+pointer.x*.04});
/* beat 3: dial appears at 9.6 s, needle sweeps and settles in the green */
const din=io(clamp((c-9.6)/.8))*(1-fout);dialT.material.opacity=.7*din;needle.material.opacity=din;
const ns=io(clamp((c-9.8)/2.2)),ang=lerp(Math.PI*.95,Math.PI*.3,ns)+Math.sin(clamp((c-9.8)/2.2)*Math.PI*2)*.06*(1-ns);needle.rotation.z=ang;
dialV.material.opacity=.95*din;dvGeo.setDrawRange(0,Math.max(2,Math.round(61*(1-ang/Math.PI))));dialV.material.color.copy(orange).lerp(green,ns);
/* requests */
for(let i=0;i<NR;i++){const q=reqs[i];let a=((c-q.born)%14+14)%14*q.sp/3.2;
 if(a>1.9||(c<3&&i/NR>c/3)){hide();inst.setMatrixAt(i,o3.matrix);continue}
 let pos,cl;const src=q.src===0?keel:(q.src===1?feedA:feedB);
 if(a<1){pos=src.getPointAt(clamp(a));cl=ink}
 else{const b=clamp(a-1);const rr=(q.route===2&&failOn&&b<.98)?re:tracks[q.route];pos=rr.getPointAt(b*.98);
  cl=rr===re?orange:(q.route===1?green:ink)}
 o3.position.set(pos.x,pos.y,pos.z);o3.scale.setScalar(a<1?.9:1.1);o3.updateMatrix();inst.setMatrixAt(i,o3.matrix);inst.setColorAt(i,col.copy(cl))}
inst.instanceMatrix.needsUpdate=!0;if(inst.instanceColor)inst.instanceColor.needsUpdate=!0;
/* camera: slow eased dolly, pointer parallax, no shake */
const d=io(.5-.5*Math.cos(t/14*Math.PI*2));camera.position.set(C0.x+off.x+.35*d+pointer.x*.25,C0.y+.12*d-pointer.y*.15,C0.z-.45*d);
lk.copy(look).add(off);lk.x+=pointer.x*.08;camera.lookAt(lk)}
return{frame,resize:(w,h)=>{const a=w/h,narrow=a<.9;C0.z=narrow?13+(.9-a)*9:(a<1.5?8.6+(1.5-a)*2.4:8.6);off.x=narrow?(.9-a)*3.2:(a<1.5?(1.5-a)*1.6:0);look.y=narrow?-.4:-.15;scene.fog.near=C0.z-1.6;scene.fog.far=C0.z+10.4},dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());inst.dispose&&inst.dispose()}}}
