/* Chronicward page tools. Run offline in the browser; nothing typed here leaves the page. All patients and readings are synthetic.
   [data-cw=sim]    Check-in Simulator: play a patient (language, condition), send readings or words, see the reply and the care team view
   [data-cw=mini]   home: three sample check-ins played through the same engine
   [data-cw=rules]  care team: change the clinic's thresholds and the sample call list re-ranks
   [data-cw=report] sample report: cohort tabs with minimum group size suppression */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const tag=(t,k)=>'<span class="mv-tag mv-tag--'+k+'">'+esc(t)+"</span>";
/* ---------- rules (sample rule set, Clinic A) */
const RULE={dm:{lo:70,urgLo:54,inHi:130,watch:180,once:250,urg:400,days:3},htn:{sys:140,dia:90,callS:160,callD:100,urgS:180,urgD:120,low:90,runs:3},miss:3};
const WORDS={urgent:/chest pain|dolor (de|en el) pecho|faint|desmay|can'?t breathe|trouble breathing|short of breath|no puedo respirar|falta de aire|confus/i,
refill:/ran out|run out|out of (my )?(pills|tablets|medicine|meds)|no (more )?pills|refill|se me acab|sin (pastillas|medicina)|no tengo (pastillas|medicina)|receta/i,
dizzy:/dizzy|mare(o|ad)|shaky|tembl|sweaty|sudor/i,took:/^(yes|yep|took it|i took|s[ií]|ya la tom[eé]|tom[eé])\b/i,no:/^(no|not yet|todav[ií]a no|a[uú]n no)\b/i,
stop:/^(stop|para|alto|baja)$/i};
const NUMW={en:{"one hundred":100,"two hundred":200,"three hundred":300},es:{"ciento":100,"cien":100,"doscientos":200,"trescientos":300}};
function parse(txt,cond){
 const t=txt.trim();if(!t)return{k:"empty"};
 if(WORDS.stop.test(t))return{k:"stop"};
 if(WORDS.urgent.test(t))return{k:"urgent"};
 const bp=t.match(/(\d{2,3})\s*(?:\/|over|sobre|-)\s*(\d{2,3})/i);
 if(bp){const s=+bp[1],d=+bp[2];if(s<60||s>260||d<30||d>160||d>=s)return{k:"bad"};return{k:"bp",s,d,flag:WORDS.refill.test(t)?"refill":WORDS.dizzy.test(t)?"dizzy":""}}
 const n=t.match(/\b(\d{2,3})\b/);
 if(n&&cond==="dm"){const v=+n[1];if(v<20||v>600)return{k:"bad"};return{k:"glu",v,flag:WORDS.refill.test(t)?"refill":WORDS.dizzy.test(t)?"dizzy":""}}
 if(n&&cond==="htn")return{k:"needbp"};
 const sp=t.toLowerCase();let w=0;for(const L of["en","es"])for(const k in NUMW[L])if(sp.includes(k))w=Math.max(w,NUMW[L][k]);
 if(w&&cond==="dm"){const m=sp.match(/(treinta|cuarenta|cincuenta|sesenta|setenta|ochenta|noventa|thirty|forty|fifty|sixty|seventy|eighty|ninety)/);
  const T={treinta:30,cuarenta:40,cincuenta:50,sesenta:60,setenta:70,ochenta:80,noventa:90,thirty:30,forty:40,fifty:50,sixty:60,seventy:70,eighty:80,ninety:90};
  const u=sp.match(/\b(y )?(uno|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|one|two|three|four|five|six|seven|eight|nine)\b(?!\s*(hundred|cientos))/);
  const U={uno:1,dos:2,tres:3,cuatro:4,cinco:5,seis:6,siete:7,ocho:8,nueve:9,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9};
  return{k:"glu",v:w+(m?T[m[1]]:0)+(u?U[u[2]]:0),flag:"",voice:1}}
 if(WORDS.refill.test(t))return{k:"refill"};
 if(WORDS.dizzy.test(t))return{k:"dizzy"};
 if(WORDS.took.test(t))return{k:"took"};
 if(WORDS.no.test(t))return{k:"notyet"};
 return{k:"unknown"}}
/* classify one reading against the rules and the recent history -> level 0 routine,1 watch,2 call today,3 urgent */
function judge(r,hist,cond){
 if(r.k==="glu"){const v=r.v,D=RULE.dm,above=[...hist.slice(-(D.days-1)),v].filter(x=>x>D.watch).length;
  if(v>=D.urg||v<D.urgLo)return{lvl:3,why:v<D.urgLo?"Fasting "+v+" mg/dL, below "+D.urgLo:"Fasting "+v+" mg/dL, at or above "+D.urg};
  if(v<D.lo)return{lvl:2,why:"Fasting "+v+" mg/dL, below "+D.lo};
  if(v>=D.once)return{lvl:2,why:"Fasting "+v+" mg/dL, above "+D.once+" once"};
  if(above>=D.days)return{lvl:2,why:"Above "+D.watch+" for "+D.days+" days in a row"};
  if(v>D.inHi)return{lvl:1,why:"Fasting "+v+" mg/dL, above target"};
  return{lvl:0,why:"Fasting "+v+" mg/dL, in range"}}
 if(r.k==="bp"){const H=RULE.htn,{s,d}=r,hi=[...hist.slice(-(H.runs-1)),s].filter(x=>x>=H.callS).length;
  if(s>=H.urgS||d>=H.urgD)return{lvl:3,why:s+"/"+d+", at or above "+H.urgS+"/"+H.urgD};
  if(s<H.low)return{lvl:2,why:"Systolic "+s+", below "+H.low};
  if(s>=H.callS||d>=H.callD)return{lvl:2,why:s+"/"+d+", at or above "+H.callS+"/"+H.callD+(hi>=H.runs?", "+hi+" in a row":"")};
  if(s>=H.sys||d>=H.dia)return{lvl:1,why:s+"/"+d+", above target"};
  return{lvl:0,why:s+"/"+d+", in range"}}
 return{lvl:0,why:""}}
const LV=[["Routine","ok"],["Watch","warn"],["Call today","sig"],["Urgent","sig"]];
/* companion replies, in English and Spanish, from the sample approved script library */
const SAY={
en:{ask:{dm:"Good morning. What was your fasting reading today? Reply with the number, or say it if you are on a call.",htn:"Good morning. What is your blood pressure today? Reply like 132/84."},
 lv:["Thank you, logged: {r}. That is in your range. Your next reminder is at 8 p.m.","Thank you, logged: {r}. That is a little above your target. A short walk after a meal often helps. Did you take your last dose?",
 "Thank you, logged: {r}. That is outside the range your care team set. A nurse from your clinic will call you today.","Logged: {r}. Your care team asked us to tell you: if you feel unwell, call 911 now. We have alerted your clinic."],
 urgent:"If you have chest pain, fainting or trouble breathing, call 911 now. We have alerted your care team.",
 refill:"Thank you for telling us. We have let your care team know you need a refill. They will contact you today.",
 dizzy:"Thank you for telling us. Please follow the steps your care team gave you, and sit down if you feel unsteady. A nurse will call you today.",
 took:"Good, thank you. Your next reminder is at 8 p.m.",notyet:"No problem. We will remind you again in one hour.",
 needbp:"Please send both numbers, like 142/91.",unknown:"Sorry, I did not catch that. Reply with a reading like {ex}, or write \"refill\" if you have run out.",
 bad:"That number looks unusual. Please check the meter and send it again.",stop:"You will not get more check-ins. Your care team has been told. Reply START to begin again.",
 miss:"We did not hear from you today. Reply with your reading when you can.",miss2:"It has been {n} days since your last check-in. A nurse from your clinic will call to see how you are.",
 ex:{dm:"128",htn:"132/84"},unit:"mg/dL"},
es:{ask:{dm:"Buenos días. ¿Cuál fue su azúcar en ayunas hoy? Responda con el número, o dígalo si está en una llamada.",htn:"Buenos días. ¿Cuál es su presión hoy? Responda así: 132/84."},
 lv:["Gracias, anotado: {r}. Está dentro de su rango. Su próximo recordatorio es a las 8 p.m.","Gracias, anotado: {r}. Está un poco por encima de su meta. Caminar un poco después de comer suele ayudar. ¿Tomó su última dosis?",
 "Gracias, anotado: {r}. Está fuera del rango que fijó su equipo de cuidado. Una enfermera de su clínica le llamará hoy.","Anotado: {r}. Su equipo de cuidado nos pidió decirle: si se siente mal, llame al 911 ahora. Avisamos a su clínica."],
 urgent:"Si tiene dolor en el pecho, se desmaya o le falta el aire, llame al 911 ahora. Avisamos a su equipo de cuidado.",
 refill:"Gracias por avisarnos. Le dijimos a su equipo de cuidado que necesita una receta. Le contactarán hoy.",
 dizzy:"Gracias por avisarnos. Siga los pasos que le dio su equipo de cuidado y siéntese si se siente inestable. Una enfermera le llamará hoy.",
 took:"Muy bien, gracias. Su próximo recordatorio es a las 8 p.m.",notyet:"No se preocupe. Le recordamos de nuevo en una hora.",
 needbp:"Por favor envíe los dos números, así: 142/91.",unknown:"Perdón, no entendí. Responda con una lectura como {ex}, o escriba \"receta\" si se le acabó la medicina.",
 bad:"Ese número parece raro. Revise el aparato y envíelo otra vez.",stop:"No recibirá más mensajes. Avisamos a su equipo de cuidado. Responda START para empezar de nuevo.",
 miss:"Hoy no supimos de usted. Responda con su lectura cuando pueda.",miss2:"Han pasado {n} días desde su último mensaje. Una enfermera de su clínica le llamará para saber cómo está.",
 ex:{dm:"128",htn:"132/84"},unit:"mg/dL"}};
const QUICK={dm:{en:["128","162","236","I ran out of my pills","feeling dizzy"],es:["128","Hoy salió en ciento sesenta y dos","236","Se me acabó la pastilla","Me siento mareado"]},
 htn:{en:["128/82","148/94","168/102","186/122","I ran out of my pills"],es:["128/82","148 sobre 94","168/102","186/122","Se me acabó la pastilla"]}};
const SEED={dm:[128,134,126,149,191,204],htn:[136,142,151,147,158,162]};
const OTHERS=[{id:"CW-0388",c:"Hypertension",lvl:2,sc:78,why:"Three readings at or above 160/100 in five days"},{id:"CW-0457",c:"Type 2 diabetes",lvl:2,sc:70,why:"Three missed check-ins in a row"},
 {id:"CW-0371",c:"Hypertension",lvl:1,sc:41,why:"Above target, first time this week"},{id:"CW-0429",c:"Type 2 diabetes",lvl:0,sc:12,why:"In range for 14 days"}];
function score(lvl,hist,miss){const last=hist.slice(-3),tr=last.length>1?last[last.length-1]-last[0]:0;return [10,40,72,100][lvl]+Math.max(-6,Math.min(12,Math.round(tr/6)))+miss*8}
function spark(vals,line,cond){if(!vals.length)return"";const w=220,h=56,lo=cond==="dm"?60:90,hi=cond==="dm"?300:200,X=i=>vals.length<2?w/2:6+i*(w-12)/(vals.length-1),Y=v=>h-4-(Math.min(hi,Math.max(lo,v))-lo)/(hi-lo)*(h-8);
 return'<svg class="cw-spark" viewBox="0 0 '+w+" "+h+'" aria-hidden="true"><path class="cw-spark__c" d="M0 '+Y(line).toFixed(1)+"H"+w+'"/><path class="cw-spark__l" d="M'+vals.map((v,i)=>X(i).toFixed(1)+" "+Y(v).toFixed(1)).join(" L")+'"/>'+
 vals.map((v,i)=>'<circle class="cw-spark__p'+(v>=line?" is-hot":"")+'" cx="'+X(i).toFixed(1)+'" cy="'+Y(v).toFixed(1)+'" r="3"/>').join("")+"</svg>"}
/* ---------- engine shared by sim and mini: state -> reply + team view */
function engine(){return{lang:"en",cond:"dm",hist:[],miss:0,day:1,lvl:0,why:"",last:"",log:[],stopped:!1}}
function reset(st){st.hist=SEED[st.cond].slice();st.miss=0;st.day=1;st.lvl=0;st.why="";st.last="";st.log=[];st.stopped=!1}
function step(st,txt){const S=SAY[st.lang],r=parse(txt,st.cond);let reply,lvl=null,why="",logged="";
 if(st.stopped&&!/^start$/i.test(txt.trim()))return{err:st.lang==="es"?"Los mensajes están detenidos. Escriba START.":"Check-ins are stopped. Type START to begin again."};
 if(/^start$/i.test(txt.trim())){st.stopped=!1;return{reply:S.ask[st.cond]}}
 switch(r.k){
 case"empty":return{err:st.lang==="es"?"Escriba una lectura, por ejemplo "+S.ex[st.cond]+".":"Type a reading, such as "+S.ex[st.cond]+", or tap a sample reply."};
 case"glu":{const j=judge(r,st.hist,"dm");lvl=j.lvl;why=j.why;logged=r.v+" "+S.unit;st.hist.push(r.v);reply=S.lv[j.lvl].replace("{r}",logged);if(r.flag){reply+=" "+S[r.flag];lvl=Math.max(lvl,2);why+=r.flag==="refill"?"; refill needed":"; reports dizziness"}break}
 case"bp":{const j=judge(r,st.hist,"htn");lvl=j.lvl;why=j.why;logged=r.s+"/"+r.d;st.hist.push(r.s);reply=S.lv[j.lvl].replace("{r}",logged);if(r.flag){reply+=" "+S[r.flag];lvl=Math.max(lvl,2);why+=r.flag==="refill"?"; refill needed":"; reports dizziness"}break}
 case"urgent":reply=S.urgent;lvl=3;why="Reported a red-flag symptom";break;
 case"refill":reply=S.refill;lvl=Math.max(2,st.lvl);why="Refill needed";break;
 case"dizzy":reply=S.dizzy;lvl=Math.max(2,st.lvl);why="Reports dizziness";break;
 case"stop":st.stopped=!0;reply=S.stop;lvl=st.lvl;why="Patient stopped check-ins";break;
 case"took":reply=S.took;break;case"notyet":reply=S.notyet;break;
 case"needbp":reply=S.needbp;break;case"bad":reply=S.bad;break;
 default:reply=S.unknown.replace("{ex}",S.ex[st.cond])}
 if(lvl!==null){st.lvl=lvl;st.why=why;st.miss=0;if(logged)st.last=logged;st.log.unshift([(st.day>7?"Day 7":"Day "+st.day),why||"Reply logged",lvl]);st.day=Math.min(8,st.day+1)}
 return{reply,r,lvl}}
function skip(st){const S=SAY[st.lang];st.miss++;st.day=Math.min(8,st.day+1);let reply=S.miss;
 if(st.miss>=RULE.miss){reply=S.miss2.replace("{n}",st.miss);st.lvl=Math.max(st.lvl,2);st.why=st.miss+" missed check-ins in a row"}else if(st.lvl<1){st.lvl=st.lvl}
 st.log.unshift(["Day "+Math.min(7,st.day-1),"No reply ("+st.miss+" in a row)",st.miss>=RULE.miss?2:0]);return{reply}}
function team(st,id){const me={id,c:st.cond==="dm"?"Type 2 diabetes":"Hypertension",lvl:st.lvl,sc:score(st.lvl,st.hist,st.miss),why:st.why||"Waiting for today's check-in",me:1};
 const list=[...OTHERS,me].sort((a,b)=>b.sc-a.sc),rank=list.indexOf(me)+1,line=st.cond==="dm"?RULE.dm.watch:RULE.htn.callS,L=LV[st.lvl];
 return'<div class="cw-tv"><div class="cw-tv__h"><div><p class="mv-mi">Patient</p><b>'+id+"</b><small>"+esc(me.c)+" · "+(st.lang==="es"?"Spanish":"English")+"</small></div>"+tag(L[0],L[1])+"</div>"+
 '<dl class="cw-tv__kv"><div><dt>Latest</dt><dd>'+esc(st.last||"None today")+"</dd></div><div><dt>Reason</dt><dd>"+esc(me.why)+"</dd></div><div><dt>Missed check-ins</dt><dd>"+st.miss+"</dd></div><div><dt>Place on today's list</dt><dd>"+rank+" of "+list.length+"</dd></div></dl>"+
 '<p class="mv-mi">Last '+Math.min(7,st.hist.length)+" readings"+(st.cond==="dm"?", fasting mg/dL":", systolic")+"</p>"+spark(st.hist.slice(-7),line,st.cond)+
 '<ol class="cw-tv__l">'+list.map((p,i)=>'<li class="'+(p.me?"is-me":"")+'"><span>'+(i+1)+"</span><b>"+p.id+"</b><small>"+esc(p.why)+"</small>"+tag(LV[p.lvl][0],LV[p.lvl][1])+"</li>").join("")+"</ol>"+
 (st.log.length?'<p class="mv-mi">Recorded</p><ul class="cw-tv__log">'+st.log.slice(0,4).map(x=>"<li><span>"+esc(x[0])+"</span>"+esc(x[1])+"</li>").join("")+"</ul>":"")+"</div>"}
function bubble(side,text,voice){return'<li class="cw-m cw-m--'+side+'"><span>'+(voice?'<i class="cw-m__v">Voice</i>':"")+esc(text)+"</span></li>"}
/* ---------- simulator */
function sim(root){const st=engine(),th=$("[data-sim-thread]",root),inp=$("[data-sim-in]",root),err=$("[data-sim-err]",root),tv=$("[data-sim-team]",root),stat=$("[data-sim-status]",root),
 who=$("[data-sim-who]",root),day=$("[data-sim-day]",root),qk=$("[data-sim-quick]",root);let touched=!1;
 const id=()=>st.cond==="dm"?"CW-0412":"CW-0371";
 const paint=()=>{who.textContent="Patient "+id()+" (synthetic)";day.textContent="Day "+Math.min(7,st.day)+" of 7";stat.textContent=touched?LV[st.lvl][0]:"Waiting";
  tv.innerHTML=touched?team(st,id()):'<p class="cw-empty">Send a reading to see what the care team sees.</p>';th.scrollTop=th.scrollHeight};
 const quick=()=>{qk.innerHTML=QUICK[st.cond][st.lang].map(q=>'<button type="button" class="cw-q" data-q="'+esc(q)+'">'+esc(q)+"</button>").join("")};
 const start=()=>{reset(st);touched=!1;th.innerHTML=bubble("out",SAY[st.lang].ask[st.cond]);err.textContent="";inp.removeAttribute("aria-invalid");inp.placeholder=st.lang==="es"?"Escriba una lectura, como "+SAY.es.ex[st.cond]:"Type a reading, such as "+SAY.en.ex[st.cond];quick();paint()};
 const send=txt=>{const o=step(st,txt);if(o.err){err.textContent=o.err;inp.setAttribute("aria-invalid","true");inp.focus();return}
  err.textContent="";inp.removeAttribute("aria-invalid");th.insertAdjacentHTML("beforeend",bubble("in",txt,o.r&&o.r.voice)+bubble("out",o.reply));touched=!0;inp.value="";paint()};
 $("[data-sim-go]",root).addEventListener("click",()=>send(inp.value));
 inp.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();send(inp.value)}});
 qk.addEventListener("click",e=>{const b=e.target.closest("[data-q]");if(b)send(b.dataset.q)});
 $("[data-sim-skip]",root).addEventListener("click",()=>{if(st.stopped)return;const o=skip(st);th.insertAdjacentHTML("beforeend",'<li class="cw-m cw-m--gap"><span>'+(st.lang==="es"?"Sin respuesta":"No reply")+"</span></li>"+bubble("out",o.reply));touched=!0;paint()});
 $("[data-sim-replay]",root).addEventListener("click",start);
 const mark=fs=>$$("label",fs).forEach(l=>l.classList.toggle("is-on",$("input",l).checked));
 /* choosing a language or condition (even the current one) starts the conversation again from day 1 */
 $$("input[name=sim-lang],input[name=sim-cond]",root).forEach(r=>r.addEventListener("click",()=>{const fs=r.closest("fieldset");if(r.name==="sim-lang")st.lang=r.value;else st.cond=r.value;
  fs.dataset.run=(+fs.dataset.run||0)+1;mark(fs);start()}));
 $$("fieldset",root).forEach(mark);
 start()}
/* ---------- home mini: three scripted cases on the same engine */
const CASES={es:{lang:"es",cond:"dm",id:"CW-0412",steps:[["say","Hoy salió en doscientos treinta y seis"]]},bp:{lang:"en",cond:"htn",id:"CW-0388",steps:[["say","168/102"]]},quiet:{lang:"en",cond:"dm",id:"CW-0457",steps:[["skip"],["skip"],["skip"]]}};
/* a click on the current tab plays it again; the tablist counts runs so the replay is visible in markup */
function tabs(list,on){list.forEach((t,i)=>{t.addEventListener("click",()=>{const tl=t.parentElement;tl.dataset.run=(+tl.dataset.run||0)+1;on(t)});t.addEventListener("keydown",e=>{const k=e.key,n=k==="ArrowRight"?1:k==="ArrowLeft"?-1:0;
 if(k==="Home"||k==="End"||n){e.preventDefault();const j=k==="Home"?0:k==="End"?list.length-1:(i+n+list.length)%list.length;list[j].focus();on(list[j])}})});
 const sel=t=>list.forEach(x=>{const a=x===t;x.setAttribute("aria-selected",a);a?x.removeAttribute("tabindex"):x.tabIndex=-1});return sel}
function mini(root){const out=$("[data-mini-out]",root),T=$$("[data-case]",root);let timer=0;
 const play=t=>{sel(t);out.setAttribute("aria-labelledby",t.id);clearTimeout(timer);const c=CASES[t.dataset.case],st=engine();st.lang=c.lang;st.cond=c.cond;reset(st);
  let html=bubble("out",SAY[c.lang].ask[c.cond]),voice=c.lang==="es";
  c.steps.forEach(s=>{if(s[0]==="say"){const o=step(st,s[1]);html+=bubble("in",s[1],voice)+bubble("out",o.reply)}else{const o=skip(st);html+='<li class="cw-m cw-m--gap"><span>No reply</span></li>'+bubble("out",o.reply)}});
  const L=LV[st.lvl];out.innerHTML='<div class="cw-mini__g"><ol class="cw-sim__th cw-sim__th--mini">'+html+'</ol><div class="cw-flag"><p class="mv-mi">Flag raised for a nurse call</p><b>'+c.id+"</b>"+tag(L[0],L[1])+'<p class="cw-flag__w">'+esc(st.why)+"</p><p class=\"cw-flag__r\">Rule set "+(c.cond==="dm"?"DM-2":"HTN-1")+", Clinic A</p></div></div>"};
 const sel=tabs(T,play);play(T[0])}
/* ---------- care team rules */
const PATS=[{id:"CW-0388",c:"htn",r:[152,163,166,168],miss:0},{id:"CW-0412",c:"dm",r:[191,204,236],miss:0},{id:"CW-0457",c:"dm",r:[142],miss:3},{id:"CW-0371",c:"htn",r:[138,141,148],miss:0},
 {id:"CW-0429",c:"dm",r:[121,118,118],miss:0},{id:"CW-0466",c:"htn",r:[171,158,154],miss:2},{id:"CW-0402",c:"dm",r:[226,231,212],miss:0},{id:"CW-0435",c:"dm",r:[190,176,188],miss:1}];
function rules(root){const out=$("[data-rule-out]",root),cnt=$("[data-rule-count]",root),S=$$("[data-rule]",root),def={};S.forEach(s=>def[s.dataset.rule]=s.value);
 const run=()=>{const v={};S.forEach(s=>v[s.dataset.rule]=+s.value);const bpD={150:95,160:100,170:105}[v.bp];
  const rows=PATS.map(p=>{let lvl=0,why=[];const last=p.r.slice(-v.days);
   if(p.c==="dm"){const n=p.r.filter(x=>x>v.glu).length;if(last.length>=v.days&&last.every(x=>x>v.glu)){lvl=2;why.push("Above "+v.glu+" for "+v.days+" days")}else if(n){lvl=1;why.push(n+" reading"+(n>1?"s":"")+" above "+v.glu)}
    else if(p.r[p.r.length-1]>130){lvl=1;why.push("Above target, under the call line")}}
   else{const n=p.r.filter(x=>x>=v.bp).length;if(last.length>=v.days&&last.every(x=>x>=v.bp)){lvl=2;why.push(v.days+" readings at or above "+v.bp+"/"+bpD)}else if(n){lvl=1;why.push(n+" reading"+(n>1?"s":"")+" at or above "+v.bp+"/"+bpD)}
    else if(p.r[p.r.length-1]>=140){lvl=1;why.push("Above target, under the call line")}}
   if(p.miss>=v.miss){lvl=2;why.unshift(p.miss+" missed check-ins")}else if(p.miss){why.push(p.miss+" missed")}
   if(!why.length)why.push("In range");return{p,lvl,why:why.join("; "),sc:lvl*100+p.miss*10+p.r[p.r.length-1]/10}}).sort((a,b)=>b.sc-a.sc);
  const calls=rows.filter(r=>r.lvl===2).length;cnt.textContent=calls+" to call today";
  out.innerHTML=(calls?"":'<p class="cw-empty">No one needs a call under these rules. Routine check-ins continue, and anyone in Watch is checked again tomorrow.</p>')+
   '<ol class="cw-cl__l">'+rows.map((r,i)=>'<li class="'+(r.lvl===2?"is-hot":"")+'"><span class="cw-cl__n">'+(i+1)+'</span><span class="cw-cl__id">'+r.p.id+"<small>"+(r.p.c==="dm"?"Type 2 diabetes":"Hypertension")+'</small></span><span class="cw-cl__r">'+esc(r.p.c==="dm"?r.p.r.slice(-3).join(", ")+" mg/dL":r.p.r.slice(-3).join(", ")+" systolic")+"<small>"+esc(r.why)+"</small></span>"+tag(LV[r.lvl][0],LV[r.lvl][1])+"</li>").join("")+"</ol>"};
 S.forEach(s=>s.addEventListener("change",run));$("[data-rule-reset]",root).addEventListener("click",()=>{S.forEach(s=>s.value=def[s.dataset.rule]);run()});run()}
/* ---------- sample report */
const COH={all:{n:58,ans:[71,73,74,76,77,78,79,79],oor:[64,60,55,52,49,45,43,41],esc:31,calls:29,clin:9},a:{n:34,ans:[74,75,77,78,79,80,81,82],oor:[37,35,31,30,27,25,24,22],esc:17,calls:17,clin:5},
 b:{n:8},c:{n:16,ans:[66,69,70,73,74,75,76,76],oor:[19,18,17,16,16,15,14,14],esc:9,calls:8,clin:3}};
function report(root){const out=$("[data-rep-out]",root),T=$$("[data-cohort]",root);
 const show=t=>{sel(t);out.setAttribute("aria-labelledby",t.id);const c=COH[t.dataset.cohort];
  if(!c.ans){out.innerHTML='<div class="cw-rep__s"><p class="mv-mi">'+esc(t.textContent)+" · "+c.n+' patients</p><p class="cw-rep__sup">Suppressed. This group has fewer than 11 patients, so the sponsor view does not report it on its own. Its patients are counted in All sites.</p></div>';return}
  const bars=c.ans.map((v,i)=>'<li><span class="cw-rep__b" style="--h:'+v+'%"><i></i></span><small>W'+(i+1)+"</small><b>"+v+"%</b></li>").join("");
  out.innerHTML='<div class="cw-rep__g"><div><p class="mv-mi">'+esc(t.textContent)+" · "+c.n+' patients · check-ins answered per week</p><ol class="cw-rep__bars">'+bars+'</ol></div><dl class="cw-rep__kv"><div><dt>Out-of-range readings, week 1</dt><dd>'+c.oor[0]+"</dd></div><div><dt>Out-of-range readings, week 8</dt><dd>"+c.oor[7]+
  "</dd></div><div><dt>Escalations</dt><dd>"+c.esc+"</dd></div><div><dt>Called within a working day</dt><dd>"+c.calls+"</dd></div><div><dt>Sent to a clinician</dt><dd>"+c.clin+"</dd></div></dl></div>"};
 const sel=tabs(T,show);show(T[0])}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-cw=sim]").forEach(sim);$$("[data-cw=mini]").forEach(mini);$$("[data-cw=rules]").forEach(rules);$$("[data-cw=report]").forEach(report)}
