/* Iracquill page tools, all offline in the browser, nothing is sent anywhere:
   ev     - the free answer evaluation: three sample questions, a 30-minute timer with a pace meter, a rubric scorecard
            (structure, issue spotting, rule statements, application, conclusion, time and pace), three fixes,
            margin notes per paragraph and a suggested rewrite. Fixed rules written for these three questions.
   scrollers - wide tables get keyboard focus only when they scroll */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const R=s=>new RegExp(s,"i");
const CONC="\\b(so|therefore|thus|accordingly|in conclusion|so the|so a|as a result|it follows|likely|will (probably )?(win|prevail|succeed|lose)|is liable|was formed|is enforceable|owns|acquired title|title passed)\\b";
const ISSUECUE=/\b(whether|the issue is|issue:|issue is whether|the question is)\b/i,APPCUE=/\b(here|in this case|on these facts|on the facts|because|since)\b/i,RULECUE=/\b(under|requires?|is defined|the rule|elements?|must)\b/i;
/* ------------------------------------------------------------------ the three sample questions (written for this page) */
const Q=[
{id:"k",tab:"Contracts",label:"Contracts · offer held open",min:30,
facts:"On March 1, Seller, a lumber dealer, sent Buyer, a home builder, a letter signed by Seller's sales manager: \"We offer you 400 cedar beams at $90 per beam, delivery May 1. This offer will be held open until March 31.\" Buyer gave nothing in return. On March 10, after lumber prices rose, Seller emailed Buyer: \"We revoke our offer of March 1.\" On March 12, Buyer mailed a letter accepting the offer. It reached Seller on March 15. Seller refuses to deliver the beams.",
call:"Was a contract formed between Seller and Buyer? Discuss.",
facts_re:["march 1\\b","march 10","march 12","march 15","march 31","\\b400\\b","\\$?90\\b","beams?","lumber","dealer","builder","e-?mail","letter","sales manager","nothing in return"],
issues:[
{n:"Governing law: UCC Article 2",kw:"\\bucc\\b|article 2|uniform commercial code|sale of goods|\\bgoods\\b",rule:["movable","applies to (a |the )?(sales?|contracts?) (of|for) goods","article 2 (governs|applies)","goods"],rmin:1,f:["beams?","lumber"],
fix:"Open with the governing law. Cedar beams are goods, so UCC Article 2 governs, and its firm-offer rule decides the case. Say so in one sentence before the analysis.",
model:"Governing law. Article 2 of the UCC governs contracts for the sale of goods, meaning things that are movable when identified to the contract. Cedar beams are goods, so Article 2 applies, and the common law fills only the gaps it leaves."},
{n:"Firm offer",kw:"firm offer|2-205|irrevocab|held open|hold (it |the offer )?open|option",rule:["merchant","signed (writing|letter|record)|in a signed|signed by","three months|3 months","(without|no|lack of) consideration"],rmin:2,f:["dealer","sales manager","signed","march 31","nothing in return"],
fix:"State the firm-offer rule with its elements: a merchant, a signed writing, an assurance that the offer will be held open, and a limit of three months. Then match each element to a fact: a lumber dealer, the sales manager's signature, \"held open until March 31\".",
model:"Firm offer. Under UCC 2-205, an offer by a merchant to buy or sell goods in a signed writing that by its terms gives assurance it will be held open is not revocable for lack of consideration during the time stated, up to three months. Here, Seller deals in lumber and is a merchant, its sales manager signed the March 1 letter, and the letter promised to hold the offer open until March 31. The offer was therefore irrevocable until March 31, even though Buyer gave nothing for it."},
{n:"Attempted revocation",kw:"revo(k|c)",rule:["ineffective|not effective|no effect|without effect","cannot (be )?revoke|could not (be )?revoke|could not revoke|irrevocable"],rmin:1,f:["march 10","e-?mail","prices? (rose|rising|went up)"],
fix:"Deal with the March 10 email directly. Say whether the revocation worked and why: an offer that is irrevocable under the firm-offer rule cannot be revoked during the stated period.",
model:"Revocation. Because the March 1 letter was a firm offer, Seller's March 10 email could not revoke it. A revocation sent during the period the offer is held open has no effect, so the offer was still open when Buyer acted on March 12."},
{n:"Acceptance and the mailbox rule",kw:"accept",rule:["mailbox","dispatch","upon (sending|mailing)|when (it is |it was )?(sent|mailed)|on (sending|mailing)","effective (on|when|upon)"],rmin:1,f:["march 12","mailed","march 15"],
fix:"Say when the acceptance took effect. Under the mailbox rule it was effective when Buyer mailed it on March 12, not when it arrived on March 15, and both dates fall inside the period the offer was held open.",
model:"Acceptance. An acceptance sent by a reasonable medium is effective when it is dispatched, not when it arrives. Buyer mailed its acceptance on March 12, before March 31, so the acceptance took effect that day and a contract was formed for 400 beams at $90 each. Seller's refusal to deliver is a breach."}],
sample:"Issue: whether there is a contract between Seller and Buyer.\n\nAn offer is a manifestation of willingness to enter a bargain. Seller made an offer on March 1 to sell 400 beams at $90 each.\n\nSeller revoked the offer on March 10 by email. Usually an offer can be revoked any time before acceptance unless there is consideration. Buyer gave nothing, so the offer could be revoked.\n\nBuyer accepted on March 12 but the letter arrived on March 15, after the revocation.\n\nSo there is probably no contract and Buyer will lose."},
{id:"t",tab:"Torts",label:"Torts · wet floor",min:30,
facts:"At 4:40 p.m. a grocery store employee mopped the floor of aisle 6 and put up no warning sign. The store's written policy requires a warning sign whenever a floor is mopped during opening hours. At 5:00 p.m. a shopper walked down aisle 6 while reading a shopping list on her phone, slipped on the wet floor and broke her wrist. The jurisdiction follows pure comparative negligence.",
call:"Discuss the shopper's negligence claim against the store and any defenses.",
facts_re:["4:40","5:00","20 minutes|twenty minutes","aisle","mopp","sign","polic","phone","list","wrist","wet","employee","shopper|customer"],
issues:[
{n:"Duty owed to an invitee",kw:"duty|invitee|business visitor",rule:["reasonable care","inspect","warn","make (it|them|the (premises|floor|aisle)) safe","know|should have known|reasonably discover"],rmin:2,f:["shopper|customer","store|grocery"],
fix:"Name the duty precisely. The shopper is a business invitee, so the store owed reasonable care: to inspect for dangerous conditions and to make them safe or warn of them.",
model:"Duty. A business invitee enters to do business with the occupier. The store owed the shopper, an invitee, a duty of reasonable care to inspect for dangerous conditions it knew of or could reasonably discover, and to make them safe or warn of them."},
{n:"Breach",kw:"breach",rule:["reasonabl","fail(ed|ure)? to (warn|put|place|post)","fell below|standard of care"],rmin:1,f:["sign","polic","4:40|5:00|20 minutes|twenty minutes","mopp"],
fix:"Prove breach with the facts. The store's own employee created the wet floor and posted no sign for 20 minutes, against the store's written policy. Use the policy as evidence of what reasonable care required.",
model:"Breach. The store breached its duty if it failed to act as a reasonable store would. Its own employee created the wet floor at 4:40 p.m. and posted no sign for the 20 minutes before the fall, contrary to the store's written policy. The policy is evidence of what reasonable care required, and leaving a freshly mopped aisle unmarked likely falls below that standard."},
{n:"Causation",kw:"caus",rule:["but for|but-for|actual cause|cause in fact","proximate|foreseeab"],rmin:2,f:["slip","wet","wrist"],
fix:"Split causation in two. Actual cause: but for the unmarked wet floor, the shopper would not have slipped. Proximate cause: a slip and an injury are the foreseeable risk of a wet floor.",
model:"Causation. But for the wet, unmarked floor, the shopper would not have slipped, so the store's conduct is an actual cause. A fall and a broken bone are exactly the harm that makes a wet floor dangerous, so the injury was foreseeable and the store's breach is also a proximate cause."},
{n:"Damages",kw:"damage|injur|harm",rule:["actual (injury|harm|damages?|loss)","compensat|medical|pain"],rmin:1,f:["wrist","broke"],
fix:"Close the elements with damages: the broken wrist is an actual injury, and the shopper can recover medical costs and pain and suffering.",
model:"Damages. The shopper suffered an actual injury, a broken wrist, and can recover compensatory damages such as medical costs, lost wages and pain and suffering."},
{n:"Vicarious liability",kw:"vicarious|respondeat|employer|scope of (employment|her|his|the job)",rule:["scope of (employment|the job)","respondeat superior","liable for (the )?(torts?|negligence)"],rmin:1,f:["employee","mopp"],
fix:"Add the employer's liability. The employee mopped the aisle as part of the job, so the store answers for that negligence under respondeat superior, on top of its own duty as occupier.",
model:"Vicarious liability. Under respondeat superior an employer is liable for the torts of an employee acting within the scope of employment. Mopping the aisle was part of the employee's job, so the store is also liable for the employee's failure to post a sign."},
{n:"Comparative negligence",kw:"comparative|contributory|own negligence|her negligence|plaintiff's negligence|phone",rule:["reduc","percent|proportion|share of (fault|responsibility)","pure comparative"],rmin:1,f:["phone","list","reading"],
fix:"Use the phone fact. Reading her list while walking may be negligence by the shopper, and under pure comparative negligence her recovery is reduced by her share of fault but not barred.",
model:"Defense. The store will argue the shopper was negligent for reading her phone while walking. Under pure comparative negligence her damages are reduced by her percentage of fault, but she still recovers the rest, even if her share is large."}],
sample:"The issue is whether the store is liable in negligence.\n\nTo prove negligence the plaintiff needs duty, breach, causation and damages.\n\nThe store owed a duty to the shopper because she was a customer. The store breached the duty because there was no sign.\n\nThe shopper slipped and broke her wrist so there is causation and damages.\n\nThe store can say she was looking at her phone.\n\nTherefore the store is liable."},
{id:"p",tab:"Real property",label:"Real property · fenced strip",min:30,
facts:"In June 2012, a farmer fenced a three-acre strip of land next to her farm, believing it was part of her parcel. The strip in fact belonged to the neighbouring landowner, who lived in another state and never visited. From 2012 to 2024 the farmer grazed cattle on the strip every summer, kept the fence in repair and paid no rent. In 2024 the neighbour's survey showed the true boundary, and the neighbour demanded the strip back. The jurisdiction's statutory period for adverse possession is 10 years.",
call:"Who owns the strip? Discuss.",
facts_re:["2012","2024","three-acre|3-acre|three acre","fence","graz|cattle","summer","another state|never visited","survey","no rent","believ","10 years|ten years"],
issues:[
{n:"Actual possession",kw:"\\bactual",rule:["physical|physically","as an? (true |reasonable )?owner would|use (of|the) (land|strip)"],rmin:1,f:["fence","graz|cattle"],
fix:"State actual possession and prove it: the farmer physically used the strip as an owner would, by fencing it and grazing cattle on it.",
model:"Actual. Possession is actual when the possessor physically uses the land as an owner would. The farmer fenced the strip and grazed cattle on it every summer, which is the ordinary use of grazing land."},
{n:"Open and notorious",kw:"open|notorious",rule:["visible","reasonabl[ey]? (owner|inspection)","would (have )?(discover|notice|seen)|on notice|put .{0,20}on notice"],rmin:1,f:["fence","another state|never visited"],
fix:"Answer the absent owner point. Open and notorious asks whether a reasonable owner who inspected would notice the use, not whether this owner did. A fence and cattle are visible, so the neighbour's absence does not help.",
model:"Open and notorious. The use must be visible enough to put a reasonable owner on notice. A fence and grazing cattle are plain to anyone who inspects the land. That the neighbour lived in another state and never visited does not matter, because the test is what a reasonable owner would have seen."},
{n:"Exclusive",kw:"exclusiv",rule:["not shar|without shar|did not share","true owner|the owner|public"],rmin:1,f:["fence","graz|cattle"],
fix:"Add exclusivity: the farmer did not share possession with the neighbour or the public, and the fence kept others out.",
model:"Exclusive. Possession is exclusive when it is not shared with the true owner or the public. The farmer fenced the strip and used it alone, so the possession was exclusive."},
{n:"Hostile",kw:"hostile|claim of right|without (the owner's |the neighbour's |the neighbor's )?permission",rule:["permission","good faith|mistake|state of mind|objective|belie"],rmin:1,f:["believ","no rent"],
fix:"Deal with the farmer's mistake. Possession is hostile when it is without the owner's permission, and in most jurisdictions a good-faith mistake about the boundary does not defeat the claim.",
model:"Hostile. Possession is hostile when it is without the true owner's permission. In most jurisdictions the possessor's state of mind does not matter, so the farmer's good-faith belief that the strip was hers does not defeat the claim. She used it without permission and paid no rent, so the possession was hostile."},
{n:"Continuous for the statutory period",kw:"continu|statutory period|10 years|ten years|uninterrupt",rule:["uninterrupt|without interruption","seasonal|ordinary|nature of the land|as an owner would","statutory period|10 years|ten years"],rmin:2,f:["2012","2024","summer"],
fix:"Count the years and handle seasonal use. Grazing each summer can be continuous where that is how such land is ordinarily used, and June 2012 to 2024 is more than the 10-year period.",
model:"Continuous. The use must be continuous for the statutory period, judged by how an ordinary owner would use that kind of land, so seasonal grazing each summer can count. The farmer's use ran from June 2012 to 2024, longer than the 10-year period, so title likely passed to the farmer in June 2022, before the neighbour's demand."}],
sample:"Issue: whether the farmer got title by adverse possession.\n\nAdverse possession needs possession that is open, hostile and continuous.\n\nThe farmer fenced the land and grazed cattle so it was open.\n\nBut she thought the land was hers, so it was not hostile.\n\nShe only used it in the summer so it was not continuous.\n\nTherefore the neighbour still owns the strip."}];
const CRIT=[["s","Structure"],["i","Issue spotting"],["r","Rule statements"],["a","Application"],["c","Conclusion"],["t","Time and pace"]];
const LO=650,HI=1100;
/* ------------------------------------------------------------------ scoring, fixed rules */
const words=t=>(t.trim().match(/\S+/g)||[]).length;
const paras=t=>{let p=t.split(/\n\s*\n/);if(p.length<2)p=t.split(/\n/);return p.map(s=>s.trim()).filter(s=>words(s)>2)};
function evaluate(q,text,secs){
const P=paras(text),W=words(text),hits=(arr,s)=>arr.filter(r=>R(r).test(s)).length;
const per=q.issues.map(is=>{const ps=P.filter(p=>R(is.kw).test(p)),joined=ps.join(" ");const spot=ps.length>0;
const rule=spot&&hits(is.rule,joined)>=(is.rmin||1);const app=spot&&hits(is.f,joined)>0;
const con=spot&&R(CONC).test(joined);return{is,spot,rule,app,con}});
const n=per.length,sp=per.filter(x=>x.spot).length,ru=per.filter(x=>x.rule).length,ap=per.filter(x=>x.app).length,co=per.filter(x=>x.con).length;
const fh=hits(q.facts_re,text)/q.facts_re.length,last=P[P.length-1]||"";
let s=0;if(P.length>=3)s++;if(P.length>=sp+1&&sp>0)s++;if(ISSUECUE.test(text))s++;if(RULECUE.test(text))s++;if(APPCUE.test(text)&&R(CONC).test(last))s++;
const sc={s:Math.min(5,s),i:Math.round(5*sp/n),r:Math.round(5*ru/n),a:Math.min(5,Math.round(5*(ap/n*.7+Math.min(fh*1.6,1)*.3))),c:Math.min(5,Math.round(4*co/n+(R(CONC).test(last)?1:0)))};
let t=W>=LO&&W<=HI?5:W>HI?4:W>=450?3:W>=250?2:1;const over=secs>q.min*60;if(over)t=Math.max(0,t-1);sc.t=t;
const why={s:P.length+" paragraph"+(P.length===1?"":"s")+(ISSUECUE.test(text)?", issues framed":", no issue statements")+(R(CONC).test(last)?", a closing conclusion.":", no closing conclusion."),
i:sp+" of "+n+" issues found"+(sp<n?": missing "+per.filter(x=>!x.spot).map(x=>x.is.n).join("; ")+".":"."),
r:ru+" of "+n+" rules stated with their elements.",a:ap+" of "+n+" issues tied to the facts; "+Math.round(fh*100)+"% of the key facts used.",
c:co+" of "+n+" issues reach a conclusion"+(R(CONC).test(last)?", and the answer closes with one.":"."),
t:W+" words"+(secs?" in "+fmt(secs):"")+". This page's pace guide is "+LO+" to "+HI+" words in "+q.min+" minutes"+(over?"; the timer ran over.":".")};
/* three fixes: missed issues, then missing rules, then missing application, then structure */
const fx=[];per.filter(x=>!x.spot).forEach(x=>fx.push(["Missed issue: "+x.is.n,x.is.fix]));per.filter(x=>x.spot&&!x.rule).forEach(x=>fx.push(["Rule statement: "+x.is.n,x.is.fix]));
per.filter(x=>x.spot&&x.rule&&!x.app).forEach(x=>fx.push(["Use the facts: "+x.is.n,x.is.fix]));
if(sc.s<4)fx.push(["Structure","Give each issue its own paragraph in the same order: the issue as a question, the rule, the facts that matter, and a one-line conclusion."]);
if(!R(CONC).test(last))fx.push(["Conclusion","End with a short paragraph that answers the call of the question in one or two sentences."]);
if(W<LO)fx.push(["Length","At "+W+" words the answer is short for a 30-minute question. Spend the extra time on the rules and on the facts."]);
const notes=P.map((p,k)=>{const m=per.filter(x=>R(x.is.kw).test(p));if(!m.length)return k===P.length-1&&R(CONC).test(p)?"Conclusion. Good: it answers the call.":ISSUECUE.test(p)?"Issue statement. Good start; now take each issue in turn.":"No issue from the question is named here. Say which issue this paragraph is about.";
return m.map(x=>{const pr=[];if(hits(x.is.rule,p)<(x.is.rmin||1))pr.push("rule?");if(hits(x.is.f,p)===0)pr.push("use the facts");if(!R(CONC).test(p))pr.push("conclude");return x.is.n+(pr.length?": "+pr.join(", "):": rule, facts and conclusion")}).join(" · ")});
const weak=per.find(x=>x.spot&&(!x.rule||!x.app))||per.find(x=>!x.spot)||per[0];
return{sc,why,fixes:fx.slice(0,3),notes,P,W,rewrite:weak.is,over}}
const fmt=s=>{s=Math.max(0,Math.round(s));return String(Math.floor(s/60)).padStart(2,"0")+":"+String(s%60).padStart(2,"0")};
/* ------------------------------------------------------------------ the widget */
function ev(root){
const mini=root.classList.contains("iq-ev--mini");let qi=0,secs=0,tick=null,status=$("[data-ev-status]",root);
const ta=$("[data-ev-answer]",root),out=$("[data-ev-out]",root),qb=$("[data-ev-q]",root),clock=$("[data-ev-clock]",root),pace=$("[data-ev-pace]",root),paceT=$("[data-ev-pacet]",root),tb=$("[data-ev-timer]",root),cnt=$("[data-ev-count]",root);
const say=t=>{status.textContent=t};
function showQ(){const q=Q[qi];qb.innerHTML='<p class="iq-ev__k">'+esc(q.label)+' · '+q.min+' minutes · sample question written for this page</p><p class="iq-ev__f">'+esc(q.facts)+'</p><p class="iq-ev__call"><b>'+esc(q.call)+'</b></p>'}
function count(){const w=words(ta.value);cnt.textContent=w+" words";const m=secs/60,wpm=m>.2?w/m:0,tgt=(LO+HI)/2/Q[qi].min;
const f=Math.min(1,secs/(Q[qi].min*60));pace.style.setProperty("--f",f.toFixed(3));pace.style.setProperty("--w",Math.min(1,w/HI).toFixed(3));
paceT.textContent=secs?(Math.round(wpm)+" words a minute, guide about "+Math.round(tgt)):"Timer not started · blue bar: words against the "+HI+"-word guide"}
function stop(){clearInterval(tick);tick=null;tb.setAttribute("aria-pressed","false");$("span",tb).textContent=secs?"Resume timer":"Start timer"}
tb.addEventListener("click",()=>{if(tick){stop();say("Timer paused at "+fmt(secs)+".");return}tb.setAttribute("aria-pressed","true");$("span",tb).textContent="Pause timer";say("Timer running. "+Q[qi].min+" minutes for this question.");
tick=setInterval(()=>{secs++;clock.textContent=fmt(Q[qi].min*60-secs);clock.classList.toggle("is-over",secs>Q[qi].min*60);if(secs===Q[qi].min*60)say("Time is up. Finish your sentence and evaluate.");count()},1000)});
$$("[data-ev-pick]",root).forEach((b,i)=>b.addEventListener("click",()=>{if(i===qi){say(Q[i].tab+" question is already open.");return}qi=i;
$$("[data-ev-pick]",root).forEach((x,j)=>x.setAttribute("aria-pressed",j===i?"true":"false"));showQ();stop();secs=0;clock.textContent=fmt(Q[qi].min*60);clock.classList.remove("is-over");count();
out.innerHTML='<p class="iq-mute">'+esc(EMPTY)+'</p>';say(Q[i].tab+" question loaded. The timer is reset.")}));
$("[data-ev-sample]",root).addEventListener("click",()=>{ta.value=Q[qi].sample;ta.removeAttribute("aria-invalid");count();say("Sample answer loaded: "+words(ta.value)+" words, written for this page with gaps on purpose.")});
$("[data-ev-clear]",root).addEventListener("click",()=>{ta.value="";count();out.innerHTML='<p class="iq-mute">'+esc(EMPTY)+'</p>';say("Answer cleared.")});
ta.addEventListener("input",count);
$("[data-ev-go]",root).addEventListener("click",()=>{const t=ta.value;if(words(t)<40){ta.setAttribute("aria-invalid","true");
out.innerHTML='<p class="iq-err" role="alert">'+(words(t)?"That is "+words(t)+" words. Write at least 40 words, or load the sample answer, so there is enough to evaluate.":"Write or paste an answer first, or load the sample answer.")+'</p>';ta.focus();say("Nothing evaluated yet.");return}
ta.removeAttribute("aria-invalid");if(tick)stop();const r=evaluate(Q[qi],t,secs);render(r);say("Evaluation ready: scorecard, three fixes"+(mini?".":", margin notes and a suggested rewrite."))});
function render(r){const rows=CRIT.map(([k,l])=>'<li><span class="iq-sc__l">'+l+'</span><span class="iq-sc__b" style="--v:'+r.sc[k]/5+'"><i></i></span><b>'+r.sc[k]+'/5</b><small>'+esc(r.why[k])+'</small></li>').join("");
const fx=r.fixes.map((f,i)=>'<li><b>'+(i+1)+'. '+esc(f[0])+'</b><span>'+esc(f[1])+'</span></li>').join("")||'<li><b>No major gaps</b><span>Every issue has a rule, the facts and a conclusion. Try the timer next time and keep the same shape under pressure.</span></li>';
let h='<h3 class="iq-ev__h">Scorecard</h3><ul class="iq-sc">'+rows+'</ul><h3 class="iq-ev__h">Three fixes for the next answer</h3><ol class="iq-fx">'+fx+'</ol>';
if(!mini){h+='<h3 class="iq-ev__h">Margin notes</h3><ol class="iq-mn">'+r.P.map((p,i)=>'<li><p class="iq-mn__p">'+esc(p.length>220?p.slice(0,217)+"...":p)+'</p><p class="iq-mn__n">'+esc(r.notes[i])+'</p></li>').join("")+'</ol>'+
'<h3 class="iq-ev__h">Suggested rewrite: '+esc(r.rewrite.n.toLowerCase())+'</h3><p class="iq-rw">'+esc(r.rewrite.model)+'</p>'}
h+='<p class="iq-note">Guidance only. These rules were written for the three sample questions on this page; they are not a bar exam score and do not predict one. <a href="/how-evaluation-works">How evaluation works</a> · <a href="/rubric">The public rubric</a></p>';
out.innerHTML=h;if(!RM){root.classList.remove("is-anim");void root.offsetWidth;root.classList.add("is-anim")}}
const EMPTY=mini?"Load the sample answer or write your own, then evaluate. You get a rubric scorecard and three fixes.":"Pick a question, start the timer if you like, then write or paste your answer and evaluate it. You get a rubric scorecard, three fixes, margin notes on each paragraph and a suggested rewrite.";
showQ();count()}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-iq=ev]").forEach(ev)}
