/* Routekeel page tools. Everything runs offline in the browser; nothing typed or clicked here leaves the page.
   [data-rk=sim]   routing simulator: traffic, task mix and policy in, cost, latency, quality risk and a policy preview out
   [data-rk=yard]  route yard: requests split into four routes, take the large tier down, replay, pick a route with the arrow keys
   [data-rk=log]   home request log that streams synthetic rows
   [data-rk=tabs]  code tabs; [data-rk=copy] copy buttons; [data-hud-count] hero counter
   Prices, latencies and quality scores are a synthetic price card (same numbers as the copy in content.py). */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const RM=matchMedia("(prefers-reduced-motion: reduce)");
const TIER={small:{n:"Small tier",i:.15,o:.6,p95:700},mid:{n:"Mid tier",i:1,o:4,p95:1400},large:{n:"Large tier",i:5,o:15,p95:3000}};
const TASK={classify:{n:"Classification and tagging",q:{small:95,mid:96.5,large:97}},extract:{n:"Extraction to JSON",q:{small:91,mid:95,large:96}},
chat:{n:"Support chat",q:{small:86,mid:91,large:92.5}},summary:{n:"Summaries",q:{small:88,mid:92.5,large:93.5}},code:{n:"Code and reasoning",q:{small:70,mid:84,large:92}}};
const POL={cost:5,balanced:2,quality:0},POLN={cost:"cheapest tier within 5 quality points",balanced:"cheapest tier within 2 quality points",quality:"large tier unless a smaller tier scores the same"};
const ORDER=["small","mid","large"],CACHE_MS=15;
const usd=v=>v>=100?"$"+Math.round(v).toLocaleString("en-US"):"$"+v.toFixed(2);
const perReq=(t,i,o)=>(i*TIER[t].i+o*TIER[t].o)/1e6;
const secs=ms=>ms>=1000?(ms/1000).toFixed(1)+" s":Math.round(ms)+" ms";
/* shared yard state, so the home log can follow an outage */
const STATE={down:false};

function choose(task,policy,down){const q=TASK[task].q,lim=POL[policy];let t=ORDER.find(k=>q[k]>=q.large-lim)||"large";if(down&&t==="large")t="mid";return t}

/* ---------------- route yard */
const YARD_DEF={cache:18,small:34,mid:31,large:17},YARD_TXT={cache:"exact and semantic hits",small:"classification and extraction",mid:"support chat and summaries",large:"code and reasoning"};
function yard(root){
 const mini=root.hasAttribute("data-mini"),svg=$("svg",root),dots=$("[data-yard-dots]",root),cnt=$("[data-yard-count]",root),det=$("[data-yard-detail]",root),xg=$("[data-yard-x]",root);
 const paths={};$$("[data-route]",root).forEach(p=>paths[p.dataset.route]=p);
 const btns=$$("[data-route-btn]",root),down=$("[data-yard-down]",root);
 let share={...YARD_DEF},cost={cache:0,small:perReq("small",900,250)*1e3,mid:perReq("mid",900,250)*1e3,large:perReq("large",900,250)*1e3},sel="mid",isDown=false,n=0,live=[],last=0,acc=0,raf=0,vis=true;
 const eff=()=>{const s={...share};if(isDown){s.mid+=s.large;s.large=0}return s};
 const p95=k=>k==="cache"?CACHE_MS:TIER[k].p95;
 const names={cache:"Cache",small:"Small tier",mid:"Mid tier",large:"Large tier"};
 function label(){const s=eff();Object.keys(s).forEach(k=>{const el=$('[data-share="'+k+'"]',root);if(el)el.textContent=Math.round(s[k])+"%"});
  const k=sel,c=k==="mid"&&isDown?"Synthetic cost $"+cost.mid.toFixed(2)+" per 1K requests, now also carrying the large tier traffic.":"Synthetic cost $"+cost[k].toFixed(2)+" per 1K requests, p95 "+secs(p95(k))+".";
  det.textContent=k==="large"&&isDown?"Large tier: down. Its requests fail over to the mid tier, so nothing fails for users.":names[k]+": "+Math.round(s[k])+"% of requests, "+YARD_TXT[k]+". "+c;
  $$(".rk-y__n",root).forEach(g=>g.classList.toggle("is-sel",g.dataset.node===sel));
  btns.forEach(b=>{const on=b.dataset.routeBtn===sel;b.setAttribute("aria-pressed",on);b.tabIndex=on?0:-1})}
 function pick(){const s=eff();let r=Math.random()*100;for(const k of ["cache","small","mid","large"]){if(r<s[k])return k;r-=s[k]}return"mid"}
 function spawn(){const k=pick(),c=document.createElementNS("http://www.w3.org/2000/svg","circle");c.setAttribute("r",mini?4:4.5);c.setAttribute("class","rk-y__dot"+(isDown&&k==="mid"&&Math.random()<share.large/(share.mid+share.large)?" is-re":"")+(k==="cache"?" is-cache":""));
  dots.appendChild(c);live.push({c,k,t:0,sp:.32+Math.random()*.12});n++;cnt.textContent=n.toLocaleString("en-US")}
 function place(d){const p=paths[d.k],L=p.getTotalLength();let x,y;if(d.t<.35){x=d.t/.35*150;y=146}else{const pt=p.getPointAtLength(Math.min(1,(d.t-.35)/.65)*L);x=pt.x;y=pt.y}d.c.setAttribute("cx",x.toFixed(1));d.c.setAttribute("cy",y.toFixed(1))}
 function tick(ts){raf=0;if(!vis||document.hidden){last=0;return}const dt=last?Math.min(.05,(ts-last)/1000):0;last=ts;acc+=dt;
  while(acc>.16){acc-=.16;if(live.length<(mini?26:40))spawn()}
  live=live.filter(d=>{d.t+=dt*d.sp;if(d.t>=1){d.c.remove();return false}place(d);return true});raf=requestAnimationFrame(tick)}
 function still(){dots.textContent="";live=[];const s=eff();let i=0;["cache","small","mid","large"].forEach(k=>{const m=Math.round(s[k]/10);for(let j=0;j<m;j++){const c=document.createElementNS("http://www.w3.org/2000/svg","circle");c.setAttribute("r",4);c.setAttribute("class","rk-y__dot"+(k==="cache"?" is-cache":""));dots.appendChild(c);place({c,k,t:.42+.5*(j+1)/(m+1)});i++}});cnt.textContent=i}
 function start(){if(RM.matches){still();return}if(!raf)raf=requestAnimationFrame(tick)}
 function replay(){live.forEach(d=>d.c.remove());live=[];n=0;cnt.textContent="0";acc=0;det.textContent=RM.matches?"Replayed. Reduced motion is on, so the requests are shown in place.":"Replay started: the counter runs from zero again.";start()}
 btns.forEach((b,i)=>{b.addEventListener("click",()=>{sel=b.dataset.routeBtn;label()});
  b.addEventListener("keydown",e=>{const k=e.key;let j=i;if(k==="ArrowRight"||k==="ArrowDown")j=(i+1)%btns.length;else if(k==="ArrowLeft"||k==="ArrowUp")j=(i-1+btns.length)%btns.length;else if(k==="Home")j=0;else if(k==="End")j=btns.length-1;else return;
   e.preventDefault();sel=btns[j].dataset.routeBtn;label();btns[j].focus()})});
 $("[data-yard-replay]",root).addEventListener("click",replay);
 down.addEventListener("click",()=>{isDown=!isDown;STATE.down=isDown;down.setAttribute("aria-pressed",isDown);$("span",down).textContent=isDown?"Bring the large tier back":"Take the large tier down";
  paths.large.classList.toggle("is-down",isDown);xg.hidden=!isDown;root.querySelector('[data-node="large"]').classList.toggle("is-down",isDown);
  live.forEach(d=>{if(d.k==="large"&&isDown){d.k="mid";d.c.classList.add("is-re")}});label();if(RM.matches)still()});
 if("IntersectionObserver"in window)new IntersectionObserver(es=>{vis=es[0].isIntersecting;if(vis)start()}).observe(root);
 document.addEventListener("visibilitychange",()=>{if(!document.hidden)start()});
 RM.addEventListener&&RM.addEventListener("change",()=>{replay()});
 root.rkSet=(s,c)=>{share=s;cost=c;label();if(RM.matches)still()};
 label();start()}

/* ---------------- simulator */
function sim(root){
 const f=k=>$('[data-sim="'+k+'"]',root),err=$("[data-sim-err]",root),rows=$("[data-sim-rows]",root),empty=$("[data-sim-empty]",root),pol=$("[data-sim-policy]",root);
 const yardEl=root.parentElement.querySelector('[data-rk="yard"]');
 const DEF={req:"2,000,000",in:"900",out:"250",cache:"0.2",mix:{classify:30,extract:15,chat:30,summary:15,code:10},policy:"balanced"};
 const num=(el,lo,hi,what)=>{const v=el.value.replace(/[\s,]/g,"");if(!/^\d+$/.test(v)||+v<lo||+v>hi){el.setAttribute("aria-invalid","true");throw what+" must be a whole number between "+lo.toLocaleString("en-US")+" and "+hi.toLocaleString("en-US")+"."}el.removeAttribute("aria-invalid");return+v};
 const set=(k,v,s)=>{$('[data-k="'+k+'"]',root).textContent=v;if(s!=null)$('[data-ks="'+k+'"]',root).textContent=s};
 function run(){
  $$("[data-mix]",root).forEach(r=>{$('[data-mix-out="'+r.dataset.mix+'"]',root).textContent=r.value+"%"});
  let req,ti,to;try{req=num(f("req"),1000,1e9,"Monthly requests");ti=num(f("in"),1,200000,"Average input tokens");to=num(f("out"),1,100000,"Average output tokens");err.textContent=""}
  catch(m){err.textContent=m;return}
  const cache=+f("cache").value,policy=($('input[name="sim-policy"]:checked',root)||{}).value||"balanced",down=f("outage").checked;
  const mix={};let sum=0;$$("[data-mix]",root).forEach(r=>{mix[r.dataset.mix]=+r.value;sum+=+r.value});
  if(!sum){empty.hidden=false;rows.textContent="";["base","routed","save","p95","risk"].forEach(k=>set(k,"-"));pol.textContent="# Set a task share above 0% to see a policy.";return}
  empty.hidden=true;let base=0,routed=0,p95=0,risk=0,html="";const tierShare={small:0,mid:0,large:0};const lines=[];
  Object.keys(TASK).forEach(k=>{const sh=mix[k]/sum;if(!sh)return;const t=choose(k,policy,down),n=req*sh,miss=n*(1-cache);
   const b=n*perReq("large",ti,to),r=miss*perReq(t,ti,to),dq=TASK[k].q.large-TASK[k].q[t];base+=b;routed+=r;p95+=sh*((1-cache)*TIER[t].p95+cache*CACHE_MS);risk=Math.max(risk,dq);tierShare[t]+=sh*(1-cache);
   html+='<tr><th scope="row">'+TASK[k].n+'</th><td>'+Math.round(sh*100)+'%</td><td>'+TIER[t].n+(down&&choose(k,policy,false)==="large"?" (failover)":"")+'</td><td>'+usd(r)+'</td><td>'+(dq?"-"+dq.toFixed(1)+" pts":"Same")+'</td></tr>';
   lines.push('  - when: task == "'+k+'"\n    send_to: '+t+'-tier'+(dq?'   # '+dq.toFixed(1)+' pts below large':''))});
  rows.innerHTML=html;const save=base-routed;
  set("base",usd(base),"Synthetic price card, no cache");set("routed",usd(routed),Math.round(cache*100)+"% cache hits");set("save",usd(Math.max(0,save)),base?Math.round(100*save/base)+"% per month":"");
  set("p95",secs(p95),"Model time only, approx.");set("risk",risk<1?"Low":(risk<=3?"Medium":"High"),risk?"Largest drop "+risk.toFixed(1)+" pts":"No task below large");
  pol.textContent="route: app-default\npolicy: "+policy+"   # "+POLN[policy]+"\ncache:\n  exact: on\n  semantic: "+(cache?"on, similarity 0.95":"off")+"\nrules:\n"+lines.join("\n")+"\nfallback: ["+(down?"mid-tier, small-tier":"mid-tier, large-tier")+"]\nrollback:\n  quality_drop_pts: 2\n# Sample data: synthetic price card";
  if(yardEl&&yardEl.rkSet){const c=(t)=>perReq(t,ti,to)*1e3;yardEl.rkSet({cache:cache*100,small:tierShare.small*100,mid:tierShare.mid*100,large:tierShare.large*100},{cache:0,small:c("small"),mid:c("mid"),large:c("large")})}
  STATE.down=down}
 let tm=0;const later=()=>{clearTimeout(tm);tm=setTimeout(run,180)};
 root.addEventListener("input",later);root.addEventListener("change",run);
 $("[data-sim-reset]",root).addEventListener("click",()=>{f("req").value=DEF.req;f("in").value=DEF.in;f("out").value=DEF.out;f("cache").value=DEF.cache;f("outage").checked=false;
  $$("[data-mix]",root).forEach(r=>r.value=DEF.mix[r.dataset.mix]);$('input[value="'+DEF.policy+'"]',root).checked=true;$$("[aria-invalid]",root).forEach(e=>e.removeAttribute("aria-invalid"));run()});
 setTimeout(run,0)}

/* ---------------- home request log */
function log(tb){if(RM.matches)return;const R=[["support-chat","mid"],["ticket-tagging","small"],["support-chat","cache"],["invoice-extract","small"],["code-review","large"],["support-chat","mid"]];let i=0;
 const pad=n=>String(n).padStart(2,"0");
 setInterval(()=>{if(document.hidden)return;const r=R[i++%R.length],d=new Date(Date.UTC(2026,10,27,10,42,8+i)),ms=String(100+(i*137)%900).padStart(3,"0");
  let k=r[1],st=["200","ok"];if(k==="large"&&STATE.down){k="mid";st=["Failover","warn"]}
  const tok=k==="cache"?1100+(i*53)%300:k==="small"?300+(i*97)%1900:k==="mid"?800+(i*61)%900:4000+(i*211)%3000;
  const lat=k==="cache"?(8+i%5)+" ms":secs(TIER[k].p95*(.3+((i*7)%5)/10));const cost=k==="cache"?0:perReq(k,tok*.78,tok*.22);
  const tr=document.createElement("tr");tr.className="is-new";
  tr.innerHTML='<td class="rk-mono">'+pad(d.getUTCHours())+":"+pad(d.getUTCMinutes())+":"+pad(d.getUTCSeconds())+"."+ms+'</td><td>'+r[0]+'</td><td>'+(k==="cache"?"Cache":TIER[k].n)+'</td><td class="rk-num">'+tok.toLocaleString("en-US")+'</td><td class="rk-num">'+lat+'</td><td class="rk-num">$'+cost.toFixed(4)+'</td><td><span class="mv-tag mv-tag--'+st[1]+'">'+(k==="cache"?"Hit":st[0])+'</span></td>';
  tb.prepend(tr);while(tb.children.length>6)tb.lastElementChild.remove()},2200)}

/* ---------------- tabs, copy, hud */
function tabs(root){const sel=$(".rk-sel",root),ps=$$(".rk-tabs__p",root);sel.addEventListener("change",()=>{ps.forEach(p=>p.hidden=p.dataset.panel!==sel.value)})}
function copy(b){b.addEventListener("click",async()=>{const src=b.dataset.copyFrom?document.getElementById(b.dataset.copyFrom):b.closest("figure").querySelector("pre");
 const txt=[...src.querySelectorAll(".rk-cl")].filter(l=>!l.classList.contains("rk-cl--del")).map(l=>l.textContent).join("\n")||src.textContent;const lab=$("span",b);let ok=false;
 try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(txt);ok=true}}catch(e){}
 if(!ok){const ta=document.createElement("textarea");ta.value=txt;ta.setAttribute("readonly","");ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.select();try{ok=document.execCommand("copy")}catch(e){}ta.remove()}
 lab.textContent=ok?"Copied":"Select and copy";setTimeout(()=>lab.textContent="Copy",1600)})}
function hud(){const el=$("[data-hud-count]");if(!el||RM.matches)return;let n=18240;setInterval(()=>{if(document.hidden)return;n+=3+Math.floor(Math.random()*9);el.textContent=n.toLocaleString("en-US")},1400)}

export function boot(){
$$('[data-rk="yard"]').forEach(yard);
$$('[data-rk="sim"]').forEach(sim);
$$('[data-rk="log"]').forEach(log);
$$('[data-rk="tabs"]').forEach(tabs);
$$('[data-rk="copy"]').forEach(copy);
hud();
$$(".mv-pscroll,.rk-code pre,.rk-pp pre").forEach(el=>{const f=()=>{const s=el.scrollWidth>el.clientWidth+2;s?el.setAttribute("tabindex","0"):el.removeAttribute("tabindex")};f();addEventListener("resize",f)});
}
