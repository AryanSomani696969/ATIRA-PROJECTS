/* Iracquill hero: a moonlit study room on a midnight ground. A timer ring of 60 ticks lies around the desk and fills in amber.
   On the desk an answer sheet turns slowly and rises; its handwritten strokes straighten into typed lines, five rubric rungs fill
   beside it, and at rest the subject tracker lights tomorrow's weakest topic. 12 second cycle; scrolling holds the resolved state.
   Every figure is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const bg=new T.Color(colors.bg),paper=new T.Color(color("--iq-paper","#faf7f0")),amber=new T.Color(color("--iq-amber","#e98a15")),pen=new T.Color(color("--iq-penl","#a9bee6")),royal=new T.Color(color("--iq-royal","#1b3a6b"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),9,20);
const root=new T.Group;scene.add(root);const geos=[],mats=[];const G=g=>(geos.push(g),g);const M=(c,o={})=>{const m=new T.MeshStandardMaterial(Object.assign({color:c,roughness:.8,metalness:0},o));mats.push(m);return m};
root.add(new T.AmbientLight(0xd9d4e8,.85));
const key=new T.DirectionalLight(0xffe6c4,1.1);key.position.set(-3,6,5);root.add(key);
const rim=new T.DirectionalLight(amber.getHex(),.3);rim.position.set(5,2,-4);root.add(rim);
/* moon and window, far back */
const moon=new T.Mesh(G(new T.SphereGeometry(.24,small?16:28,small?12:20)),new T.MeshBasicMaterial({color:paper.clone().lerp(bg,.08)}));moon.position.set(1.95,2.3,-3.4);root.add(moon);

const wl=[],X0=.6,X1=2.6,Y0=1.25,Y1=2.75,Z=-3.5;[[X0,Y0,X1,Y0],[X1,Y0,X1,Y1],[X1,Y1,X0,Y1],[X0,Y1,X0,Y0],[(X0+X1)/2,Y0,(X0+X1)/2,Y1],[X0,(Y0+Y1)/2,X1,(Y0+Y1)/2]].forEach(([a,b,c,d])=>wl.push(a,b,Z,c,d,Z));
const wg=G(new T.BufferGeometry);wg.setAttribute("position",new T.Float32BufferAttribute(wl,3));const lineMat=new T.LineBasicMaterial({color:bg.clone().lerp(paper,.35)});mats.push(lineMat);root.add(new T.LineSegments(wg,lineMat));
/* desk */
const deskMat=new T.MeshBasicMaterial({color:bg.clone().lerp(paper,.015)});mats.push(deskMat);const desk=new T.Mesh(G(new T.BoxGeometry(10,.1,5)),deskMat);desk.position.set(.8,-.06,.4);root.add(desk);
/* timer ring: 60 instanced ticks around the desk centre */
const TK=60,tickGeo=G(new T.BoxGeometry(.035,.02,.13)),tickMat=new T.MeshBasicMaterial({color:0xffffff});mats.push(tickMat);const ticks=new T.InstancedMesh(tickGeo,tickMat,TK),o=new T.Object3D;root.add(ticks);
const RC=new T.Vector3(1.45,.02,.75),RX=2.05,RZ=1.2,off=bg.clone().lerp(paper,.3);
for(let i=0;i<TK;i++){const a=-Math.PI/2+i/TK*Math.PI*2;o.position.set(RC.x+Math.cos(a)*RX,RC.y,RC.z+Math.sin(a)*RZ);o.rotation.set(0,-a+Math.PI/2,0);o.updateMatrix();ticks.setMatrixAt(i,o.matrix);ticks.setColorAt(i,off)}
/* the answer sheet: a page group that turns and rises; handwriting strokes are short segments that straighten into typed lines */
const sheet=new T.Group;sheet.position.set(1.3,.06,.75);root.add(sheet);
const PW=1.7,PD=2.2;const page=new T.Mesh(G(new T.BoxGeometry(PW,.025,PD)),M(paper.clone(),{roughness:.92,emissive:paper.clone(),emissiveIntensity:.42}));sheet.add(page);
const margin=new T.Mesh(G(new T.BoxGeometry(.012,.004,PD-.3)),new T.MeshBasicMaterial({color:royal}));margin.position.set(PW/2-.42,.016,0);sheet.add(margin);mats.push(margin.material);
const ROWS=9,SEG=small?7:12,segGeo=G(new T.BoxGeometry(1,.006,.03)),inkMat=M(royal.clone(),{roughness:.6});const ink=new T.InstancedMesh(segGeo,inkMat,ROWS*SEG);sheet.add(ink);
const LW=[];for(let r=0;r<ROWS;r++)LW.push((PW-.75)*(.62+((r*29)%34)/100));
function write(k){/* k: 0 handwriting, 1 typed */for(let r=0;r<ROWS;r++){const z=-PD/2+.34+r*(PD-.55)/(ROWS-1),w=LW[r],sw=w/SEG;for(let s=0;s<SEG;s++){const j=r*SEG+s,wob=Math.sin(s*1.9+r*1.3)*.035*(1-k),tilt=Math.cos(s*2.3+r)*.5*(1-k);
o.position.set(-PW/2+.18+sw*(s+.5),.016,z+wob);o.rotation.set(0,tilt,0);o.scale.set(sw*(1.05-.2*(1-k)),1,k*1.4+.6);o.updateMatrix();ink.setMatrixAt(j,o.matrix)}}ink.instanceMatrix.needsUpdate=!0}
/* margin notes: two small pen-blue loops beside the lines */
const lp=[];for(let i=0;i<=40;i++){const a=i/40*Math.PI*2;lp.push(Math.cos(a)*.17,0,Math.sin(a)*.08)}const loopGeo=G(new T.BufferGeometry);loopGeo.setAttribute("position",new T.Float32BufferAttribute(lp,3));
const loopMat=new T.LineBasicMaterial({color:royal,transparent:!0,opacity:0});mats.push(loopMat);
const loops=[0,1].map(i=>{const l=new T.Line(loopGeo,loopMat);l.position.set(PW/2-.22,.02,-.5+i*.8);sheet.add(l);return l});
/* rubric rungs: five tracks with fills on a standing card */
const board=new T.Group;board.position.set(3.05,1.55,-.7);board.rotation.set(0,-.42,0);board.scale.setScalar(.78);root.add(board);
const card=new T.Mesh(G(new T.BoxGeometry(1.25,1.45,.03)),M(bg.clone().lerp(paper,.12),{roughness:.5,transparent:!0,opacity:.92}));board.add(card);
const trGeo=G(new T.BoxGeometry(1,.07,.02)),trMat=new T.MeshBasicMaterial({color:bg.clone().lerp(paper,.28)});mats.push(trMat);
const TV=[.82,.58,.4,.74,.5],fills=TV.map((v,i)=>{const y=.48-i*.24,tr=new T.Mesh(trGeo,trMat);tr.scale.x=.95;tr.position.set(0,y,.025);board.add(tr);
const fm=new T.MeshBasicMaterial({color:i===2?amber:pen});mats.push(fm);const f=new T.Mesh(trGeo,fm);f.position.set(-.475,y,.04);board.add(f);return f});
/* subject tracker: 12 tiles, the weakest one lights amber at rest */
const trk=new T.Group;trk.position.set(3.3,2.15,-2.2);trk.rotation.set(0,-.3,0);trk.scale.setScalar(.85);root.add(trk);const tileGeo=G(new T.BoxGeometry(.24,.24,.03)),LV=[.55,.35,.6,.2,.4,.55,.08,.35,.25,.6,.4,.35],tiles=[];
for(let i=0;i<12;i++){const m=M(bg.clone().lerp(pen,LV[i]),{emissive:amber.clone(),emissiveIntensity:0,roughness:.6});const t=new T.Mesh(tileGeo,m);t.position.set((i%4)*.3-.45,-Math.floor(i/4)*.3+.3,0);trk.add(t);tiles.push(t)}
const WEAK=6;
const C0=new T.Vector3(2.1,3.4,7.6),look=new T.Vector3(1.55,.9,0),lk=new T.Vector3;camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const tc=new T.Color;
function frame(t,dt,p){
const hold=clamp((p-.5)/.3),c0=t%12,c=hold>0?lerp(c0,10.5,ease(hold)):c0,reset=c>11.3?ease((c-11.3)/.7):0;
camera.position.set(C0.x+Math.sin(t/12*Math.PI*2)*.25+pointer.x*.3,C0.y-pointer.y*.16,C0.z);lk.copy(look);lk.x+=pointer.x*.08;camera.lookAt(lk);
/* sheet: slow turn and rise over the cycle */
const rise=ease(clamp(c/6))*(1-reset);sheet.position.y=.08+rise*.75;sheet.rotation.set(.25+rise*.55,.12-rise*.3,0);
const k=ease(clamp((c-2)/4))*(1-reset);write(k);
loopMat.opacity=ease(clamp((c-6.2)/.8))*(1-reset);loops.forEach(l=>l.scale.set(.6+.4*loopMat.opacity,1,.6+.4*loopMat.opacity));
/* ticks fill with the cycle */
const lit=Math.floor(clamp(c/10)*TK*(1-reset));for(let i=0;i<TK;i++){tc.copy(i<lit?amber:off);ticks.setColorAt(i,tc)}ticks.instanceColor.needsUpdate=!0;
fills.forEach((f,i)=>{const e=ease(clamp((c-4.5-i*.35)/1.4))*(1-reset),w=Math.max(.001,TV[i]*.95*e);f.scale.x=w;f.position.x=-.475+w/2});
board.position.y=1.55+Math.sin(t*.7)*.04;trk.position.y=2.15+Math.sin(t*.6+1)*.03;
const rest=ease(clamp((c-8.6)/.8))*(1-reset);tiles.forEach((tl,i)=>{tl.material.emissiveIntensity=i===WEAK?rest*.9:0;tl.material.color.copy(bg).lerp(i===WEAK&&rest>.5?amber:pen,i===WEAK?lerp(LV[i],1,rest):LV[i])})}
return{frame,resize:(w,h)=>{C0.z=w/h<.8?10.5:7.6;look.x=w/h<.8?1.5:1.55},dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());ticks.dispose();ink.dispose()}}}
