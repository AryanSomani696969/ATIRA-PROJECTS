/* Dueweave hero: a calm inbox river on deep teal. Invoice cards drift with the current toward the shore,
   a coral thread weaves through them, disputed cards are pulled aside with a coral edge, and paid cards
   stack into a green cash column on the shore. Three looping shots of the same scene, 9 seconds each (27 s loop):
   shot 1 establish (slow push-in), shot 2 process (a quarter-turn orbit while the thread draws), shot 3 outcome
   (pull back to the opening frame so the loop closes). One easing curve, no shake. Everything here is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp}=helpers,R=rand(14);
const io=x=>x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2;
const bg=new T.Color(colors.bg),cream=new T.Color(color("--dw-cream","#faf4e8")),coral=new T.Color(color("--dw-coral","#f26b5b")),green=new T.Color(color("--dw-green","#2e9e6b"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),8,19);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xa9d3d0,.6));
const key=new T.DirectionalLight(0xffe9d2,1.1);key.position.set(-4,8,6);root.add(key);
const rim=new T.DirectionalLight(coral.getHex(),.18);rim.position.set(6,3,-6);root.add(rim);
/* river: a segmented plane with slow travelling waves */
const SX=small?40:72,SZ=small?20:36,rGeo=new T.PlaneGeometry(44,26,SX,SZ);rGeo.rotateX(-Math.PI/2);
const rMat=new T.MeshStandardMaterial({color:new T.Color(0x14596a),emissive:bg.clone(),emissiveIntensity:.35,roughness:.38,metalness:.12});
const river=new T.Mesh(rGeo,rMat);root.add(river);const rp=rGeo.attributes.position,base=Float32Array.from(rp.array);
const H=(x,z,t)=>Math.sin(x*.55+t*.7)*.09+Math.sin(z*.9-t*.5+x*.2)*.06;
/* shore: a low cream bank on the right where the column stands */
const bank=new T.Mesh(new T.BoxGeometry(5,.3,14),new T.MeshStandardMaterial({color:cream.clone().lerp(bg,.3),roughness:.9}));bank.position.set(6.2,.02,0);root.add(bank);
/* invoice cards */
const N=small?16:26,cGeo=new T.BoxGeometry(.9,.03,.62),cMat=new T.MeshStandardMaterial({color:0xffffff,roughness:.6,emissive:cream.clone(),emissiveIntensity:.08}),cards=new T.InstancedMesh(cGeo,cMat,N);root.add(cards);
const C=[];for(let i=0;i<N;i++)C.push({ph:i/N,lane:(R()-.5)*4.2,rot:(R()-.5)*.9,disp:i%9===4,sp:.9+R()*.2});
const o=new T.Object3D,tc=new T.Color;
/* cash column: green coins stacking on the bank */
const NC=small?16:24,coGeo=new T.CylinderGeometry(.42,.42,.09,small?18:30),coMat=new T.MeshStandardMaterial({color:green.clone(),roughness:.35,metalness:.25}),coins=new T.InstancedMesh(coGeo,coMat,NC);
const COL=new T.Vector3(3.9,.2,.6);for(let i=0;i<NC;i++){o.position.set(COL.x+((i*7)%3-1)*.02,COL.y+i*.105,COL.z);o.rotation.set(0,0,0);o.scale.set(1,1,1);o.updateMatrix();coins.setMatrixAt(i,o.matrix)}root.add(coins);
/* the thread: one coral line weaving over the water and ending at the top of the column */
const pts=[];for(let i=0;i<=24;i++){const u=i/24,x=lerp(-5,COL.x,u),z=Math.sin(u*Math.PI*5)*1.5*(1-u*.7)+COL.z*u;pts.push(new T.Vector3(x,.34+Math.sin(u*9)*.05+(u>.92?(u-.92)/.08*2.6:0),z))}
const curve=new T.CatmullRomCurve3(pts),TS=small?220:400,RS=6,tGeo=new T.TubeGeometry(curve,TS,.032,RS,!1),tMat=new T.MeshBasicMaterial({color:coral.clone()}),thread=new T.Mesh(tGeo,tMat);root.add(thread);
const TOT=tGeo.index.count,SEG=RS*6;
camera.fov=40;camera.updateProjectionMatrix();
const A=new T.Vector3(.2,3.6,9.4),B=new T.Vector3(.8,2.7,7.4),tgt=new T.Vector3(1.4,.2,0),cam=new T.Vector3,lk=new T.Vector3,wide={k:1};
const rail=[...document.querySelectorAll("[data-dw-rail] li")];let shotNow=-1;
function frameFn(t,dt,p){
const c=t%27,shot=Math.min(2,Math.floor(c/9)),u=(c%9)/9;
/* camera: push-in, quarter orbit, pull back to the opening frame */
if(shot===0)cam.lerpVectors(A,B,io(u));
else if(shot===1){const r0=Math.hypot(B.x-tgt.x,B.z-tgt.z),a0=Math.atan2(B.z-tgt.z,B.x-tgt.x),a=a0-io(u)*Math.PI/2*.5;cam.set(tgt.x+Math.cos(a)*r0,B.y+Math.sin(io(u)*Math.PI)*.4,tgt.z+Math.sin(a)*r0)}
else{const r0=Math.hypot(B.x-tgt.x,B.z-tgt.z),a1=Math.atan2(B.z-tgt.z,B.x-tgt.x)-Math.PI/4,E=new T.Vector3(tgt.x+Math.cos(a1)*r0,B.y,tgt.z+Math.sin(a1)*r0);cam.lerpVectors(E,A,io(u))}
camera.position.set(cam.x+pointer.x*.25,cam.y-pointer.y*.12,cam.z).multiplyScalar(1).add(new T.Vector3(0,0,(wide.k-1)*6));lk.copy(tgt);lk.x+=pointer.x*.08;camera.lookAt(lk);
if(shot!==shotNow){shotNow=shot;rail.forEach((li,i)=>li.classList.toggle("is-on",i===shot))}
/* waves */
const a=rp.array;for(let i=0;i<a.length;i+=3){a[i+1]=H(base[i],base[i+2],t)}rp.needsUpdate=!0;if(!small||((t*10)|0)%2===0)rGeo.computeVertexNormals();
/* cards drift left to right; disputed ones are pulled aside, paid ones leave the water at the column */
let paid=0;C.forEach((k,i)=>{const q=((t/27*k.sp)+k.ph)%1,x=lerp(-10,COL.x-.6,q);let z=k.lane*(1-io(clamp((q-.55)/.45)))+COL.z*io(clamp((q-.55)/.45));let y=H(x,z,t)+.05,s=1;
if(k.disp&&q>.45){const d=io(clamp((q-.45)/.15));z=lerp(z,-3.2,d);tc.copy(cream).lerp(coral,d*.85)}else tc.copy(cream);
if(!k.disp&&q>.9){s=1-clamp((q-.9)/.1);tc.lerp(green,clamp((q-.86)/.06));paid++}
o.position.set(x,y,z);o.rotation.set(Math.cos(x*.55+t*.7)*.05,k.rot+q*.4,Math.sin(z*.9-t*.5)*.05);o.scale.set(s,1,s);o.updateMatrix();cards.setMatrixAt(i,o.matrix);cards.setColorAt(i,tc)});
cards.instanceMatrix.needsUpdate=!0;if(cards.instanceColor)cards.instanceColor.needsUpdate=!0;
/* column grows over the loop, the thread draws in during shot 2 and stays drawn in shot 3 */
const grow=Math.round(lerp(4,NC,io(clamp(c/24))));coins.count=Math.max(1,c>26?Math.round(lerp(grow,4,(c-26))):grow);
const k2=shot===0?.3+u*.15:shot===1?.45+io(u)*.55:1;tGeo.setDrawRange(0,Math.floor(TOT*k2/SEG)*SEG);
}
return{frame:frameFn,resize:(w,h)=>{wide.k=w/h<.6?1.5:w/h<1.2?1.12:1},dispose:()=>{[rGeo,cGeo,coGeo,tGeo,bank.geometry].forEach(g=>g.dispose())}}}
