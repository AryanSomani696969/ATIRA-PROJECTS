/* Dataroomiq hero: a tidy vault of stage-labelled folders in cool light.
   A near-static camera makes one slow 20-second dolly; a single pulse of light crosses the scene every 10 seconds.
   Story on a 24-second loop (scrolling past the hero holds the final state):
   0-3 s loose documents rest on the table; 3-10 s they sort into six folders; 10-14 s two red gap markers pulse
   until their last documents arrive and turn lime; 14-20 s the index tabs lock in order; 20-24 s it eases back.
   Every document and folder here is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(41);
const bg=new T.Color(colors.bg),mist=new T.Color(color("--dq-mist","#eef2f6")),lime=new T.Color(color("--dq-lime","#b7e34b")),red=new T.Color(color("--dq-red","#e5484d"));
const steel=bg.clone().lerp(mist,.22),dim=bg.clone().lerp(mist,.07),fol=new T.Color(0xa9bdd6);const wallC=new T.Color(0x1c3760),paper=new T.Color(0xf4f7fb);
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),8,18);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xa8bfe0,.5));
const key=new T.DirectionalLight(0xeef3ff,1.05);key.position.set(-3,7,5);root.add(key);
const rim=new T.DirectionalLight(lime.getHex(),.35);rim.position.set(5,3,-5);root.add(rim);
const pulse=new T.DirectionalLight(0xdfe8f5,0);pulse.position.set(-6,2.4,3);root.add(pulse);
/* table */
const table=new T.Mesh(new T.PlaneGeometry(30,16),new T.MeshStandardMaterial({color:bg.clone().multiplyScalar(.55),roughness:1}));table.rotation.x=-Math.PI/2;table.position.y=-.01;root.add(table);
/* vault wall: instanced dim folders on shelves */
const WR=4,WC=small?7:10,wGeo=new T.BoxGeometry(.86,.6,.1),wMat=new T.MeshStandardMaterial({color:0xffffff,roughness:.85}),wall=new T.InstancedMesh(wGeo,wMat,WR*WC),o=new T.Object3D,tc=new T.Color;
for(let r=0;r<WR;r++)for(let c=0;c<WC;c++){const i=r*WC+c;o.position.set((c-(WC-1)/2)*1.02,.55+r*.8,-3.2);o.rotation.set(0,0,0);o.scale.set(1,1,1);o.updateMatrix();wall.setMatrixAt(i,o.matrix);
tc.copy(wallC).lerp(bg,R()*.5);wall.setColorAt(i,tc)}root.add(wall);
const shelfMat=new T.MeshStandardMaterial({color:wallC.clone().lerp(mist,.12),roughness:.7});
for(let r=0;r<WR;r++){const s=new T.Mesh(new T.BoxGeometry(WC*1.02+.4,.04,.5),shelfMat);s.position.set(0,.23+r*.8,-3.1);root.add(s)}
/* six front folders, upright, with index tabs */
const NF=6,FX=f=>(f-(NF-1)/2)*.9,FZ=.2,fGeo=new T.BoxGeometry(.76,.72,.16),tGeo=new T.BoxGeometry(.24,.08,.17),FOL=[],TABS=[];
for(let f=0;f<NF;f++){const m=new T.MeshStandardMaterial({color:fol.clone(),roughness:.6});const b=new T.Mesh(fGeo,m);b.position.set(FX(f),.36,FZ);root.add(b);FOL.push(b);
const tm=new T.MeshStandardMaterial({color:steel.clone(),emissive:0x000000,roughness:.6});const t=new T.Mesh(tGeo,tm);t.position.set(FX(f)-.2+(f%3)*.2,.78,FZ);root.add(t);TABS.push(t)}
/* gap markers: red outline frames in front of folders 1 and 4 */
const GAP=[1,4],gGeo=new T.PlaneGeometry(.8,.76),GM=GAP.map(f=>{const m=new T.MeshBasicMaterial({color:red.clone(),transparent:!0,opacity:0,depthWrite:!1});const l=new T.Mesh(gGeo,m);l.position.set(FX(f),.36,FZ+.09);root.add(l);return l});
/* documents: 18 sheets, 3 per folder; the last sheet of each gap folder arrives late */
const ND=18,dGeo=new T.BoxGeometry(.44,.012,.58),dMat=new T.MeshStandardMaterial({color:paper.clone(),emissive:mist.clone(),emissiveIntensity:.22,roughness:.7}),docs=new T.InstancedMesh(dGeo,dMat,ND);root.add(docs);
const D=[];for(let i=0;i<ND;i++){const f=i%NF,k=Math.floor(i/NF),late=GAP.includes(f)&&k===2;
D.push({f,k,late,lx:(R()-.5)*5.2,lz:1.5+R()*1.5,ly:.006+(i%4)*.013,lr:(R()-.5)*1.4,d:late?0:(i*.27)%3.6})}
const v=new T.Vector3,sc=new T.Vector3;
camera.fov=40;camera.updateProjectionMatrix();
const look=new T.Vector3(0,.45,.6),lk=new T.Vector3(),wide={k:1};
function frameFn(t,dt,p){
const hold=clamp((p-.56)/.3),c0=t%24,c=hold>0?lerp(c0,19,ease(hold)):c0,back=c>20?ease((c-20)/4):0;
/* camera: one slow dolly per 20 s */
const dl=.5-.5*Math.cos(t/20*Math.PI*2);camera.position.set(-.3+pointer.x*.3,3.1-dl*.35-pointer.y*.12,(7.9-dl*1.1)*wide.k);lk.copy(look);lk.x+=pointer.x*.06;camera.lookAt(lk);
/* light pulse every 10 s */
const pt=(t%10)/1.6;pulse.intensity=pt<1?Math.sin(pt*Math.PI)*.9:0;pulse.position.x=lerp(-7,7,clamp(pt));
/* documents */
D.forEach((d,i)=>{const s0=d.late?10.4+(GAP.indexOf(d.f))*1.3:3+d.d,e=ease(clamp((c-s0)/1.6))*(1-back);
const tx=FX(d.f)+(d.k-1)*.05,ty=.46,tz=FZ+.02;
v.set(lerp(d.lx,tx,e),lerp(d.ly,ty,e)+Math.sin(e*Math.PI)*.55,lerp(d.lz,tz,e));
const s=lerp(1,.0001,clamp((e-.85)/.15));sc.set(s,1,s);o.position.copy(v);o.rotation.set(e*Math.PI/2,d.lr*(1-e),0);o.scale.copy(sc);o.updateMatrix();docs.setMatrixAt(i,o.matrix)});
docs.instanceMatrix.needsUpdate=!0;
/* gap markers: pulse red from 8 s, turn lime when the late sheet lands */
GM.forEach((g,j)=>{const on=clamp((c-8)/.6)*(1-back),fill=clamp((c-(12+j*1.3))/.4);g.material.opacity=on*(fill>0?.5*(1-fill):.3+.2*Math.sin(t*4.2));g.material.color.copy(red).lerp(lime,fill)});
/* folders fill a little lighter as they receive sheets; tabs lock lime in order */
FOL.forEach((b,f)=>{const n=D.filter(d=>d.f===f&&c>(d.late?10.4+GAP.indexOf(f)*1.3:3+d.d)+1.4).length*(1-back);b.material.color.copy(fol).lerp(mist,n*.12)});
TABS.forEach((tb,f)=>{const e=clamp((c-14.4-f*.6)/.5)*(1-back);tb.material.color.copy(steel).lerp(lime,e);tb.material.emissive.copy(lime).multiplyScalar(e*.25);tb.position.y=.78+(1-e)*.06})}
return{frame:frameFn,resize:(w,h)=>{wide.k=w/h<.6?1.45:w/h<1.2?1.08:1},dispose:()=>{[wGeo,fGeo,tGeo,gGeo,dGeo,table.geometry].forEach(g=>g.dispose())}}}
