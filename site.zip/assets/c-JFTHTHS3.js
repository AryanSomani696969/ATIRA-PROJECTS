// kit_cine runtime: plays rendered loops only while visible, honours reduced motion / Save-Data, Pause control, word reveal
export function boot() {
  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const cn = navigator.connection || {};
  const light = !!(cn.saveData || /(^|-)2g$/.test(cn.effectiveType || ''));
  const vids = [].slice.call(document.querySelectorAll('[data-cn-vid]'));
  const seen = new Map();
  let held = false;
  const ok = () => !held && !mq.matches && !light && document.visibilityState === 'visible';
  const play = (v) => { if (!ok()) return; const sh = v.closest('[data-cn-shot]'); if (sh && !sh.classList.contains('is-active')) return; const p = v.play(); if (p && p.then) p.then(() => v.classList.add('is-on')).catch(() => {}); };
  const io = 'IntersectionObserver' in window ? new IntersectionObserver((es) => es.forEach((e) => { const v = e.target; seen.set(v, e.isIntersecting); if (e.isIntersecting) play(v); else v.pause(); }), { rootMargin: '80px' }) : null;
  vids.forEach((v) => { if (io) io.observe(v); else play(v); });
  document.addEventListener('visibilitychange', () => vids.forEach((v) => (seen.get(v) ? play(v) : v.pause())));
  mq.addEventListener && mq.addEventListener('change', () => vids.forEach((v) => (ok() && seen.get(v) ? play(v) : (v.pause(), v.classList.remove('is-on')))));
  document.querySelectorAll('[data-cn-pause]').forEach((b) => b.addEventListener('click', () => {
    held = !held; b.setAttribute('aria-pressed', held ? 'true' : 'false');
    const s = b.querySelector('span'); if (s) s.textContent = held ? 'Play animation' : 'Pause animation';
    vids.forEach((v) => (held ? v.pause() : seen.get(v) && play(v)));
  }));

  // hero stack: shots cross-fade as the chapter rail advances (the rail bar's own animation is the clock)
  const stack = document.querySelector('[data-cn-stack]');
  if (stack) {
    const shots = [].slice.call(stack.querySelectorAll('[data-cn-shot]'));
    const items = [].slice.call(document.querySelectorAll('[data-cn-go]'));
    const root = stack.closest('.cn-hero');
    let cur = 0;
    const show = (i) => {
      cur = (i + shots.length) % shots.length;
      shots.forEach((s, k) => {
        const on = k === cur; s.classList.toggle('is-active', on);
        const v = s.querySelector('video');
        if (!v) return;
        if (on) { v.preload = 'auto'; try { v.currentTime = 0; } catch (e) {} v.classList.remove('is-on'); play(v); } else setTimeout(() => { if (cur !== k) v.pause(); }, 1500);
      });
      items.forEach((it, k) => { const on = k === cur; it.classList.toggle('is-on', on); it.setAttribute('aria-current', on ? 'true' : 'false'); const b = it.querySelector('.cn-rail__bar'); if (b) { b.style.animation = 'none'; void b.offsetWidth; b.style.animation = ''; } });
      const nxt = shots[(cur + 1) % shots.length].querySelector('video'); if (nxt) nxt.preload = 'auto';
    };
    items.forEach((it, k) => {
      it.addEventListener('click', () => show(k));
      const b = it.querySelector('.cn-rail__bar');
      if (b) b.addEventListener('animationend', () => { if (!mq.matches && !held && it.classList.contains('is-on')) show(cur + 1); });
    });
    if (mq.matches) root && root.classList.add('is-still');
    document.querySelectorAll('[data-cn-pause]').forEach((b) => b.addEventListener('click', () => root && root.classList.toggle('is-held', held)));
    // when the first shot is ready the next two start loading
    const first = shots[0] && shots[0].querySelector('video'); if (first) first.addEventListener('playing', () => shots.slice(1).forEach((s) => { const v = s.querySelector('video'); if (v) v.preload = 'auto'; }), { once: true });
  }
  // words that light up as the section scrolls into view (skipped for automated browsers and reduced motion)
  const blocks = [].slice.call(document.querySelectorAll('[data-cn-words]'));
  if (blocks.length && !mq.matches && !navigator.webdriver) {
    blocks.forEach((el) => {
      const walk = (n) => { [].slice.call(n.childNodes).forEach((c) => { if (c.nodeType === 3) { const f = document.createDocumentFragment(); c.textContent.split(/(\s+)/).forEach((t) => { if (!t) return; if (/^\s+$/.test(t)) f.appendChild(document.createTextNode(t)); else { const s = document.createElement('span'); s.className = 'cn-w'; s.textContent = t; f.appendChild(s); } }); n.replaceChild(f, c); } else if (c.nodeType === 1) walk(c); }); };
      walk(el); el.setAttribute('data-cn-on', '');
    });
    let tick = false;
    const upd = () => { tick = false; const vh = innerHeight; blocks.forEach((el) => { const r = el.getBoundingClientRect(); const p = Math.min(1, Math.max(0, (vh * 0.9 - r.top) / (vh * 0.55))); const w = el.querySelectorAll('.cn-w'); const n = w.length; w.forEach((s, i) => s.classList.toggle('is-on', p * (n + 2) > i + 1)); }); };
    addEventListener('scroll', () => { if (!tick) { tick = true; requestAnimationFrame(upd); } }, { passive: true }); addEventListener('resize', upd); upd();
  }
}
