/* Simquill hero: a rehearsal stage on an indigo ground. A persona bust stands in a pool of light and turns slowly toward the
   learner; two speech bubbles orbit it and trade places as they talk; four rubric meters fill in score green on a standing card,
   one stays tangerine; at rest a small skills map for the cohort lights up. 12 second cycle; scrolling holds the resolved state.
   Every figure is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const bg=new T.Color(colors.bg),cloud=new T.Color(color("--sq-cloud","#f6f7fb")),tang=new T.Color(color("--sq-tang","#ff7a2f")),green=new T.Color(color("--sq-green","#2fa66a")),deep=new T.Color(color("--sq-deep","#221f57"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),10,22);
const root=new T.Group;scene.add(root);const geos=[],mats=[];const G=g=>(geos.push(g),g);const M=(c,o={})=>{const m=new T.MeshStandardMaterial(Object.assign({color:c,roughness:.75,metalness:0},o));mats.push(m);return m};const B=(c,o={})=>{const m=new T.MeshBasicMaterial(Object.assign({color:c},o));mats.push(m);return m};
root.add(new T.AmbientLight(0xdcdaf2,.8));
const key=new T.DirectionalLight(0xffe9d6,1.15);key.position.set(-3,6,5);root.add(key);
const rim=new T.DirectionalLight(tang.getHex(),.35);rim.position.set(4,2.5,-4);root.add(rim);
/* stage: floor disc, light pool and an arch drawn as a line */
const floor=new T.Mesh(G(new T.CylinderGeometry(3.2,3.2,.01,small?40:72)),B(bg.clone().lerp(cloud,.07)));floor.scale.set(1,1,.55);floor.position.set(1.4,0,0);root.add(floor);
const pool=new T.Mesh(G(new T.CylinderGeometry(1.6,1.6,.01,small?32:56)),B(bg.clone().lerp(cloud,.13)));pool.scale.set(1,1,.55);pool.position.set(1.45,.008,.05);root.add(pool);
const ap=[];for(let i=0;i<=48;i++){const a=Math.PI*i/48;ap.push(1.4+Math.cos(a)*2.4,2.2+Math.sin(a)*1.2,-1.8)}ap.unshift(3.8,0,-1.8);ap.push(-1,0,-1.8);
const archG=G(new T.BufferGeometry);archG.setAttribute("position",new T.Float32BufferAttribute(ap,3));const lineMat=new T.LineBasicMaterial({color:bg.clone().lerp(cloud,.32)});mats.push(lineMat);root.add(new T.Line(archG,lineMat));
/* persona bust: torso, neck and head; turns and rises over the cycle */
const bust=new T.Group;bust.position.set(1.45,0,0);root.add(bust);const skin=M(bg.clone().lerp(cloud,.82),{roughness:.6,emissive:cloud.clone(),emissiveIntensity:.12});
const torso=new T.Mesh(G(new T.CylinderGeometry(.56,.8,.92,small?20:36,1,!1)),skin);torso.position.y=.46;bust.add(torso);
const shoulder=new T.Mesh(G(new T.SphereGeometry(.42,small?16:28,small?10:18,0,Math.PI*2,0,Math.PI/2)),skin);shoulder.scale.set(1.34,.5,.95);shoulder.position.y=.92;bust.add(shoulder);
const neck=new T.Mesh(G(new T.CylinderGeometry(.13,.15,.3,16)),skin);neck.position.y=1.12;bust.add(neck);
const headG=new T.Group;headG.position.y=1.52;bust.add(headG);const head=new T.Mesh(G(new T.SphereGeometry(.34,small?20:36,small?14:24)),skin);head.scale.set(.9,1.05,.95);headG.add(head);
/* speech bubbles: a rounded slab with a tail; persona bubble cloud, learner bubble tangerine edged */
function bubble(fill,edge){const g=new T.Group;const slab=new T.Mesh(G(new T.BoxGeometry(1.05,.52,.06)),M(fill,{roughness:.5}));g.add(slab);
const tail=new T.Mesh(G(new T.CylinderGeometry(0,.09,.22,3)),slab.material);tail.rotation.z=Math.PI;tail.position.set(-.32,-.34,0);g.add(tail);
const eg=G(new T.BufferGeometry);eg.setAttribute("position",new T.Float32BufferAttribute([-.525,-.26,.032,.525,-.26,.032,.525,-.26,.032,.525,.26,.032,.525,.26,.032,-.525,.26,.032,-.525,.26,.032,-.525,-.26,.032],3));const em=new T.LineBasicMaterial({color:edge});mats.push(em);g.add(new T.LineSegments(eg,em));
const lines=[];for(let i=0;i<3;i++){const l=new T.Mesh(G(new T.BoxGeometry(1,.045,.01)),B(fill===cloud?bg.clone().lerp(cloud,.45):tang.clone()));l.position.set(-.38,.12-i*.12,.035);g.add(l);lines.push(l)}
return{g,lines}}
const pB=bubble(cloud,cloud),lB=bubble(deep,tang);root.add(pB.g,lB.g);
/* rubric meters on a standing card */
const board=new T.Group;board.position.set(3.75,1.85,-1.4);board.rotation.set(0,-.4,0);board.scale.setScalar(.8);root.add(board);
board.add(new T.Mesh(G(new T.BoxGeometry(1.3,1.25,.03)),M(bg.clone().lerp(cloud,.12),{roughness:.5,transparent:!0,opacity:.94})));
const trGeo=G(new T.BoxGeometry(1,.08,.02)),trMat=B(bg.clone().lerp(cloud,.26));
const TV=[.5,1,.5,.75],LOW=[0,2],fills=TV.map((v,i)=>{const y=.36-i*.24,tr=new T.Mesh(trGeo,trMat);tr.position.set(0,y,.025);board.add(tr);
const f=new T.Mesh(trGeo,B(LOW.includes(i)?tang:green));f.position.set(-.5,y,.04);board.add(f);return f});
/* skills map: six nodes and their links, lit green at rest */
const map=new T.Group;map.position.set(-.35,.55,1.1);map.rotation.set(-.5,.3,0);map.scale.setScalar(.75);root.add(map);
const NP=[[0,.3],[.4,.6],[.82,.38],[.52,.02],[1.1,0],[.14,-.2]],NL=[[0,1],[1,2],[1,3],[2,4],[3,4],[0,5],[3,5]],LIT=[1,3];
const lp=[];NL.forEach(([a,b])=>lp.push(NP[a][0],NP[a][1],0,NP[b][0],NP[b][1],0));const mg=G(new T.BufferGeometry);mg.setAttribute("position",new T.Float32BufferAttribute(lp,3));
const ml=new T.LineBasicMaterial({color:bg.clone().lerp(cloud,.4),transparent:!0,opacity:.9});mats.push(ml);map.add(new T.LineSegments(mg,ml));
const nodeGeo=G(new T.SphereGeometry(.06,12,8)),nodes=NP.map(p=>{const m=new T.Mesh(nodeGeo,M(bg.clone().lerp(cloud,.55),{emissive:green.clone(),emissiveIntensity:0}));m.position.set(p[0],p[1],0);map.add(m);return m});
const C0=new T.Vector3(1.9,2.6,7.4),look=new T.Vector3(1.6,1.25,0),lk=new T.Vector3;camera.fov=38;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
function place(b,a,talk){/* bubbles ride an ellipse around the head; a=angle */b.g.position.set(1.45+Math.cos(a)*1.45,1.75+Math.sin(a*2)*.12,.2+Math.sin(a)*.7);b.g.rotation.y=-Math.cos(a)*.25;
b.lines.forEach((l,i)=>{const w=Math.max(.02,(i===2?.55:.8)*clamp(talk*3-i));l.scale.x=w;l.position.x=-.42+w/2})}
function frame(t,dt,p){
const hold=clamp((p-.5)/.3),c0=t%12,c=hold>0?lerp(c0,10.5,ease(hold)):c0,reset=c>11.3?ease((c-11.3)/.7):0;
camera.position.set(C0.x+Math.sin(t/12*Math.PI*2)*.22+pointer.x*.3,C0.y-pointer.y*.16,C0.z);lk.copy(look);lk.x+=pointer.x*.08;camera.lookAt(lk);
/* bust: slow turn toward the learner and a small rise; the head reacts to the learner's line at 4s and 7s */
const turn=ease(clamp(c/6))*(1-reset);bust.rotation.y=-.5+turn*.55;bust.position.y=turn*.08;
const nod=Math.exp(-Math.pow((c-4.3)*2.2,2))*.16+Math.exp(-Math.pow((c-7.2)*2.2,2))*.12;headG.rotation.set(nod,Math.sin(t*.5)*.05,-nod*.4);
/* bubbles trade places: the swap runs from 1s to 8s, so each ends where the other began */
const s=ease(clamp((c-1)/7))*(1-reset),a0=2.5+s*Math.PI,a1=.6+s*Math.PI;
place(pB,a0,clamp(((c%6)/3)));place(lB,a1,clamp((((c+3)%6)/3)));
/* meters fill as the session is scored */
fills.forEach((f,i)=>{const e=ease(clamp((c-4.8-i*.4)/1.3))*(1-reset),w=Math.max(.001,TV[i]*e);f.scale.x=w;f.position.x=-.5+w/2});
board.position.y=1.85+Math.sin(t*.7)*.04;map.position.y=.55+Math.sin(t*.6+1)*.03;
const rest=ease(clamp((c-8.8)/.8))*(1-reset);nodes.forEach((n,i)=>{const on=LIT.includes(i)||i===0&&rest>.6;n.material.emissiveIntensity=on?rest*.85:0;n.material.color.copy(bg).lerp(on&&rest>.4?green:cloud,on?lerp(.55,1,rest):.55)})}
return{frame,resize:(w,h)=>{C0.z=w/h<.8?10.4:7.4;look.x=w/h<.8?1.5:1.6},dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose())}}}
