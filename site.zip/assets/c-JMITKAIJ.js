import{B as Torus,G as PLight}from"./c-5CYXJTUX.js";
/* Appealquill hero chamber: a quiet archive hall of translucent claim folders on rails.
   One letter rests in front with a denial stamp; scrolling turns the stamp into an approval seal.
   A single pulse of light runs down the centre rail every 10 seconds. Camera dollies over 20 seconds. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(23);
const bg=new T.Color(colors.bg),ink=new T.Color(colors.ink),amber=new T.Color(color("--mv-signal","#e09f3e")),green=new T.Color(color("--mv-deep","#2e9e6b"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),6,19);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0x9fb0d0,.75));
const key=new T.DirectionalLight(0xfff0dc,1.05);key.position.set(-3,6,4);root.add(key);
const rim=new T.DirectionalLight(amber.getHex(),.35);rim.position.set(5,2,-6);root.add(rim);
const floor=new T.Mesh(new T.PlaneGeometry(40,40),new T.MeshBasicMaterial({color:bg.clone().lerp(ink,.025)}));floor.rotation.x=-Math.PI/2;floor.position.y=-1.2;root.add(floor);
/* rails: three rows receding into the hall */
const rows=[-2.3,0,2.3],LEN=14,railGeo=new T.BoxGeometry(.04,.04,LEN),railMat=new T.MeshStandardMaterial({color:ink.clone().lerp(bg,.55),metalness:.6,roughness:.4});
rows.forEach(x=>{[-.55,.55].forEach(dx=>{const r=new T.Mesh(railGeo,railMat);r.position.set(x+dx,-.05,-LEN/2+1.5);root.add(r)})});
/* folders: instanced translucent boards standing on the rails */
const per=small?11:16,N=rows.length*per,fGeo=new T.BoxGeometry(.035,1,1.25),fMat=new T.MeshStandardMaterial({color:0xffffff,transparent:!0,opacity:.2,roughness:.6,metalness:0,depthWrite:!1}),
inst=new T.InstancedMesh(fGeo,fMat,N),o=new T.Object3D,F=[];
let k=0;rows.forEach((x,ri)=>{for(let i=0;i<per;i++){const z=1-i*.82-R()*.12,tilt=(R()-.5)*.12,h=.85+R()*.25;F.push({x,z,tilt,h,ri});o.position.set(x+(R()-.5)*.04,.45*h,z);o.rotation.set(0,Math.PI/2+tilt,0);o.scale.set(1,h,1);o.updateMatrix();inst.setMatrixAt(k,o.matrix);inst.setColorAt(k,ink);k++}});
root.add(inst);
/* folder edges and tabs as light line work */
const seg=[];F.forEach(f=>{const w=.62,hh=f.h,c=Math.cos(f.tilt),s=Math.sin(f.tilt),P=(a,y)=>[f.x+a*s,y,f.z+a*c];const p=[P(-w,0),P(w,0),P(w,hh),P(-w*.2,hh),P(-w*.35,hh+.09),P(-w,hh+.09)];for(let i=0;i<p.length;i++){seg.push(...p[i],...p[(i+1)%p.length])}});
const eg=new T.BufferGeometry;eg.setAttribute("position",new T.Float32BufferAttribute(seg,3));const edges=new T.LineSegments(eg,new T.LineBasicMaterial({color:ink.clone().lerp(bg,.35),transparent:!0,opacity:.55}));root.add(edges);
/* the letter in front: paper sheet with text lines, a stamp ring and a seal disc */
const letter=new T.Group;letter.position.set(1.45,.18,1.05);letter.rotation.set(-1.08,0,-.2);letter.scale.setScalar(.72);root.add(letter);
const sheet=new T.Mesh(new T.PlaneGeometry(1.5,1.95),new T.MeshStandardMaterial({color:ink,emissive:ink,emissiveIntensity:.28,roughness:.85,side:T.DoubleSide}));letter.add(sheet);
const lines=[];for(let i=0;i<11;i++){const y=.72-i*.12,w=i===0?.55:i%4===3?.7:1.15-((i*5)%4)*.08;lines.push(-.6,y,.002,-.6+w,y,.002)}
const lg=new T.BufferGeometry;lg.setAttribute("position",new T.Float32BufferAttribute(lines,3));letter.add(new T.LineSegments(lg,new T.LineBasicMaterial({color:bg.clone().lerp(ink,.45)})));
const ringMat=new T.MeshStandardMaterial({color:amber.clone(),emissive:amber.clone(),emissiveIntensity:.35,roughness:.5,metalness:.2});
const ring=new T.Mesh(new Torus(.27,.028,10,small?40:64),ringMat);ring.position.set(.3,-.5,.02);letter.add(ring);
const discMat=new T.MeshBasicMaterial({color:green.clone(),transparent:!0,opacity:0});const disc=new T.Mesh(new T.CylinderGeometry(.2,.2,.01,40),discMat);disc.rotation.x=Math.PI/2;disc.position.copy(ring.position);disc.position.z=.015;letter.add(disc);
const barMat=new T.MeshBasicMaterial({color:amber.clone(),transparent:!0,opacity:.9});const bar=new T.Mesh(new T.BoxGeometry(.4,.05,.01),barMat);bar.position.copy(ring.position);bar.position.z=.03;bar.rotation.z=-.5;letter.add(bar);
/* pulse along the centre rail */
const pl=new PLight(0xfff1d6,0,3.2,2);root.add(pl);
const dot=new T.Mesh(new T.SphereGeometry(.04,12,10),new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:0}));root.add(dot);
/* dust */
const DN=small?50:110,dp=new Float32Array(DN*3);for(let i=0;i<DN;i++){dp[i*3]=lerp(-4,4,R());dp[i*3+1]=lerp(-.8,2.6,R());dp[i*3+2]=lerp(-11,3,R())}
const dg=new T.BufferGeometry;dg.setAttribute("position",new T.BufferAttribute(dp,3));root.add(new T.Points(dg,new T.PointsMaterial({color:ink.clone().lerp(amber,.2),size:.02,transparent:!0,opacity:.35,depthWrite:!1})));
const C0=new T.Vector3(2.6,1.9,6.2),look=new T.Vector3(.2,.1,-1.6),lk=new T.Vector3;camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const tmpC=new T.Color;
function frame(t,dt,p){
const d=ease(.5-.5*Math.cos(t/20*Math.PI*2));
camera.position.set(C0.x-.35*d+pointer.x*.25,C0.y-.12*d-pointer.y*.15,C0.z-.8*d);lk.copy(look);lk.x+=pointer.x*.1;camera.lookAt(lk);
/* pulse: 10 second cycle, travels 3.4 s from the back of the hall to the letter */
const c=t%10,u=clamp(c/3.4),vis=c<3.8?Math.min(1,c*3,(3.8-c)*2.5):0,z=lerp(-LEN+2,2,ease(u));
pl.position.set(0,.9,z);pl.intensity=vis*2.4;dot.position.set(0,.06,z);dot.material.opacity=vis*.9;
for(let i=0;i<N;i++){const f=F[i],near=f.ri===1?Math.max(0,1-Math.abs(f.z-z)/1.2)*vis:0;tmpC.copy(ink).lerp(amber,near*.7);inst.setColorAt(i,tmpC)}inst.instanceColor.needsUpdate=!0;
/* stamp to seal with scroll (hero progress runs about .5 at rest to 1 when scrolled past) */
const s=clamp((p-.56)/.28),e=ease(s);
ringMat.color.copy(amber).lerp(green,e);ringMat.emissive.copy(amber).lerp(green,e);ringMat.emissiveIntensity=.3+(c>3.2&&c<4.6?Math.sin((c-3.2)/1.4*Math.PI)*.35:0);
discMat.opacity=e*.5;barMat.opacity=(1-e)*.9;bar.scale.x=1-e*.6;
letter.position.y=.18+Math.sin(t*.35)*.015;
const a=dg.attributes.position.array;for(let i=0;i<DN;i++)a[i*3+1]+=Math.sin(t*.2+i)*3e-4;dg.attributes.position.needsUpdate=!0}
return{frame,resize:(w,h)=>{C0.z=6.2+(w/h<.8?2:0)},dispose:()=>{[railGeo,fGeo,eg,lg,dg,floor.geometry,sheet.geometry,ring.geometry,disc.geometry,bar.geometry,dot.geometry].forEach(g=>g.dispose())}}}
