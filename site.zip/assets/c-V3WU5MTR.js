/* Cohortsherpa page tools. Everything runs in the browser on synthetic records; nothing typed here leaves the page.
   [data-cs=sim]     Eligibility Simulator: sample protocol + adjustable criteria -> funnel, top excluders, ranked candidates with reasons
   [data-cs=mini]    the same engine on one protocol and one criterion (home page)
   [data-cs=feas]    feasibility estimator: likely-eligible per month and funnel rates -> months to the enrollment target
   [data-cs=sample]  sample parsed protocol: pick a synthetic patient, see each criterion met, not met or unknown */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const fmt=n=>n.toLocaleString("en-US");
/* ---------- synthetic records: 640 de-identified patients across three sites, fixed seed */
function rng(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const DXN={nsclc4:"NSCLC, stage IV",nsclc3b:"NSCLC, stage IIIB",sclc:"Small cell lung cancer",hf:"Heart failure, reduced EF",t2d:"Type 2 diabetes",copd:"COPD",ckd:"Chronic kidney disease"};
const DEPT={nsclc4:"Oncology",nsclc3b:"Oncology",sclc:"Oncology",hf:"Cardiology",t2d:"Endocrinology",copd:"Pulmonology",ckd:"Nephrology"};
function records(){const r=rng(7),P=[],W=[["nsclc4",.15],["nsclc3b",.06],["sclc",.04],["hf",.21],["t2d",.3],["copd",.12],["ckd",.12]];
const pick=()=>{let u=r(),a=0;for(const[k,w]of W){a+=w;if(u<a)return k}return"t2d"},nul=(p,v)=>r()<p?null:v,rd=(v,d=0)=>Math.round(v*10**d)/10**d;
for(let i=0;i<640;i++){const dx=pick(),onc=dx[0]==="n"||dx==="sclc",hf=dx==="hf",dm=dx==="t2d";
const age=Math.min(89,Math.round((dm?30:onc?42:38)+r()*46));
P.push({id:"CS-"+String(1000+i*7%9000).padStart(4,"0"),site:["Site A","Site B","Site C"][Math.floor(r()*3)],dept:DEPT[dx],dx,age,
egfr:nul(.08,Math.round(dx==="ckd"?14+r()*42:34+r()*72)),
ecog:onc?nul(.06,[0,0,0,1,1,1,1,2,2,3][Math.floor(r()*10)]):null,
pd1:onc?nul(.1,r()<.27):null,brain:onc?nul(.32,r()<.16):null,
lvef:hf?nul(.05,Math.round(18+r()*34)):r()<.3?Math.round(50+r()*15):null,
bnp:hf?nul(.14,Math.round(180+r()*2600)):null,sbp:Math.round(92+r()*58),hosp:hf?nul(.22,r()<.24):null,
a1c:dm?nul(.07,rd(6.3+r()*5.1,1)):r()<.4?rd(5+r()*1.4,1):null,bmi:nul(.05,rd(20+r()*21,1)),
metf:dm?(r()<.74?Math.round(1+r()*60):0):0,ins:dm?r()<.21:false,last:Math.round(2+r()*360)})}
return P}
const PTS=records();
/* ---------- sample protocols (synthetic) */
const UNIT={age:" years",egfr:" mL/min/1.73m2",ecog:"",lvef:"%",bnp:" pg/mL",sbp:" mmHg",a1c:"%",bmi:" kg/m2",metf:" months"};
const NEXT={egfr:"Recent creatinine to calculate eGFR",ecog:"Performance status from the last clinic note",pd1:"Prior treatment lines in the oncology record",brain:"Brain MRI within the last 28 days",
lvef:"Echocardiogram in the last 12 months",bnp:"NT-proBNP in the last 90 days",hosp:"Admissions at other hospitals in the last 30 days",a1c:"HbA1c in the last 3 months",bmi:"Height and weight at the last visit"};
const PROT={
onc:{code:"ONC-LUNG-02",name:"Second-line NSCLC immunotherapy",area:"Oncology",crit:[
{id:"dx",t:"in",f:"dx",set:["nsclc4","nsclc3b"],l:"Diagnosis: NSCLC, stage IIIB or IV",logic:"dx IN (C34.*) AND stage IN (IIIB, IV)",fix:1},
{id:"age",t:"range",f:"age",lo:18,hi:75,min:18,max:90,step:1,l:"Age",logic:"age BETWEEN {lo} AND {hi}"},
{id:"ecog",t:"max",f:"ecog",v:1,min:0,max:3,step:1,l:"ECOG performance status at most",logic:"ecog <= {v}"},
{id:"egfr",t:"min",f:"egfr",v:45,min:15,max:90,step:5,l:"eGFR at least",logic:"egfr >= {v}  (LOINC 98979-8)"},
{id:"pd1",t:"not",f:"pd1",l:"No prior PD-1 or PD-L1 therapy",logic:"NOT prior_therapy IN (pd1, pdl1)"},
{id:"brain",t:"not",f:"brain",l:"No active brain metastases",logic:"NOT brain_mets_active"}]},
hf:{code:"CARD-HF-07",name:"Heart failure with reduced ejection fraction",area:"Cardiology",crit:[
{id:"dx",t:"in",f:"dx",set:["hf"],l:"Diagnosis: heart failure",logic:"dx IN (I50.2*)",fix:1},
{id:"age",t:"range",f:"age",lo:40,hi:85,min:18,max:90,step:1,l:"Age",logic:"age BETWEEN {lo} AND {hi}"},
{id:"lvef",t:"max",f:"lvef",v:40,min:20,max:50,step:5,l:"LVEF at most",logic:"lvef <= {v}"},
{id:"bnp",t:"min",f:"bnp",v:600,min:200,max:2000,step:100,l:"NT-proBNP at least",logic:"nt_probnp >= {v}  (LOINC 33762-6)"},
{id:"sbp",t:"min",f:"sbp",v:100,min:85,max:120,step:5,l:"Systolic blood pressure at least",logic:"sbp >= {v}"},
{id:"hosp",t:"not",f:"hosp",l:"No heart failure admission in the last 30 days",logic:"NOT admit_hf_30d"}]},
dm:{code:"ENDO-T2D-11",name:"Type 2 diabetes on metformin, add-on therapy",area:"Endocrinology",crit:[
{id:"dx",t:"in",f:"dx",set:["t2d"],l:"Diagnosis: type 2 diabetes",logic:"dx IN (E11.*)",fix:1},
{id:"age",t:"range",f:"age",lo:30,hi:70,min:18,max:90,step:1,l:"Age",logic:"age BETWEEN {lo} AND {hi}"},
{id:"a1c",t:"range",f:"a1c",lo:7.5,hi:10.5,min:6,max:12,step:.1,l:"HbA1c",logic:"hba1c BETWEEN {lo} AND {hi}  (LOINC 4548-4)"},
{id:"bmi",t:"min",f:"bmi",v:27,min:20,max:40,step:1,l:"BMI at least",logic:"bmi >= {v}"},
{id:"metf",t:"min",f:"metf",v:3,min:1,max:12,step:1,l:"Metformin for at least (months)",logic:"metformin_months >= {v}"},
{id:"ins",t:"not",f:"ins",l:"Not on insulin",logic:"NOT on_insulin"},
{id:"egfr",t:"min",f:"egfr",v:60,min:30,max:90,step:5,l:"eGFR at least",logic:"egfr >= {v}  (LOINC 98979-8)"}]}};
function evalC(c,p){const v=p[c.f];if(c.t==="in")return c.set.includes(v)?"m":"x";if(v===null||v===undefined)return"u";
if(c.t==="range")return v>=c.lo&&v<=c.hi?"m":"x";if(c.t==="min")return v>=c.v?"m":"x";if(c.t==="max")return v<=c.v?"m":"x";if(c.t==="not")return v?"x":"m";return"u"}
function evidence(c,p){const v=p[c.f];if(c.t==="in")return DXN[p.dx];if(v===null||v===undefined)return"Not in the extract";if(c.t==="not")return v?"Recorded":"None recorded";return v+(UNIT[c.f]||"")}
function logic(c){return c.logic.replace("{lo}",c.lo).replace("{hi}",c.hi).replace("{v}",c.v)}
function run(prot,off){const act=prot.crit.filter(c=>!off.has(c.id)),dx=act[0];
const scope=PTS.filter(p=>evalC(dx,p)==="m"),rest=act.slice(1);
const ex={};rest.forEach(c=>ex[c.id]=0);const funnel=[["Records searched",PTS.length],[dx.l.replace("Diagnosis: ",""),scope.length]];
let alive=scope;rest.forEach(c=>{alive=alive.filter(p=>evalC(c,p)!=="x");funnel.push([c.l,alive.length])});
const rows=scope.map(p=>{const st=rest.map(c=>evalC(c,p));st.forEach((s,i)=>{if(s==="x")ex[rest[i].id]++});const x=st.filter(s=>s==="x").length,u=st.filter(s=>s==="u").length,m=st.length-x-u;
return{p,st,x,u,m,score:rest.length?m/rest.length:1}});
const live=rows.filter(r=>!r.x).sort((a,b)=>a.u-b.u||b.score-a.score||a.p.last-b.p.last);
return{rest,scope,funnel,ex,eligible:live.filter(r=>!r.u),check:live.filter(r=>r.u),ranked:live}}
const ST={m:["Met","is-m"],x:["Not met","is-x"],u:["Unknown","is-u"]};
function badge(s){return'<span class="cs-st '+ST[s][1]+'"><i aria-hidden="true"></i>'+ST[s][0]+"</span>"}
/* ---------- simulator */
function sim(root){let runs=0,key="onc",off=new Set,sel=0,P=JSON.parse(JSON.stringify(PROT));
const crit=$("[data-sim-crit]",root),out=$("[data-sim-out]",root),tabs=$$("[data-prot]",root),live=$("[data-sim-live]",root);
function controls(){const pr=P[key];crit.innerHTML=pr.crit.map(c=>{const on=!off.has(c.id),dis=c.fix?" disabled":"";let inp="";
if(c.t==="range")inp='<span class="cs-rg"><label><span class="cs-vh">'+esc(c.l)+' minimum</span><input class="cs-num" type="number" inputmode="decimal" data-k="lo" value="'+c.lo+'" min="'+c.min+'" max="'+c.max+'" step="'+c.step+'"></label><span aria-hidden="true">to</span><label><span class="cs-vh">'+esc(c.l)+' maximum</span><input class="cs-num" type="number" inputmode="decimal" data-k="hi" value="'+c.hi+'" min="'+c.min+'" max="'+c.max+'" step="'+c.step+'"></label></span>';
else if(c.t==="min"||c.t==="max")inp='<label class="cs-sl"><span class="cs-vh">'+esc(c.l)+'</span><input type="range" data-k="v" value="'+c.v+'" min="'+c.min+'" max="'+c.max+'" step="'+c.step+'"><output>'+c.v+(UNIT[c.f]||"")+"</output></label>";
return'<li class="cs-cr'+(on?"":" is-off")+'" data-id="'+c.id+'"><div class="cs-cr__h"><label class="cs-sw"><input type="checkbox" data-on'+(on?" checked":"")+dis+'><span>'+esc(c.l)+"</span></label>"+(c.fix?'<span class="cs-fixed">Required</span>':"")+"</div>"+inp+'<code class="cs-logic">'+esc(logic(c))+"</code></li>"}).join("")}
function render(anim){const pr=P[key],bad=pr.crit.find(c=>c.t==="range"&&!(c.lo<=c.hi&&c.lo>=c.min&&c.hi<=c.max)),badN=pr.crit.find(c=>c.t==="range"&&(isNaN(c.lo)||isNaN(c.hi)));
if(bad||badN){const c=bad||badN;out.innerHTML='<div class="cs-err" role="alert"><b>Check the '+esc(c.l.toLowerCase())+' range.</b> The minimum must be a number from '+c.min+" to "+c.max+" and not above the maximum.</div>";live.textContent="Range error in "+c.l;return}
const R=run(pr,off),top=Object.entries(R.ex).sort((a,b)=>b[1]-a[1]),cby=id=>pr.crit.find(c=>c.id===id),mx=Math.max(1,...top.map(t=>t[1])),f0=R.funnel[1][1]||1;
const fun=R.funnel.map(([l,n],i)=>'<li style="--w:'+Math.max(3,Math.round(100*n/(i?f0:PTS.length)))+'%"><span>'+esc(l)+"</span><b>"+fmt(n)+"</b></li>").join("");
const exc=top.map(([id,n])=>'<li><span>'+esc(cby(id).l)+'</span><i style="--w:'+Math.round(100*n/mx)+'%" aria-hidden="true"></i><b>'+fmt(n)+"</b></li>").join("")||'<li class="cs-mute">No optional criteria are active.</li>';
let list="",det="";
if(!R.ranked.length){const t=top[0]?cby(top[0][0]).l:"";list='<div class="cs-empty"><b>No synthetic patient passes every active criterion.</b><p>'+(t?"The criterion that excludes the most is <em>"+esc(t)+"</em>. Loosen it or switch it off to see who comes back.":"Switch a criterion back on or reset the protocol.")+"</p></div>"}
else{sel=Math.min(sel,R.ranked.length-1);const L=R.ranked.slice(0,8);list='<ol class="cs-cands" role="listbox" aria-label="Ranked candidates, synthetic" tabindex="0" aria-activedescendant="cand-'+sel+'">'+L.map((r,i)=>'<li role="option" id="cand-'+i+'" aria-selected="'+(i===sel)+'" data-i="'+i+'"><span class="cs-cands__n">'+(i+1)+'</span><span class="cs-cands__id">'+r.p.id+"<small>"+r.p.site+" · "+r.p.dept+'</small></span><span class="cs-cands__s">'+r.st.map(s=>'<i class="cs-pip '+ST[s][1]+'" title="'+ST[s][0]+'"></i>').join("")+'</span><span class="cs-cands__k">'+(r.u?r.u+" to check":"All met")+"</span></li>").join("")+"</ol>";
const r=L[sel],gaps=R.rest.filter((c,i)=>r.st[i]==="u");det='<div class="cs-det" aria-live="polite"><p class="mv-mi">Why '+r.p.id+" matches · Synthetic</p><table class=\"cs-tbl\"><thead><tr><th scope=\"col\">Criterion</th><th scope=\"col\">Record</th><th scope=\"col\">State</th></tr></thead><tbody>"+
[[pr.crit[0],"m"]].concat(R.rest.map((c,i)=>[c,r.st[i]])).map(([c,s])=>"<tr><td>"+esc(c.l)+(c.t==="range"?" "+c.lo+" to "+c.hi:c.v!==undefined?" "+c.v:"")+"</td><td>"+esc(evidence(c,r.p))+"</td><td>"+badge(s)+"</td></tr>").join("")+"</tbody></table>"+
(gaps.length?'<p class="cs-gap"><b>Check next:</b> '+gaps.map(c=>esc(NEXT[c.f]||c.l)).join("; ")+".</p>":'<p class="cs-gap cs-gap--ok"><b>No gaps.</b> Every active criterion has a value in the extract. A coordinator still confirms before any contact.</p>')+"</div>"}
if(anim)runs++;out.innerHTML='<div class="cs-res'+(anim?" is-anim":"")+'" data-run="'+runs+'"><p class="cs-run">Run '+runs+' · '+esc(pr.code)+' · synthetic records</p><div class="cs-kpis"><div><span>Likely eligible</span><b>'+fmt(R.eligible.length)+'</b></div><div><span>Need a check</span><b>'+fmt(R.check.length)+'</b></div><div><span>In diagnosis scope</span><b>'+fmt(R.scope.length)+'</b></div></div>'+
'<div class="cs-res__g"><div><p class="mv-mi">Cohort funnel</p><ol class="cs-fun">'+fun+'</ol><p class="mv-mi">Excluded by each criterion</p><ul class="cs-exc">'+exc+"</ul></div><div><p class=\"mv-mi\">Ranked candidates</p>"+list+det+"</div></div></div>";
live.textContent=R.eligible.length+" likely eligible and "+R.check.length+" needing a check for "+pr.code;
const lb=$(".cs-cands",out);if(lb){$$("li",lb).forEach(li=>li.addEventListener("click",()=>{sel=+li.dataset.i;render();$(".cs-cands",out).focus()}));
lb.addEventListener("keydown",e=>{const n=$$("li",lb).length;if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();sel=(sel+(e.key==="ArrowDown"?1:n-1))%n;render();$(".cs-cands",out).focus()}else if(e.key==="Home"){e.preventDefault();sel=0;render();$(".cs-cands",out).focus()}})}}
crit.addEventListener("change",e=>{const li=e.target.closest("[data-id]");if(!li)return;const c=P[key].crit.find(x=>x.id===li.dataset.id);
if(e.target.matches("[data-on]")){e.target.checked?off.delete(c.id):off.add(c.id);li.classList.toggle("is-off",!e.target.checked)}else{c[e.target.dataset.k]=parseFloat(e.target.value)}render()});
crit.addEventListener("input",e=>{if(e.target.type!=="range")return;const li=e.target.closest("[data-id]"),c=P[key].crit.find(x=>x.id===li.dataset.id);c.v=parseFloat(e.target.value);e.target.nextElementSibling.textContent=c.v+(UNIT[c.f]||"");$(".cs-logic",li).textContent=logic(c);render()});
function pick(k,focus){key=k;off=new Set;sel=0;tabs.forEach(t=>{const on=t.dataset.prot===k;t.setAttribute("aria-pressed",on);if(on&&focus)t.focus()});$("[data-sim-name]",root).textContent=P[k].code+" · "+P[k].name;controls();render(1)}
tabs.forEach((t,i)=>{t.addEventListener("click",()=>pick(t.dataset.prot));t.addEventListener("keydown",e=>{if(e.key==="ArrowRight"||e.key==="ArrowLeft"){e.preventDefault();const n=tabs[(i+(e.key==="ArrowRight"?1:tabs.length-1))%tabs.length];pick(n.dataset.prot,1)}})});
$("[data-sim-reset]",root).addEventListener("click",()=>{P[key]=JSON.parse(JSON.stringify(PROT[key]));pick(key)});
$("[data-sim-replay]",root).addEventListener("click",()=>render(1));
pick("onc")}
/* ---------- home mini: one protocol, one slider */
function mini(root){const pr=JSON.parse(JSON.stringify(PROT.onc)),c=pr.crit.find(x=>x.id==="egfr"),s=$("input",root),o=$("output",root),out=$("[data-mini-out]",root);
function go(){c.v=+s.value;o.textContent=c.v+UNIT.egfr;const R=run(pr,new Set),top=Object.entries(R.ex).sort((a,b)=>b[1]-a[1])[0],tl=pr.crit.find(x=>x.id===top[0]).l;
out.innerHTML='<div class="cs-kpis cs-kpis--s"><div><span>Likely eligible</span><b>'+R.eligible.length+'</b></div><div><span>Need a check</span><b>'+R.check.length+'</b></div><div><span>Excluded by eGFR</span><b>'+R.ex.egfr+'</b></div></div><p class="cs-mute">Biggest excluder right now: '+esc(tl)+" ("+top[1]+" of "+R.scope.length+").</p>"}
s.addEventListener("input",go);go()}
/* ---------- feasibility estimator */
function feas(root){const ins=$$("input",root),out=$("[data-feas-out]",root);
function go(){const v={};let bad=null;ins.forEach(i=>{const n=parseFloat(i.value);v[i.name]=n;const lo=+i.min,hi=+i.max;if(i.value===""||isNaN(n)||n<lo||n>hi){bad=bad||i;i.setAttribute("aria-invalid","true")}else i.removeAttribute("aria-invalid")});
if(bad){out.innerHTML='<div class="cs-err" role="alert"><b>'+esc($('label[for="'+bad.id+'"]',root).textContent)+"</b> needs a number from "+bad.min+" to "+bad.max+".</div>";return}
const m=v.leads*(v.accept/100)*(v.consent/100)*(1-v.fail/100),months=m>0?v.target/m:Infinity,rows=[["Likely eligible found",v.leads],["Approached by the treating physician",v.leads*v.accept/100],["Consented",v.leads*v.accept/100*v.consent/100],["Enrolled after screening",m]];
out.innerHTML='<ol class="cs-fun cs-fun--s">'+rows.map(([l,n])=>'<li style="--w:'+Math.max(3,Math.round(100*n/(v.leads||1)))+'%"><span>'+l+" per month</span><b>"+(Math.round(n*10)/10)+"</b></li>").join("")+"</ol>"+
(isFinite(months)?'<p class="cs-feas__r"><b>'+(months<1?"Under 1":Math.ceil(months))+'</b> months to enroll '+v.target+" at this site</p>":'<p class="cs-feas__r"><b>No enrollment</b> at these rates. Raise one of the rates above zero.</p>')+'<p class="cs-mute">An estimate from the numbers above, not a promise of enrollment.</p>'}
root.addEventListener("input",go);go()}
/* ---------- sample protocol explorer */
function sample(root){const t=$$("[role=tab]",root);function pick(i,f){t.forEach((b,j)=>{const on=j===i;b.setAttribute("aria-selected",on);b.tabIndex=on?0:-1;$("#"+b.getAttribute("aria-controls")).hidden=!on;if(on&&f)b.focus()})}
t.forEach((b,i)=>{b.addEventListener("click",()=>pick(i));b.addEventListener("keydown",e=>{if(e.key==="ArrowRight"||e.key==="ArrowLeft"){e.preventDefault();pick((i+(e.key==="ArrowRight"?1:t.length-1))%t.length,1)}})})}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-cs=sim]").forEach(sim);$$("[data-cs=mini]").forEach(mini);$$("[data-cs=feas]").forEach(feas);$$("[data-cs=sample]").forEach(sample)}
