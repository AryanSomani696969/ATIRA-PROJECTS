/* Synthlattice page tools. Everything runs in this browser; nothing is sent anywhere.
   data-sl=explorer   Privacy-Utility Explorer. A synthetic customer table (240 records, seeded) is split into a training
                      part (160) and a holdout part (80). At the chosen privacy level a generator copies training rows with
                      noise and resampling, then the page measures utility (distribution similarity, correlation
                      similarity, a churn model trained on the copy and tested on the holdout) and runs three privacy
                      tests (nearest-neighbour distance, membership inference, attribute inference) against thresholds.
                      data-compact: the smaller home version (no thresholds, no chart).
   data-sl=tabs       tab lists (arrow keys, Home, End). */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
function rng(seed){let a=seed>>>0;return()=>{a=a+0x6D2B79F5>>>0;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}}
function gauss(r){let u=0,v=0;while(!u)u=r();while(!v)v=r();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)}
const REG=["Northeast","South","Midwest","West"],NUM=["age","tenure","balance","products","spend"],COLS=NUM.concat(["region","churned"]);
/* the source table: synthetic, written for this page */
function source(){const r=rng(20250404),rows=[];for(let i=0;i<240;i++){const age=Math.round(Math.min(80,Math.max(22,44+gauss(r)*12))),
 ten=Math.round(Math.min(120,Math.max(1,(age-20)*.9+gauss(r)*18))),reg=REG[Math.floor(r()*4*(r()<.3?.5:1))],
 bal=Math.round(Math.min(250000,Math.max(0,Math.exp(8.3+age*.018+ten*.006+gauss(r)*.55)))),prod=Math.max(1,Math.min(4,Math.round(1+ten/45+gauss(r)*.6))),
 spend=Math.round(Math.max(40,600+bal*.006+gauss(r)*260)),z=1.1-ten*.025-prod*.55+(reg==="South"?.3:0)+gauss(r)*1.1,ch=z>-.9?1:0;
 rows.push({id:"c-"+String(1001+i),age,tenure:ten,balance:bal,products:prod,spend,region:reg,churned:ch})}return rows}
const SRC=source(),TRAIN=SRC.slice(0,160),HOLD=SRC.slice(160);
const stat=c=>{const v=TRAIN.map(x=>x[c]),m=v.reduce((a,b)=>a+b,0)/v.length,sd=Math.sqrt(v.reduce((a,b)=>a+(b-m)**2,0)/v.length)||1;return{m,sd,min:Math.min(...v),max:Math.max(...v)}};
const ST={};NUM.concat(["churned"]).forEach(c=>ST[c]=stat(c));
const regF=REG.map(g=>TRAIN.filter(x=>x.region===g).length/TRAIN.length);
function generate(q,seed){const r=rng(seed||7),out=[],s=.03+q*1.3+q*q*q*1.8,cat=.04+q*.55+q*q*q*.4,flip=.02+q*.22;
 for(let i=0;i<160;i++){const j=TRAIN[i],o={id:"s-"+String(5001+i)};
  NUM.forEach(c=>{const S=ST[c];let v=j[c]+gauss(r)*S.sd*s;v=Math.min(S.max,Math.max(S.min,v));o[c]=c==="balance"?Math.round(v/10)*10:Math.round(v)});
  if(r()<cat){let u=r(),k=0;while(k<3&&u>regF[k]){u-=regF[k];k++}o.region=REG[k]}else o.region=j.region;
  o.churned=r()<flip?1-j.churned:j.churned;out.push(o)}return out}
function dist(a,b,cols){let d=0;(cols||NUM).forEach(c=>{const x=(a[c]-b[c])/ST[c].sd;d+=x*x});if(!cols||cols.includes("region"))d+=a.region===b.region?0:1;return Math.sqrt(d)}
function nn(x,set,cols){let best=1e9,k=-1;for(let i=0;i<set.length;i++){const d=dist(x,set[i],cols);if(d<best){best=d;k=i}}return[best,k]}
function hist(rows,c){if(c==="region")return REG.map(g=>rows.filter(x=>x.region===g).length/rows.length);if(c==="churned"){const p=rows.filter(x=>x.churned).length/rows.length;return[p,1-p]}
 const S=ST[c],h=new Array(10).fill(0);rows.forEach(x=>{h[Math.min(9,Math.max(0,Math.floor((x[c]-S.min)/(S.max-S.min+1e-9)*10)))]++});return h.map(v=>v/rows.length)}
function corr(rows){const C=NUM.concat(["churned"]),m={};C.forEach(c=>{const v=rows.map(x=>x[c]),mu=v.reduce((a,b)=>a+b,0)/v.length;m[c]={v,mu,sd:Math.sqrt(v.reduce((a,b)=>a+(b-mu)**2,0)/v.length)||1}});
 const out=[];for(let i=0;i<C.length;i++)for(let j=i+1;j<C.length;j++){const a=m[C[i]],b=m[C[j]];let s=0;for(let k=0;k<a.v.length;k++)s+=(a.v[k]-a.mu)*(b.v[k]-b.mu);out.push(s/a.v.length/a.sd/b.sd)}return out}
const FEAT=x=>[1,(x.age-ST.age.m)/ST.age.sd,(x.tenure-ST.tenure.m)/ST.tenure.sd,(x.balance-ST.balance.m)/ST.balance.sd,(x.products-ST.products.m)/ST.products.sd,(x.spend-ST.spend.m)/ST.spend.sd,x.region==="South"?1:0];
function fit(rows){let w=new Array(7).fill(0);const X=rows.map(FEAT),y=rows.map(x=>x.churned);for(let it=0;it<220;it++){const g=new Array(7).fill(0);
 for(let i=0;i<X.length;i++){const p=1/(1+Math.exp(-X[i].reduce((a,v,k)=>a+v*w[k],0)));for(let k=0;k<7;k++)g[k]+=(p-y[i])*X[i][k]}w=w.map((v,k)=>v-.6*g[k]/X.length)}return w}
function auc(pos,neg){let s=0;pos.forEach(a=>neg.forEach(b=>{s+=a>b?1:a===b?.5:0}));return pos.length&&neg.length?s/pos.length/neg.length:.5}
function modelAuc(w){const sc=HOLD.map(x=>FEAT(x).reduce((a,v,k)=>a+v*w[k],0));return auc(sc.filter((_,i)=>HOLD[i].churned),sc.filter((_,i)=>!HOLD[i].churned))}
const BASE_AUC=modelAuc(fit(TRAIN));
const band=v=>v<12000?0:v<30000?1:2;
const HD=(()=>{const d=HOLD.map(h=>nn(h,TRAIN)[0]).sort((a,b)=>a-b);return d[Math.floor(d.length*.05)]})();
function measure1(q,seed){const syn=generate(q,seed);
 const cols=COLS,dsim=cols.map(c=>{const a=hist(TRAIN,c),b=hist(syn,c);return 1-a.reduce((s,v,i)=>s+Math.abs(v-b[i]),0)/2}),dS=dsim.reduce((a,b)=>a+b,0)/dsim.length;
 const ca=corr(TRAIN),cb=corr(syn),cS=1-ca.reduce((s,v,i)=>s+Math.abs(v-cb[i]),0)/ca.length/2;
 const mA=modelAuc(fit(syn)),mS=Math.max(0,Math.min(1,(mA-.5)/Math.max(.01,BASE_AUC-.5)));
 const util=(dS+cS+mS)/3;
 const dcr=syn.map(s=>nn(s,TRAIN)[0]),close=dcr.filter(d=>d<HD).length/syn.length;
 const dT=TRAIN.map(x=>nn(x,syn)[0]),dH=HOLD.map(x=>nn(x,syn)[0]),mia=auc(dT.map(d=>-d),dH.map(d=>-d));
 const QI=["age","tenure"],guess=x=>{const d=syn.map((y,i)=>[dist(x,y,QI)+(x.region===y.region?0:.5),i]).sort((a,b)=>a[0]-b[0]).slice(0,5),v=[0,0,0];d.forEach(([_,i])=>v[band(syn[i].balance)]++);return v.indexOf(Math.max(...v))};
 const accT=TRAIN.filter(x=>guess(x)===band(x.balance)).length/TRAIN.length,accH=HOLD.filter(x=>guess(x)===band(x.balance)).length/HOLD.length,aia=accT-accH;
 return{q,syn,dS,cS,mS,mA,util,close,mia,aia,accT,accH}}
function measure(q){const R=[11,29,47].map(s=>measure1(q,s)),o={q,syn:R[0].syn};["dS","cS","mS","mA","util","close","mia","aia"].forEach(k=>o[k]=R.reduce((a,r)=>a+r[k],0)/R.length);o.aia=Math.max(0,o.aia);return o}
const pct=v=>Math.round(v*100)+"%",f2=v=>v.toFixed(2),money=v=>"$"+v.toLocaleString("en-US");
const cache={};const M=q=>cache[q]||(cache[q]=measure(q/100));
function explorer(root){
 const compact=root.hasAttribute("data-compact"),q=$("[data-pu-q]",root),qv=$("[data-pu-qv]",root),out=$("[data-pu-out]",root),tb=$("[data-pu-tables]",root),
  rel=$("[data-pu-release]",root),svg=$("[data-pu-ring]",root),chart=$("[data-pu-chart]",root),ctab=$("[data-pu-ctab]",root),msg=$("[data-pu-msg]",root);
 const th=()=>({mia:+($("[data-th=mia]",root)||{value:.6}).value,close:+($("[data-th=close]",root)||{value:7}).value/100,aia:+($("[data-th=aia]",root)||{value:5}).value/100,util:+($("[data-th=util]",root)||{value:.75}).value});
 const word=v=>v<20?"Close copy":v<45?"Light":v<70?"Balanced":v<90?"Strict":"Very strict";
 function row(x,keys){return"<tr>"+keys.map(k=>"<td>"+(k==="balance"||k==="spend"?money(x[k]):k==="churned"?(x[k]?"yes":"no"):x[k])+"</td>").join("")+"</tr>"}
 function tables(m){const K=["id","age","region","tenure","balance","churned"],H="<thead><tr>"+K.map(k=>'<th scope="col">'+(k==="tenure"?"months":k)+"</th>").join("")+"</tr></thead>";
  const s=m.syn.slice(0,5).map((x,i)=>Object.assign({},x));
  tb.innerHTML='<figure class="sl-tbl"><figcaption><span>customers · source</span><b>Synthetic</b></figcaption><div class="mv-pscroll" data-label="Source rows"><table>'+H+"<tbody>"+TRAIN.slice(0,5).map(x=>row(x,K)).join("")+"</tbody></table></div></figure>"+
  '<figure class="sl-tbl sl-tbl--syn"><figcaption><span>customers · generated at level '+m.q*100+'</span><b>Synthetic</b></figcaption><div class="mv-pscroll" data-label="Generated rows"><table>'+H+"<tbody>"+s.map(x=>row(x,K)).join("")+"</tbody></table></div></figure>"}
 function ringArt(m){if(!svg)return;const W=360,Hh=300,px=x=>40+(x.age-22)/58*(W-60),py=x=>Hh-30-Math.max(0,Math.min(1,(Math.log(500+x.balance)-Math.log(500))/(Math.log(250500)-Math.log(500))))*(Hh-60);
  const reach=14+Math.max(0,m.mia-.5)*360,pts=m.syn.slice(0,60),cx=pts.reduce((a,s)=>a+px(s),0)/pts.length,cy=pts.reduce((a,s)=>a+py(s),0)/pts.length;let o='<rect class="sl-rg__bg" width="'+W+'" height="'+Hh+'" rx="14"/>';
  const focus=TRAIN.slice(0,36),syn=m.syn;o+='<g class="sl-rg__src">'+focus.map(x=>'<circle cx="'+px(x).toFixed(1)+'" cy="'+py(x).toFixed(1)+'" r="3"/>').join("")+"</g>";
  o+="<g>"+syn.slice(0,60).map(s=>{const d=nn(s,TRAIN)[0],cls=d<HD?"sl-rg__risk":"sl-rg__syn";return'<circle class="'+cls+'" cx="'+px(s).toFixed(1)+'" cy="'+py(s).toFixed(1)+'" r="'+(d<HD?4.4:3.2)+'"/>'}).join("")+"</g>";
  o+='<circle class="sl-rg__ring" cx="'+cx+'" cy="'+cy+'" r="'+reach.toFixed(1)+'"/><text class="sl-rg__t" x="16" y="'+(Hh-10)+'">age →</text><text class="sl-rg__t" x="16" y="22">balance ↑</text>';
  svg.innerHTML=o;svg.setAttribute("aria-label","Scatter of 36 source and 60 generated records by age and balance. "+Math.round(m.close*100)+" percent of generated records sit closer to a source record than the holdout threshold. The ring radius follows membership advantage: AUC "+f2(m.mia)+".")}
 function drawChart(cur){if(!chart)return;const L=[0,10,20,30,40,50,60,70,80,90,100].filter(v=>cache[v]).map(v=>cache[v]);if(!L.length)return;const W=420,Hh=220,x=v=>44+v/100*(W-64),y=v=>Hh-30-v*(Hh-50);
  const path=k=>L.map((m,i)=>(i?"L":"M")+x(m.q*100).toFixed(1)+" "+y(k(m)).toFixed(1)).join("");
  let o='<g class="sl-ch__ax"><path d="M44 '+(Hh-30)+"H"+(W-20)+'"/><path d="M44 20V'+(Hh-30)+'"/></g>';
  [0,.5,1].forEach(v=>o+='<text class="sl-ch__t" x="36" y="'+(y(v)+4)+'" text-anchor="end">'+v.toFixed(1)+"</text>");
  [0,50,100].forEach(v=>o+='<text class="sl-ch__t" x="'+x(v)+'" y="'+(Hh-10)+'" text-anchor="middle">'+v+"</text>");
  o+='<path class="sl-ch__u" d="'+path(m=>m.util)+'"/><path class="sl-ch__m" d="'+path(m=>m.mia)+'"/>';
  const c=M(cur);if(!cache[cur])return;o+='<line class="sl-ch__cur" x1="'+x(cur)+'" x2="'+x(cur)+'" y1="20" y2="'+(Hh-30)+'"/><circle class="sl-ch__du" cx="'+x(cur)+'" cy="'+y(c.util)+'" r="5"/><circle class="sl-ch__dm" cx="'+x(cur)+'" cy="'+y(c.mia)+'" r="5"/>';
  chart.innerHTML=o;if(ctab)ctab.innerHTML="<thead><tr><th scope=\"col\">Privacy level</th><th scope=\"col\">Utility</th><th scope=\"col\">Membership AUC</th><th scope=\"col\">Close records</th></tr></thead><tbody>"+
   L.map(m=>"<tr"+(m.q*100===cur?' class="is-cur"':"")+"><td>"+m.q*100+"</td><td>"+f2(m.util)+"</td><td>"+f2(m.mia)+"</td><td>"+pct(m.close)+"</td></tr>").join("")+"</tbody>"}
 function render(){const v=+q.value,m=M(v),T=th();if(qv)qv.textContent=v+" · "+word(v);q.setAttribute("aria-valuetext",v+", "+word(v));
  const bad=[];if(m.close>T.close)bad.push("nearest-neighbour");if(m.mia>T.mia)bad.push("membership inference");if(m.aia>T.aia)bad.push("attribute inference");const low=m.util<T.util;
  const tag=(ok,t)=>'<span class="sl-tag sl-tag--'+(ok?"ok":"bad")+'">'+(t||(ok?"pass":"fail"))+"</span>";
  out.innerHTML='<div class="sl-sc"><div class="sl-sc__k'+(low?" is-low":"")+'"><span>Utility score</span><b>'+f2(m.util)+"</b>"+(compact?"":"<small>minimum "+f2(T.util)+"</small>")+"</div>"+
   '<dl class="sl-sc__d"><div><dt>Distributions</dt><dd>'+f2(m.dS)+"</dd></div><div><dt>Correlations</dt><dd>"+f2(m.cS)+"</dd></div><div><dt>Churn model, holdout AUC</dt><dd>"+f2(m.mA)+" <small>source "+f2(BASE_AUC)+"</small></dd></div></dl></div>"+
   '<div class="mv-pscroll" data-label="Privacy tests"><table class="sl-at"><thead><tr><th scope="col">Privacy test</th><th scope="col">Result</th>'+(compact?"":'<th scope="col">Threshold</th>')+'<th scope="col">Status</th></tr></thead><tbody>'+
   "<tr><th scope=\"row\">Nearest neighbour<small>Generated rows closer to a source row than real holdout rows are</small></th><td>"+pct(m.close)+" of rows</td>"+(compact?"":"<td>max "+pct(T.close)+"</td>")+"<td>"+tag(m.close<=T.close)+"</td></tr>"+
   "<tr><th scope=\"row\">Membership inference<small>Tell training rows from holdout rows by distance to the copy</small></th><td>AUC "+f2(m.mia)+"</td>"+(compact?"":"<td>max "+f2(T.mia)+"</td>")+"<td>"+tag(m.mia<=T.mia)+"</td></tr>"+
   "<tr><th scope=\"row\">Attribute inference<small>Guess a balance band from age, tenure and region</small></th><td>"+(m.aia>=0?"+":"")+Math.round(m.aia*100)+" pts</td>"+(compact?"":"<td>max +"+Math.round(T.aia*100)+" pts</td>")+"<td>"+tag(m.aia<=T.aia)+"</td></tr></tbody></table></div>";
  if(rel){const ok=!bad.length&&!low;rel.className="sl-rel "+(ok?"is-ok":"is-bad");
   rel.innerHTML='<p class="sl-rel__s">'+(ok?"Release can go to the data owner":"Release blocked")+"</p><p class=\"sl-rel__r\">"+(ok?"All three privacy tests and the utility minimum are met at level "+v+". The data owner still signs off.":
    (bad.length?"Failed: "+bad.join(", ")+". ":"")+(low?"Utility "+f2(m.util)+" is under the minimum "+f2(T.util)+". ":"")+(bad.length?"Raise the privacy level or tighten the generator.":"Lower the privacy level or relax the minimum."))+"</p>"}
  tables(m);ringArt(m);drawChart(v);$$("[data-pu-p]",root).forEach(b=>b.setAttribute("aria-pressed",String(+b.dataset.puP===v)))}
 let raf=0;function replay(){cancelAnimationFrame(raf);const to=+q.value;if(RM){render();if(msg)msg.textContent="Replayed at level "+to+".";return}const t0=performance.now();
  (function st(t){const k=Math.min(1,(t-t0)/2400),e=1-Math.pow(1-k,3);q.value=String(Math.round(e*to/5)*5);render();if(k<1)raf=requestAnimationFrame(st);else{q.value=String(to);render();if(msg)msg.textContent="Replayed from 0 to level "+to+"."}})(t0)}
 q.addEventListener("input",render);$$("[data-pu-p]",root).forEach(b=>b.addEventListener("click",()=>{q.value=b.dataset.puP;render();if(msg)msg.textContent="Level set to "+b.dataset.puP+"."}));
 $$("[data-th]",root).forEach(i=>i.addEventListener("input",()=>{const ok=i.value!==""&&!isNaN(+i.value)&&+i.value>=+i.min&&+i.value<=+i.max;i.setAttribute("aria-invalid",String(!ok));
  if(msg)msg.textContent=ok?"":"Enter a value from "+i.min+" to "+i.max+" for "+i.labels[0].textContent+".";if(ok)render()}));
 const rp=$("[data-pu-replay]",root);if(rp)rp.addEventListener("click",replay);
 const rs=$("[data-pu-reset]",root);if(rs)rs.addEventListener("click",()=>{$$("[data-th]",root).forEach(i=>{i.value=i.defaultValue;i.setAttribute("aria-invalid","false")});q.value=q.defaultValue;render();if(msg)msg.textContent="Thresholds and level reset."});

 let wt=0;function warm(){const rest=[0,10,20,30,40,50,60,70,80,90,100].filter(v=>!cache[v]);if(!rest.length||!chart)return;M(rest[0]);drawChart(+q.value);wt=setTimeout(warm,40)}
 render();if(chart)setTimeout(warm,300)}
function tabs(root){const t=$$('[role=tab]',root);function go(i,f){t.forEach((b,k)=>{const on=k===i;b.setAttribute("aria-selected",String(on));b.tabIndex=on?0:-1;const p=document.getElementById(b.getAttribute("aria-controls"));if(p)p.hidden=!on});if(f)t[i].focus()}
 t.forEach((b,i)=>{b.addEventListener("click",()=>go(i));b.addEventListener("keydown",e=>{const k=e.key;let n=-1;if(k==="ArrowRight")n=(i+1)%t.length;else if(k==="ArrowLeft")n=(i-1+t.length)%t.length;else if(k==="Home")n=0;else if(k==="End")n=t.length-1;if(n>=0){e.preventDefault();go(n,!0)}})})}
export function boot(){$$("[data-sl=explorer]").forEach(explorer);$$("[data-sl=tabs]").forEach(tabs);
 $$(".mv-pscroll").forEach(el=>{const f=()=>{if(el.scrollWidth>el.clientWidth+2){el.tabIndex=0;el.setAttribute("role","region");el.setAttribute("aria-label",el.dataset.label||"Scrollable table")}else{el.removeAttribute("tabindex")}};f();addEventListener("resize",f)})}
