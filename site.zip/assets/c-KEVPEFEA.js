/* Filingquill page tools. Everything runs in the browser with no network calls.
   Filing data comes from the inline <script id="fq-data"> block written by gen/filingquill/filings.py (synthetic companies only).
   [data-fq=demo]   Filing Demo: pick a synthetic company, choose a prepared question or type one, read the cited answer,
                    press a page number (or use the arrow keys) to open the source page with the line highlighted
   [data-fq=mini]   home walkthrough: the debt answer for one company, page numbers open their pages
   [data-fq=ratio]  ratio calculator: company and ratio in, result and the source cells with their pages out */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
let D=null;function data(){if(!D){const el=$("#fq-data");try{D=el?JSON.parse(el.textContent):null}catch(e){D=null}}return D}

/* ---------- rendering, mirrors content.answer() and content.page_view() */
function cite(p,l){return'<button type="button" class="fq-cite" data-p="'+p+'" data-l="'+l+'" aria-pressed="false">p. '+p+"</button>"}
function answerHtml(q,own){
const li=q.a.map(s=>"<li>"+esc(s[0])+' <span class="fq-cites">'+s[1].map(c=>cite(c[0],c[1])).join("")+"</span></li>").join("");
let tb="";if(q.table){const t=q.table;tb='<figure class="fq-xt"><figcaption><span>Extracted table · '+esc(t[0])+'</span><span class="fq-cite">p. '+t[1]+'</span></figcaption><div class="mv-pscroll" data-label="'+esc(t[0])+'"><table><thead><tr>'+t[2].map(h=>'<th scope="col">'+esc(h)+"</th>").join("")+"</tr></thead><tbody>"+t[3].map(r=>"<tr"+(r[0]==="Total"?' class="fq-tot"':"")+">"+r.map(x=>"<td>"+esc(x)+"</td>").join("")+"</tr>").join("")+"</tbody></table></div></figure>"}
const ch='<p class="fq-check fq-check--'+q.check[1]+'"><b>'+(q.check[1]==="ok"?"Check":"Read closely")+"</b>"+esc(q.check[0])+"</p>";
const hd='<p class="fq-ans__q"><span>'+(own?"Your question":"Question")+"</span>"+esc(own||q.q)+"</p>";
return'<div class="fq-ans'+(q.nf?" fq-ans--nf":"")+' fq-in">'+hd+(q.nf?'<p class="fq-nf">Not in the filing</p>':"")+'<ol class="fq-ans__s">'+li+"</ol>"+tb+ch+"</div>"}
function pageHtml(co,p,l){const pg=co.pages[String(p)];if(!pg)return'<div class="fq-err" role="alert"><b>That page is not in the sample.</b><p>Choose another page number.</p></div>';
return'<figure class="fq-pg fq-in" aria-label="Source page '+p+'"><div class="fq-pg__h"><span>'+esc(co.name)+"</span><b>p. "+p+" of "+co.total+'</b></div><p class="fq-pg__sec">'+esc(pg.sec)+'</p><ol class="fq-pg__l">'+pg.lines.map((t,i)=>"<li"+(i===l?' class="is-hl"':"")+">"+esc(t)+"</li>").join("")+'</ol><p class="fq-pg__n">Synthetic filing</p></figure>'}

/* ---------- citations: click or arrow keys open the page */
function bindCites(root,co,pageEl,live){const bs=()=>$$(".fq-cite[data-p]",root);
function open(b,focus){bs().forEach(x=>x.setAttribute("aria-pressed",String(x===b)));const p=+b.dataset.p,l=+b.dataset.l;pageEl.innerHTML=pageHtml(co,p,l);if(focus)b.focus();if(live)live.textContent="Opened page "+p+", line "+(l+1)+" highlighted"}
root.addEventListener("click",e=>{const b=e.target.closest(".fq-cite[data-p]");if(b&&root.contains(b))open(b)});
root.addEventListener("keydown",e=>{const b=e.target.closest&&e.target.closest(".fq-cite[data-p]");if(!b)return;const a=bs(),i=a.indexOf(b);let j=-1;
if(e.key==="ArrowRight"||e.key==="ArrowDown")j=(i+1)%a.length;else if(e.key==="ArrowLeft"||e.key==="ArrowUp")j=(i+a.length-1)%a.length;else if(e.key==="Home")j=0;else if(e.key==="End")j=a.length-1;else return;
e.preventDefault();open(a[j],!0)});
return{first:()=>{const b=bs()[0];if(b)open(b)}}}

/* ---------- matching a typed question to the prepared ones (prefix match on keywords, no network) */
const STOP=new Set("the a an of to in on for and or is are was were what how why does do did any there this that it its company s with by be has have from about much many which who will".split(" "));
function match(co,text){const toks=text.toLowerCase().replace(/[^a-z0-9\s]/g," ").split(/\s+/).filter(t=>t.length>2&&!STOP.has(t));
let best=null,score=0;co.qs.forEach(q=>{let s=0;toks.forEach(t=>{if(q.kw.some(k=>t.startsWith(k)||k.startsWith(t)&&t.length>=4))s++});if(s>score){score=s;best=q}});
return{toks,q:score>0?best:null}}
function notFound(co){return{nf:!0,a:[["The filing does not say. No passage in this synthetic "+co.doc.split(" ·")[0]+" answers that question.",[]],["Try asking about debt, revenue, related parties, the auditor's report or accounting changes.",[]]],table:null,check:["No passage was found, so no figure is given.","ok"]}}

/* ---------- Filing Demo */
function demo(root){const d=data(),out=$("[data-out]",root),pageEl=$("[data-page]",root),live=$("[data-live]",root),qs=$("[data-qs]",root),about=$("[data-about]",root),own=$("[data-own]",root);
if(!d){out.innerHTML='<div class="fq-err" role="alert"><b>The sample filings did not load.</b><p>Reload the page to try again.</p></div>';return}
let key="calder",cur=null,curOwn="";const co=()=>d.co[key];const C=bindCites(out,{get pages(){return co().pages},get name(){return co().name},get total(){return co().total}},pageEl,live);
function empty(){out.innerHTML='<div class="fq-empty"><b>No question yet.</b><p>Choose a question on the left or write your own. The answer will cite its pages, and each page number opens the source.</p></div>';pageEl.innerHTML=""}
function loadCo(){const c=co();about.innerHTML='<b>'+esc(c.name)+"</b> "+esc(c.doc)+". "+esc(c.about);
qs.innerHTML=c.qs.map(q=>'<button type="button" class="fq-q" data-q="'+q.id+'" aria-pressed="false">'+esc(q.q)+(q.nf?'<small>The filing may not say</small>':"")+"</button>").join("");cur=null;empty()}
function show(q,ownText){cur=q;curOwn=ownText||"";$$(".fq-q",qs).forEach(b=>b.setAttribute("aria-pressed",String(!ownText&&b.dataset.q===q.id)));
out.innerHTML=answerHtml(q,ownText);const n=q.a.reduce((s,x)=>s+x[1].length,0);
if(n)C.first();else pageEl.innerHTML='<div class="fq-empty"><b>No source page.</b><p>Nothing in the filing answers this, so there is no page to open.</p></div>';
live.textContent=(q.nf?"Not in the filing. ":"Answer with "+n+" citation"+(n===1?"":"s")+". ")+(q.table?"Extracted table included.":"")}
$$("input[name=fq-co]",root).forEach(r=>r.addEventListener("change",()=>{if(r.checked){key=r.value;loadCo();live.textContent="Loaded "+co().name}}));
qs.addEventListener("click",e=>{const b=e.target.closest(".fq-q");if(!b)return;show(co().qs.find(q=>q.id===b.dataset.q))});
function ask(){const t=own.value.trim();if(!t){out.innerHTML='<div class="fq-err" role="alert"><b>Write a question first.</b><p>For example: how much debt is due in 2028?</p></div>';pageEl.innerHTML="";live.textContent="Write a question first";own.focus();return}
if(t.length<6){out.innerHTML='<div class="fq-err" role="alert"><b>That question is too short to search on.</b><p>Use a few words, such as: are there related-party leases?</p></div>';pageEl.innerHTML="";live.textContent="Question too short";return}
const m=match(co(),t);show(m.q||notFound(co()),t)}
$("[data-ask]",root).addEventListener("click",ask);own.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();ask()}});
$("[data-replay]",root).addEventListener("click",()=>{if(cur){const q=cur,o=curOwn;out.innerHTML="";pageEl.innerHTML="";requestAnimationFrame(()=>show(q,o));live.textContent="Replaying the answer"}else{show(co().qs[0]);live.textContent="Showing the first question"}});
loadCo();show(co().qs[0])}

/* ---------- home walkthrough */
function mini(root){const d=data(),co=d&&d.co[root.dataset.co],pageEl=$("[data-page]",root);if(!co||!pageEl)return;bindCites(root,co,pageEl,null)}

/* ---------- ratio calculator */
const fmt=x=>x.toLocaleString("en-US",{minimumFractionDigits:1,maximumFractionDigits:1});
function ratio(root){const d=data(),out=$("[data-r-out]",root),sc=$("[data-r-co]",root),sr=$("[data-r-k]",root);
if(!d){out.innerHTML='<div class="fq-err" role="alert"><b>The sample figures did not load.</b><p>Reload the page to try again.</p></div>';return}
function calc(k,f){if(k==="nde"){const nd=f.debt-f.cash;return nd<0?{v:"Net cash",n:"Cash of $"+fmt(f.cash)+" million exceeds total debt, so the ratio is not meaningful."}:{v:(nd/(f.opi+f.da)).toFixed(2)+"x"}}
if(k==="opm")return{v:(100*f.opi/f.rev).toFixed(1)+"%"};if(k==="cov")return{v:(f.opi/f.int).toFixed(1)+"x"};if(k==="de")return{v:(f.debt/f.eq).toFixed(2)+"x"};
if(k==="gr"){const g=100*(f.rev-f.rev0)/f.rev0;return{v:(g>0?"+":"")+g.toFixed(1)+"%"}}return null}
function run(){const c=d.co[sc.value],r=d.ratios.find(x=>x[0]===sr.value);if(!c||!r){out.innerHTML='<div class="fq-err" role="alert"><b>Choose a company and a ratio.</b></div>';return}
const res=calc(r[0],c.fig);let note=res.n||"";
if(sc.value==="calder"&&r[0]==="nde")note="The credit agreement reports 3.40x on page 73, using its own EBITDA definition with add-backs. The two figures use different definitions.";
out.innerHTML='<div class="fq-in"><p class="fq-ratio__k">'+esc(c.short)+" · "+esc(r[1])+'</p><p class="fq-ratio__v">'+esc(res.v)+'</p><p class="fq-ratio__f">'+esc(r[2])+'</p><ul class="fq-cells">'+
r[3].map(k=>"<li><span>"+esc(d.cell[k])+'</span><b>'+fmt(c.fig[k])+'</b><span class="fq-cite">p. '+c.src[k]+"</span></li>").join("")+"</ul>"+(note?'<p class="fq-check fq-check--warn"><b>Note</b>'+esc(note)+"</p>":"")+"</div>"}
sc.addEventListener("change",run);sr.addEventListener("change",run);run()}

function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set);new MutationObserver(()=>set()).observe(document.body,{childList:!0,subtree:!0})}
export function boot(){scrollers();$$("[data-fq=demo]").forEach(demo);$$("[data-fq=mini]").forEach(mini);$$("[data-fq=ratio]").forEach(ratio)}
