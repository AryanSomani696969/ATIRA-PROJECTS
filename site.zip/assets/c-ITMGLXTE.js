/* Voxkeel hero: a warm sound stage on ocean blue. Voice bars rise from a small sand table as a spoken answer,
   lift and gather into a speech bubble, two bars turn mango and a feedback tag rises from each, then a green progress
   ring closes and the next prompt card appears. 12 second cycle; scrolling holds the settled state. Synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const bg=new T.Color(color("--vk-stage","#0f4eb5")),sand=new T.Color(color("--vk-sand","#fff4e0")),mango=new T.Color(color("--vk-mango","#ffb400")),green=new T.Color(color("--vk-green","#2fa66a"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),9,20);
const root=new T.Group;scene.add(root);const geos=[];const G=g=>(geos.push(g),g);
root.add(new T.AmbientLight(0xf2f4f8,1.25));
const key=new T.DirectionalLight(0xffeccc,1.1);key.position.set(-3,6,5);root.add(key);
const rim=new T.DirectionalLight(mango.getHex(),.4);rim.position.set(5,3,-4);root.add(rim);
const M=(c,o={})=>new T.MeshStandardMaterial(Object.assign({color:c,roughness:.7,metalness:0},o));
/* stage rings, far back */
const rings=new T.Group;rings.position.set(.2,.2,-3);root.add(rings);
const circ=(r,n)=>{const a=[];for(let k=0;k<=n;k++){const q=k/n*Math.PI*2;a.push(new T.Vector3(Math.cos(q)*r,Math.sin(q)*r,0))}return a};
for(let i=0;i<5;i++){const r=new T.Line(G(new T.BufferGeometry().setFromPoints(circ(1.3+i*.75,small?48:96))),new T.LineBasicMaterial({color:bg.clone().lerp(sand,.2-i*.03)}));rings.add(r)}
/* table */
const tab=new T.Group;tab.position.set(-.2,-.1,.6);root.add(tab);
const top=new T.Mesh(G(new T.BoxGeometry(4.4,.1,1.6)),M(sand.clone(),{roughness:.85,emissive:sand.clone(),emissiveIntensity:.28}));tab.add(top);
const legGeo=G(new T.BoxGeometry(.07,1.6,.07)),legMat=M(sand.clone().lerp(bg,.35));[[-2,-.6],[2,-.6],[-2,.6],[2,.6]].forEach(([x,z])=>{const l=new T.Mesh(legGeo,legMat);l.position.set(x,-.85,z);tab.add(l)});
/* voice bars */
const N=small?18:26,barGeo=G(new T.BoxGeometry(.09,1,.09)),o=new T.Object3D,cl=new T.Color;
const bars=new T.InstancedMesh(barGeo,M(sand.clone(),{roughness:.5,emissive:sand.clone(),emissiveIntensity:.3}),N);root.add(bars);
const H=[];for(let i=0;i<N;i++){const e=Math.pow(Math.sin(Math.PI*(i+.5)/N),.7);H.push((.25+.75*e)*(.45+.55*(((i*37+3)%23)/23)))}
const HOT=[Math.floor(N*.27),Math.floor(N*.66)];
/* bubble: a rounded rectangle with a tail, outline plus a faint fill */
const BW=3.1,BH=1.5,BR=.42,BX=-1.3,BY=1.35,bp=[];
const arc=(cx,cy,a0)=>{for(let k=0;k<=6;k++){const q=a0+k/6*Math.PI/2;bp.push(new T.Vector3(cx+Math.cos(q)*BR,cy+Math.sin(q)*BR,0))}};
bp.push(new T.Vector3(BX+BW*.15,BY,0),new T.Vector3(BX+BW*.1,BY-.38,0),new T.Vector3(BX+BW*.26,BY,0));
arc(BX+BW-BR,BY+BR,-Math.PI/2);arc(BX+BW-BR,BY+BH-BR,0);arc(BX+BR,BY+BH-BR,Math.PI/2);arc(BX+BR,BY+BR,Math.PI);
const bub=new T.Group;bub.position.set(0,0,.62);root.add(bub);
const fill=new T.Mesh(G(new T.PlaneGeometry(BW-.28,BH-.28)),new T.MeshBasicMaterial({color:bg.clone().lerp(sand,.1),transparent:!0,opacity:0,depthWrite:!1}));fill.position.set(BX+BW/2,BY+BH/2,-.08);bub.add(fill);
const line=new T.Mesh(G(new T.TubeGeometry(new T.CatmullRomCurve3(bp,!0,"centripetal"),small?90:160,.022,6,!0)),new T.MeshBasicMaterial({color:sand.clone(),transparent:!0,opacity:0}));bub.add(line);
const CX=BX+BW/2,CY=BY+BH/2;
/* feedback tags */
const tagGeo=G(new T.BoxGeometry(.62,.2,.04)),tags=HOT.map((h,k)=>{const m=new T.Mesh(tagGeo,M(k?sand.clone():mango.clone(),{emissive:mango.clone(),emissiveIntensity:.15,transparent:!0,opacity:0}));root.add(m);return m});
/* progress ring of dots */
const RD=40,dot=new T.InstancedMesh(G(new T.SphereGeometry(.045,8,6)),M(green.clone(),{emissive:green.clone(),emissiveIntensity:.25}),RD);root.add(dot);
const ringC=new T.Vector3(1.7,3.05,-.2),ringBack=new T.InstancedMesh(G(new T.SphereGeometry(.03,6,4)),new T.MeshBasicMaterial({color:bg.clone().lerp(sand,.3)}),RD);root.add(ringBack);
for(let i=0;i<RD;i++){const a=Math.PI/2-i/RD*Math.PI*2;o.position.set(ringC.x+Math.cos(a)*.48,ringC.y+Math.sin(a)*.48,ringC.z);o.scale.setScalar(1);o.rotation.set(0,0,0);o.updateMatrix();ringBack.setMatrixAt(i,o.matrix);dot.setMatrixAt(i,o.matrix)}
/* next prompt card */
const card=new T.Mesh(G(new T.BoxGeometry(1.5,.5,.04)),M(sand.clone(),{transparent:!0,opacity:0}));card.position.set(-1.75,3.0,-.3);root.add(card);
const C0=new T.Vector3(.2,2.1,9.4),look=new T.Vector3(.1,1.3,0),lk=new T.Vector3;camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
function frame(t,dt,p){
const hold=clamp((p-.5)/.3),c0=t%12,c=hold>0?lerp(c0,10.6,ease(hold)):c0,reset=c>11.2?ease((c-11.2)/.8):0;
camera.position.set(C0.x+Math.sin(t/12*Math.PI*2)*.25+pointer.x*.3,C0.y-pointer.y*.18,C0.z);lk.copy(look);lk.x+=pointer.x*.08;camera.lookAt(lk);
rings.rotation.z=t*.02;rings.children.forEach((r,i)=>{r.scale.setScalar(1+.02*Math.sin(t*1.2-i*.6))});
const speak=clamp(c/3.6),gather=ease(clamp((c-3.6)/2.2))*(1-reset),tagT=ease(clamp((c-6.4)/1.6))*(1-reset),ringT=clamp((c-8.4)/1.6)*(1-reset),cardT=ease(clamp((c-9.8)/.8))*(1-reset);
for(let i=0;i<N;i++){
const f=i/(N-1),live=c<3.6?Math.abs(Math.sin(t*6+i*.9))*.7+.3:1,talk=speak>f?1:.08;
const h0=(.12+H[i]*1.05*live)*talk,x0=-2.1+f*3.2,y0=-.05+h0/2;
const h1=.12+H[i]*.95,x1=CX-BW*.4+f*BW*.8,y1=CY;
const h=lerp(h0,h1,gather);o.position.set(lerp(x0,x1,gather),lerp(y0,y1,gather),lerp(.6,.62,gather));o.scale.set(1,Math.max(h,.02),1);o.rotation.set(0,0,0);o.updateMatrix();bars.setMatrixAt(i,o.matrix);
const hot=HOT.indexOf(i);bars.setColorAt(i,cl.copy(hot>=0&&tagT>.2?(hot?sand.clone().lerp(mango,.55):mango):sand))}
bars.instanceMatrix.needsUpdate=!0;if(bars.instanceColor)bars.instanceColor.needsUpdate=!0;
fill.material.opacity=gather*.85;line.material.opacity=gather;bub.scale.setScalar(.92+.08*gather);bub.position.y=(1-gather)*-.2;
tags.forEach((m,k)=>{const f=HOT[k]/(N-1);m.position.set(CX-BW*.4+f*BW*.8,BY+BH+.25+tagT*.25+k*.12,.7);m.material.opacity=tagT;m.rotation.z=(k?-.06:.05)*tagT});
dot.count=Math.round(RD*ringT);
card.material.opacity=cardT;card.position.y=2.85+cardT*.15}
return{frame,resize:(w,h)=>{C0.z=w/h<.8?11.5:w/h<1.3?9.4:8.2;look.x=.1},dispose:()=>geos.forEach(g=>g.dispose())}}
