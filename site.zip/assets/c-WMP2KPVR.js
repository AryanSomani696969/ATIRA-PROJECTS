/* Synthlattice hero: two linked tables drawn as crystalline lattices on graphite. The left lattice is the source table
   (frost points), the right one is its synthetic copy (mint points), and constraint links join the key columns.
   Every 12 seconds the right lattice regenerates row by row with every link kept, the privacy ring around it tightens
   to the release threshold, and the one amber record that sat too close to a source record is regenerated and turns
   mint. Slow 12 second turn and rise, no shake. Scrolling holds the settled state. Synthetic. */
export default function({THREE:T,scene,camera,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const gr=new T.Color(color("--sl-graphite","#0f172a")),fr=new T.Color(color("--sl-frost","#f1f5f9")),mint=new T.Color(color("--sl-mint","#5eead4")),amb=new T.Color(color("--sl-amber","#f59e0b")),slate=new T.Color(color("--sl-slate","#1e293b"));
scene.background=gr.clone();scene.fog=new T.Fog(gr.getHex(),8,18);
const root=new T.Group;scene.add(root);const off=-.3;const geos=[],mats=[];const G=g=>(geos.push(g),g),Mt=m=>(mats.push(m),m);
root.add(new T.AmbientLight(0xe2e8f0,1.1));
const key=new T.DirectionalLight(0xfff3e0,1.1);key.position.set(-4,6,5);root.add(key);
const rim=new T.DirectionalLight(mint.getHex(),.45);rim.position.set(5,2,-4);root.add(rim);
/* lattice: hex rows on a tilted plane, one table per lattice */
const C=small?5:6,R=small?6:7,S=.42,H=S*.866;
function nodes(ox){const p=[];for(let r=0;r<R;r++)for(let c=0;c<C;c++)p.push(new T.Vector3(ox+(c-(C-1)/2)*S+(r%2?S/2:0),((R-1)/2-r)*H,((c*7+r*3)%5-2)*.05));return p}
const A=nodes(-1.45),B=nodes(1.45),N=A.length,o=new T.Object3D,cl=new T.Color;
const ptG=G(new T.IcosahedronGeometry(.055,1));
const mA=new T.InstancedMesh(ptG,Mt(new T.MeshStandardMaterial({color:fr.clone(),roughness:.45,emissive:fr.clone(),emissiveIntensity:.12})),N);
const mB=new T.InstancedMesh(ptG,Mt(new T.MeshStandardMaterial({color:0xffffff,roughness:.4,emissive:mint.clone(),emissiveIntensity:.18})),N);
A.forEach((v,i)=>{o.position.copy(v);o.scale.setScalar(1);o.updateMatrix();mA.setMatrixAt(i,o.matrix)});root.add(mA,mB);
function edges(P){const e=[];for(let r=0;r<R;r++)for(let c=0;c<C;c++){const i=r*C+c;if(c<C-1)e.push(i,i+1);if(r<R-1){e.push(i,i+C);const d=r%2?c+1:c-1;if(d>=0&&d<C)e.push(i,(r+1)*C+d)}}
 const a=new Float32Array(e.length*3);e.forEach((k,j)=>{a[j*3]=P[k].x;a[j*3+1]=P[k].y;a[j*3+2]=P[k].z});const g=G(new T.BufferGeometry);g.setAttribute("position",new T.BufferAttribute(a,3));return g}
const lmA=Mt(new T.LineBasicMaterial({color:fr.clone().lerp(gr,.55),transparent:!0,opacity:.7})),lmB=Mt(new T.LineBasicMaterial({color:mint.clone().lerp(gr,.45),transparent:!0,opacity:0}));
root.add(new T.LineSegments(edges(A),lmA));const lB=new T.LineSegments(edges(B),lmB);root.add(lB);
/* constraint links: key column of the source to the same rows of the copy, as soft arcs */
const lk=Mt(new T.LineBasicMaterial({color:mint.clone().lerp(fr,.35),transparent:!0,opacity:.5}));const links=[];
[0,2,4,R-1].filter(r=>r<R).forEach(r=>{const a=A[r*C+C-1],b=B[r*C];const cv=new T.CatmullRomCurve3([a,new T.Vector3((a.x+b.x)/2,a.y+.12,.35),b]);
 const g=G(new T.BufferGeometry().setFromPoints(cv.getPoints(24)));const l=new T.Line(g,lk);root.add(l);links.push(l)});
/* the privacy ring around the copy */
const RP=96,rg=G(new T.BufferGeometry);rg.setAttribute("position",new T.BufferAttribute(new Float32Array((RP+1)*3),3));
const rm=Mt(new T.LineBasicMaterial({color:mint.clone(),transparent:!0,opacity:.85}));const ring=new T.Line(rg,rm);root.add(ring);
const rg2=G(new T.BufferGeometry);rg2.setAttribute("position",new T.BufferAttribute(new Float32Array((RP+1)*3),3));
const ring2=new T.Line(rg2,Mt(new T.LineBasicMaterial({color:fr.clone().lerp(gr,.5),transparent:!0,opacity:.5})));root.add(ring2);
const cx=1.45,cy=0;function setRing(g,r,tw){const a=g.attributes.position.array;for(let i=0;i<=RP;i++){const t=i/RP*Math.PI*2;a[i*3]=cx+Math.cos(t)*r;a[i*3+1]=cy+Math.sin(t)*r*.92;a[i*3+2]=Math.sin(t*3+tw)*.04}g.attributes.position.needsUpdate=!0}
/* the record at risk: one synthetic point that copies a source point too closely */
const RISK=Math.min(N-1,2*C+C-2);
const halo=new T.Mesh(G(new T.SphereGeometry(.14,16,12)),Mt(new T.MeshBasicMaterial({color:amb.clone(),transparent:!0,opacity:0,depthWrite:!1,blending:T.AdditiveBlending})));root.add(halo);
const C0=new T.Vector3(0,.5,6.2),look=new T.Vector3(0,-.05,0),lt=new T.Vector3;camera.fov=38;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
function frame(t,dt,p){
 const hold=clamp((p-.4)/.3),c0=t%12,c=hold>0?lerp(c0,10.5,ease(hold)):c0;
 const regen=clamp(c/4.2),tight=ease(clamp((c-4.4)/3)),fix=ease(clamp((c-7.2)/1)),fade=c>11.2?ease((c-11.2)/.8):0;
 const turn=Math.sin(t/12*Math.PI*2);root.rotation.y=turn*.18+pointer.x*.08;root.position.set(off,Math.sin(t/12*Math.PI*2+1)*.06,0);
 camera.position.set(C0.x+pointer.x*.2,C0.y-pointer.y*.12,C0.z);lt.copy(look);camera.lookAt(lt);
 for(let i=0;i<N;i++){const r=Math.floor(i/C),k=clamp((regen*(R+2)-r-(i%C)*.12)/1.6)*(1-fade)+(fade>0?0:0),v=B[i];
  let s=ease(clamp(k)),pp=v.clone();
  if(i===RISK){const src=A[i].clone();src.x+=2.9;const near=src.clone().lerp(v,.25);pp=near.lerp(v,fix);}
  o.position.copy(pp);o.scale.setScalar(.25+.75*s);o.updateMatrix();mB.setMatrixAt(i,o.matrix);
  cl.copy(fr).lerp(mint,s);if(i===RISK)cl.copy(amb).lerp(mint,fix);mB.setColorAt(i,cl)}
 mB.instanceMatrix.needsUpdate=!0;if(mB.instanceColor)mB.instanceColor.needsUpdate=!0;
 lmB.opacity=.65*ease(clamp((regen-.5)/.5))*(1-fade*.6);lk.opacity=.25+.4*ease(regen);
 const rr=lerp(1.95,1.5,tight);setRing(rg,rr,t*.4);setRing(rg2,1.95,0);rm.opacity=.4+.5*tight;
 const rv=B[RISK].clone(),src=A[RISK].clone();src.x+=2.9;halo.position.copy(src.lerp(rv,.25).lerp(rv,fix));halo.material.opacity=(regen>.6?.35:0)*(1-fix);}
return{frame,resize:(w,h)=>{const a=w/h,k=a<.8?0:a<1.3?1:2;C0.set(0,[.3,.4,.5][k],[12.5,10.2,8.4][k]);root.scale.setScalar([.8,.9,1][k])},
 dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose())}}}
