/* Peoplecairn page tools. Everything runs in the browser and sends nothing.
   [data-pc=bot]   Policy Bot: a question against one of two synthetic handbooks -> a cited answer, the clause with the sentence marked,
                   a confidence level, an offer to send it to HR; sensitive topics are routed to a person and never answered
   [data-pc=play]  home workspace: one synthetic PTO question stepped from asking to an approval request */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

/* ---------- the two synthetic handbooks. Each clause: id, title, version, sentences, the answer (indexes of sentences used), keyword weights */
const HB={
K:{name:"Handbook K",co:"Company K, logistics, 1,400 employees",cl:[
{id:"4.1",t:"PTO accrual",v:"v7 · Jan 1, 2026",s:["Full-time employees accrue 6.15 hours of PTO per biweekly pay period, which is 160 hours a year.","Part-time employees accrue PTO in proportion to their scheduled hours.","Accrual starts on the first day of employment."],a:[0,1],k:{accru:3,earn:2,"how much pto":2,"per year":1,"part-time":2,"part time":2,pto:1,vacation:1,"new hire":1}},
{id:"4.3",t:"Carryover of unused PTO",v:"v7 · Jan 1, 2026",s:["Up to 40 hours of unused PTO carry over into the next calendar year.","Hours above 40 are forfeited on December 31, except where state law requires them to be paid out or carried over.","Carried-over hours must be used by March 31 of the following year."],a:[0,1,2],core:[0,1,2],k:{"carry over":4,carryover:4,"roll over":4,rollover:4,unused:3,"next year":2,forfeit:3,"use it or lose":3,"lose my":2,expire:2,pto:1,vacation:1,"left over":2}},
{id:"4.5",t:"Requesting time off",v:"v7 · Jan 1, 2026",s:["Time off is requested in the HR system.","Requests for three or more consecutive working days need 10 working days of notice.","Your manager approves or declines within three working days."],a:[0,1,2],k:{request:2,"book time":3,"time off":2,notice:3,"how far in advance":3,approve:2,"take a day":2,"day off":2}},
{id:"5.1",t:"Paid holidays",v:"v7 · Jan 1, 2026",s:["Company K observes ten paid holidays in 2027: New Year's Day (Fri Jan 1), Martin Luther King Jr. Day (Mon Jan 18), Memorial Day (Mon May 31), Juneteenth (observed Fri Jun 18), Independence Day (observed Mon Jul 5), Labor Day (Mon Sep 6), Thanksgiving Day and the day after (Thu Nov 25 and Fri Nov 26) and Christmas Day (observed Fri Dec 24).","Each employee also has one floating holiday to use in the calendar year.","When a holiday falls on a Saturday it is observed on the Friday before, and on a Sunday the Monday after."],a:[0,1],k:{holiday:4,holidays:4,christmas:3,thanksgiving:3,juneteenth:3,"new year":3,"labor day":3,"memorial day":3,"floating":3,"day off":1,observed:2,"2027":1,"bank holiday":3}},
{id:"6.2",t:"Expense reimbursement limits",v:"v4 · Mar 1, 2026",s:["Meals while traveling are reimbursed up to $60 per day, with itemized receipts for anything over $25.","Hotels are reimbursed up to $220 per night unless a higher rate was approved before booking.","Claims are submitted in the HR system within 30 days of the expense and paid with the next payroll after manager approval."],a:[0,1,2],k:{meal:4,meals:4,food:3,dinner:3,lunch:2,hotel:4,expense:3,expenses:3,reimburs:4,receipt:3,receipts:3,travel:2,traveling:2,limit:2,per:1,claim:2,"per diem":4}},
{id:"6.4",t:"Mileage",v:"v4 · Mar 1, 2026",s:["Business driving in a personal car is reimbursed at the IRS standard mileage rate for business use in effect on the date of travel.","Driving between home and your usual workplace is not reimbursed."],a:[0,1],k:{mileage:5,miles:4,drive:2,driving:2,car:2,gas:2,fuel:2,commute:3}},
{id:"7.1",t:"Pay schedule",v:"v3 · Jan 1, 2026",s:["Employees are paid every other Friday by direct deposit.","Timesheets for hourly employees are due by 10:00 local time on the Monday after the pay period ends.","When payday falls on a company holiday, you are paid on the business day before."],a:[0,2],k:{payday:5,"pay day":5,paid:2,"get paid":3,paycheck:4,"direct deposit":3,timesheet:4,biweekly:2,salary:1,"when is":1}},
{id:"7.3",t:"Pay stubs, W-2 and W-4",v:"v3 · Jan 1, 2026",s:["Pay stubs are available in the HR system on each payday.","Form W-2 is available electronically by January 31 for the previous year.","To change federal withholding, submit a new Form W-4 in the HR system. It applies from the next payroll processed after submission."],a:[2],k:{"w-4":5,w4:5,withholding:5,"tax":2,"w-2":5,w2:5,"pay stub":3,paystub:3,payslip:3,"tax form":3}},
{id:"8.1",t:"Benefits enrollment",v:"v5 · Nov 1, 2026",s:["Open enrollment runs each November for coverage that starts on January 1.","New hires enroll within 30 days of their start date, with coverage from the first of the following month.","A qualifying life event, such as marriage or the birth of a child, allows changes within 30 days of the event."],a:[0,1,2],k:{enroll:4,enrollment:4,"open enrollment":5,benefits:3,medical:1,dental:3,vision:3,insurance:3,coverage:3,"life event":4,married:2,baby:2}},
{id:"8.4",t:"Parental leave",v:"v5 · Nov 1, 2026",s:["Employees with six months of service receive eight weeks of paid parental leave after the birth, adoption or foster placement of a child.","Leave is taken within twelve months of the event, in up to two blocks."],a:[0,1],k:{parental:5,maternity:4,paternity:4,adoption:4,"new baby":3,"having a baby":3,foster:3}},
{id:"9.2",t:"Remote work",v:"v2 · Feb 1, 2026",s:["Office roles may work remotely up to two days a week with their manager's approval.","Depot and driving roles are on site.","Working from outside the United States is not covered by this policy."],a:[0,1],k:{remote:5,"work from home":5,wfh:5,hybrid:4,"from home":4}}]},
R:{name:"Handbook R",co:"Company R, retail, 3,200 hourly staff",cl:[
{id:"2.3",t:"Meal and rest breaks",v:"v9 · Feb 1, 2026",s:["Shifts longer than six hours include an unpaid 30-minute meal break.","Where state law sets a different break rule, the state rule applies."],a:[0,1],k:{break:5,breaks:5,lunch:3,meal:3,rest:2,"30 minute":2}},
{id:"3.1",t:"Shift swaps",v:"v9 · Feb 1, 2026",s:["Shift swaps are arranged in the scheduling app.","The store manager must approve a swap at least 24 hours before the shift starts."],a:[0,1],k:{swap:5,"trade shift":5,"switch shift":5,"cover my shift":4,schedule:2,shift:2}},
{id:"4.2",t:"Paid time off for hourly staff",v:"v9 · Feb 1, 2026",s:["Hourly employees accrue one hour of PTO for every 30 hours worked.","Balances are capped at 80 hours. At the cap, accrual pauses until the balance drops below 80.","Unused hours do not expire and carry over from year to year up to the cap."],a:[0,1,2],k:{pto:2,accru:3,"carry over":4,carryover:4,"roll over":4,unused:3,cap:3,expire:3,vacation:2,"time off":2,"next year":2}},
{id:"4.4",t:"Holiday pay",v:"v9 · Feb 1, 2026",s:["Hours worked on New Year's Day, Memorial Day, Independence Day and Labor Day are paid at 1.5 times the regular rate.","Stores are closed on Thanksgiving Day and Christmas Day."],a:[0,1],k:{holiday:4,holidays:4,"holiday pay":5,christmas:3,thanksgiving:3,"time and a half":4,closed:2,"new year":3}},
{id:"5.1",t:"Employee discount",v:"v9 · Feb 1, 2026",s:["Employees receive 20% off regular-price items in store and online.","The discount does not apply to gift cards."],a:[0,1],k:{discount:5,"staff discount":5,"gift card":3,shopping:2}},
{id:"6.1",t:"Mileage and uniforms",v:"v9 · Feb 1, 2026",s:["Driving between stores at a manager's request is reimbursed at the IRS standard mileage rate for business use, claimed within 30 days.","Two uniform shirts are issued at hire and replaced when worn."],a:[0,1],k:{mileage:4,expense:3,expenses:3,reimburs:4,uniform:4,shirt:3,drive:2,receipt:2}},
{id:"7.1",t:"Pay schedule",v:"v9 · Feb 1, 2026",s:["Employees are paid weekly by direct deposit every Thursday, or onto a paycard if they choose.","When payday falls on a store holiday, pay arrives on the business day before."],a:[0,1],k:{payday:5,"pay day":5,paid:2,"get paid":3,paycheck:4,paycard:4,weekly:2,"direct deposit":3}},
{id:"7.2",t:"Missing hours and pay corrections",v:"v9 · Feb 1, 2026",s:["Report missing hours to your store manager within seven days of payday.","Corrections are paid on the next weekly payday, or off-cycle within two business days when more than $50 is missing."],a:[0,1],k:{missing:5,"short paid":5,underpaid:5,correction:4,wrong:2,overtime:3,"not paid":4}},
{id:"8.1",t:"Benefits eligibility",v:"v9 · Feb 1, 2026",s:["Employees who average 30 or more hours a week over the measurement period are offered medical coverage.","Eligibility is reviewed each year before open enrollment in November."],a:[0,1],k:{benefits:4,medical:1,insurance:4,eligible:4,eligibility:4,"health plan":4,"open enrollment":4,"30 hours":3,coverage:3}}]}};

/* sensitive topics: never answered, routed to a person */
const SENS=[/harass/,/discriminat/,/retaliat/,/accommodat/,/disabilit/,/pregnan/,/medical leave/,/\bfmla\b/,/sick leave for (my|a) (condition|surgery)/,/mental health/,/depress/,/anxiety/,/\babuse/,/assault/,/bully/,/unsafe/,/threat/,/injur/,/complain/,/whistle/,/lawyer|attorney|\bsue\b|lawsuit/,/\bfired\b|terminat|dismiss/,/disciplin/,/immigration|visa status/,/suicid|self-harm|hurt myself/,/racis|sexis/];
/* personal look-ups: need a signed-in identity, which this page does not have */
const PERS=[/\bmy (pto )?balance\b/,/how (many|much) (pto|hours|days|vacation)[^?]*(do i|have i|i have)/,/\bmy (pay ?stub|payslip|salary|paycheck)\b/,/how much (do|did) i (get paid|earn|make)/,/\bmy (benefits|plan) (is|are)\b/];
const STOP=new Set("a an the i me my we our you your is are am do does did can could would should will to of for on in at and or if it this that be with what when where how which who much many any there".split(" "));
const norm=s=>" "+s.toLowerCase().replace(/[’']/g,"'").replace(/[^a-z0-9$'\- ]+/g," ").replace(/\s+/g," ").trim()+" ";
function score(q,c){let n=0,hit=[];for(const k in c.k){const kk=k.includes(" ")||k.includes("-")?" "+k:" "+k;if(q.includes(kk)){n+=c.k[k];hit.push(k)}}
/* words of the title count a little too */
c.t.toLowerCase().split(/\W+/).forEach(w=>{if(w.length>3&&!STOP.has(w)&&q.includes(" "+w.slice(0,5))&&!hit.some(h=>h.includes(w.slice(0,5)))){n+=1;hit.push(w)}});return[n,hit]}
function ask(hbk,raw){const q=norm(raw);
if(SENS.some(r=>r.test(q)))return{kind:"sens"};
if(PERS.some(r=>r.test(q)))return{kind:"pers"};
const hb=HB[hbk],r=hb.cl.map(c=>{const[n,h]=score(q,c);return{c,n,h}}).sort((a,b)=>b.n-a.n),top=r[0],nx=r[1];
if(!top||top.n<3)return{kind:"none",near:top&&top.n>0?top.c:null};
const lvl=top.n>=6&&top.n-nx.n>=3?"high":top.n>=4&&top.n-nx.n>=1?"medium":"low";
if(lvl==="low")return{kind:"none",near:top.c};
const st=top.h.map(h=>h.slice(0,5)),pick=top.c.a.filter(i=>(top.c.core||[]).includes(i)||st.some(x=>top.c.s[i].toLowerCase().includes(x)));
return{kind:"ans",c:top.c,lvl,used:pick.length?pick:top.c.a,alt:lvl==="medium"&&nx.n>=3?nx.c:null}}

function bot(root){const log=$("[data-bot-log]",root),go=$("[data-bot-go]",root),inp=$("[data-bot-q]",root),err=$("[data-bot-err]",root),sel=$("[data-bot-hb]",root),
clause=$("[data-bot-clause]",root),conf=$("[data-bot-conf]",root),meter=$("[data-bot-meter]",root),confT=$("[data-bot-conf-t]",root),hr=$("[data-bot-hr]",root),clr=$("[data-bot-clear]",root);
const EMPTY=clause.innerHTML;let n=0,last=null,ticket=1040;
const t=()=>{const d=new Date();return d.toTimeString().slice(0,5)};
const hbName=()=>HB[sel.value].name;
function greet(){log.innerHTML='<li class="pc-m pc-m--sys"><span class="pc-m__t">'+esc(hbName())+'</span><p>Ask about PTO, pay, holidays or expenses. Answers come only from '+esc(HB[sel.value].co)+', a synthetic employer.</p></li>'}
function add(side,who,html,tag){const tg=tag?'<span class="pc-tg pc-tg--'+tag[1]+'">'+esc(tag[0])+"</span>":"";const li=document.createElement("li");
li.className="pc-m pc-m--"+side+(RM?"":" is-new");li.innerHTML=side==="sys"?'<span class="pc-m__t">'+esc(who)+"</span><p>"+html+"</p>"+tg:'<p class="pc-m__h"><span>'+esc(who)+"</span><span>"+t()+'</span></p><div class="pc-m__b">'+html+"</div>"+tg;
log.appendChild(li);log.scrollTop=log.scrollHeight}
function showClause(c,used){const hb=hbName();clause.innerHTML='<p class="pc-clause__id"><b>'+esc(hb)+" "+c.id+"</b> "+esc(c.t)+'</p><p class="pc-clause__t">'+c.s.map((x,i)=>used.includes(i)?"<mark>"+esc(x)+"</mark>":esc(x)).join(" ")+'</p><p class="pc-clause__v">'+esc(c.v)+" · Source: "+esc(hb)+", section "+c.id+"</p>"}
function setConf(l){if(!l){conf.hidden=true;return}conf.hidden=false;const m={high:[92,"High: one clause answers this, with no conflict."],medium:[58,"Medium: a clause covers part of this. Check with HR if your case is unusual."],low:[18,"Low: no clause fits. Nothing was guessed."],route:[0,"Not answered: this topic always goes to a person."]}[l];
meter.style.width=m[0]+"%";meter.parentNode.className="pc-meter pc-meter--"+l;confT.textContent=m[1]}
function run(raw){err.hidden=true;inp.removeAttribute("aria-invalid");const q=raw.trim();
if(!q){err.textContent="Type a question first, or pick one of the suggestions.";err.hidden=false;inp.setAttribute("aria-invalid","true");inp.focus();return}
if(q.length<4||!/[a-z]{2}/i.test(q)){err.textContent="That is too short to look up. Try a full question, such as: how many PTO hours carry over?";err.hidden=false;inp.setAttribute("aria-invalid","true");return}
n++;add("in","You",'<p>'+esc(q)+"</p>");const r=ask(sel.value,q);last={q,r};hr.disabled=false;clr.disabled=false;hr.textContent="Send this to HR";
if(r.kind==="sens"){add("out","Policy Bot","<p>Thank you for telling us. This is something a person on the HR team should handle, so the bot does not answer it. In the product your message would go privately to HR, and someone would contact you within one working day. If anyone is in immediate danger, contact local emergency services first.</p>",["Routed to a person","bad"]);
clause.innerHTML='<p class="pc-empty">No clause is cited for sensitive topics. They are routed, not answered.</p>';setConf("route");hr.textContent="Sent to HR automatically";hr.disabled=true}
else if(r.kind==="pers"){add("out","Policy Bot","<p>Your own balance or pay needs a signed-in identity, which this page does not have. In the product the bot checks who you are on that channel, reads only your record within your role, and writes the look-up to the audit log.</p>",["Needs sign-in","warn"]);
clause.innerHTML='<p class="pc-empty">Personal look-ups read the HR system, not the handbook, so there is no clause to show.</p>';setConf(null)}
else if(r.kind==="none"){add("out","Policy Bot","<p>I could not find a clear answer to that in "+esc(hbName())+". I have not guessed."+(r.near?" The closest section is "+r.near.id+", "+esc(r.near.t.toLowerCase())+", which does not settle it.":"")+" Shall I send your question to HR?</p>",["Low confidence","warn"]);
if(r.near)showClause(r.near,[]);else clause.innerHTML='<p class="pc-empty">No clause matched. Nothing is cited when nothing fits.</p>';setConf("low")}
else{const c=r.c,ans=r.used.map(i=>esc(c.s[i])).join(" ");
add("out","Policy Bot","<p>"+ans+(r.lvl==="medium"?" If your situation is unusual, check with HR.":"")+'</p><span class="pc-cite-c"><b>'+esc(hbName().replace("Handbook ","HB "))+" "+c.id+"</b> "+esc(c.t)+"</span>"+(r.alt?'<p class="pc-m__alt">Also related: section '+r.alt.id+", "+esc(r.alt.t.toLowerCase())+".</p>":""),r.lvl==="high"?["High confidence","ok"]:["Medium confidence","warn"]);
showClause(c,r.used);setConf(r.lvl)}
inp.value=""}
go.addEventListener("click",()=>run(inp.value));inp.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();run(inp.value)}});
$$("[data-q]",root).forEach(b=>b.addEventListener("click",()=>{inp.value=b.dataset.q;run(b.dataset.q)}));
hr.addEventListener("click",()=>{if(!last)return;ticket++;add("sys","HR queue","Case <b>HR-"+ticket+"</b> opened with your question, the answer given and the clause. A person replies within one working day. (Synthetic)",["Handed to HR","mute"]);hr.disabled=true;hr.textContent="Sent to HR"});
clr.addEventListener("click",()=>{greet();clause.innerHTML=EMPTY;setConf(null);last=null;hr.disabled=true;clr.disabled=true;hr.textContent="Send this to HR";inp.focus()});
sel.addEventListener("change",()=>{greet();clause.innerHTML=EMPTY;setConf(null);last=null;hr.disabled=true;clr.disabled=true});
greet()}

/* ---------- home workspace: one PTO question, four steps */
function play(root){const out=$("[data-play-out]",root),next=$("[data-play-next]",root),rep=$("[data-play-replay]",root),btns=$$("[data-step]",root),cnt=$("[data-play-n]",root);let s=0,k=0;
const chip='<span class="pc-cite-c"><b>HB K 4.3</b> Carryover of unused PTO</span>';
const M=[['in','Employee 0412','09:02','<p>Can I carry over the PTO I have not used this year?</p>',null],
['out','Peoplecairn','09:02','<p>Yes, up to 40 hours carry into next year. Anything above 40 is forfeited on December 31, and carried hours need to be used by March 31.</p>'+chip,['High confidence','ok']],
['in','Employee 0412','09:03','<p>How many hours do I have?</p>',null],
['sys','','09:03','Identity confirmed by workplace sign-in. PTO balance read for <b>Employee 0412</b> only. Logged.',['Self only','ok']],
['out','Peoplecairn','09:03','<p>You have <b>52.0 hours</b>. 40 will carry over, so <b>12 hours</b> would be forfeited if not used by December 31. Want me to request Monday and Tuesday, December 28 and 29?</p>',null],
['in','Employee 0412','09:04','<p>Yes please.</p>',null],
['sys','','09:04','Request <b>R-2291</b>: 12 hours PTO, Dec 28 and 29. Notice rule in HB K 4.5 checked. Sent to the line manager for approval.',['Waiting for manager','warn']]];
const upto=[1,2,5,7];
function li(m,isNew){const tg=m[4]?'<span class="pc-tg pc-tg--'+m[4][1]+'">'+m[4][0]+"</span>":"";const c=isNew?" is-new":"";
return m[0]==="sys"?'<li class="pc-m pc-m--sys'+c+'"><span class="pc-m__t">'+m[2]+"</span><p>"+m[3]+"</p>"+tg+"</li>":'<li class="pc-m pc-m--'+m[0]+c+'"><p class="pc-m__h"><span>'+m[1]+"</span><span>"+m[2]+'</span></p><div class="pc-m__b">'+m[3]+"</div>"+tg+"</li>"}
function draw(anim){k++;const n=upto[s],prev=anim?upto[Math.max(0,s-1)]:n;out.dataset.run=k;
out.innerHTML=M.slice(0,n).map((m,i)=>li(m,anim&&!RM&&i>=prev)).join("");btns.forEach((b,i)=>{if(i===s)b.setAttribute("aria-current","step");else b.removeAttribute("aria-current");b.classList.toggle("is-done",i<s)});
cnt.textContent="Step "+(s+1)+" of "+btns.length;next.textContent=s>=btns.length-1?"Start again":"Next step"}
let tm=0;const stop=()=>{clearTimeout(tm);tm=0};
next.addEventListener("click",()=>{stop();if(s<btns.length-1){s++;draw(1)}else{s=0;draw(0)}});
rep.addEventListener("click",()=>{stop();if(RM){s=btns.length-1;draw(0);return}s=0;draw(0);const go=()=>{if(s<btns.length-1){s++;draw(1);tm=setTimeout(go,1100)}else tm=0};tm=setTimeout(go,300)});
btns.forEach((b,i)=>b.addEventListener("click",()=>{stop();const a=i>s;s=i;draw(a)}));draw(0)}

function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
/* hero rail follows the active shot of the hero loop (three shots of 9 s); static when the loop does not play */
function rail(r){const v=$("[data-cn-vid]"),li=$$("li",r);if(!v||li.length<3)return;let on=0;
v.addEventListener("timeupdate",()=>{const i=Math.floor((v.currentTime||0)/9)%3;if(i!==on){on=i;li.forEach((x,j)=>x.classList.toggle("is-on",j===i))}})}
export function boot(){scrollers();$$("[data-pc-rail]").forEach(rail);$$("[data-pc=bot]").forEach(bot);$$("[data-pc=play]").forEach(play)}
