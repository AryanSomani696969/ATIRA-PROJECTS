/* Creoiq page tools. Everything runs in this browser; nothing is sent anywhere.
   data-cq=score   Creative Scorer. A sample product's three ad variants are scored on hook clarity, offer prominence,
                   visual focus and brand fit with weights from a sample brand history, minus a text-load penalty. Rank
                   reorders the tiles into the predicted order, gives each one its reasons, holds a variant whose claim is
                   not on the approved list, says when the top pair is too close to call and suggests the test.
                   Tiles toggle in and out of the ranking; arrow keys move between them; Replay runs the reshuffle again.
   data-cq=plan    Sample-size planner: two-sided test of two proportions at 80% power, Bonferroni for k > 2. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[c]);
const FX={hook:"Hook clarity",offer:"Offer prominence",focus:"Visual focus",fit:"Brand fit"};

function scorer(root){
 const D=JSON.parse($("[data-s-data]",root).textContent),sel=$('[data-s="p"]',root),grid=$("[data-s-grid]",root),out=$("[data-s-out]",root),C=root.hasAttribute("data-compact");
 let ranked=false,timer=0,reps=0;
 const items=()=>$$(".cq-sc__c",grid);
 function flip(fn){const els=items(),a=new Map(els.map(e=>[e,e.getBoundingClientRect()]));fn();if(RM)return;
  els.forEach(e=>{const b=e.getBoundingClientRect(),r=a.get(e);const dx=r.left-b.left,dy=r.top-b.top;if(!dx&&!dy)return;
   e.style.transition="none";e.style.transform="translate("+dx+"px,"+dy+"px)";requestAnimationFrame(()=>{requestAnimationFrame(()=>{e.style.transition="transform .6s cubic-bezier(.22,1,.36,1)";e.style.transform=""})})})}
 function load(k){reps=0;const tpl=$('template[data-s-tpl="'+k+'"]',root);grid.innerHTML="";grid.appendChild(tpl.content.cloneNode(!0));ranked=!1;idle()}
 function idle(t){out.innerHTML='<p class="cq-sc__k">Predicted order</p><p class="cq-sc__e'+(t?" cq-sc__e--err":"")+'">'+(t||"Press Rank to see the predicted order and the reasons behind it.")+"</p>"}
 function score(P,v,inc){const w=P.w,m={};Object.keys(FX).forEach(f=>{m[f]=inc.reduce((s,x)=>s+x.f[f],0)/inc.length});
  let s=0;Object.keys(FX).forEach(f=>{s+=w[f]*v.f[f]});s=Math.round(s*10-2*v.load);
  const c=Object.keys(FX).map(f=>[f,w[f]*(v.f[f]-m[f])]).sort((a,b)=>b[1]-a[1]);
  const pros=c.filter(x=>x[1]>.05).slice(0,2).map(x=>x[0]),con=c[c.length-1][1]<-.05?c[c.length-1][0]:null;
  const held=!!v.claim&&!D.ok.includes(v.claim);return{v,s,pros,con,held}}
 function rank(){const k=sel.value,P=D.p[k],inc=P.v.filter(v=>{const b=$('[data-pick="'+v.id+'"]',grid);return b&&b.getAttribute("aria-pressed")==="true"});
  if(inc.length<2){unrank();idle("Choose at least two variants to rank. Select a tile to put it back in.");return}
  const R=inc.map(v=>score(P,v,inc)).sort((a,b)=>(a.held-b.held)||(b.s-a.s));
  flip(()=>{R.forEach(r=>grid.appendChild($('.cq-sc__c[data-v="'+r.v.id+'"]',grid)));P.v.filter(v=>!inc.includes(v)).forEach(v=>grid.appendChild($('.cq-sc__c[data-v="'+v.id+'"]',grid)))});
  items().forEach(li=>{const r=R.find(x=>x.v.id===li.dataset.v),rk=$("[data-rk]",li),n=r?R.indexOf(r):-1;
   li.classList.toggle("is-held",!!(r&&r.held));li.classList.toggle("is-win",n===0&&!r.held);li.classList.toggle("is-top",!!r&&!r.held&&n===1);
   rk.textContent=!r?"":r.held?"Held":"#"+(n+1)+" · "+r.s});
  const ok=R.filter(r=>!r.held),b=P.band;
  let h='<p class="cq-sc__k">Predicted order · '+esc(P.n)+"</p><ol class=\"cq-sc__l\">";
  R.forEach((r,i)=>{h+='<li class="'+(r.held?"is-held":i===0?"is-win":"")+'"><p class="cq-sc__r"><b>'+(r.held?"Held":"#"+(i+1))+"</b><span>Variant "+r.v.id+'</span><span class="cq-mono">'+r.s+" ±"+b+"</span></p>";
   if(r.held)h+='<p class="cq-sc__w cq-sc__w--flag">The claim "'+esc(r.v.claim)+'" is not on the approved claims list. This variant cannot be tested until the claim is removed or approved.</p>';
   if(!C||i<1||r.held){h+='<ul class="cq-sc__why">'+r.pros.map(f=>"<li><b>"+FX[f]+".</b> "+esc(r.v.notes[f])+"</li>").join("")+(r.con?'<li class="is-con"><b>'+FX[r.con]+".</b> "+esc(r.v.notes[r.con])+"</li>":"")+(r.v.load>=5?'<li class="is-con"><b>Text load.</b> Heavy text on the tile costs points at phone size.</li>':"")+"</ul>"}
   h+="</li>"});h+="</ol>";
  if(ok.length>=2){const d=ok[0].s-ok[1].s;h+='<p class="cq-sc__t"><b>Suggested test:</b> Variant '+ok[0].v.id+" against Variant "+ok[1].v.id+", 50/50 split, 14 days, cost per acquisition as the primary metric, read once at the end. "+
   (d<b?"The two are within ±"+b+" of each other, too close to call, which is why they are the pair worth testing.":"Variant "+ok[0].v.id+" leads by "+d+" points. The ranking is only a starting order; the test decides.")+"</p>"}
  else h+='<p class="cq-sc__t"><b>No test yet:</b> only one variant can be tested. Approve or edit the held variant first.</p>';
  if(reps)h+='<p class="cq-sc__n">Replay '+reps+': the same inputs give the same order, so the ranking is repeatable.</p>';h+='<p class="cq-sc__n">'+esc(P.why)+" Based on "+P.hist+" past ads in the sample history, so each score carries a band of ±"+b+".</p>";
  out.innerHTML=h;ranked=!0}
 function unrank(){const k=sel.value,P=D.p[k];flip(()=>{P.v.forEach(v=>{const li=$('.cq-sc__c[data-v="'+v.id+'"]',grid);if(li)grid.appendChild(li)})});
  items().forEach(li=>{li.classList.remove("is-held","is-win","is-top");$("[data-rk]",li).textContent=""});ranked=!1}
 sel.addEventListener("change",()=>{clearTimeout(timer);load(sel.value)});
 $("[data-s-rank]",root).addEventListener("click",()=>{clearTimeout(timer);rank()});
 $("[data-s-replay]",root).addEventListener("click",()=>{clearTimeout(timer);reps++;unrank();idle("Reshuffling the tiles.");timer=setTimeout(rank,RM?0:650)});
 grid.addEventListener("click",e=>{const b=e.target.closest("[data-pick]");if(!b)return;const on=b.getAttribute("aria-pressed")!=="true";b.setAttribute("aria-pressed",on);
  b.setAttribute("aria-label","Variant "+b.dataset.pick+(on?", included in the ranking":", left out of the ranking"));b.closest("li").classList.toggle("is-out",!on);
  if(ranked)rank();else if(!on&&$$('[data-pick][aria-pressed="true"]',grid).length<2)idle("Choose at least two variants to rank. Select a tile to put it back in.");else idle()});
 grid.addEventListener("keydown",e=>{const keys={ArrowRight:1,ArrowDown:1,ArrowLeft:-1,ArrowUp:-1};if(!(e.key in keys))return;const bs=$$("[data-pick]",grid),i=bs.indexOf(document.activeElement);if(i<0)return;
  e.preventDefault();bs[(i+keys[e.key]+bs.length)%bs.length].focus()})}

/* inverse standard normal (Acklam) */
function qnorm(p){const a=[-39.6968302866538,220.946098424521,-275.928510446969,138.357751867269,-30.6647980661472,2.50662827745924],b=[-54.4760987982241,161.585836858041,-155.698979859887,66.8013118877197,-13.2806815528857],
 c=[-.00778489400243029,-.322396458041136,-2.40075827716184,-2.54973253934373,4.37466414146497,2.93816398269878],d=[.00778469570904146,.32246712907004,2.445134137143,3.75440866190742],pl=.02425;
 let q,r;if(p<pl){q=Math.sqrt(-2*Math.log(p));return(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5])/((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)}
 if(p>1-pl){q=Math.sqrt(-2*Math.log(1-p));return-(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5])/((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)}
 q=p-.5;r=q*q;return(((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q/(((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)}
function plan(root){const q=k=>$('[data-p="'+k+'"]',root),out=$("[data-p-out]",root),msg=$("[data-p-msg]",root),fmt=n=>Math.round(n).toLocaleString("en-US");
 const R={cr:[.1,50,"The baseline conversion rate must be between 0.1% and 50%."],mde:[2,100,"The lift must be between 2% and 100%."],d:[10,1e6,"Clicks per day must be between 10 and 1,000,000."]};
 function render(){const v={cr:parseFloat(q("cr").value),mde:parseFloat(q("mde").value),k:+q("k").value,a:+q("cl").value,d:parseFloat(q("d").value)};
  ["cr","mde","d"].forEach(k=>q(k).removeAttribute("aria-invalid"));
  for(const k of["cr","mde","d"]){if(!(v[k]>=R[k][0]&&v[k]<=R[k][1])){q(k).setAttribute("aria-invalid","true");out.innerHTML='<div class="cq-res cq-res--err"><p class="cq-res__s">No size yet</p><p class="cq-res__r">'+R[k][2]+"</p></div>";msg.textContent=R[k][2];return}}
  const p1=v.cr/100,p2=p1*(1+v.mde/100);if(p2>=1){q("mde").setAttribute("aria-invalid","true");const t="That lift would push the conversion rate past 100%. Lower the lift or the baseline.";out.innerHTML='<div class="cq-res cq-res--err"><p class="cq-res__s">No size yet</p><p class="cq-res__r">'+t+"</p></div>";msg.textContent=t;return}
  const aa=v.a/(v.k-1),za=qnorm(1-aa/2),zb=qnorm(.8),n=Math.ceil((za+zb)**2*(p1*(1-p1)+p2*(1-p2))/(p2-p1)**2),days=Math.ceil(n/v.d),conv=n*p1;
  msg.textContent=days>28?"Over four weeks. Long tests pick up seasonality and fatigue; consider a bolder variant or more traffic.":"";
  out.innerHTML='<div class="cq-res"><p class="cq-res__k">Clicks needed per variant</p><p class="cq-res__v"><b>'+fmt(n)+"</b><span>about "+fmt(conv)+" conversions in the control</span></p>"+
   '<dl class="cq-res__d"><div><dt>Variants</dt><dd>'+v.k+"</dd></div><div><dt>Total clicks</dt><dd>"+fmt(n*v.k)+"</dd></div><div><dt>Significance per comparison</dt><dd>"+(aa*100).toFixed(aa<.01?2:1)+"%</dd></div>"+
   "<div><dt>Days at "+fmt(v.d)+" clicks a day</dt><dd>"+fmt(days)+"</dd></div><div><dt>Read the result</dt><dd>once, on day "+fmt(days)+"</dd></div></dl></div>"}
 root.addEventListener("input",render);root.addEventListener("change",render);
 $("[data-p-reset]",root).addEventListener("click",()=>{$$(".inp",root).forEach(e=>{if(e.tagName==="SELECT")e.value=[...e.options].find(o=>o.defaultSelected).value;else e.value=e.defaultValue});render()});render()}

export function boot(){$$("[data-cq=score]").forEach(scorer);$$("[data-cq=plan]").forEach(plan);
 $$(".mv-pscroll").forEach(el=>{const f=()=>{if(el.scrollWidth>el.clientWidth+2){el.tabIndex=0;el.setAttribute("role","region");el.setAttribute("aria-label",el.dataset.label||"Scrollable table")}else{el.removeAttribute("tabindex")}};f();addEventListener("resize",f)})}
