/* Amlwarden page tools. Everything runs in the browser with no network calls.
   Case data comes from the inline <script id="aw-cases"> block written by gen/amlwarden/cases.py (synthetic cases only).
   [data-aw=lab]    Narrative Lab: pick a synthetic alert, tick or untick evidence, draft the narrative, click or arrow through
                    sentences to see their sources, then confirm or override the suggestion with a reason (audit log kept on the page)
   [data-aw=mini]   home walkthrough: the drafted narrative for the cash case, sentence to source
   [data-aw=count]  the hero counter (synthetic), still under reduced motion */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
let CASES=null;function data(){if(!CASES){const el=$("#aw-cases");try{CASES=el?JSON.parse(el.textContent):{}}catch(e){CASES={}}}return CASES}
const chips=ids=>ids.map(i=>'<span class="aw-chip">'+esc(i)+"</span>").join("");
const now=()=>{const d=new Date;return String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0")+":"+String(d.getSeconds()).padStart(2,"0")};

/* ---------- engine: sentences whose evidence is all included, and the suggestion */
function draft(c,inc){const sents=c.sents.filter(s=>s[1].every(e=>inc.has(e))).map(s=>({t:s[0],ev:s[1]}));
const miss=c.need.filter(e=>!inc.has(e));let sug=null;
if(!miss.length){const reasons=c.out[2].filter(r=>inc.has(r[0]));sug={label:c.out[0],kind:c.out[1],reasons}}
return{sents,miss,sug,dropped:c.sents.length-sents.length}}
function srcHtml(c,s){return s.ev.map(id=>{const e=c.ev.find(x=>x.id===id);return'<div class="aw-srcc"><p class="aw-srcc__h"><span class="aw-chip">'+esc(id)+"</span><b>"+esc(e.title)+"</b><small>"+esc(e.src)+'</small></p><p class="aw-srcc__d">'+esc(e.detail)+"</p></div>"}).join("")}
function listbox(lb,n,get,set){lb.addEventListener("keydown",e=>{let i=get();if(e.key==="ArrowDown"||e.key==="ArrowRight")i=(i+1)%n();else if(e.key==="ArrowUp"||e.key==="ArrowLeft")i=(i+n()-1)%n();else if(e.key==="Home")i=0;else if(e.key==="End")i=n()-1;else return;e.preventDefault();set(i)})}

/* ---------- Narrative Lab */
function lab(root){const out=$("[data-lab-out]",root),live=$("[data-lab-live]",root),evUl=$("[data-lab-ev]",root),alertP=$("[data-lab-alert]",root);
let key="cash",inc=new Set,D=null,sel=0,runs=0,log=[],decided=null;
const C=()=>data()[key];
function loadCase(){const c=C();if(!c){out.innerHTML='<div class="aw-err" role="alert"><b>The synthetic cases did not load.</b><p>Reload the page to try again.</p></div>';return}
inc=new Set(c.ev.map(e=>e.id));alertP.innerHTML='<span class="aw-id">'+esc(c.id)+"</span> "+esc(c.rule);
evUl.innerHTML=c.ev.map(e=>'<li data-ev="'+e.id+'"><input type="checkbox" id="lab-'+key+"-"+e.id+'" value="'+e.id+'" checked><label for="lab-'+key+"-"+e.id+'"><span class="aw-chip">'+e.id+"</span><b>"+esc(e.title)+"</b><small>"+esc(e.src)+"</small></label></li>").join("");
$$("input",evUl).forEach(cb=>cb.addEventListener("change",()=>{cb.checked?inc.add(cb.value):inc.delete(cb.value);if(D){run(!0)}else live.textContent=(cb.checked?"Included ":"Left out ")+cb.value}));
D=null;decided=null;log=[];empty()}
function empty(){out.innerHTML='<div class="aw-empty"><b>No draft yet.</b><p>Review the evidence on the left, leave out anything you like, then draft the narrative. Every sentence will show the evidence it was written from.</p></div>'}
function err(h,p){out.innerHTML='<div class="aw-err" role="alert"><b>'+esc(h)+"</b><p>"+esc(p)+"</p></div>";live.textContent=h}
function run(re){const c=C();if(!inc.has("E1")){D=null;err("The alert itself has to stay in.","Tick E1, the monitoring or screening alert. A narrative cannot start without it.");return}
if(inc.size<2){D=null;err("Not enough evidence to write from.","Tick at least one more item besides the alert.");return}
D=draft(c,inc);sel=0;runs++;decided=null;
log.push(["Narrative drafted · "+D.sents.length+" sentences from "+inc.size+" items","System",now(),!1]);
draw();live.textContent=(re?"Redrafted: ":"Draft "+runs+": ")+D.sents.length+" sentences"+(D.dropped?", "+D.dropped+" left out for missing evidence":"")+". "+(D.sug?"Suggestion: "+D.sug.label+".":"No suggestion.")}
function draw(){const c=C();
const ls=D.sents.map((s,i)=>'<li role="option" id="lab-s'+i+'" aria-selected="'+(i===sel)+'" data-i="'+i+'"><span class="aw-s__n">'+(i+1)+'</span><span class="aw-s__t">'+esc(s.t)+" "+chips(s.ev)+"</span></li>").join("");
const sug=D.sug?'<p class="aw-disp__v aw-disp__v--'+D.sug.kind+'">'+esc(D.sug.label)+'</p><ul class="aw-disp__r">'+D.sug.reasons.map(r=>'<li><span class="aw-chip">'+esc(r[0])+"</span>"+esc(r[1])+"</li>").join("")+"</ul>"
:'<p class="aw-disp__v aw-disp__v--none">No suggestion</p><p class="aw-mute">The suggestion needs '+D.miss.map(m=>esc(m+" "+c.ev.find(e=>e.id===m).title)).join(" and ")+". Tick "+(D.miss.length>1?"them":"it")+" to get one.</p>";
const alt=D.sug&&D.sug.kind==="close"?"Escalate for further review":"Close, no further action";
out.innerHTML='<div class="aw-res"><p class="aw-run">Draft '+runs+" · "+esc(c.label)+" · "+inc.size+" of "+c.ev.length+" evidence items"+(D.dropped?" · "+D.dropped+" sentences not written":"")+"</p>"+
'<div class="aw-res__g"><div><p class="mv-mi" id="lab-nl">Narrative · '+esc(c.id)+'</p><ol class="aw-sents" role="listbox" tabindex="0" aria-labelledby="lab-nl" aria-activedescendant="lab-s0">'+ls+"</ol></div>"+
'<div><p class="mv-mi">Source of the selected sentence</p><div class="aw-src" data-src></div></div></div>'+
'<div class="aw-res__g aw-res__g--2"><div class="aw-dbox"><p class="mv-mi">Suggested disposition</p>'+sug+"</div>"+
'<div class="aw-dbox"><p class="mv-mi">Analyst decision</p><label class="aw-lab__l" for="lab-reason">Reason</label><select id="lab-reason" class="aw-sel"><option value="">Choose a reason</option><option>The evidence supports it</option><option>Customer explanation on file</option><option>Needs further review</option><option>Other, noted in the case</option></select>'+
'<div class="aw-dec"><button type="button" class="mv-btn mv-btn--acc" data-dec="confirm"'+(D.sug?"":" disabled")+">Confirm suggestion</button>"+'<button type="button" class="aw-btn2" data-dec="override">Override: '+esc(alt)+"</button></div><p class=\"aw-mute\" data-dec-msg aria-live=\"polite\"></p></div></div>"+
'<div class="aw-logw"><p class="mv-mi">Audit log · this session</p><ol class="aw-log" data-log></ol></div></div>';
const lb=$(".aw-sents",out);$$("li",lb).forEach(li=>li.addEventListener("click",()=>{pick(+li.dataset.i)}));listbox(lb,()=>D.sents.length,()=>sel,i=>pick(i));
$$("[data-dec]",out).forEach(b=>b.addEventListener("click",()=>decide(b.dataset.dec,alt)));
detail();logDraw()}
function pick(i){sel=i;const lb=$(".aw-sents",out);$$("li",lb).forEach((li,j)=>li.setAttribute("aria-selected",j===i));lb.setAttribute("aria-activedescendant","lab-s"+i);detail();
log.push(["Sentence "+(i+1)+" source viewed","Analyst",now(),!1]);logDraw();live.textContent="Sentence "+(i+1)+", cites "+D.sents[i].ev.join(", ")}
function detail(){const c=C(),s=D.sents[sel];$("[data-src]",out).innerHTML=s?srcHtml(c,s):'<p class="aw-mute">No sentences.</p>';
$$("li[data-ev]",evUl).forEach(li=>li.classList.toggle("is-cited",!!s&&s.ev.includes(li.dataset.ev)))}
function decide(kind,alt){const r=$("#lab-reason",out).value,msg=$("[data-dec-msg]",out);
if(!r){msg.textContent="Choose a reason first. Every decision is recorded with its reason.";$("#lab-reason",out).focus();return}
if(kind==="confirm"&&!D.sug){msg.textContent="There is no suggestion to confirm.";return}
const label=kind==="confirm"?D.sug.label:alt;decided=label;
log.push([(kind==="confirm"?"Suggestion confirmed: ":"Suggestion overridden: ")+label,"Analyst · reason: "+r.toLowerCase(),now(),!0]);logDraw();
msg.textContent="Recorded: "+label+". In the product this would go to your approval rules; nothing is filed automatically.";live.textContent="Decision recorded: "+label}
function logDraw(){const l=$("[data-log]",out);if(!l)return;l.innerHTML=log.slice(-6).reverse().map(x=>'<li class="'+(x[3]?"is-sig":"")+'"><b>'+esc(x[0])+"</b><small>"+esc(x[1])+'</small><span class="aw-t">'+esc(x[2])+"</span></li>").join("")}
$$("input[name=lab-case]",root).forEach(r=>r.addEventListener("change",()=>{key=r.value;loadCase();live.textContent="Loaded the "+C().label.toLowerCase()+" case. "+C().ev.length+" evidence items."}));
$("[data-lab-run]",root).addEventListener("click",()=>run(!1));
$("[data-lab-replay]",root).addEventListener("click",()=>{runs=0;loadCase();run(!1);live.textContent="Replayed from the start: all evidence ticked, a fresh draft and an empty audit log."});
loadCase();run(!1)}

/* ---------- home walkthrough */
function mini(root){const c=data()[root.dataset.case||"cash"],ol=$("[data-sents]",root),sec=root.closest("section"),src=sec&&$("[data-src]",sec);if(!c||!ol)return;
const D=draft(c,new Set(c.ev.map(e=>e.id)));let sel=-1;
ol.innerHTML=D.sents.map((s,i)=>'<li role="option" id="mini-s'+i+'" aria-selected="false" data-i="'+i+'"><span class="aw-s__n">'+(i+1)+'</span><span class="aw-s__t">'+esc(s.t)+" "+chips(s.ev)+"</span></li>").join("");
function pick(i,tog){if(tog&&i===sel){sel=-1;$$("li",ol).forEach(li=>li.setAttribute("aria-selected","false"));ol.removeAttribute("aria-activedescendant");if(src)src.innerHTML='<p class="aw-mute">Select a sentence to see its source evidence.</p>';return}
sel=i;$$("li",ol).forEach((li,j)=>li.setAttribute("aria-selected",j===i));ol.setAttribute("aria-activedescendant","mini-s"+i);if(src)src.innerHTML='<p class="mv-mi">Sentence '+(i+1)+" · source</p>"+srcHtml(c,D.sents[i])}
$$("li",ol).forEach(li=>li.addEventListener("click",()=>pick(+li.dataset.i,!0)));listbox(ol,()=>D.sents.length,()=>Math.max(sel,0),pick);
ol.addEventListener("focus",()=>{if(sel<0)pick(0)});pick(2)}

/* ---------- hero counter */
function count(el){const rm=matchMedia("(prefers-reduced-motion: reduce)").matches;if(rm)return;let n=+el.dataset.n||0;
setInterval(()=>{if(document.hidden)return;n+=Math.random()<.6?1:-1;el.textContent=n.toLocaleString("en-US")},2600)}

function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-aw=lab]").forEach(lab);$$("[data-aw=mini]").forEach(mini);$$("[data-aw=count]").forEach(count)}
