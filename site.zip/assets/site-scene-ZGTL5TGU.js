import{a as o}from"./c-KLNZNFFD.js";o["odra-room"]=()=>import("./c-D64KF5H7.js");
