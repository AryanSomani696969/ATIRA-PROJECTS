/* Irrigiq page tools. Everything runs offline in the browser and sends nothing:
   console - home console: Setup, Schedule and Ledger views switched by pressed buttons
   rain    - home demo: tomorrow's rain forecast shifts the plan, the held-back counter ticks up
   pump    - pump panel override: keep the plan, hold today, stop now, with a log
   ledger  - water ledger: plot picker, unit switch, redrawn chart and totals, CSV download
   est     - savings estimator: crop, area, method, practice, last season's water and pumping energy in, a range out
   plan    - sample daily plan: plot buttons and map, the reason for each line, an override with a safety limit
   filter  - status and guide filters
   scrollers - wide tables get keyboard focus only when they scroll */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const store={get(k){try{return JSON.parse(localStorage.getItem(k)||"null")}catch(e){return null}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}},del(k){try{localStorage.removeItem(k)}catch(e){}}};
const f1=n=>(Math.round(n*10)/10).toLocaleString("en-US",{minimumFractionDigits:1,maximumFractionDigits:1});
const f2=n=>n.toFixed(2);
const int=n=>Math.round(n).toLocaleString("en-US");
const now=()=>{const d=new Date();return String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0")};
function press(btns,on){btns.forEach(b=>b.setAttribute("aria-pressed",b===on?"true":"false"))}
function arrows(btns,cb){btns.forEach((b,i)=>b.addEventListener("keydown",e=>{let j=null;if(e.key==="ArrowRight"||e.key==="ArrowDown")j=(i+1)%btns.length;if(e.key==="ArrowLeft"||e.key==="ArrowUp")j=(i-1+btns.length)%btns.length;if(e.key==="Home")j=0;if(e.key==="End")j=btns.length-1;if(j!==null){e.preventDefault();btns[j].focus();cb(btns[j],j)}}))}
function count(el,to,ms=600){const from=parseFloat(el.dataset.v||"0");el.dataset.v=to;if(RM){el.textContent=f1(to);return}const t0=performance.now();const step=t=>{const k=Math.min(1,(t-t0)/ms),e=1-Math.pow(1-k,3);el.textContent=f1(from+(to-from)*e);if(k<1)requestAnimationFrame(step)};requestAnimationFrame(step)}
/* ------------------------------------------------------------------ console */
function consoleV(root){const bs=$$("[data-cv]",root);const pick=b=>{press(bs,b);bs.forEach(x=>{$("#"+x.dataset.cv).hidden=x!==b})};bs.forEach(b=>b.addEventListener("click",()=>pick(b)));arrows(bs,b=>pick(b))}
/* ------------------------------------------------------------------ rain demo */
function rain(root){const bs=$$("[data-rn]",root),rows=$$("tr[data-row]",root),c=$("[data-rn-c]",root),st=$("[data-rn-s]",root);
 const cell=(tr,wet)=>{const a=parseFloat(tr.dataset.in),r=parseFloat(tr.dataset.rin),td=$(".iq-pl",tr);if(!td.dataset.h)td.dataset.h=td.innerHTML;const ch=!!(wet&&a);tr.classList.toggle("is-chg",ch);
  if(!ch){td.innerHTML=td.dataset.h;return}td.innerHTML=r?'<b class="iq-st iq-st--run">'+f2(r)+' in</b><small>Cut for rain, starts '+esc(tr.dataset.start)+"</small>":'<b class="iq-st">No run</b><small>Rain covers it</small>'};
 const set=b=>{press(bs,b);const wet=b.dataset.rn==="wet";let held=0,runs=0,drop=0;rows.forEach(tr=>{cell(tr,wet);const a=parseFloat(tr.dataset.in),r=parseFloat(tr.dataset.rin),ac=+tr.dataset.ac;if(a){held+=wet?(a-r)*ac:0;if(!wet||r)runs++;else drop++}});
  count(c,held);st.textContent=wet?"Rain forecast for Thursday. "+runs+" plots still run, "+drop+" drop out and "+f1(held)+" acre-inches are held back.":"Dry forecast. "+runs+" plots run tonight."};
 bs.forEach(b=>b.addEventListener("click",()=>set(b)))}
/* ------------------------------------------------------------------ pump panel */
function pump(root){const bs=$$("[data-pp]",root),state=$("[data-pp-state]",root),log=$("[data-pp-log]",root);
 const T={run:["Scheduled, starts 03:40","Plan kept. Pump 1 will run A3, then A1."],hold:["Held for today","Pump 1 held for today by the farm manager. A3 and A1 move to the irrigator's list."],stop:["Stopped, manual control","Pump 1 stopped. Automation paused until you press Keep the plan."]};
 bs.forEach(b=>b.addEventListener("click",()=>{press(bs,b);const t=T[b.dataset.pp];state.textContent=t[0];const li=document.createElement("li");li.innerHTML="<time>"+now()+"</time>"+esc(t[1]);log.appendChild(li);while(log.children.length>5)log.firstElementChild.remove()}))}
/* ------------------------------------------------------------------ ledger */
const LED=[["Jun 2",1.9,1.8],["Jun 9",2.1,1.9],["Jun 16",2.3,1.9],["Jun 23",2.4,2.0],["Jun 30",2.4,2.1],["Jul 7",2.2,1.8],["Jul 14",2.0,1.6],["Jul 21",1.8,1.5]],KWH=28,FARM_AC=264;
function ledger(root){const sel=$("[data-lg-plot]",root),ub=$("[data-lg-u]",root),box=$("[data-lg-c]",root),ttl=$("[data-lg-t]",root),csv=$("[data-lg-csv]",root);let unit="in";
 const series=()=>{const o=sel.selectedOptions[0],id=sel.value,ac=id==="farm"?FARM_AC:+o.dataset.ac;let h=0;for(const ch of id)h=(h*31+ch.charCodeAt(0))%997;
  const fb=id==="farm"?1:.86+(h%25)/100,fa=id==="farm"?1:fb*(.9+(h%9)/100);return{id,ac,name:id==="farm"?"Whole farm":o.textContent.split(",").slice(0,2).join(","),rows:LED.map(([w,b,a],i)=>id==="farm"?[w,b,a]:[w,b*fb*(1+((h+i)%5-2)/100),Math.min(b*fb,a*fa*(1+((h+i*3)%5-2)/100))])}};
 const draw=()=>{const s=series(),k=unit==="af"?s.ac/12:1,u=unit==="af"?"acre-ft":"in";const rows=s.rows.map(([w,b,a])=>[w,b*k,a*k]);const mx=Math.max(...rows.map(r=>r[1]))*1.15;
  const W=900,H=240,x0=44,y0=200,sc=v=>v/mx*170;let g="";const ticks=[0,mx/2.3,mx/1.15].map(v=>Math.round(v*10)/10);
  ticks.forEach(v=>{g+='<path class="iq-cg" d="M'+(x0-6)+" "+(y0-sc(v)).toFixed(1)+"H"+(W-10)+'"/><text class="iq-ct" x="'+(x0-12)+'" y="'+(y0-sc(v)+4).toFixed(1)+'" text-anchor="end">'+f1(v)+"</text>"});
  rows.forEach(([w,b,a],i)=>{const x=x0+i*104;g+='<rect class="iq-cb" x="'+x+'" y="'+(y0-sc(b)).toFixed(1)+'" width="36" height="'+sc(b).toFixed(1)+'" rx="3"/><rect class="iq-ca" x="'+(x+39)+'" y="'+(y0-sc(a)).toFixed(1)+'" width="36" height="'+sc(a).toFixed(1)+'" rx="3"/><text class="iq-ct" x="'+(x+38)+'" y="'+(y0+20)+'" text-anchor="middle">'+w+"</text>"});
  const tb=rows.reduce((t,r)=>t+r[1],0),ta=rows.reduce((t,r)=>t+r[2],0),sv=tb-ta,kwh=(s.rows.reduce((t,r)=>t+r[1]-r[2],0))*s.ac*KWH;
  box.innerHTML='<svg class="iq-chart" viewBox="0 0 '+W+" "+H+'" role="img" aria-label="Bar chart: baseline and applied water by week for '+esc(s.name)+". Baseline "+f1(tb)+" "+u+", applied "+f1(ta)+", saved "+f1(sv)+'.">'+g+"</svg>";
  $('[data-lg="a"]',root).textContent=f1(ta)+" "+u;$('[data-lg="b"]',root).textContent=f1(tb)+" "+u;$('[data-lg="s"]',root).textContent=f1(sv)+" "+u;$('[data-lg="p"]',root).textContent=f1(sv/tb*100)+"% below baseline";
  $('[data-lg="e"]',root).textContent=int(Math.round(kwh/10)*10)+" kWh";ttl.textContent="Water ledger / "+s.name+", "+(unit==="af"?"acre-feet":"inches per acre")+" by week";return{s,rows,u}};
 sel.addEventListener("change",draw);ub.addEventListener("click",()=>{const on=ub.getAttribute("aria-pressed")!=="true";ub.setAttribute("aria-pressed",on);unit=on?"af":"in";draw()});
 csv.addEventListener("click",()=>{const{s,rows,u}=draw();const lines=["plot,week,baseline_"+u.replace("-","_")+",applied_"+u.replace("-","_")+",saved,data"].concat(rows.map(([w,b,a])=>[s.id,w+" 2026",b.toFixed(2),a.toFixed(2),(b-a).toFixed(2),"synthetic sample"].join(",")));
  const url=URL.createObjectURL(new Blob([lines.join("\n")+"\n"],{type:"text/csv"}));const a=document.createElement("a");a.href=url;a.download="irrigiq-sample-ledger-"+s.id+".csv";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  csv.lastChild.textContent="Downloaded";setTimeout(()=>{csv.lastChild.textContent="Download CSV"},1600)});draw()}
/* ------------------------------------------------------------------ savings estimator */
const CROP={almond:["almonds",42],walnut:["walnuts",36],pistachio:["pistachios",36],tomato:["processing tomatoes",26],onion:["onions",30],melon:["melons",24],other:["this crop",30]};
const PRAC={calendar:[.10,.20,"A fixed calendar"],feel:[.08,.16,"Scheduling by experience"],weekly:[.05,.10,"Weekly sensor checks"],et:[.02,.06,"ET-based scheduling"]};
const METH={drip:[1,"Drip"],micro:[1,"Micro-sprinkler"],pivot:[.9,"Center pivot"],flood:[.6,"Furrow or flood"]};
function est(root){const q=k=>$('[data-e="'+k+'"]',root),out=$("[data-e-out]",root),wh=$("[data-e-wh]",root);const KEY="iq-est";
 const saved=store.get(KEY);if(saved)Object.keys(saved).forEach(k=>{if(q(k))q(k).value=saved[k]});
 const hint=()=>{const c=CROP[q("crop").value];wh.textContent="Sample default for "+c[0]+" is "+c[1]+" inches. Replace it with your own meter or pump records."};
 const bad=(el,msg)=>{el.setAttribute("aria-invalid","true");out.innerHTML='<p class="iq-err" role="alert">'+esc(msg)+"</p>"};
 const run=()=>{["ac","w","k"].forEach(k=>q(k).removeAttribute("aria-invalid"));const ac=parseFloat(q("ac").value),w=parseFloat(q("w").value),k=parseFloat(q("k").value);
  if(!(ac>=1&&ac<=50000))return bad(q("ac"),"Enter an irrigated area between 1 and 50,000 acres.");if(!(w>=1&&w<=120))return bad(q("w"),"Enter last season's water between 1 and 120 inches per acre.");
  if(!(k>=0&&k<=400))return bad(q("k"),"Enter pumping energy between 0 and 400 kWh per acre-inch, or 0 for gravity-fed water.");
  store.set(KEY,{crop:q("crop").value,ac:q("ac").value,m:q("m").value,p:q("p").value,w:q("w").value,k:q("k").value});
  const P=PRAC[q("p").value],Mf=METH[q("m").value],lo=P[0]*Mf[0],hi=P[1]*Mf[0];const ilo=w*lo,ihi=w*hi,alo=ilo*ac,ahi=ihi*ac;
  const pos=v=>Math.min(100,v/.2*100);
  out.innerHTML='<p class="iq-k">Estimated range for one season</p><p class="iq-est__n">'+f1(ilo)+" to "+f1(ihi)+' in per acre<span>'+Math.round(lo*100)+" to "+Math.round(hi*100)+"% of the "+f1(w)+" inches applied last season</span></p>"+
   '<div class="iq-rg" aria-hidden="true"><i style="left:'+pos(lo)+"%;width:"+Math.max(2,pos(hi)-pos(lo))+'%"></i><span>0%</span><span>10%</span><span>20%</span></div>'+
   '<dl class="iq-kv iq-kv--out"><div><dt>Water, whole area</dt><dd>'+f1(alo/12)+" to "+f1(ahi/12)+" acre-feet</dd></div><div><dt>In gallons</dt><dd>"+f1(alo*27154/1e6)+" to "+f1(ahi*27154/1e6)+" million US gallons</dd></div>"+
   "<div><dt>Pumping energy</dt><dd>"+(k?int(alo*k)+" to "+int(ahi*k)+" kWh":"None entered, gravity-fed")+"</dd></div><div><dt>Area</dt><dd>"+int(ac)+" acres of "+esc(CROP[q("crop").value][0])+"</dd></div></dl>"+
   '<p class="iq-k" style="margin-top:18px">Assumptions used</p><ul class="iq-as"><li>'+esc(P[2])+" leaves "+Math.round(P[0]*100)+" to "+Math.round(P[1]*100)+"% of applied water to save in this estimator.</li><li>"+esc(Mf[1])+(Mf[0]<1?" can follow a plan less closely, so the range is cut to "+Math.round(Mf[0]*100)+"%.":" can follow a daily plan closely, so the range is kept.")+
   "</li><li>One acre-inch is taken as 27,154 US gallons, and energy follows water at "+f1(k)+" kWh per acre-inch.</li></ul>"};
 q("crop").addEventListener("change",()=>{q("w").value=CROP[q("crop").value][1];hint();run()});["ac","m","p","w","k"].forEach(k=>q(k).addEventListener("input",run));q("m").addEventListener("change",run);q("p").addEventListener("change",run);
 $("[data-e-reset]",root).addEventListener("click",()=>{store.del(KEY);q("crop").value="almond";q("ac").value=120;q("m").value="micro";q("p").value="calendar";q("w").value=42;q("k").value=30;hint();run();q("crop").focus()});
 hint();run()}
/* ------------------------------------------------------------------ sample plan */
function plan(root){const PL=JSON.parse($("script[data-pl]",root).textContent),bs=$$("[data-pb]",root),d=$("[data-pd]",root),mp=$$("[data-mp]",root),
 oin=$("[data-ov-in]",root),onote=$("[data-ov-note]",root),os=$("[data-ov-s]",root),log=$("[data-ov-log]",root);const ov={};let at=2;
 const line=i=>{const r=PL[i],o=ov[i],v=o?o.v:r[7];return v?f2(v)+" in"+(o?", changed":", "+r[8]):"No run"+(o?", changed":"")};
 const show=i=>{at=i;const r=PL[i],o=ov[i],v=o?o.v:r[7];press(bs,bs[i]);mp.forEach((g,j)=>g.classList.toggle("is-on",j===i));
  d.innerHTML='<p class="iq-k">'+esc(r[0])+" · "+esc(r[1])+", "+esc(r[2])+'</p><p class="iq-pd__n">'+(v?f2(v)+" in tonight":"No run tonight")+"<span>"+(v&&!o?"Starts "+esc(r[8])+", runs "+esc(r[9]):o?"Changed by the farm manager at "+esc(o.t):"Below the trigger")+"</span></p>"+
   '<dl class="iq-kv"><div><dt>Area</dt><dd>'+r[3]+" acres, "+esc(r[4].toLowerCase())+"</dd></div><div><dt>Depletion</dt><dd>"+r[5]+"% against a "+r[6]+"% trigger</dd></div>"+
   "<div><dt>Water</dt><dd>"+(v?f1(v*r[3])+" acre-inches":"None")+"</dd></div><div><dt>Reason</dt><dd>"+esc(o&&o.n?o.n:r[10])+"</dd></div></dl>";
  oin.value=v?f2(v):"0.00";onote.value=o?o.n:"";os.textContent=""};
 bs.forEach((b,i)=>b.addEventListener("click",()=>show(i)));arrows(bs,(b,i)=>show(i));mp.forEach((g,i)=>g.addEventListener("click",()=>{show(i);bs[i].focus()}));
 $("[data-ov-save]",root).addEventListener("click",()=>{const v=parseFloat(oin.value);oin.removeAttribute("aria-invalid");
  if(!(v>=0)){oin.setAttribute("aria-invalid","true");os.textContent="Enter the inches to apply tonight, 0 for no run.";return}
  if(v>1){oin.setAttribute("aria-invalid","true");os.textContent="Refused: "+f2(v)+" in is over the safety limit of 1.0 inch per day for this plot.";return}
  const r=PL[at];ov[at]={v,n:onote.value.trim(),t:now()};$("small",bs[at]).textContent=line(at);show(at);os.textContent="Saved. "+r[0]+" now gets "+(v?f2(v)+" in":"no run")+" tonight.";
  const li=document.createElement("li");li.innerHTML="<time>"+now()+"</time>"+esc(r[0]+": "+(v?f2(v)+" in":"no run")+(ov[at].n?". Note: "+ov[at].n:""));log.prepend(li)});
 $("[data-ov-undo]",root).addEventListener("click",()=>{if(!ov[at]){os.textContent="No override on "+PL[at][0]+" to undo.";return}delete ov[at];$("small",bs[at]).textContent=line(at);show(at);os.textContent="Back to the plan for "+PL[at][0]+"."});
 show(at)}
/* ------------------------------------------------------------------ filters */
function filter(root){const bs=$$("[data-f]",root),items=$$("[data-st]",root),st=$("[data-f-s]",root);
 bs.forEach(b=>{const n=$("[data-f-n]",b),k=b.dataset.f;n.textContent=k==="all"?items.length:items.filter(x=>x.dataset.st===k).length});
 const set=b=>{press(bs,b);const k=b.dataset.f;let c=0;items.forEach(x=>{const on=k==="all"||x.dataset.st===k;x.hidden=!on;if(on)c++});st.textContent="Showing "+c+" of "+items.length+"."};
 bs.forEach(b=>b.addEventListener("click",()=>set(b)))}
/* ------------------------------------------------------------------ scrollers */
function scrollers(){const fix=()=>$$(".mv-pscroll").forEach(el=>{if(el.scrollWidth>el.clientWidth+2){el.tabIndex=0;el.setAttribute("role","region");el.setAttribute("aria-label",el.dataset.label||"Table")}else{el.removeAttribute("tabindex");el.removeAttribute("role");el.removeAttribute("aria-label")}});fix();addEventListener("resize",fix)}
export function boot(){const map={console:consoleV,rain,pump,ledger,est,plan,filter};$$("[data-iq]").forEach(r=>{const f=map[r.dataset.iq];if(f)try{f(r)}catch(e){console.error(e)}});scrollers()}
