/* Dataroomiq page tools. Everything runs in the browser; nothing chosen or typed here leaves the page.
   [data-dq=quiz]  Readiness Quiz: stage, about twenty weighted questions, a live score ring, top three risks and a checklist
   [data-dq=mini]  five of the same questions on the home page with the same scoring
   [data-dq=sort]  home one-folder demo: fourteen synthetic file names classified into a seven-folder index, six flags ranked
   [data-dq=tabs]  tab sets (checklist stages, sample report flags) with arrow-key movement */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ---------- questions: id, area, weight, stages (s seed, a Series A, m acquisition), question, risk, fix */
const AREAS=["Corporate records","Cap table and equity","Intellectual property","Contracts","Financials and tax","Compliance and people"];
const Q=[
["c1",0,3,"sam","Do you have the certificate of incorporation and every amendment, as filed with the state?","Charter documents incomplete","Order certified copies of the charter and each amendment from the state of incorporation."],
["c2",0,3,"sam","Is there a signed board approval for every share issuance and option grant?","Issuances without approval","Match each issuance and grant to a signed consent; counsel drafts ratifications for any gaps."],
["c3",0,2,"am","Are board minutes and written consents for the last 24 months in one place?","Board records scattered","Collect minutes and consents into the corporate folder, dated and signed."],
["c4",0,1,"sam","Are annual state reports and franchise taxes filed and paid for every year?","State filings behind","Check good standing in each state where you are registered and file what is outstanding."],
["e1",1,3,"sam","Does the cap table reconcile to the stock ledger and the signed agreements, share by share?","Cap table does not reconcile","Reconcile every line of the cap table to a signed document and correct the ledger."],
["e2",1,3,"sam","Does the option pool on the cap table match the equity plan as approved?","Option pool mismatch","Compare the pool with the plan and its amendments; correct the cap table or approve an amendment."],
["e3",1,2,"sam","Was a 409A valuation dated within twelve months before each of your recent option grants?","Stale 409A valuation","Order a new 409A valuation before the next grants and ask counsel to review recent ones."],
["e4",1,2,"sam","For founder stock that vests, do you have proof that each 83(b) election was filed on time?","83(b) proof missing","Find the filed elections and the proof of mailing; if one was never filed, ask counsel."],
["e5",1,2,"sam","Are all SAFEs and convertible notes listed with their caps, discounts and conversion terms?","Convertibles missing from the count","Add every SAFE and note to the fully diluted cap table with its terms."],
["i1",2,3,"sam","Has every founder signed an IP assignment covering work done before incorporation?","Founder IP not assigned","Have each founder sign a technology assignment that covers pre-incorporation work."],
["i2",2,2,"sam","Has every employee and contractor signed an invention assignment agreement?","Employee or contractor IP gaps","Collect signed invention assignments from everyone who worked on the product."],
["i3",2,1,"am","Are the open-source licences in your product listed and reviewed?","Open-source licences unreviewed","Run a licence scan and have counsel review anything copyleft."],
["k1",3,2,"sam","Are your top customer and vendor contracts signed and filed in one place?","Key contracts missing or unsigned","Collect the signed versions of your top ten contracts and file them by counterparty."],
["k2",3,2,"am","Do you know which contracts need consent on a change of control or assignment?","Change-of-control consents unknown","List every contract with assignment or change-of-control terms and who must consent."],
["f1",4,2,"sam","Do you have monthly financial statements for the last twelve months, or since founding?","Monthly financials missing","Close the books monthly and keep income statement, balance sheet and cash flow by month."],
["f2",4,2,"am","Are your financial statements reviewed or audited by an outside accountant?","Financials not reviewed","Ask your accountant which level of review your next investor or buyer will expect."],
["f3",4,1,"sam","Are federal and state tax returns filed for every year the company has existed?","Tax returns outstanding","File outstanding returns with your accountant and keep the filed copies."],
["s1",5,2,"sam","If your financings relied on Regulation D, was a Form D filed for each one?","Securities filings unclear","Check SEC EDGAR for each round; counsel advises on any late filing and state notice filings."],
["s2",5,1,"sam","Do you have a privacy policy and a record of how customer personal data is handled?","Privacy records thin","Write down what personal data you hold, where and why, and publish a privacy policy that matches."],
["p1",5,1,"sam","Are offer letters signed, and is each worker's classification as employee or contractor documented?","Worker records incomplete","Collect signed offer letters and contractor agreements; review classification with counsel."]];
const ANS=[["1","Yes"],[".5","Partly"],["0","No"],[".25","Not sure"]];
const STW={s:{},a:{f1:3,k1:2},m:{k2:3,f2:3,k1:3}};
function applies(q,st){return q[3].includes(st)}
function wt(q,st){return STW[st][q[0]]||q[2]}
function score(ans,st){let s=0,w=0;Q.forEach(q=>{if(!applies(q,st))return;const v=ans[q[0]];const k=wt(q,st);w+=k;s+=k*(v==null?0:v)});return w?Math.round(s/w*100):0}
function band(n){return n>=85?"Ready to share":n>=70?"Close, a few fixes":n>=50?"Work to do":"Start with the basics"}
function ringHTML(n,label,sub){return '<div class="dq-ringw"><svg class="dq-rsvg" viewBox="0 0 120 120" width="148" height="148" aria-hidden="true" focusable="false"><circle class="dq-r0" cx="60" cy="60" r="50"/><circle class="dq-r1'+(n<50?" dq-r1--lo":"")+'" cx="60" cy="60" r="50" pathLength="100" stroke-dasharray="'+n+' 100" transform="rotate(-90 60 60)"/></svg><div class="dq-ringw__t"><b class="dq-num">'+n+'</b><span>'+esc(label)+'</span></div><p class="dq-ringw__s">'+esc(sub)+"</p></div>"}
function setRing(box,n,sub){const c=$(".dq-r1",box),b=$(".dq-num",box),s=$(".dq-ringw__s",box);if(!c){box.innerHTML=ringHTML(n,"of 100",sub);return}
c.setAttribute("stroke-dasharray",n+" 100");c.classList.toggle("dq-r1--lo",n<50);b.textContent=n;if(sub!=null)s.textContent=sub}

/* ---------- full quiz */
function quiz(root){const qbox=$("[data-qz-q]",root),out=$("[data-qz-out]",root),ringBox=$("[data-qz-ring]",root),live=$("[data-qz-live]",root);let ans={},st="seed",tm;
const S={seed:"s",a:"a",m:"m"};
function render(){const k=S[st];let h="";AREAS.forEach((a,ai)=>{const qs=Q.filter(q=>q[1]===ai&&applies(q,k));if(!qs.length)return;
h+='<section class="dq-qa"><h3 class="dq-qa__h"><span class="dq-id">'+String(ai+1).padStart(2,"0")+"</span>"+esc(a)+"</h3>";
qs.forEach(q=>{h+='<fieldset class="dq-q"><legend>'+esc(q[4])+'</legend><div class="dq-seg">'+ANS.map((o,j)=>{const id="qz-"+q[0]+"-"+j;const on=ans[q[0]]!=null&&String(ans[q[0]])===String(+o[0]);return '<input type="radio" id="'+id+'" name="qz-'+q[0]+'" value="'+o[0]+'"'+(on?" checked":"")+'><label for="'+id+'">'+o[1]+"</label>"}).join("")+"</div></fieldset>"});h+="</section>"});
qbox.innerHTML=h;update(!1)}
function update(say){const k=S[st],app=Q.filter(q=>applies(q,k)),done=app.filter(q=>ans[q[0]]!=null).length,n=score(ans,k);
setRing(ringBox,n,done?band(n)+" · "+done+" of "+app.length+" answered":"Answer to see your score");
if(!done){out.innerHTML='<div class="dq-empty"><b>No answers yet.</b><p>Pick an answer for each question. The score uses every question for your stage; unanswered questions count as no.</p></div>';return}
const risks=app.map(q=>({q,g:wt(q,k)*(1-(ans[q[0]]==null?0:ans[q[0]]))})).filter(r=>r.g>0).sort((a,b)=>b.g-a.g||a.q[1]-b.q[1]);
const top=risks.slice(0,3),rest=risks.slice(3);
let h='<p class="dq-mi">Top three risks</p>';
h+=top.length?'<ol class="dq-risks">'+top.map(r=>'<li><b>'+esc(r.q[5])+"</b><span>"+esc(AREAS[r.q[1]])+" · weight "+wt(r.q,k)+"</span><p>"+esc(r.q[6])+"</p></li>").join("")+"</ol>":'<p class="dq-ok">No open risks in your answers. Bring the documents and we check them.</p>';
if(rest.length)h+='<p class="dq-mi">Checklist · '+rest.length+' more</p><ul class="dq-ckl dq-ckl--q">'+rest.map(r=>'<li class="dq-ck dq-ck--x"><span class="dq-b" aria-hidden="true"></span><div><b>'+esc(r.q[5])+"</b><small>"+esc(r.q[6])+"</small></div></li>").join("")+"</ul>";
if(done<app.length)h+='<p class="dq-mute">'+(app.length-done)+" questions unanswered, counted as no.</p>";
out.innerHTML=h;if(say){clearTimeout(tm);tm=setTimeout(()=>{live.textContent="Score "+n+" of 100, "+band(n)+". Top risk: "+(top[0]?top[0].q[5]:"none")+"."},400)}}
qbox.addEventListener("change",e=>{const t=e.target;if(t.name&&t.name.startsWith("qz-")){ans[t.name.slice(3)]=parseFloat(t.value);update(!0)}});
$$("input[name=qz-stage]",root).forEach(r=>r.addEventListener("change",()=>{st=r.value;render();live.textContent="Stage changed. Questions updated."}));
$("[data-qz-reset]",root).addEventListener("click",()=>{ans={};render();live.textContent="Answers cleared.";const f=$("input[name=qz-stage]:checked",root);f&&f.focus()});
render()}

/* ---------- home mini quiz */
function mini(root){const box=$(".dq-ringw",root).parentNode,live=$("[data-mini-live]",root),ids=["e1","e2","i1","f1","s1"];
function run(say){let s=0,w=0;ids.forEach(id=>{const q=Q.find(x=>x[0]===id),r=$("input[name=mq-"+id+"]:checked",root),v=r?parseFloat(r.value):0;s+=q[2]*v;w+=q[2]});const n=Math.round(s/w*100);
setRing(box,n,band(n)+" · five questions");if(say)live.textContent="Starter score "+n+" of 100."}
root.addEventListener("change",()=>run(!0));run(!1)}

/* ---------- home one-folder demo */
const FILES=[["Cap Table FINAL v7 (2).xlsx",{pool:15e5}],["EIP 2025 amended.pdf",{reserve:125e4}],["Certificate of Incorporation - DE.pdf"],["bylaws_signed.pdf"],
["Board consent Apr 2026 grants.pdf",{grant:"2026-04-14"}],["PIIA founder 1.pdf"],["PIIA founder 2.pdf"],["SAFE investor A.pdf"],["SAFE investor B.pdf"],
["409A report Feb 2025.pdf",{val:"2025-02-03"}],["RSPA founder 3 May 2025.pdf",{rs:"2025-05-12"}],["P&L 2025 monthly.xlsx"],["MSA customer - signed.pdf"],["scan0034.pdf"]];
const FOLD=[["01","Corporate records",/incorporation|bylaws|board consent|minutes/i],["02","Equity and cap table",/cap table|eip|equity plan|409a|rspa|stock purchase/i],
["03","Intellectual property",/piia|assignment|ciiaa/i],["04","Material contracts",/msa|agreement - signed|customer/i],["05","Financials and tax",/p&l|balance|return|financial/i],
["06","Securities filings",/safe|form d|note/i],["07","People and policies",/offer|handbook|policy/i]];
function classify(name){const i=FOLD.findIndex(f=>f[2].test(name));return i}
function sortDemo(root){const list=$("[data-sort-files]",root),out=$("[data-sort-out]",root),run=$("[data-sort-run]",root),reset=$("[data-sort-reset]",root),msg=$("[data-sort-msg]",root);
function draw(){list.innerHTML=FILES.map((f,i)=>'<li style="--r:'+(((i*37)%9)-4)+'deg"><span class="dq-id">'+esc(f[0])+"</span></li>").join("");list.classList.remove("is-sorted")}
function check(){const idx=FOLD.map(()=>[]),un=[];let X={};FILES.forEach(f=>{Object.assign(X,f[1]||{});const k=classify(f[0]);(k<0?un:idx[k]).push(f[0])});
const flags=[],founders=3,ipa=idx[2].length,days=(a,b)=>Math.round((new Date(b)-new Date(a))/864e5);
if(X.pool!==X.reserve)flags.push([3,"Option pool does not match the plan","Cap table "+X.pool.toLocaleString("en-US")+", plan "+X.reserve.toLocaleString("en-US")]);
if(ipa<founders)flags.push([3,"Founder IP assignment missing",ipa+" of "+founders+" founder assignments found"]);
if(X.rs&&!FILES.some(f=>/83\(?b\)?/i.test(f[0])))flags.push([2,"83(b) election proof not found","restricted stock purchase "+X.rs]);
if(idx[5].length&&!FILES.some(f=>/form d/i.test(f[0])))flags.push([2,"No Form D found for the SAFE round",idx[5].length+" SAFEs, no filing copy"]);
if(X.val&&X.grant&&days(X.val,X.grant)>365)flags.push([2,"409A older than twelve months at last grant",days(X.val,X.grant)+" days between valuation and grants"]);
un.forEach(u=>flags.push([1,"File could not be classified",u]));
const n=Math.max(0,100-flags.reduce((s,f)=>s+[0,2,6,10][f[0]],0)-idx.filter(x=>!x.length).length*6);
const L={3:["High","hi"],2:["Medium","md"],1:["Low","lo"]};
out.innerHTML='<div class="dq-res'+(RM?"":" is-anim")+'"><div class="dq-res__g"><div><p class="dq-mi">Index · 7 folders</p><ol class="dq-ixl dq-ixl--live">'+FOLD.map((f,i)=>{const ok=idx[i].length&&!flags.some(g=>g[0]>1&&((i===1&&/pool|409A|83/.test(g[1]))||(i===2&&/IP/.test(g[1]))||(i===5&&/Form D/.test(g[1]))));
return '<li class="dq-ix dq-ix--'+(ok?"ok":"x")+'"><span class="dq-id">'+f[0]+"</span><b>"+esc(f[1])+'</b><span class="dq-ix__n">'+idx[i].length+" file"+(idx[i].length===1?"":"s")+'</span><span class="dq-b" aria-hidden="true"></span></li>'}).join("")+"</ol></div>"+
'<div class="dq-res__s">'+ringHTML(n,"of 100","Readiness score")+"</div></div>"+
'<p class="dq-mi">Flags · '+flags.length+' ranked</p><ol class="dq-fl">'+flags.map(f=>'<li><span class="dq-sev dq-sev--'+L[f[0]][1]+'">'+L[f[0]][0]+"</span><div><b>"+esc(f[1])+"</b><small>"+esc(f[2])+"</small></div></li>").join("")+"</ol>"+
'<p class="dq-mute"><a href="/sample-red-flag-report">Read the full sample report</a> for the reason, the sources and the fix behind each flag.</p></div>';
list.classList.add("is-sorted");msg.textContent=FILES.length-un.length+" of "+FILES.length+" files classified. "+flags.length+" flags, score "+n+".";run.disabled=!0;reset.disabled=!1;reset.focus()}
run.addEventListener("click",check);reset.addEventListener("click",()=>{draw();out.innerHTML='<div class="dq-empty"><b>Nothing checked yet.</b><p>Press Classify and check. Everything runs in your browser on synthetic files.</p></div>';msg.textContent="14 files, no structure yet.";run.disabled=!1;reset.disabled=!0;run.focus()});draw()}

/* ---------- tabs */
function tabs(root){const t=$$("[role=tab]",root);function pick(i,f){t.forEach((b,j)=>{const on=j===i;b.setAttribute("aria-selected",on);b.tabIndex=on?0:-1;const p=$("#"+b.getAttribute("aria-controls"));p.hidden=!on;if(on)$$("[data-rv]",p).forEach(x=>x.classList.add("is-in"));if(on&&f)b.focus()})}
t.forEach((b,i)=>{b.addEventListener("click",()=>pick(i));b.addEventListener("keydown",e=>{if(e.key==="ArrowRight"||e.key==="ArrowLeft"){e.preventDefault();pick((i+(e.key==="ArrowRight"?1:t.length-1))%t.length,1)}})})}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
/* checklist rows that start red turn green when their panel is on screen */
function flips(){const ps=$$(".dq-ckp");if(!ps.length)return;if(RM||!("IntersectionObserver" in window)){ps.forEach(p=>p.classList.add("is-flipped"));return}
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){setTimeout(()=>e.target.classList.add("is-flipped"),500);io.unobserve(e.target)}}),{threshold:.5});ps.forEach(p=>io.observe(p))}
export function boot(){scrollers();flips();$$("[data-dq=quiz]").forEach(quiz);$$("[data-dq=mini]").forEach(mini);$$("[data-dq=sort]").forEach(sortDemo);$$("[data-dq=tabs]").forEach(tabs)}
