<?php
/*
 * Form intake for Rfqsherpa.
 * Receives the site's forms as JSON, keeps a copy on the server (outside the public folder)
 * and mails the team. Nothing is sent to any third party.
 */
error_reporting(0);
ini_set('display_errors', '0');

const SITE_NAME = 'Rfqsherpa';
const SITE_HOST = 'rfqsherpa.com';
const MAIL_FROM = 'no-reply@rfqsherpa.com';
const NOTIFY_TO = 'elsa@rfqsherpa.com';
const ALT_HOSTS = 'rfqsherpa.vercel.app';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function out($code, $body)
{
    http_response_code($code);
    echo json_encode($body);
    exit;
}

function clip($s, $n)
{
    return function_exists('mb_substr') ? mb_substr($s, 0, $n, 'UTF-8') : substr($s, 0, $n);
}

function clean($s, $multiline = false)
{
    $s = str_replace("\r", '', (string) $s);
    $s = preg_replace($multiline ? '/[^\P{C}\n\t]+/u' : '/[^\P{C}]+/u', ' ', $s);
    if ($s === null) {
        $s = '';
    }
    return trim($s);
}

function host_ok($h)
{
    $h = strtolower(preg_replace('/:\d+$/', '', (string) $h));
    if ($h === '') {
        return false;
    }
    $self = strtolower(preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? '')));
    if ($h === $self || $h === SITE_HOST || $h === 'www.' . SITE_HOST) {
        return true;
    }
    foreach (explode(',', ALT_HOSTS) as $a) {
        $a = strtolower(trim($a));
        if ($a !== '' && $h === $a) {
            return true;
        }
    }
    return false;
}

function client_ip()
{
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP'] as $k) {
        if (!empty($_SERVER[$k]) && filter_var($_SERVER[$k], FILTER_VALIDATE_IP)) {
            return $_SERVER[$k];
        }
    }
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '');
}

function data_dir()
{
    $root = rtrim((string) ($_SERVER['DOCUMENT_ROOT'] ?? __DIR__), '/');
    $dir = dirname($root) . '/forms-data';
    if (!is_dir($dir)) {
        @mkdir($dir, 0700, true);
    }
    if (!is_dir($dir) || !is_writable($dir)) {
        $dir = rtrim(sys_get_temp_dir(), '/') . '/forms-data-' . preg_replace('/[^a-z0-9.-]/i', '', SITE_HOST);
        @mkdir($dir, 0700, true);
    }
    @mkdir($dir . '/rate', 0700, true);
    if (!is_file($dir . '/.htaccess')) {
        @file_put_contents($dir . '/.htaccess', "Require all denied\n");
    }
    return $dir;
}

function salt($dir)
{
    $f = $dir . '/.salt';
    $s = @file_get_contents($f);
    if (!$s) {
        $s = bin2hex(random_bytes(16));
        @file_put_contents($f, $s);
        @chmod($f, 0600);
    }
    return $s;
}

function over_limit($dir, $key)
{
    $f = $dir . '/rate/' . $key . '.json';
    $now = time();
    $fh = @fopen($f, 'c+');
    if (!$fh) {
        return false;
    }
    flock($fh, LOCK_EX);
    $raw = stream_get_contents($fh);
    $hits = json_decode($raw ?: '[]', true);
    $hits = is_array($hits) ? $hits : [];
    $hits = array_values(array_filter($hits, function ($t) use ($now) {
        return is_int($t) && $t > $now - 86400;
    }));
    $recent = count(array_filter($hits, function ($t) use ($now) {
        return $t > $now - 900;
    }));
    $over = $recent >= 6 || count($hits) >= 30;
    if (!$over) {
        $hits[] = $now;
    }
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($hits));
    flock($fh, LOCK_UN);
    fclose($fh);
    if (mt_rand(1, 100) === 1) {
        foreach ((array) glob($dir . '/rate/*.json') as $g) {
            if (@filemtime($g) < $now - 172800) {
                @unlink($g);
            }
        }
    }
    return $over;
}

function mime_header($s)
{
    return preg_match('/[^\x20-\x7e]/', $s) ? '=?UTF-8?B?' . base64_encode($s) . '?=' : $s;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    out(405, ['ok' => false, 'error' => 'method']);
}

$src = ($_SERVER['HTTP_ORIGIN'] ?? '') !== '' ? $_SERVER['HTTP_ORIGIN'] : ($_SERVER['HTTP_REFERER'] ?? '');
if (!host_ok($src === '' ? '' : parse_url($src, PHP_URL_HOST))) {
    out(403, ['ok' => false, 'error' => 'origin']);
}

$raw = file_get_contents('php://input', false, null, 0, 60001);
if ($raw === false || strlen($raw) > 60000) {
    out(413, ['ok' => false, 'error' => 'size']);
}
$d = json_decode($raw, true);
if (!is_array($d)) {
    out(400, ['ok' => false, 'error' => 'format']);
}

$types = ['contact', 'demo', 'apply', 'file', 'sub', 'signin'];
$type = (isset($d['type']) && is_string($d['type']) && in_array($d['type'], $types, true)) ? $d['type'] : 'contact';
$page = clip(clean(isset($d['page']) && is_string($d['page']) ? $d['page'] : ''), 200);

$fields = [];
$list = (isset($d['fields']) && is_array($d['fields'])) ? array_slice($d['fields'], 0, 40) : [];
foreach ($list as $f) {
    if (!is_array($f)) {
        continue;
    }
    $kind = (isset($f['kind']) && in_array($f['kind'], ['email', 'tel', 'url'], true)) ? $f['kind'] : 'text';
    $label = clip(clean(isset($f['label']) && is_string($f['label']) ? $f['label'] : ''), 120);
    $value = clip(clean(isset($f['value']) && is_string($f['value']) ? $f['value'] : '', true), 4000);
    if ($label === '') {
        $label = clip(clean(isset($f['name']) && is_string($f['name']) ? $f['name'] : 'Field'), 60);
    }
    if ($value === '' || preg_match('/pass(word|code)?\b/i', $label)) {
        continue;
    }
    $fields[] = ['label' => $label, 'value' => $value, 'kind' => $kind];
}

$email = '';
$phone = false;
foreach ($fields as $f) {
    if ($f['kind'] === 'email' && filter_var($f['value'], FILTER_VALIDATE_EMAIL)) {
        $email = $f['value'];
        break;
    }
    if ($f['kind'] === 'tel' && preg_match_all('/\d/', $f['value']) >= 7) {
        $phone = true;
    }
}
if ($email === '' && !$phone) {
    out(422, ['ok' => false, 'error' => 'email']);
}

$dir = data_dir();
$key = substr(hash('sha256', salt($dir) . client_ip()), 0, 24);

// Bots: a filled honeypot or a form sent faster than a person can type it.
// They get the normal reply, and the post is kept apart in spam.jsonl (capped) so a real lead is never lost.
$hp = isset($d['hp']) && is_string($d['hp']) ? trim($d['hp']) : '';
$t = isset($d['t']) ? (int) $d['t'] : 0;
if ($hp !== '' || $t < 800) {
    $sp = $dir . '/spam.jsonl';
    if (!is_file($sp) || filesize($sp) < 1048576) {
        @file_put_contents($sp, json_encode(['at' => gmdate('c'), 'type' => $type, 'page' => $page, 'email' => $email, 'hp' => clip($hp, 80), 't' => $t, 'client' => $key, 'fields' => array_slice($fields, 0, 12)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);
    }
    out(200, ['ok' => true]);
}

if (over_limit($dir, $key)) {
    out(429, ['ok' => false, 'error' => 'rate']);
}

$id = bin2hex(random_bytes(6));
$rec = [
    'id' => $id,
    'at' => gmdate('c'),
    'type' => $type,
    'page' => $page,
    'site' => SITE_NAME,
    'email' => $email,
    'fields' => $fields,
    'client' => $key,
    'agent' => clip(clean($_SERVER['HTTP_USER_AGENT'] ?? ''), 160),
];
$stored = @file_put_contents(
    $dir . '/submissions-' . gmdate('Y-m') . '.jsonl',
    json_encode($rec, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n",
    FILE_APPEND | LOCK_EX
) !== false;

if ($stored && $type === 'sub' && $email !== '') {
    $sf = $dir . '/subscribers.txt';
    $have = is_file($sf) ? file($sf, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
    if (!in_array(strtolower($email), array_map('strtolower', (array) $have), true)) {
        @file_put_contents($sf, $email . "\n", FILE_APPEND | LOCK_EX);
    }
}

$mailed = false;
if ($type !== 'signin' && NOTIFY_TO !== '') {
    $titles = ['contact' => 'Message', 'demo' => 'Demo request', 'apply' => 'Application', 'file' => 'Resource request', 'sub' => 'New subscriber'];
    $who = '';
    foreach ($fields as $f) {
        if ($f['kind'] === 'text' && preg_match('/^(your )?(full )?name\b/i', $f['label'])) {
            $who = preg_replace('/\s+/', ' ', $f['value']);
            break;
        }
    }
    $subject = SITE_NAME . ' / ' . $titles[$type] . ($who !== '' ? ' from ' . clip($who, 60) : ($email !== '' ? ' from ' . $email : ''));
    $lines = [$titles[$type] . ' received on ' . SITE_NAME, 'Page: ' . $page, 'Received: ' . gmdate('Y-m-d H:i') . ' UTC', 'Reference: ' . $id, ''];
    foreach ($fields as $f) {
        $v = str_replace("\n", "\n    ", $f['value']);
        $lines[] = $f['label'] . ': ' . $v;
    }
    $headers = 'From: ' . mime_header(SITE_NAME) . ' <' . MAIL_FROM . ">\r\n";
    if ($email !== '') {
        $headers .= 'Reply-To: ' . $email . "\r\n";
    }
    $headers .= "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\nX-Form-Type: " . $type . "\r\n";
    $mailed = @mail(NOTIFY_TO, mime_header(preg_replace('/[\r\n]+/', ' ', $subject)), implode("\n", $lines) . "\n", $headers);
}

if (!$stored && !$mailed && $type !== 'signin') {
    out(500, ['ok' => false, 'error' => 'server']);
}
out(200, ['ok' => true]);
