/* Appealquill page tools. Runs offline in the browser; nothing typed here leaves the page.
   [data-aq=decoder]  Denial Decoder: payer type + denial wording -> category, plain reading, usual evidence, deadline
   [data-aq=mini]     the same engine on three sample reasons (home page)
   [data-aq=explorer] sample appeal: each sentence opens the clause or record page behind it */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const CAT={
med:{name:"Medical necessity",sub:"Clinical",step:"Appeal with clinical evidence",plain:"The payer accepts the service happened but says the record does not show it was needed at that level of care, on that day.",
ev:["Physician history and physical, and progress notes from the first 24 hours","Orders with times, showing when the decision to admit or treat was made","Results that show severity at the time: labs, imaging, vital-sign trends","The screening criteria your hospital applied and the result","The section of the payer's medical policy that the service meets","Notes from any peer-to-peer call"],
tip:"Answer the exact criterion the payer names. Quote the note and the page, not the whole chart."},
auth:{name:"Prior authorization",sub:"Administrative",step:"Appeal with the authorization trail",plain:"The payer has no record of an approval it required before the service, or the service went beyond what was approved.",
ev:["Authorization or reference number with date and time","Portal screenshot or call log showing the request","Admission time against the notification deadline in the contract","Emergency evidence if the patient arrived through the emergency department","Any retro-authorization request and the payer's reply"],
tip:"If the patient came in as an emergency, say so in the first sentence and attach the triage record."},
doc:{name:"Documentation gap",sub:"Records",step:"Send the missing records",plain:"The payer says something it asked for, or needs to process the claim, never arrived or was incomplete.",
ev:["The exact records the request letter lists, in the order listed","Itemized bill matching the claim lines","Signed and dated orders and operative or procedure reports","A cover sheet mapping each requested item to its page number"],
tip:"Check the request letter date. Many payers close the claim if records arrive after their stated deadline."},
cov:{name:"Coverage exclusion",sub:"Benefit",step:"Check coverage before appealing",plain:"The payer says the plan does not pay for this service, or the patient was not covered on the date of service.",
ev:["Eligibility check from the date of service","The plan's benefit language for the service","Network status or a network-gap exception, if out of network","Medical policy criteria if the payer calls the service experimental","Emergency evidence where emergency rules override network limits"],
tip:"If eligibility really lapsed, an appeal will not help. Look for other coverage or a patient balance instead."},
bill:{name:"Billing error",sub:"Coding",step:"Fix and send a corrected claim",plain:"Something on the claim itself does not match: a code, a modifier, a duplicate line, or the order of payers.",
ev:["The coding note or documentation that supports the code billed","Modifier rationale for any bundled procedure","Proof the line is not a duplicate: dates, units, times","Coordination of benefits details if another payer is primary","A corrected claim marked as a replacement (frequency code 7)"],
tip:"Most of these are faster as a corrected claim than as an appeal. Appeal only if the original claim was right."},
time:{name:"Billing error",sub:"Timely filing",step:"Prove the claim was filed on time",plain:"The payer says the claim reached it after the filing limit in the contract or plan.",
ev:["Clearinghouse acceptance report with the original submission date","Payer acknowledgment of the first submission","Any rejection notices that show the claim was in the payer's hands","The filing limit clause from the contract"],
tip:"Without proof of a timely first submission this one is hard to win. Find the acceptance report first."}};
const CODES={med:[50,55,56,150,151,152,"N115"],auth:[197,198,15,62,39,288,"N54"],doc:[16,252,226,227,251,"M127","N706"],cov:[96,204,27,26,31,109,167,49,"N130"],bill:[4,5,6,7,8,9,11,18,22,23,97,146,181,182,"B7"],time:[29]};
const WORDS=[
["time",/timely filing|time limit|filed (?:too )?late|filing limit|after the filing/],
["auth",/prior auth|pre-?auth|pre-?cert|authori[sz]ation|referral (?:was )?(?:absent|missing|required)|notification (?:was )?not|not notified/],
["med",/medical(?:ly)? necess|not (?:deemed )?(?:reasonable and )?necessary|level of care|inpatient (?:criteria|status)|observation (?:status|level)|does not meet (?:criteria|guidelines)|clinical criteria/],
["doc",/lacks? information|additional (?:information|documentation|records)|records (?:were )?(?:not received|requested)|missing (?:documentation|records|information)|incomplete|attachment|itemi[sz]ed bill/],
["cov",/not covered|non-?covered|exclu|benefit (?:maximum|limit)|coverage (?:terminated|ended)|not eligible|experimental|investigational|out[- ]of[- ]network/],
["bill",/modifier|duplicate|bundl|inconsistent|invalid (?:code|procedure|diagnosis)|procedure code|coordination of benefits|place of service|incorrect (?:code|units)/]];
const PAYER={commercial:{label:"Commercial plan",days:180,note:"180 days is common for member appeals under employer and marketplace plans. Provider appeal windows are set by your contract and are often shorter."},
ma:{label:"Medicare Advantage",days:65,note:"65 days from the notice for a plan reconsideration. Contracted providers follow the plan's own dispute process."},
mcd:{label:"Medicaid managed care",days:60,note:"60 days from the notice for a plan appeal. State rules can add steps."},
mcr:{label:"Traditional Medicare",days:120,note:"120 days from the remittance for a redetermination."}};
function decode(text){
const t=(text||"").toLowerCase().trim();if(t.length<4)return{err:"short"};
const m=t.match(/\b(co|pr|oa|pi|cr)\s?-?\s?([a-z]?\d{1,3})\b/i);let key=null,code=null;
if(m){code=(m[1]+"-"+m[2]).toUpperCase();const c=m[2].toUpperCase();for(const k in CODES)if(CODES[k].some(x=>String(x)===c)){key=k;break}}
if(!key)for(const[k,rx]of WORDS)if(rx.test(t)){key=k;break}
if(!key)return{err:"nomatch",code};
const hits=[];WORDS.forEach(([k,rx])=>{const x=t.match(rx);if(x&&k===key)hits.push(x[0])});
return{key,code,hit:hits[0]||null}}
function due(dateStr,payer){
if(!dateStr)return null;const d=new Date(dateStr+"T12:00:00");if(isNaN(d))return null;
const p=PAYER[payer]||PAYER.commercial,end=new Date(d);end.setDate(end.getDate()+p.days);
const now=new Date();now.setHours(12,0,0,0);const left=Math.round((end-now)/864e5);
return{end:end.toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"}),left}}
function result(r,payer,dateStr,compact){
const c=CAT[r.key],p=PAYER[payer]||PAYER.commercial,d=due(dateStr,payer);
let dl;if(d){dl=d.left<0?`The usual ${p.days}-day window ended on ${d.end}. Check the notice and your contract for any late-filing provision before writing off the claim.`:`Usual window ends ${d.end}: ${d.left} day${d.left===1?"":"s"} left. ${p.note}`}else dl=`${p.label}: about ${p.days} days from the date on the notice. ${p.note}`;
const ev=(compact?c.ev.slice(0,3):c.ev).map(x=>`<li>${esc(x)}</li>`).join("");
return`<div class="aq-res" data-cat="${r.key}"><div class="aq-res__h"><p class="mv-mi">Decoded${r.code?` · ${esc(r.code)}`:""}</p><p class="aq-res__cat"><span class="aq-chip aq-chip--${r.key==="bill"||r.key==="time"?"bill":r.key}">${esc(c.name)}</span><span class="aq-res__sub">${esc(c.sub)}</span></p></div>
<p class="aq-res__plain">${esc(c.plain)}</p><div class="aq-res__g"><div><p class="mv-mi">Evidence usually needed</p><ul class="aq-ev">${ev}</ul></div>
<div><p class="mv-mi">Usual next step</p><p class="aq-res__step">${esc(c.step)}</p>${compact?"":`<p class="mv-mi">Deadline</p><p class="aq-res__dl${d&&d.left<0?" is-late":""}">${esc(dl)}</p><p class="aq-res__tip">${esc(c.tip)}</p>`}</div></div></div>`}
function err(kind,code){
if(kind==="short")return`<div class="aq-res aq-res--empty"><p class="aq-res__plain">Paste the reason text from the denial letter or remittance, or pick one of the sample reasons.</p></div>`;
return`<div class="aq-res aq-res--err" role="alert"><p class="mv-mi">No match${code?` for ${esc(code)}`:""}</p><p class="aq-res__plain">We could not place this wording in a category. Try the adjustment code from the remittance (for example CO-50) or the sentence that follows "denied because".</p></div>`}
function decoder(root){
const ta=$("[data-dd-text]",root),out=$("[data-dd-out]",root),date=$("[data-dd-date]",root),go=$("[data-dd-go]",root),letter=$("[data-dd-letter]",root),hl=$("[data-dd-hl]",root),rp=$("[data-dd-replay]",root),cat=$("[data-dd-stamp]",root);
const payer=()=>($("input[name=dd-payer]:checked",root)||{}).value||"commercial";
let n=0;
const run=()=>{const r=decode(ta.value);n++;root.dataset.run=n;
if(r.err){out.innerHTML=err(r.err,r.code);letter.classList.remove("is-on");if(cat)cat.textContent=r.err==="short"?"Waiting":"No match";ta.setAttribute("aria-invalid",r.err==="nomatch"?"true":"false");return}
ta.setAttribute("aria-invalid","false");out.innerHTML=result(r,payer(),date&&date.value,!1);
if(hl)hl.textContent=(r.code&&!/\b(co|pr|oa|pi|cr)\s?-?\s?[a-z]?\d/i.test(ta.value)?r.code+": ":"")+ta.value.trim().slice(0,90)+(ta.value.trim().length>90?"...":"");
if(cat)cat.textContent=CAT[r.key].name;letter.dataset.cat=r.key;letter.classList.remove("is-on");void letter.offsetWidth;letter.classList.add("is-on")};
go.addEventListener("click",run);
ta.addEventListener("keydown",e=>{if(e.key==="Enter"&&(e.metaKey||e.ctrlKey)){e.preventDefault();run()}});
$$("input[name=dd-payer]",root).forEach(i=>i.addEventListener("click",()=>{const f=i.closest("fieldset");f.dataset.payer=i.value;f.dataset.n=(+f.dataset.n||0)+1;run()}));
date&&date.addEventListener("change",()=>{if(out.querySelector(".aq-res[data-cat]"))run()});
const sm=$$("[data-sample]",root);
sm.forEach((b,i)=>{b.addEventListener("click",()=>{ta.value=b.dataset.sample;sm.forEach(x=>x.setAttribute("aria-pressed",x===b));run()});
b.addEventListener("keydown",e=>{const d=e.key==="ArrowRight"||e.key==="ArrowDown"?1:e.key==="ArrowLeft"||e.key==="ArrowUp"?-1:0;if(d){e.preventDefault();const t=sm[(i+d+sm.length)%sm.length];t.focus();t.click()}})});
rp&&rp.addEventListener("click",()=>{if(!out.querySelector(".aq-res[data-cat]")){(sm[0]||go).click();return}letter.classList.remove("is-on");void letter.offsetWidth;letter.classList.add("is-on");n++;root.dataset.run=n});
const q=new URLSearchParams(location.search).get("reason");if(q){ta.value=q.slice(0,400);run()}}
function mini(root){
const tabs=$$("[role=tab]",root),out=$("[data-mini-out]",root);
const show=i=>{root.dataset.n=(+root.dataset.n||0)+1;tabs.forEach((t,j)=>{t.setAttribute("aria-selected",j===i);t.tabIndex=j===i?0:-1});const r=decode(tabs[i].dataset.text);out.innerHTML=r.err?err(r.err,r.code):result(r,tabs[i].dataset.payer,null,!0)};
tabs.forEach((t,i)=>{t.addEventListener("click",()=>show(i));t.addEventListener("keydown",e=>{const d=e.key==="ArrowRight"?1:e.key==="ArrowLeft"?-1:0;if(d){e.preventDefault();const k=(i+d+tabs.length)%tabs.length;tabs[k].focus();show(k)}})});show(0)}
function explorer(root){
const ss=$$("[data-s]",root),evs=$$("[data-ev]",root),fl=$$("[data-f]",root),meta=$("[data-x-meta]",root);
root.classList.add("is-js");
const pick=i=>{root.dataset.n=(+root.dataset.n||0)+1;const s=ss[i];ss.forEach(x=>x.setAttribute("aria-pressed",x===s));const ids=s.dataset.s.split(" ");evs.forEach(e=>{e.hidden=!ids.includes(e.dataset.ev)});
if(meta)meta.textContent=`Sentence ${i+1} of ${ss.length} · ${ids.length} source${ids.length>1?"s":""}`};
ss.forEach((s,i)=>{s.addEventListener("click",()=>pick(i));s.addEventListener("keydown",e=>{const d=e.key==="ArrowDown"||e.key==="ArrowRight"?1:e.key==="ArrowUp"||e.key==="ArrowLeft"?-1:0;if(d){e.preventDefault();let k=i;do{k=(k+d+ss.length)%ss.length}while(ss[k].hidden&&k!==i);ss[k].focus();pick(k)}})});
fl.forEach(b=>b.addEventListener("click",()=>{const f=b.dataset.f;root.dataset.n=(+root.dataset.n||0)+1;fl.forEach(x=>x.setAttribute("aria-pressed",x===b));ss.forEach(s=>{s.classList.toggle("is-dim",f!=="all"&&!s.dataset.k.includes(f))})}));
pick(0)}
/* scroll regions get keyboard focus only when they actually scroll */
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-aq=decoder]").forEach(decoder);$$("[data-aq=mini]").forEach(mini);$$("[data-aq=explorer]").forEach(explorer)}
