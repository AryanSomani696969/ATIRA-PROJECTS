/* Radprism page tools. Run offline in the browser; nothing typed or clicked here leaves the page.
   [data-rp=worklist] Worklist demo: synthetic studies arrive, are scored with a visible reason and re-sorted;
                      threshold slider, sort order, read, find by ID, reader override with a log.
   [data-rp=mini]     the same engine on five rows (home live-operations panel)
   [data-rp=report]   sample turnaround report: filters, totals, empty state and CSV export
   [data-hud-count]   hero HUD counter (still when reduced motion is preferred)
   Scores use the same parts as content.py: finding weight x confidence + source + waiting time + trauma note. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)");
const FIND={ich:["Suspected intracranial hemorrhage",62],shift:["Suspected midline shift",58],ptx:["Suspected pneumothorax",56],free:["Suspected free air",50],
eff:["Suspected large pleural effusion",24],tube:["Tube position to check",18],none:["No urgent finding suggested",0]};
const SRC={ED:12,Inpatient:6,Outpatient:0};
const S=(id,mod,site,src,f,conf,ind,age,gap)=>({id,mod,site,src,f,conf,ind,age,gap:gap||0});
const QUEUE=[S("RP-24011","CXR","Site A","Outpatient","none",0,"Annual follow-up",48),S("RP-24012","CT head","Site B","Inpatient","none",0,"Headache, known migraine",41),
S("RP-24013","CXR","Site A","Inpatient","tube",.88,"Line placement check",36),S("RP-24014","CXR","Site C","Outpatient","eff",.74,"Shortness of breath",29),
S("RP-24015","CT head","Site A","Outpatient","none",0,"Dizziness",22),S("RP-24016","CXR","Site B","ED","none",0,"Cough, fever",14),
S("RP-24017","CT head","Site C","Inpatient","none",0,"Post-op follow-up",9)];
const POOL=[S("RP-24018","CT head","Site B","ED","ich",.91,"Fall, on anticoagulants",6,1),S("RP-24019","CXR","Site A","Inpatient","none",0,"Pre-op",2,3),
S("RP-24020","CXR","Site C","ED","ptx",.84,"Chest pain after trauma",3,4),S("RP-24021","CXR","Site B","ED","eff",.69,"Shortness of breath",4,2),
S("RP-24022","CT head","Site A","Inpatient","shift",.77,"Drowsy after surgery",5,3),S("RP-24023","CT head","Site C","ED","ich",.96,"Head trauma, cyclist",2,2),
S("RP-24024","CXR","Site A","Outpatient","none",0,"Routine screening",8,5),S("RP-24025","CXR","Site B","Inpatient","free",.72,"Abdominal pain, post-op",3,3)];
const parts=s=>{const fw=FIND[s.f][1]*s.conf,src=SRC[s.src],wait=Math.min(14,s.age/5),tr=/trauma/i.test(s.ind)?8:0;return{fw,src,wait,tr,total:Math.max(1,Math.min(99,Math.round(fw+src+wait+tr)))}};
const score=s=>parts(s).total;
const tierOf=(sc,th,ovr)=>ovr?["rout","Routine"]:sc>=th?["crit","Critical"]:sc>=th-30?["prio","Priority"]:["rout","Routine"];
const hhmm=m=>{const h=Math.floor(m/60)%24,mm=m%60;return String(h).padStart(2,"0")+":"+String(mm).padStart(2,"0")};
const reasonOf=s=>s.f!=="none"?FIND[s.f][0]:s.src+" · "+s.ind;

function worklist(root){
const mini=root.dataset.rp==="mini",N=mini?5:7;
const list=$(".rp-wl__l",root),status=$("[data-wl-status]",root),clockEl=$("[data-wl-clock]",root),countEl=$("[data-wl-count]",root);
const det=$("[data-wl-detail]",root),logEl=$("[data-wl-log]",root),empty=$("[data-wl-empty]",root),err=$("[data-wl-err]",root),thIn=$("[data-wl-th]",root),thOut=$("[data-wl-th-out]",root),find=$("[data-wl-find]",root);
let msg=$(".rp-wl__err",root);if(mini&&!msg){msg=document.createElement("p");msg.className="rp-wl__err";msg.setAttribute("role","status");$(".rp-wl__ctl",root).after(msg)}
let q,pool,clock,th,sort,sel,logs;
const reset=()=>{q=QUEUE.slice(0,N).map(s=>({...s}));pool=POOL.map(s=>({...s}));clock=8*60+14;th=thIn?+thIn.value:70;sort="urg";sel=null;logs=[];
 $$("[data-wl-sort]",root).forEach(x=>x.setAttribute("aria-pressed",x.dataset.wlSort==="urg"));say("");setErr("")};
const key=s=>{const sc=score(s);return s.ovr?Math.min(sc,th-31):sc};
const ordered=()=>q.slice().sort(sort==="arr"?(a,b)=>b.age-a.age:(a,b)=>key(b)-key(a)||b.age-a.age);
const say=t=>{if(status)status.textContent=t};
const setErr=t=>{if(err)err.textContent=t;if(mini&&msg)msg.textContent=t};
function render(focusId){
 const before=new Map($$(".rp-row",list).map(li=>[li.dataset.id,li.getBoundingClientRect().top]));
 const rows=ordered();
 list.innerHTML=rows.map((s,i)=>{const sc=score(s),[k,t]=tierOf(sc,th,s.ovr);
  return '<li class="rp-row is-'+k+(s.id===sel?" is-sel":"")+(s.fresh?" is-new":"")+'" data-id="'+s.id+'"><button type="button" class="rp-row__b" data-id="'+s.id+'"'+(i===0&&!focusId||s.id===focusId?"":' tabindex="-1"')+(mini?"":' aria-pressed="'+(s.id===sel)+'"')+'>'+
  '<span class="rp-row__n">'+String(i+1).padStart(2,"0")+'</span><span class="rp-row__id">'+s.id+'</span><span class="rp-row__m">'+esc(s.mod)+" · "+esc(s.site)+'</span>'+
  '<span class="rp-row__r">'+esc(reasonOf(s))+(s.ovr?" · overridden":"")+'</span><span class="rp-row__t"><i>'+t+'</i></span><span class="rp-row__s">'+sc+"</span></button></li>"}).join("");
 if(clockEl)clockEl.textContent=hhmm(clock);if(countEl)countEl.textContent=q.length+" studies";
 if(empty){empty.hidden=q.length>0;list.hidden=q.length===0}
 if(!RM.matches)$$(".rp-row",list).forEach(li=>{const b=before.get(li.dataset.id),a=li.getBoundingClientRect().top;
  if(b==null){li.animate([{opacity:0,transform:"translateX(24px)"},{opacity:1,transform:"none"}],{duration:300,easing:"cubic-bezier(.22,1,.36,1)"})}
  else if(Math.abs(b-a)>1){li.animate([{transform:"translateY("+(b-a)+"px)"},{transform:"none"}],{duration:600,easing:"cubic-bezier(.22,1,.36,1)"})}});
 q.forEach(s=>s.fresh=!1);
 if(focusId){const b=$('.rp-row__b[data-id="'+focusId+'"]',list);b&&b.focus()}
 detail()}
function detail(){
 if(!det)return;const s=q.find(x=>x.id===sel),box=$(".rp-det__b",det);
 if(!s){box.innerHTML='<p class="rp-det__e">'+(q.length?"Select a study to see its urgency score, the reason behind it and the override control.":"No study selected. The queue is empty.")+"</p>";return}
 const p=parts(s),[k,t]=tierOf(p.total,th,s.ovr),pos=ordered().findIndex(x=>x.id===s.id)+1;
 box.innerHTML='<p class="rp-det__id"><span class="rp-mono">'+s.id+'</span><span class="rp-row__t is-'+k+'"><i>'+t+"</i></span></p>"+
 '<p class="rp-det__r">'+esc(reasonOf(s))+(s.f!=="none"?" · confidence "+s.conf.toFixed(2):"")+'</p><dl class="rp-det__p">'+
 "<div><dt>Finding "+(s.f!=="none"?"x confidence":"")+"</dt><dd>"+Math.round(p.fw)+"</dd></div><div><dt>Source: "+esc(s.src)+"</dt><dd>"+p.src+"</dd></div>"+
 "<div><dt>Waiting "+s.age+" min</dt><dd>"+Math.round(p.wait)+"</dd></div><div><dt>Trauma in indication</dt><dd>"+p.tr+"</dd></div><div class=\"rp-det__tot\"><dt>Urgency score</dt><dd>"+p.total+"</dd></div></dl>"+
 '<p class="rp-det__m">'+esc(s.mod)+" · "+esc(s.site)+" · "+esc(s.ind)+" · position "+pos+" of "+q.length+"</p>"+
 (s.ovr?'<button type="button" class="rp-ghost" data-wl-undo>Restore the suggested order</button>':
 '<div class="rp-det__o"><label for="wl-why">Override reason</label><select class="inp" id="wl-why" data-wl-why><option>Same finding on a prior study</option><option>Image artifact</option><option>Clinical information from the ward</option><option>No reason given</option></select>'+
 '<button type="button" class="rp-ghost" data-wl-ovr>Move to routine</button></div>')}
const log=t=>{if(!logEl)return;logs.unshift("<li><span class=\"rp-mono\">"+hhmm(clock)+"</span> "+esc(t)+"</li>");logEl.innerHTML=logs.join("")};
function add(){
 if(!pool.length){setErr("No more synthetic studies arrive in this session. Press Replay to start again.");say("No more synthetic studies.");return}
 setErr("");const s=pool.shift();clock+=s.gap;q.forEach(x=>x.age+=s.gap);s.fresh=!0;q.push(s);
 if(mini&&q.length>6){const old=ordered().pop();q=q.filter(x=>x!==old)}
 render();const pos=ordered().findIndex(x=>x.id===s.id)+1,sc=score(s),t=tierOf(sc,th)[1];
 say(s.id+" arrived: "+s.mod+", "+s.site+". Score "+sc+", "+t.toLowerCase()+". Position "+pos+" of "+q.length+".")}
function read(){
 if(!q.length){setErr("The queue is empty. Press Replay to start again.");return}
 const s=ordered()[0];q=q.filter(x=>x!==s);clock+=4;q.forEach(x=>x.age+=4);if(sel===s.id)sel=null;log(s.id+" read and reported by the reader.");setErr("");render();say(s.id+" read. "+q.length+" studies left.")}
function pick(id,focus){sel=id;render(focus?id:null)}
root.addEventListener("click",e=>{const b=e.target.closest("button,input");if(!b)return;
 if(b.matches("[data-wl-add]"))add();else if(b.matches("[data-wl-read]"))read();
 else if(b.matches("[data-wl-reset]")){reset();render();say("Queue restored to its starting order.")}
 else if(b.matches(".rp-row__b")){if(mini){const s=q.find(x=>x.id===b.dataset.id);say(s.id+": score "+score(s)+". "+reasonOf(s)+".");setErr(s.id+": score "+score(s)+", "+reasonOf(s).toLowerCase()+".")}else pick(b.dataset.id,!0)}
 else if(b.matches("[data-wl-ovr]")){const s=q.find(x=>x.id===sel);if(!s)return;const why=$("[data-wl-why]",root).value;s.ovr=!0;log(s.id+" moved to routine by the reader. Reason: "+why.toLowerCase()+".");render(s.id);say(s.id+" moved to routine. Override logged.")}
 else if(b.matches("[data-wl-undo]")){const s=q.find(x=>x.id===sel);if(!s)return;s.ovr=!1;log(s.id+" restored to the suggested order.");render(s.id);say(s.id+" restored.")}
 else if(b.matches("[data-wl-find-go]"))doFind();
 else if(b.matches("[data-wl-sort]")){sort=b.dataset.wlSort;$$("[data-wl-sort]",root).forEach(x=>x.setAttribute("aria-pressed",x===b));render();say((sort==="arr"?"Sorted by arrival time, oldest first. ":"Sorted by urgency, highest score first. ")+q.length+" studies.")}});

if(thIn)thIn.addEventListener("input",()=>{th=+thIn.value;thOut.textContent=th;render();const n=q.filter(s=>!s.ovr&&score(s)>=th).length;say("Threshold "+th+". "+n+" critical.")});
function doFind(){const v=(find.value||"").trim().toUpperCase().replace(/\s+/g,"");
 if(!v){setErr("Type a study ID, for example RP-24013.");find.focus();return}
 const id=/^\d+$/.test(v)?"RP-"+v:v,s=q.find(x=>x.id===id);
 if(!s){setErr("No study "+id+" in this queue. IDs look like RP-24013.");find.setAttribute("aria-invalid","true");return}
 find.removeAttribute("aria-invalid");setErr("");pick(s.id,!0)}
if(find)find.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();doFind()}});
list.addEventListener("keydown",e=>{const b=e.target.closest(".rp-row__b");if(!b)return;const all=$$(".rp-row__b",list),i=all.indexOf(b);let j=-1;
 if(e.key==="ArrowDown")j=Math.min(all.length-1,i+1);else if(e.key==="ArrowUp")j=Math.max(0,i-1);else if(e.key==="Home")j=0;else if(e.key==="End")j=all.length-1;
 if(j<0)return;e.preventDefault();all.forEach(x=>x.tabIndex=-1);all[j].tabIndex=0;all[j].focus()});
reset();render()}

function report(root){
const sel=n=>$("[data-rep-"+n+"]",root),rows=$$("tbody tr[data-m]",root),rrows=$$("tbody tr[data-s]:not([data-m])",root),msg=$("[data-rep-msg]",root),title=$("[data-rep-title]",root);
const MON={Nov:"November 2026",Oct:"October 2026"};let vis=[];
function run(){const m=sel("month").value,s=sel("site").value,o=sel("mod").value;
 vis=rows.filter(r=>{const ok=r.dataset.m===m&&(s==="all"||r.dataset.s===s)&&(o==="all"||r.dataset.mod===o);r.hidden=!ok;return ok});
 rrows.forEach(r=>r.hidden=!(s==="all"||r.dataset.s===s));
 const sum=k=>vis.reduce((a,r)=>a+ +r.dataset[k],0),n=sum("n"),c=sum("c"),w=(k,by)=>{const d=vis.reduce((a,r)=>a+ +r.dataset[by],0);return d?Math.round(vis.reduce((a,r)=>a+r.dataset[k]*r.dataset[by],0)/d):0};
 const set=(k,v)=>{$('[data-k="'+k+'"]',root).textContent=v};
 if(!vis.length){["n","t","c","r","q"].forEach(k=>set(k,"-"));msg.textContent=o==="MRI"?"No MRI studies in this report. Radprism covers chest X-ray and head CT first.":"No studies match this filter."}
 else{set("n",n.toLocaleString("en-US"));set("t",w("t","n")+" min");set("c",c);set("r",w("r","c")+" min");set("q",w("q","n")+"%");msg.textContent=""}
 title.textContent=MON[m]+", "+(s==="all"?"all sites":s)+(o==="all"?"":", "+sel("mod").selectedOptions[0].text)}
root.addEventListener("change",run);
$("[data-rep-csv]",root).addEventListener("click",()=>{
 if(!vis.length){msg.textContent="Nothing to download for this filter. Choose chest X-ray or head CT.";return}
 const head="month,site,modality,studies,median_acquisition_to_report_min,critical_flags,critical_flag_to_open_min,share_over_60_min_pct,data";
 const body=vis.map(r=>[r.dataset.m,r.dataset.s,r.dataset.mod,r.dataset.n,r.dataset.t,r.dataset.c,r.dataset.r,r.dataset.q,"synthetic"].join(",")).join("\n");
 const url=URL.createObjectURL(new Blob([head+"\n"+body+"\n"],{type:"text/csv"})),a=document.createElement("a");
 a.href=url;a.download="radprism-sample-turnaround-"+sel("month").value.toLowerCase()+"-2026.csv";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
 msg.textContent="CSV prepared with "+vis.length+" rows of synthetic data."});
run()}

function hud(){const el=$("[data-hud-count]");if(!el||RM.matches)return;let n=38,t=0;setInterval(()=>{if(document.hidden)return;t++;n=Math.max(34,Math.min(42,n+(t%3===0?-2:1)));el.textContent=n},3500)}

export function boot(){
$$('[data-rp="worklist"],[data-rp="mini"]').forEach(worklist);
$$('[data-rp="report"]').forEach(report);
hud();
$$(".mv-pscroll").forEach(el=>{const f=()=>{const s=el.scrollWidth>el.clientWidth+2;s?el.setAttribute("tabindex","0"):el.removeAttribute("tabindex")};f();addEventListener("resize",f)});
}
