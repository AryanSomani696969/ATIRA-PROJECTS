/* Vulnsherpa page tools. Everything runs in this browser; nothing is stored or sent anywhere.
   data-vs=reducer   Backlog Reducer: 1,000 synthetic findings (412 unique issues across six synthetic services).
                     Three filters in any order: Deduplicate (count issues, not reports), Check reachability (drop issues
                     with a checked absence of any path; unknown stays), Add business context (keep public exploits and
                     critical or high findings on exposed or sensitive services; the rest is scheduled, not hidden).
                     The ranked list re-sorts with each step; any item opens to its reason and fix.
   data-vs=manifest  Dependency list check: parses package.json, package-lock.json, requirements.txt or name@version lines,
                     matches synth- packages against a synthetic advisory list, uses pasted source files to see which
                     packages are imported, ranks the fixes and explains why each one comes first. Also notes unpinned
                     ranges, URL dependencies and duplicates. Real packages are never flagged. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const fmt=n=>n.toLocaleString("en-US");
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

/* ------------------------------------------------------------ backlog reducer data (synthetic) */
const SVC={"billing-api":{net:1,sens:1,own:"Payments team"},"orders-svc":{net:1,sens:1,own:"Orders team"},"auth-gateway":{net:1,sens:1,own:"Identity team"},
 "support-portal":{net:1,sens:0,own:"Support tools team"},"ingest-worker":{net:0,sens:1,own:"Data platform"},"docs-builder":{net:0,sens:0,own:"Developer experience"}};
const SVN=Object.keys(SVC);
const HAND=[
 ["SYN-2026-0142","synth-pdf 2.3.1: font parsing overflow","billing-api","crit","yes",1,"POST /api/invoices > InvoiceController.create > pdf.render > parseFont","Upgrade synth-pdf to 2.4.2. PR 412 is open with 412 tests passed."],
 ["SYN-2026-0198","SQL built from request input, report.py line 88","orders-svc","high","yes",0,"GET /orders/report > report.build_query > cursor.execute","Use a parameterized query. A patch is suggested for review."],
 ["SYN-2026-0231","synth-yaml 1.8.0: unsafe load","ingest-worker","high","yes",1,"queue partner-uploads > ingest.parse > yaml.load","Upgrade to 2.0.1 and switch to safeLoad. Major version: the notes list one breaking change."],
 ["SYN-2026-0077","synth-jwt 1.1.4: empty algorithm list accepted","auth-gateway","high","unknown",0,"","Upgrade synth-jwt to 1.2.0 and set the algorithm list explicitly."],
 ["SYN-2026-0154","synth-markdown 4.2.0: link titles not escaped","support-portal","high","yes",1,"POST /tickets/comment > render.markdown > linkTitle","Upgrade synth-markdown to 4.2.3."],
 ["SYN-2026-0265","synth-requests-cache 0.11.2: cache key ignores auth header","orders-svc","high","yes",0,"GET /orders/:id > client.fetch > cache.get","Upgrade to 0.12.0. No code change needed."],
 ["SYN-2026-0188","synth-xml 1.8.3: external entities resolved","ingest-worker","high","yes",0,"queue partner-uploads > ingest.parse_xml > xml.parse","Upgrade synth-xml to 1.9.0."],
 ["SYN-2026-0219","synth-templates 3.2.1: sandbox escape","support-portal","crit","yes",1,"POST /macros/preview > macros.render > Template.render","Upgrade synth-templates to 3.2.4."]];
const UNREACH=["SYN-2026-0310","synth-tar 2.6.0: path traversal on extract","docs-builder","crit","no",0,"","Upgrade synth-tar to 3.0.2 when docs-builder is next touched. No path from user input."];
const PK=["synth-zip","synth-csv","synth-http","synth-img","synth-date","synth-ldap","synth-mail","synth-glob","synth-ws","synth-semver","synth-qs","synth-proxy"];
const KIND=["denial of service on crafted input","prototype pollution","regular expression backtracking","header injection","path traversal","unbounded memory use","open redirect","insecure default"];
const CODE=["string-built SQL","unescaped output in a template","command built from input","weak hash for tokens"];
const SEVN={crit:"Critical",high:"High",med:"Medium",low:"Low"},SEVW={crit:10,high:7,med:4,low:2};
const TOOLS=["dependency scanner","container scanner","SBOM import","static analysis","dependency scanner, branch release/1.42"];
function makeData(){const D=[];
 for(let i=0;i<412;i++){let o;
  if(i<8){const h=HAND[i];o={id:h[0],t:h[1],svc:h[2],sev:h[3],reach:h[4],ex:!!h[5],path:h[6],fix:h[7]}}
  else if(i===96){const h=UNREACH;o={id:h[0],t:h[1],svc:h[2],sev:h[3],reach:h[4],ex:!1,path:"",fix:h[7]}}
  else{const code=i%9===4,p=PK[i%PK.length],v=(1+i%4)+"."+(i%10)+"."+(i%7);
   const t=code?CODE[i%CODE.length]+", "+["handlers","views","jobs","utils"][i%4]+".py line "+(20+i%180):p+" "+v+": "+KIND[i%KIND.length];
   let sev,svc,ex=!1;
   if(i<38){sev="high";svc=i%2?"auth-gateway":"ingest-worker"}
   else if(i<96){sev=i%2?"med":"low";svc=SVN[i%SVN.length]}
   else{sev=["crit","high","high","med","med","med","low","low"][i%8];svc=SVN[(i*5)%SVN.length]}
   o={id:"SYN-2026-"+String(400+i).padStart(4,"0"),t,svc,sev,reach:i<38?(i%2?"unknown":"yes"):i<96?(i%5===3?"unknown":"yes"):"no",ex,path:"",
      fix:code?"Patch suggested for review: "+(t.indexOf("SQL")>-1?"parameterize the query.":t.indexOf("template")>-1?"escape the output.":t.indexOf("command")>-1?"pass arguments as a list.":"use a salted, slow hash."):"Upgrade "+p+" to "+(2+i%4)+".0."+(i%3)+"."}}
  o.n=1+(i*5)%3;D.push(o)}
 let tot=D.reduce((a,o)=>a+o.n,0);for(let k=0;tot<1000;k++){D[(k*7)%412].n++;tot++}
 return D}
const exposed=o=>SVC[o.svc].net||SVC[o.svc].sens;
const ctxKeep=o=>o.ex||((o.sev==="crit"||o.sev==="high")&&exposed(o));
function score(o,f){let s=SEVW[o.sev];if(f.reach)s*=o.reach==="yes"?1:o.reach==="unknown"?.7:.15;
 if(f.context){s*=(SVC[o.svc].net?1.4:1)*(SVC[o.svc].sens?1.3:1);if(o.ex)s+=4}return s}
function why(o,f,rank){const p=[];p.push(SEVN[o.sev].toLowerCase()+" severity");
 if(f.reach)p.push(o.reach==="yes"?"a call path reaches it":o.reach==="unknown"?"reachability is unknown, so it stays":"no path reaches it");
 if(f.context){const s=SVC[o.svc];p.push(s.net?"the service is internet-facing":"the service is internal");if(s.sens)p.push("it handles sensitive data");if(o.ex)p.push("a public exploit is listed in the synthetic advisory")}
 let w="Rank "+rank+": "+p.join(", ")+".";if(!f.reach&&!f.context)w+=" Severity alone sets this order; add reachability and context to see what really comes first.";return w}
function reducer(root){const D=makeData(),compact=root.classList.contains("vs-red--c"),N=compact?5:8;
 const f={dedupe:!1,reach:!1,context:!1},btn=$$("[data-r-step]",root),nEl=$("[data-r-n]",root),of=$("[data-r-of]",root),st=$("[data-r-stages]",root),
  msg=$("[data-r-msg]",root),list=$("[data-r-list]",root),cnt=$("[data-r-c]",root),lh=$("[data-r-lh]",root),det=$("[data-r-detail]",root),uid=root.id;
 let open=null;
 const STEPS=[["dedupe","Deduplicate"],["reach","Check reachability"],["context","Add business context"]];
 function keep(o,upTo){if(upTo.reach&&o.reach==="no")return!1;if(upTo.context&&!ctxKeep(o))return!1;return!0}
 function count(fl){return D.filter(o=>keep(o,fl)).reduce((a,o)=>a+(fl.dedupe?1:o.n),0)}
 function render(said){const cur=D.filter(o=>keep(o,f)),total=count(f);
  nEl.textContent=fmt(total);of.textContent=(f.dedupe?"unique issues":"findings")+" left of 1,000 sample findings";
  const g={dedupe:!1,reach:!1,context:!1};let prev=1000,h='<li class="is-on"><span>Scanner findings</span><b>1,000</b><i style="--w:100%"></i></li>';
  STEPS.forEach(([k,l])=>{if(f[k]){g[k]=!0;const c=count(g);h+='<li class="is-on"><span>'+l+'</span><b>'+fmt(c)+' (minus '+fmt(prev-c)+')</b><i style="--w:'+Math.max(c/10,.6)+'%"></i></li>';prev=c}
   else h+='<li><span>'+l+'</span><b>not applied</b><i style="--w:0%"></i></li>'});st.innerHTML=h;
  const sorted=cur.slice().sort((a,b)=>score(b,f)-score(a,f)||a.id.localeCompare(b.id));
  lh.textContent=f.context?"Fix now, ranked":"Top of the list";cnt.textContent="Showing "+Math.min(N,sorted.length)+" of "+fmt(sorted.length)+(sorted.length===1?" issue":" issues");
  list.innerHTML=sorted.slice(0,N).map((o,i)=>{const tg=o.reach==="yes"&&f.reach?["reachable","bad"]:o.reach==="unknown"&&f.reach?["unknown","mute"]:[SEVN[o.sev],o.sev==="crit"||o.sev==="high"?"bad":"mute"];
   return'<li><button type="button" class="vs-red__it" data-i="'+D.indexOf(o)+'" data-rank="'+(i+1)+'" aria-expanded="'+(open===D.indexOf(o))+'" aria-controls="'+uid+'-d"><span class="vs-mono">'+(i+1)+'</span><span>'+esc(o.t)+'</span><span class="vs-tag vs-tag--'+tg[1]+'">'+tg[0]+'</span></button></li>'}).join("");
  det.id=uid+"-d";
  if(open!==null&&!sorted.slice(0,N).includes(D[open]))open=null;
  if(open===null)det.innerHTML='<p class="vs-red__e">Choose a finding to see why it ranks there and how to fix it.</p>';else show(open,+$('[data-i="'+open+'"]',list).dataset.rank);
  const on=STEPS.filter(([k])=>f[k]).length;
  msg.textContent=said||(on===0?"Press a step to filter. Nothing is deleted: each finding that drops out keeps its reason.":on===3?"All three steps applied: "+fmt(total)+" issues to fix now. "+fmt(D.filter(o=>keep(o,{reach:!0})).length-total)+" more are scheduled for later, none hidden.":on+" of 3 steps applied.")}
 function show(i,rank){const o=D[i],s=SVC[o.svc];
  const rows=[["Service",o.svc+" · "+s.own],["Reported",o.n+(o.n===1?" report: ":" reports: ")+TOOLS.slice(0,o.n).join("; ")],["Severity",SEVN[o.sev]],
   ["Reachability",o.reach==="yes"?(o.path||"Call path from a public route, high confidence"):o.reach==="unknown"?"Unknown: no call graph for this path yet, so it stays in the list":"No path from any entry point. Dropped with this reason, still searchable"],
   ["Context",(s.net?"Internet-facing":"Internal")+", "+(s.sens?"sensitive data":"no sensitive data")+(o.ex?", public exploit listed":"")],["Why this rank",why(o,f,rank)],["Fix",o.fix]];
  det.innerHTML='<p class="vs-mono">'+o.id+' · Synthetic</p><h3>'+esc(o.t)+'</h3><dl>'+rows.map(r=>'<div><dt>'+r[0]+'</dt><dd>'+esc(r[1])+'</dd></div>').join("")+'</dl>'}
 btn.forEach(b=>b.addEventListener("click",()=>{const k=b.dataset.rStep;f[k]=!f[k];b.setAttribute("aria-pressed",f[k]);render()}));
 $("[data-r-reset]",root).addEventListener("click",()=>{Object.keys(f).forEach(k=>f[k]=!1);btn.forEach(b=>b.setAttribute("aria-pressed","false"));open=null;render("Reset: all 1,000 sample findings are back.")});
 list.addEventListener("click",e=>{const b=e.target.closest(".vs-red__it");if(!b)return;const i=+b.dataset.i;open=open===i?null:i;$$(".vs-red__it",list).forEach(x=>x.setAttribute("aria-expanded",+x.dataset.i===open));
  if(open===null)det.innerHTML='<p class="vs-red__e">Choose a finding to see why it ranks there and how to fix it.</p>';else show(i,+b.dataset.rank)});
 render()}

/* ------------------------------------------------------------ dependency list check */
const ADV=[
 {id:"SYN-2026-0142",eco:"npm",p:"synth-pdf",fix:"2.4.2",sev:"crit",ex:1,s:"A crafted font in a PDF template overflows a buffer in parseFont."},
 {id:"SYN-2026-0231",eco:"npm",p:"synth-yaml",fix:"2.0.1",sev:"high",ex:0,s:"load() builds objects from tags in untrusted YAML.",br:"2.0 makes load() safe by default; code that relied on custom tags needs loadUnsafe()."},
 {id:"SYN-2026-0077",eco:"npm",p:"synth-jwt",fix:"1.2.0",sev:"high",ex:0,s:"Tokens signed with no algorithm pass when the allowed list is empty."},
 {id:"SYN-2026-0154",eco:"npm",p:"synth-markdown",fix:"4.2.3",sev:"med",ex:1,s:"Link titles are not escaped, so rendered HTML can carry a script."},
 {id:"SYN-2026-0310",eco:"npm",p:"synth-tar",fix:"3.0.2",sev:"med",ex:0,s:"Entries named with ../ are extracted outside the target folder.",br:"3.0 drops the sync API; use extract() with await."},
 {id:"SYN-2026-0402",eco:"npm",p:"synth-cookie",fix:"0.7.1",sev:"low",ex:0,s:"Cookie names with control characters are accepted."},
 {id:"SYN-2026-0188",eco:"pip",p:"synth-xml",fix:"1.9.0",sev:"high",ex:0,s:"External entities are resolved by default."},
 {id:"SYN-2026-0219",eco:"pip",p:"synth-templates",fix:"3.2.4",sev:"crit",ex:1,s:"Attribute lookups in user templates escape the sandbox."},
 {id:"SYN-2026-0265",eco:"pip",p:"synth-requests-cache",fix:"0.12.0",sev:"med",ex:0,s:"Cached responses are keyed without the auth header and can be served to another user."}];
const SAMPLE=['{','  "name": "billing-api",','  "version": "1.42.0",','  "dependencies": {','    "express": "^4.19.2",','    "pg": "8.11.3",','    "synth-pdf": "2.3.1",',
 '    "synth-yaml": "^1.8.0",','    "synth-jwt": "1.1.4",','    "synth-markdown": "4.3.0",','    "invoice-themes": "file:../invoice-themes"','  },',
 '  "devDependencies": {','    "eslint": "^8.57.0",','    "synth-tar": "2.6.0"','  }','}'].join("\n");
const SAMPLE_CODE=['// src/invoices/pdf.ts','import { render } from "synth-pdf";','import express from "express";','','// src/import/partners.ts','const yaml = require("synth-yaml");',
 'export function parse(buf) { return yaml.load(buf.toString()); }'].join("\n");
const norm=n=>n.trim().toLowerCase().replace(/_/g,"-");
function ver(spec){if(spec==null)return{v:null,note:"no version given"};let s=String(spec).trim();
 if(/^(git\+|git:|https?:|file:|github:|link:)/.test(s))return{v:null,url:1,note:"installed from a URL, so no version can be checked"};
 if(s===""||s==="*"||s==="latest"||/^x$/i.test(s))return{v:null,note:"any version allowed ("+(s||"empty")+")"};
 const first=s.split("||")[0].split(" - ")[0].split(",")[0].trim();const range=/^[\^~><=!]/.test(first)||/\.x|\*/.test(first);
 const m=first.match(/\d+(\.\d+){0,2}/);if(!m)return{v:null,note:"version "+s+" not understood"};
 return{v:m[0],range,note:range?"range "+s+": the installed version depends on your lockfile; checked "+m[0]:""}}
function cmp(a,b){const x=a.split(".").map(Number),y=b.split(".").map(Number);for(let i=0;i<3;i++){const d=(x[i]||0)-(y[i]||0);if(d)return d}return 0}
function parse(txt,fmtSel){const t=txt.trim();let mode=fmtSel;
 if(mode==="auto")mode=t.startsWith("{")?"npm":/^[A-Za-z0-9_.\-\[\]]+\s*(==|>=|<=|~=|!=|===)/m.test(t)||/^-r\s|^--/m.test(t)?"pip":"list";
 const out=[],notes=[];
 if(mode==="npm"){let j;try{j=JSON.parse(t)}catch(e){throw new Error("This looks like JSON but does not parse ("+e.message.replace(/^JSON\.parse: /,"")+"). Check for a trailing comma or a missing quote.")}
  if(j&&j.packages&&typeof j.packages==="object"){for(const[k,v]of Object.entries(j.packages)){if(!k)continue;const n=k.split("node_modules/").pop();out.push({n,spec:v.version,dev:!!v.dev,eco:"npm",line:0})}}
  else if(j&&j.dependencies&&typeof j.dependencies==="object"&&j.lockfileVersion){for(const[n,v]of Object.entries(j.dependencies))out.push({n,spec:v.version,dev:!!v.dev,eco:"npm",line:0})}
  else{[["dependencies",0],["optionalDependencies",0],["devDependencies",1]].forEach(([k,dev])=>{if(j&&j[k]&&typeof j[k]==="object")for(const[n,v]of Object.entries(j[k]))out.push({n,spec:v,dev:!!dev,eco:"npm",line:0})})}
  return{mode:"package.json",eco:"npm",pk:out,notes}}
 t.split(/\r?\n/).forEach((raw,i)=>{const l=raw.replace(/\s+#.*$/,"").trim();if(!l||l.startsWith("#"))return;
  if(mode==="pip"){if(/^(-r|-c|--|-e)/.test(l)){notes.push("Line "+(i+1)+": "+l.split(" ")[0]+" options are skipped here.");return}
   const m=l.split(";")[0].match(/^([A-Za-z0-9_.\-]+)(\[[^\]]*\])?\s*(.*)$/);if(!m){notes.push("Line "+(i+1)+" not understood: "+l);return}
   const spec=m[3].trim();out.push({n:m[1],spec:spec?spec.replace(/^===?/,""):null,pin:/^==/.test(spec),dev:!1,eco:"pip",line:i+1})}
  else{let n,v;const at=l.lastIndexOf("@");if(at>0){n=l.slice(0,at);v=l.slice(at+1)}else{const p=l.split(/\s*==\s*|\s+/);n=p[0];v=p[1]}
   if(!/^[@A-Za-z0-9_.\/\-]+$/.test(n)){notes.push("Line "+(i+1)+" not understood: "+l);return}out.push({n,spec:v==null?null:v,dev:!1,eco:"any",line:i+1})}});
 return{mode:mode==="pip"?"requirements.txt":"name@version list",eco:mode==="pip"?"pip":"any",pk:out,notes}}
function imported(code,p){if(!code.trim())return{state:"none"};const mod=p.n.replace(/-/g,"_"),lines=code.split(/\r?\n/);
 const q=p.n.replace(/[.*+?^${}()|[\]\\\/]/g,"\\$&"),qm=mod.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
 const re=new RegExp("(require\\(\\s*['\"]"+q+"(['\"/])|from\\s+['\"]"+q+"(['\"/])|import\\s+['\"]"+q+"['\"]|^\\s*import\\s+"+qm+"\\b|^\\s*from\\s+"+qm+"(\\.|\\s+import))");
 for(let i=0;i<lines.length;i++)if(re.test(lines[i]))return{state:"yes",line:i+1};return{state:"no"}}
function manifest(root){const src=$("[data-m=src]",root),code=$("[data-m=code]",root),sel=$("[data-m=fmt]",root),out=$("[data-m-out]",root);
 $("[data-m-adv]",root).innerHTML='<thead><tr><th scope="col">Advisory</th><th scope="col">Package</th><th scope="col">Fixed in</th><th scope="col">Severity</th><th scope="col">Summary</th></tr></thead><tbody>'+
  ADV.map(a=>'<tr><td class="vs-mono">'+a.id+'</td><td class="vs-mono">'+a.p+' ('+a.eco+')</td><td class="vs-mono">'+a.fix+'</td><td>'+SEVN[a.sev]+'</td><td>'+esc(a.s)+'</td></tr>').join("")+'</tbody>';
 const empty=out.innerHTML;
 function err(title,body){src.setAttribute("aria-invalid","true");out.innerHTML='<p class="vs-err" role="alert"><b>'+esc(title)+'</b>'+esc(body)+'</p>'}
 function run(){src.removeAttribute("aria-invalid");const t=src.value;
  if(!t.trim()){err("Nothing to check yet.","Paste a package.json, package-lock.json, requirements.txt or one name@version per line, or load the sample.");src.focus();return}
  if(t.split(/\n/).length>2000){err("That list is too long for this page.","Paste up to 2,000 lines. For a whole repository, request a free scan above.");return}
  let r;try{r=parse(t,sel.value)}catch(e){err("Could not read the list.",e.message);return}
  if(!r.pk.length){err("No packages found.","Expected package names with versions, for example synth-pdf@2.3.1. If this is a package.json, check that it has a dependencies block.");return}
  const hy=r.notes.slice(),seen={},hits=[];
  r.pk.forEach(p=>{const k=norm(p.n),v=ver(p.spec);p.v=v;
   if(seen[k]&&seen[k]!==String(p.spec))hy.push(p.n+" appears twice, as "+seen[k]+" and "+p.spec+". Only one version can win.");seen[k]=String(p.spec);
   if(v.url)hy.push(p.n+": "+v.note+".");else if(v.v===null)hy.push(p.n+": "+v.note+". Pin it so the result is repeatable.");else if(v.range)hy.push(p.n+": "+v.note+".");
   else if(r.eco==="pip"&&!p.pin)hy.push(p.n+": not pinned with ==, so installs can differ between machines.");
   ADV.forEach(a=>{if(norm(a.p)!==k||(p.eco!=="any"&&p.eco!==a.eco))return;
    if(v.v===null){hits.push({p,a,unk:1});return}if(cmp(v.v,a.fix)<0)hits.push({p,a})})});
  const c=code.value;
  hits.forEach(h=>{h.imp=imported(c,h.p);const rf=h.imp.state==="yes"?1:h.imp.state==="none"?.75:.55;
   h.score=SEVW[h.a.sev]*rf*(h.p.dev?.45:1)*(h.a.ex?1.3:1)*(h.unk?.8:1)});
  hits.sort((a,b)=>b.score-a.score);
  const sum='<dl class="vs-sum"><div><dt>Packages read</dt><dd>'+r.pk.length+'</dd></div><div><dt>Format</dt><dd style="font-size:15px;padding-top:6px">'+r.mode+'</dd></div><div><dt>To fix</dt><dd>'+hits.length+'</dd></div><div><dt>Notes</dt><dd>'+hy.length+'</dd></div></dl>';
  let body;
  if(!hits.length)body='<p class="vs-fix__w"><strong>None of the '+r.pk.length+' packages is on the synthetic advisory list.</strong> That is not a clean bill of health: this page knows only '+ADV.length+' synthetic advisories, all for synth- packages. Load the sample to see a ranked result.</p>';
  else body='<h3>Ranked fixes</h3><ol class="vs-fix">'+hits.map((h,i)=>{const a=h.a,p=h.p,maj=h.p.v.v&&+a.fix.split(".")[0]>+h.p.v.v.split(".")[0];
   const reach=h.imp.state==="yes"?"imported in the pasted files, line "+h.imp.line:h.imp.state==="none"?"unknown: paste the files that import it to check":"not imported in the pasted files, so unknown and kept";
   const parts=[SEVN[a.sev].toLowerCase()+" severity"];if(a.ex)parts.push("a public exploit is listed");parts.push(p.dev?"but it is a dev dependency, so it does not ship to production":"it is a runtime dependency");
   if(h.imp.state==="yes")parts.push("your code imports it");else if(h.imp.state==="no")parts.push("no import was found in what you pasted");if(h.unk)parts.push("the version is not pinned, so it may or may not be affected");
   const lead=i===0?"Why this one first: ":"Why rank "+(i+1)+": ";
   const cmd=a.eco==="pip"?'pip install "'+a.p+'>='+a.fix+'"   # then pin '+a.p+'=='+a.fix+' in requirements.txt':"npm install "+(p.dev?"-D ":"")+a.p+"@"+a.fix;
   return'<li'+(i===0?' class="is-top"':'')+'><div class="vs-fix__h"><b>'+esc(p.n)+' '+esc(h.p.v.v||String(p.spec))+' to '+a.fix+'</b><span class="vs-tag vs-tag--'+(a.sev==="crit"||a.sev==="high"?"bad":"mute")+'">'+SEVN[a.sev]+'</span><span class="vs-mono">'+a.id+'</span><span class="vs-fix__r">rank '+(i+1)+' · score '+h.score.toFixed(1)+'</span></div>'+
    '<p>'+esc(a.s)+'</p><p class="vs-fix__w"><strong>'+lead+'</strong>'+esc(parts.join(", "))+'.</p><p>Reachability: '+esc(reach)+'.</p>'+(maj?'<p>Major version change. '+esc(a.br||"Read the changelog before merging.")+'</p>':'')+'<code>'+esc(cmd)+'</code></li>'}).join("")+'</ol>';
  const hyg=hy.length?'<h3>Notes on the list</h3><ul class="vs-hyg">'+hy.map(x=>'<li>'+esc(x)+'</li>').join("")+'</ul>':'';
  out.innerHTML=sum+body+hyg+'<p class="vs-note">Synthetic advisories only. Checked in this browser at '+new Date().toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"})+'.</p>'}
 $("[data-m-run]",root).addEventListener("click",run);
 sel.addEventListener("change",()=>{if(src.value.trim())run();else out.innerHTML='<div class="vs-man__empty"><p class="vs-red__k">Results</p><p>Format set to <b>'+esc(sel.options[sel.selectedIndex].text)+'</b>. Paste a list and press <b>Check the list</b>.</p></div>'});
 $("[data-m-sample]",root).addEventListener("click",()=>{src.value=SAMPLE;code.value=SAMPLE_CODE;sel.value="auto";run()});
 $("[data-m-clear]",root).addEventListener("click",()=>{src.value="";code.value="";src.removeAttribute("aria-invalid");out.innerHTML=empty;src.focus()});
 src.addEventListener("keydown",e=>{if(e.key==="Enter"&&(e.ctrlKey||e.metaKey)){e.preventDefault();run()}})}

export function boot(){$$("[data-vs=reducer]").forEach(reducer);$$("[data-vs=manifest]").forEach(manifest);
 $$(".mv-pscroll").forEach(el=>{const f=()=>{if(el.scrollWidth>el.clientWidth+2){el.tabIndex=0;el.setAttribute("role","region");el.setAttribute("aria-label",el.dataset.label||"Scrollable table")}else{el.removeAttribute("tabindex")}};f();addEventListener("resize",f)})}
