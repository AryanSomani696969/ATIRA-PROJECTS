/* Gradekeel page tools: the sample grader on /try-grading. Everything runs in the browser with synthetic lots;
   a photo the visitor picks is read on a canvas in the page and never leaves it. No network calls. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const E=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const STAGES=["Green","Breakers","Turning","Pink","Light red","Red"];
const FILL=["#7FB069","#C9D27A","#F2B632","#EE8A5B","#E0553D","#C0392B"];
/* the published tomato standard, kept in step with TOMATO_STD in content_b.py: serious, all defects, uniformity, small */
const TOMATO_STD=[["Grade 1",.04,.08,.80,.10],["Grade 2",.10,.15,.60,.20]];
const BANDS=[["Small",0,50],["Medium",50,57],["Large",57,64],["Extra large",64,99]];
const ONION_BANDS=[["Small",0,57],["Medium",57,76],["Large",76,95],["Jumbo",95,140]];
const PRICE={"Grade 1":21.5,"Grade 2":16.75,"Ungraded":15};
/* three synthetic lots per commodity: seed, mean size (mm), spread, colour weights, serious and minor defect rates */
const LOTS={
 tomato:{a:{name:"Lot A · packed Roma",seed:11,mean:59.5,sd:3.2,w:[0,0,0,.04,.30,.66],ser:.02,min:.03},
         b:{name:"Lot B · mixed ripeness",seed:23,mean:58,sd:3.6,w:[0,.04,.14,.46,.30,.06],ser:.03,min:.06},
         c:{name:"Lot C · field run",seed:37,mean:55,sd:5.2,w:[.04,.08,.12,.2,.26,.3],ser:.09,min:.08}},
 onion:{a:{name:"Lot A · packed yellow onion",seed:41,mean:80,sd:6,ser:.02,min:.04},
        b:{name:"Lot B · mixed sizes",seed:53,mean:72,sd:13,ser:.04,min:.06},
        c:{name:"Lot C · field run",seed:67,mean:66,sd:12,ser:.14,min:.12}}};
const N=24,DEF_S=["Crack","Soft spot"],DEF_M=["Scar","Sunscald mark"];
function rng(seed){let s=seed>>>0;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296}}
function lot(com,key){
 const L=LOTS[com][key],r=rng(L.seed),f=[];
 const pick=w=>{let x=r(),a=0;for(let i=0;i<w.length;i++){a+=w[i];if(x<a)return i}return w.length-1};
 for(let i=0;i<N;i++){
  const g=Math.sqrt(-2*Math.log(r()+1e-9))*Math.cos(2*Math.PI*r());
  const d=Math.round((L.mean+g*L.sd)*10)/10,u=r();
  const def=u<L.ser?{k:DEF_S[i%2],s:1}:u<L.ser+L.min?{k:DEF_M[i%2],s:0}:null;
  f.push({d,st:com==="tomato"?pick(L.w):-1,def,x:(i%6)*64+44+(r()-.5)*8,y:Math.floor(i/6)*56+44+(r()-.5)*8});
 }return{name:L.name,f}}
/* ------------------------------------------------------------ drawing */
function fruitSvg(com,o,mark){
 const r=com==="tomato"?o.d*.4:o.d*.31,cx=o.x,cy=o.y;let s="";
 if(com==="tomato"){s+=`<ellipse cx="${cx}" cy="${cy}" rx="${(r*1.05).toFixed(1)}" ry="${(r*.93).toFixed(1)}" fill="${FILL[o.st]}" stroke="#2A1712" stroke-width="1.6"/>`+
  `<path d="M${(cx-r*.6).toFixed(1)} ${(cy-r*.15).toFixed(1)} Q${(cx-r*.5).toFixed(1)} ${(cy-r*.6).toFixed(1)} ${(cx-r*.1).toFixed(1)} ${(cy-r*.7).toFixed(1)}" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="2.4" stroke-linecap="round"/>`+
  `<circle cx="${cx}" cy="${(cy-r*.55).toFixed(1)}" r="${(r*.14).toFixed(1)}" fill="#3E8E41"/>`}
 else{s+=`<path d="M${cx} ${(cy-r*1.1).toFixed(1)} C${(cx+r*1.25).toFixed(1)} ${(cy-r*.7).toFixed(1)} ${(cx+r*1.05).toFixed(1)} ${(cy+r).toFixed(1)} ${cx} ${(cy+r).toFixed(1)} C${(cx-r*1.05).toFixed(1)} ${(cy+r).toFixed(1)} ${(cx-r*1.25).toFixed(1)} ${(cy-r*.7).toFixed(1)} ${cx} ${(cy-r*1.1).toFixed(1)} Z" fill="#E9B566" stroke="#2A1712" stroke-width="1.6"/>`+
  `<path d="M${(cx-r*.2).toFixed(1)} ${(cy-r).toFixed(1)} C${(cx-r*.7).toFixed(1)} ${(cy-r*.3).toFixed(1)} ${(cx-r*.5).toFixed(1)} ${(cy+r*.6).toFixed(1)} ${(cx-r*.1).toFixed(1)} ${(cy+r*.95).toFixed(1)}" fill="none" stroke="#2A1712" stroke-opacity=".3" stroke-width="1.3"/>`}
 if(o.def){const k=o.def.k;s+=k==="Crack"?`<path d="M${(cx+r*.1).toFixed(1)} ${(cy+r*.05).toFixed(1)} l${(r*.18).toFixed(1)} ${(r*.12).toFixed(1)} l${(r*.06).toFixed(1)} ${(r*.2).toFixed(1)}" fill="none" stroke="#2A1712" stroke-width="1.8" stroke-linecap="round"/>`:
  k==="Soft spot"?`<circle cx="${(cx+r*.25).toFixed(1)}" cy="${(cy+r*.2).toFixed(1)}" r="${(r*.2).toFixed(1)}" fill="#5A2A1A" fill-opacity=".8"/>`:
  `<ellipse cx="${(cx+r*.2).toFixed(1)}" cy="${(cy+r*.25).toFixed(1)}" rx="${(r*.28).toFixed(1)}" ry="${(r*.14).toFixed(1)}" fill="#E8C48E"/>`;
  if(mark)s+=`<circle cx="${cx}" cy="${cy}" r="${(r*1.32).toFixed(1)}" class="gk-mk"/>`}
 return s}
function cardSvg(){let s='<g><rect x="300" y="250" width="104" height="40" rx="5" fill="#fff" stroke="#2A1712" stroke-width="1.4"/>';
 for(let i=0;i<6;i++)s+=`<rect x="${306+i*16}" y="256" width="13" height="12" fill="${FILL[i]}"/>`;
 s+='<path d="M306 282 h92" stroke="#2A1712" stroke-width="1.4"/>';for(let i=0;i<=10;i++)s+=`<path d="M${306+i*9.2} 282 v${i%5?-3:-6}" stroke="#2A1712" stroke-width="1.2"/>`;return s+"</g>"}
function photo(com,L,card,mark){
 return `<svg viewBox="0 0 420 300" aria-hidden="true"><rect width="420" height="300" fill="#EFE3CB"/><rect x="10" y="10" width="400" height="${card?232:280}" rx="12" fill="#C98F55" stroke="#2A1712" stroke-width="1.6"/>`+
  L.f.map(o=>fruitSvg(com,o,mark)).join("")+(card?cardSvg():"")+"</svg>"}
function stampSvg(t,sub){return `<circle cx="60" cy="60" r="54" fill="${t==="?"?"#FFF6E5":"#F2B632"}" stroke="#2A1712" stroke-width="3"/><circle cx="60" cy="60" r="40" fill="none" stroke="#2A1712" stroke-width="2"/>`+
 `<text x="60" y="42" text-anchor="middle" font-family="Fragment Mono,monospace" font-size="10" letter-spacing="1.2" fill="#2A1712">${E(sub)}</text>`+
 `<text x="60" y="${t.length>2?72:80}" text-anchor="middle" font-family="Bricolage Grotesque,sans-serif" font-weight="700" font-size="${t.length>2?22:44}" fill="#2A1712">${E(t)}</text>`}
/* ------------------------------------------------------------ grading */
function grade(com,L,card){
 const n=L.f.length,ser=L.f.filter(o=>o.def&&o.def.s).length/n,all=L.f.filter(o=>o.def).length/n;
 const bands=com==="tomato"?BANDS:ONION_BANDS,size=bands.map(([b,lo,hi])=>[b,L.f.filter(o=>o.d>=lo&&o.d<hi).length/n]);
 const small=size[0][1];let col=null,uni=1;
 if(com==="tomato"){col=STAGES.map((s,i)=>[s,L.f.filter(o=>o.st===i).length/n]);uni=0;for(let i=0;i<5;i++)uni=Math.max(uni,col[i][1]+col[i+1][1])}
 let g="Off-grade",why=[];
 const lim=TOMATO_STD;
 for(const [name,s,a,u,sm] of lim){const fails=[];if(ser>s)fails.push(`serious defects ${p1(ser)} (limit ${p1(s)})`);if(all>a)fails.push(`all defects ${p1(all)} (limit ${p1(a)})`);
  if(com==="tomato"&&uni<u)fails.push(`colour uniformity ${p1(uni)} (needs ${p1(u)})`);if(card&&small>sm)fails.push(`small fruit ${p1(small)} (limit ${p1(sm)})`);
  if(!fails.length){g=name;break}why.push(`Not ${name}: ${fails.join(", ")}.`)}
 /* confidence: agreement base, less without the card, less when a value sits within 2 points of a limit */
 let conf=card?.94:.78;const near=v=>lim.some(r=>r.slice(1).some(x=>Math.abs(v-x)<.02));[ser,all,uni,small].forEach(v=>{if(near(v))conf-=.04});
 if(com==="onion")conf-=.08;conf=Math.max(.5,Math.round(conf*100)/100);
 return{g,why,conf,size,col,ser,all,uni,small,defs:L.f.filter(o=>o.def).map(o=>o.def.k)}}
const pc=v=>Math.round(v*100)+"%",p1=v=>(Math.round(v*1000)/10)+"%";
const level=c=>c>=.85?"high":c>=.7?"medium":"low";
/* ------------------------------------------------------------ own photo: colour and dark-spot reading only */
function readPhoto(img){
 const cv=document.createElement("canvas"),w=200,h=Math.max(1,Math.round(img.naturalHeight/img.naturalWidth*200));cv.width=w;cv.height=h;
 const x=cv.getContext("2d",{willReadFrequently:true});x.drawImage(img,0,0,w,h);const d=x.getImageData(0,0,w,h).data;
 let m=0,red=0,ora=0,yel=0,grn=0,dark=0,tot=w*h;
 for(let i=0;i<d.length;i+=4){const r=d[i]/255,g=d[i+1]/255,b=d[i+2]/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),v=mx,s=mx?(mx-mn)/mx:0;
  if(s<.28||v<.12)continue;m++;let hh=0;const c=mx-mn;if(c){hh=mx===r?((g-b)/c)%6:mx===g?(b-r)/c+2:(r-g)/c+4;hh*=60;if(hh<0)hh+=360}
  if(v<.32)dark++;if(hh<15||hh>=340)red++;else if(hh<32)ora++;else if(hh<55)yel++;else if(hh<170)grn++}
 return{cv,share:m/tot,mix:m?[["Red",red/m],["Orange",ora/m],["Yellow",yel/m],["Green",grn/m]]:[],dark:m?dark/m:0}}
/* ------------------------------------------------------------ the widget */
function grader(root){
 const st={com:"tomato",key:"a",card:true,mark:true,own:null,res:null};
 const view=$("[data-view]",root),cap=$("[data-cap]",root),msg=$("[data-msg]",root),res=$("[data-res]",root),empty=$("[data-empty]",root);
 const samples=$$("[data-sample]",root),coms=$$("[data-com]",root),file=$("[data-file]",root),cardC=$("[data-card]",root),markC=$("[data-overlay]",root);
 const say=(t,err)=>{msg.textContent=t;msg.classList.toggle("is-err",!!err)};
 const current=()=>lot(st.com,st.key);
 function show(){
  if(st.own){view.innerHTML="";view.appendChild(st.own.cv);view.setAttribute("aria-label","Your photo");cap.textContent="Your photo, read in this browser only";return}
  const L=current();view.innerHTML=photo(st.com,L,st.card,st.mark);
  view.setAttribute("aria-label",`${L.name}: ${L.f.length} ${st.com==="tomato"?"tomatoes":"onions"} on a tray${st.card?", reference card in the lower right":""}.`);
  cap.textContent=`${L.name} · sample photo, synthetic lot`}
 function clear(){st.res=null;res.hidden=true;empty.hidden=false}
 function bars(ol,rows,cls){ol.innerHTML=rows.map(([k,v],i)=>`<li><span>${E(k)}</span><i class="${cls?cls+i:""}" style="transform:scaleX(${RM?v:0})" data-v="${v}"></i><b>${pc(v)}</b></li>`).join("");
  if(!RM)requestAnimationFrame(()=>requestAnimationFrame(()=>$$("i",ol).forEach((el,j)=>{el.style.transitionDelay=j*70+"ms";el.style.transform=`scaleX(${el.dataset.v})`})))}
 function render(){
  const sz=$("[data-size]",root),co=$("[data-color]",root),df=$("[data-def]",root),why=$("[data-why]",root),pr=$("[data-price]",root);
  res.hidden=false;empty.hidden=true;
  if(st.own){const o=st.own;$("[data-stamp]",root).innerHTML=stampSvg("?","NOT GRADED");$("[data-g]",root).textContent="Not graded";
   $("[data-conf]",root).textContent="A grade needs the reference card and a sample-photo layout this page can read.";
   sz.innerHTML='<li><span>Size</span><i style="transform:scaleX(0)"></i><b>n/a</b></li>';bars(co,o.mix,"");
   df.innerHTML=`<li>Dark areas: ${pc(o.dark)} of the produce</li>`;
   why.innerHTML=`<p>The page found produce in about ${pc(o.share)} of your photo and read its colour mix. Size and defects need the reference card in frame and the grader in the app.</p>`;pr.innerHTML="";
   say("Your photo was read in this browser. Colour mix is shown; no grade is given.");return}
  const L=current(),r=grade(st.com,L,st.card);st.res=r;
  const draft=st.com==="onion";const cert=!draft&&r.conf>=.7;
  $("[data-stamp]",root).innerHTML=stampSvg(r.g==="Grade 1"?"1":r.g==="Grade 2"?"2":"OFF",draft?"DRAFT":"GRADE");
  $("[data-g]",root).textContent=(draft?"Draft: ":"")+r.g;
  $("[data-conf]",root).textContent=`Confidence ${r.conf.toFixed(2)}, ${level(r.conf)}. ${draft?"Onion is in testing: no certificate is issued.":cert?"A certificate would be issued.":"Below 0.70: the app would ask for another photo."}`;
  if(st.card)bars(sz,r.size,"");else sz.innerHTML='<li><span>Size</span><i style="transform:scaleX(0)"></i><b>n/a</b></li><li><span>No card</span><i style="transform:scaleX(0)"></i><b></b></li>';
  if(r.col)bars(co,r.col,"gk-c");else co.innerHTML='<li><span>Not used</span><i style="transform:scaleX(0)"></i><b>n/a</b></li>';
  const cnt={};r.defs.forEach(k=>cnt[k]=(cnt[k]||0)+1);
  df.innerHTML=r.defs.length?Object.entries(cnt).map(([k,v])=>`<li>${E(k)}: ${v} of ${L.f.length}</li>`).join(""):"<li>None seen in the top layer</li>";
  why.innerHTML=(r.why.length?r.why.map(w=>`<p>${E(w)}</p>`).join(""):`<p>Every ${E(r.g)} limit is met.</p>`)+(st.card?"":"<p>Without the reference card the grader cannot measure size, so the small-fruit limit was not checked and confidence is lower.</p>");
  if(st.com==="tomato"&&r.g!=="Off-grade"){const p=PRICE[r.g],u=PRICE.Ungraded;
   pr.innerHTML=`<div class="gk-gr__why"><p><b>Price comparison</b> (sample data, 25 lb carton): ${E(r.g)} $${p.toFixed(2)} against $${u.toFixed(2)} ungraded, a difference of $${(p-u).toFixed(2)} a carton.</p></div>`}
  else pr.innerHTML=`<div class="gk-gr__why"><p><b>Price comparison</b>: ${draft?"no price link while the onion standard is in testing.":"off-grade lots are priced by negotiation; pull the marked fruit and grade again."}</p></div>`;
  say(`${L.name}: ${draft?"draft ":""}${r.g}, confidence ${r.conf.toFixed(2)}.`)}
 function setSample(k,focus){st.key=k;st.own=null;samples.forEach(b=>{const on=b.dataset.sample===k;b.setAttribute("aria-pressed",on);b.classList.toggle("is-on",on);if(on&&focus)b.focus()});clear();show();say("Sample selected. Press Grade this lot.")}
 samples.forEach((b,i)=>{b.addEventListener("click",()=>setSample(b.dataset.sample));
  b.addEventListener("keydown",e=>{const d=e.key==="ArrowDown"||e.key==="ArrowRight"?1:e.key==="ArrowUp"||e.key==="ArrowLeft"?-1:0;if(!d)return;e.preventDefault();
   setSample(samples[(i+d+samples.length)%samples.length].dataset.sample,true)})});
 coms.forEach(b=>b.addEventListener("click",()=>{st.com=b.dataset.com;coms.forEach(c=>{const on=c===b;c.setAttribute("aria-pressed",on);c.classList.toggle("is-on",on)});
  samples.forEach(s=>{$("b",s).textContent=LOTS[st.com][s.dataset.sample].name});st.own=null;clear();show();say(st.com==="onion"?"Onion selected. Its standard is in testing, so grades are drafts.":"Tomato selected.")}));
 cardC.addEventListener("change",()=>{st.card=cardC.checked;show();if(st.res)render();else say(st.card?"Reference card in the photo.":"No reference card: size cannot be measured.")});
 markC.addEventListener("change",()=>{st.mark=markC.checked;show();say(st.mark?"Defects are marked on the photo.":"Defect marks hidden.")});
 file.addEventListener("change",()=>{const f=file.files&&file.files[0];if(!f)return;
  if(!/^image\/(jpeg|png|webp|gif)$/.test(f.type)){say("That file is not a JPG or PNG photo. Choose an image file.",true);file.value="";return}
  if(f.size>15e6){say("That photo is larger than 15 MB. Choose a smaller one.",true);file.value="";return}
  const rd=new FileReader;rd.onerror=()=>say("The photo could not be read. Try another file.",true);
  rd.onload=()=>{const img=new Image;img.onerror=()=>say("The photo could not be opened. Try another file.",true);
   img.onload=()=>{const o=readPhoto(img);if(o.share<.08){say("We could not find produce in this photo. Try a closer photo on a plain surface.",true);return}
    st.own=o;samples.forEach(b=>{b.setAttribute("aria-pressed","false");b.classList.remove("is-on")});show();render()};img.src=rd.result};rd.readAsDataURL(f)});
 $("[data-grade]",root).addEventListener("click",()=>{show();render()});
 $("[data-replay]",root).addEventListener("click",()=>{if(!st.res&&!st.own){show();render();return}res.hidden=true;show();requestAnimationFrame(()=>{render();say("Replayed. "+msg.textContent)})});
 show()}
export function boot(){
 $$('[data-gk="grader"]').forEach(grader);
 $$(".mv-pscroll").forEach(el=>{const f=()=>{const s=el.scrollWidth>el.clientWidth+2;s?el.setAttribute("tabindex","0"):el.removeAttribute("tabindex")};f();addEventListener("resize",f)});
}
