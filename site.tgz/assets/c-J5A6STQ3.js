/* Teachprism hero: a classroom wall of glass lesson cards in morning light on plum. 12 second cycle in three shots.
   Shot 1 (0-4 s): slow push-in; standards tags drift in and five timed blocks leave the wall and stack into one lesson plan page.
   Shot 2 (4-8 s): a quarter-turn orbit while the plan splits into three worksheet levels (support blue, core cream, stretch green).
   Shot 3 (8-12 s): the levels fold back, the week strip locks in green and a parent note slides out and fills; pull back to the opening frame.
   Scrolling holds the locked week. Everything shown is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const bg=new T.Color(colors.bg),cream=new T.Color(color("--tp-cream","#fff8ec")),green=new T.Color(color("--tp-green","#7bc043")),blue=new T.Color(color("--tp-blue","#4c7bd1"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),9,20);
const root=new T.Group;scene.add(root);const geos=[],mats=[];const G=g=>(geos.push(g),g);const M=(c,o={})=>{const m=new T.MeshStandardMaterial(Object.assign({color:c,roughness:.7,metalness:0},o));mats.push(m);return m};
const RL=(w,h)=>{const a=w/2,b=h/2,g=new T.BufferGeometry;g.setAttribute("position",new T.Float32BufferAttribute([-a,-b,0,a,-b,0,a,-b,0,a,b,0,a,b,0,-a,b,0,-a,b,0,-a,-b,0],3));return G(g)};
root.add(new T.AmbientLight(0xe8dcef,.7));
const key=new T.DirectionalLight(0xffe9c8,1.2);key.position.set(-5,6,5);root.add(key);
const rim=new T.DirectionalLight(green.getHex(),.4);rim.position.set(5,1,-4);root.add(rim);
/* morning light on the wall: one flat, paler quad */
const lightQ=new T.Mesh(G(new T.PlaneGeometry(6,7)),new T.MeshBasicMaterial({color:bg.clone().lerp(cream,.06),transparent:!0,opacity:.9}));lightQ.position.set(1.6,1.4,-3.3);lightQ.rotation.z=-.42;root.add(lightQ);
/* the wall of glass cards */
const COLS=small?6:8,ROWS=4,CW=.82,CH=.54,GX=.16,GY=.16,WZ=-3.1;
const cardGeo=G(new T.BoxGeometry(CW,CH,.03)),glass=M(cream.clone().lerp(bg,.55),{transparent:!0,opacity:.22,roughness:.15});
const wall=new T.InstancedMesh(cardGeo,glass,COLS*ROWS),o=new T.Object3D;root.add(wall);
const wallPos=[];for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){const x=(c-(COLS-1)/2)*(CW+GX)+.6,y=(r-(ROWS-1)/2)*(CH+GY)+1.5;wallPos.push(new T.Vector3(x,y,WZ));o.position.set(x,y,WZ);o.rotation.set(0,0,0);o.scale.set(1,1,1);o.updateMatrix();wall.setMatrixAt(r*COLS+c,o.matrix)}
const eg=RL(CW,CH),edgeMat=new T.LineBasicMaterial({color:bg.clone().lerp(cream,.42),transparent:!0,opacity:.7});mats.push(edgeMat);
wallPos.forEach(p=>{const l=new T.LineSegments(eg,edgeMat);l.position.copy(p);root.add(l)});
/* the lesson plan page */
const PW=1.55,PH=2.15,page=new T.Group;page.position.set(.75,1.15,.2);root.add(page);
const sheetGeo=G(new T.BoxGeometry(PW,PH,.03)),pageMat=M(cream.clone(),{roughness:.85,emissive:cream.clone(),emissiveIntensity:.32});const sheet=new T.Mesh(sheetGeo,pageMat);page.add(sheet);
const titleBar=new T.Mesh(G(new T.BoxGeometry(.8,.07,.01)),M(bg.clone().lerp(cream,.2)));titleBar.position.set(-.33,PH/2-.22,.025);page.add(titleBar);
/* five timed blocks: each block flies from a wall card into its row */
const NB=5,blkGeo=G(new T.BoxGeometry(PW-.24,.3,.025)),timeGeo=G(new T.BoxGeometry(.28,.18,.01)),blocks=[],SRC=[2,9,13,20,26];
for(let i=0;i<NB;i++){const g=new T.Group;const b=new T.Mesh(blkGeo,M(i===3?cream.clone().lerp(green,.55):cream.clone().lerp(bg,.28),{transparent:!0,opacity:0,emissive:i===3?green.clone():cream.clone(),emissiveIntensity:i===3?.18:.12}));g.add(b);
const tm=new T.Mesh(timeGeo,M(blue.clone(),{transparent:!0,opacity:0,emissive:blue.clone(),emissiveIntensity:.15}));tm.position.set(-(PW-.24)/2+.22,0,.02);g.add(tm);
root.add(g);blocks.push({g,b,tm,home:new T.Vector3(0,PH/2-.75-i*.34,.04),src:wallPos[SRC[i]%wallPos.length].clone()})}
/* standards tags */
const tagGeo=G(new T.BoxGeometry(.42,.13,.02)),tags=[0,1,2].map(i=>{const m=new T.Mesh(tagGeo,M(i===1?green.clone():blue.clone(),{transparent:!0,opacity:0,emissive:i===1?green.clone():blue.clone(),emissiveIntensity:.25}));root.add(m);return m});
/* three worksheet levels that split out of the plan */
const lvGeo=G(new T.BoxGeometry(1.15,1.55,.02)),lvCol=[blue,cream,green],levels=lvCol.map((c,i)=>{const g=new T.Group;const s=new T.Mesh(lvGeo,M(cream.clone(),{transparent:!0,opacity:0}));g.add(s);
const edge=new T.LineSegments(RL(1.15,1.55),new T.LineBasicMaterial({color:i===1?bg.clone().lerp(cream,.6):c.clone(),transparent:!0,opacity:0}));mats.push(edge.material);g.add(edge);root.add(g);return{g,s,edge}});
/* the week strip and the parent note */
const dayGeo=G(new T.BoxGeometry(.34,.46,.02)),days=[0,1,2,3,4].map(i=>{const m=new T.Mesh(dayGeo,M(bg.clone().lerp(cream,.12),{transparent:!0,opacity:0,emissive:green.clone(),emissiveIntensity:0}));m.position.set(-.35+i*.42,-.55,.5);root.add(m);return m});
const noteG=new T.Group;root.add(noteG);const noteS=new T.Mesh(G(new T.BoxGeometry(1.1,.62,.02)),M(cream.clone(),{transparent:!0,opacity:0}));noteG.add(noteS);
const lineGeo=G(new T.BoxGeometry(1,.035,.01)),noteLines=[0,1,2].map(i=>{const m=new T.Mesh(lineGeo,M(bg.clone().lerp(cream,.35),{transparent:!0,opacity:0}));m.position.set(-.42,.14-i*.14,.02);noteG.add(m);return m});
const C0=new T.Vector3(.9,1.55,7.2),look=new T.Vector3(.75,1.05,0),lk=new T.Vector3,tmp=new T.Vector3;camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
function frame(t,dt,p){
const hold=clamp((p-.56)/.28),c0=t%12,c=hold>0?lerp(c0,10.6,ease(hold)):c0,reset=c>11.2?ease((c-11.2)/.8):0;
/* camera: push in (shot 1), quarter orbit (shot 2), pull back to the opening frame (shot 3) */
const push=ease(clamp(c/4)),orb=ease(clamp((c-4)/4))*(1-ease(clamp((c-8)/3.2))),back=ease(clamp((c-8)/3.2));
const dist=lerp(C0.z,C0.z-1.1,push*(1-back)),yaw=orb*.42;
camera.position.set(look.x+Math.sin(yaw)*dist+pointer.x*.25,C0.y-pointer.y*.14,look.z+Math.cos(yaw)*dist);lk.copy(look);lk.x+=pointer.x*.06;camera.lookAt(lk);
/* blocks assemble 0.6-3.8 s */
blocks.forEach((k,i)=>{const t0=.6+i*.55,e=ease(clamp((c-t0)/1.1));const dst=tmp.copy(k.home);page.localToWorld(dst);
k.g.position.lerpVectors(k.src,dst,e);k.g.rotation.set(0,(1-e)*.6,(1-e)*(i%2?.2:-.2));const op=clamp(c/.6)*(1-reset);k.b.material.opacity=op;k.tm.material.opacity=op;
k.g.visible=op>.01});
/* tags drift in */
tags.forEach((m,i)=>{const e=ease(clamp((c-.3-i*.4)/1.4));m.position.set(lerp(-1.6+i*.3,.2+i*.48,e),lerp(2.9+i*.2,1.15+PH/2-.44,e),lerp(-1.5,.26,e));m.material.opacity=e*(1-reset)});
/* page lifts and splits into three levels 4.2-7.6 s, folds back 8-9 s */
const split=ease(clamp((c-4.2)/1.6))*(1-ease(clamp((c-8)/1.1)));
page.position.y=1.15+Math.sin(t*.7)*.03;page.updateMatrixWorld();sheet.material.opacity=1;
levels.forEach((l,i)=>{const d=i-1;l.g.position.set(.75+d*1.35*split,1.05-Math.abs(d)*.08*split,.3+(1-Math.abs(d))*.12*split);l.g.rotation.set(0,-d*.22*split,-d*.05*split);
const op=split*(1-reset);l.s.material.opacity=op;l.edge.material.opacity=op;l.g.visible=op>.01});
/* week locks and the parent note drafts 8.6-11 s */
let lockN=0;days.forEach((m,i)=>{const e=ease(clamp((c-8.4-i*.18)/.5));m.material.opacity=e*(1-reset);const lock=c>9.4+i*.12&&!reset;m.material.emissiveIntensity=lock?.35:0;m.material.color.copy(lock?bg.clone().lerp(green,.45):bg.clone().lerp(cream,.12));if(lock)lockN++});
const ne=ease(clamp((c-9.3)/.9))*(1-reset);noteG.position.set(lerp(1.4,2.45,ne),lerp(.9,.2,ne),.55);noteG.rotation.set(0,-.25,.04);noteS.material.opacity=ne;
noteLines.forEach((m,i)=>{const f=clamp((c-9.8-i*.35)/.5)*(1-reset);m.material.opacity=ne;m.scale.x=Math.max(f*(i===2?.5:.85),.001);m.position.x=-.48+m.scale.x/2});
wall.material.opacity=.22+.06*Math.sin(t*.5)}
return{frame,resize:(w,h)=>{const port=w/h<.8;C0.z=port?10.5:7.2;look.x=port?.8:.75;look.y=port?.9:1.05},dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose())}}}
