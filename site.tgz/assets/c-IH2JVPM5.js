/* Noticevane page tools. They run offline in the browser; nothing typed or clicked here leaves the page.
   [data-nv=feed]     notice feed with a relevance filter by license profile (home live panel, Monitor page).
                      Rows carry their per-profile scores in data-rel, written by content.py from the same table.
   [data-nv=decoder]  Notice Decoder: paste one notice, choose an entity type, get a first-pass brief with the
                      source sentences quoted, affected activities, dates and questions for counsel.
   [data-hud-count]   hero HUD counter (still when reduced motion is preferred) */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)");

/* ---------------- feed */
function feed(root){
const rows=$$(".nv-feed__r",root),count=$("[data-feed-count]",root),status=$("[data-feed-status]",root),empty=$("[data-feed-empty]",root),list=$(".nv-feed__l",root);
const th=+root.dataset.th||60;let prof=root.dataset.prof||"lending",only=!0;
const rel=r=>{const m={};r.dataset.rel.split(",").forEach(p=>{const[k,v]=p.split(":");m[k]=+v});return m};
const data=rows.map(r=>({r,rel:rel(r)}));
function draw(){
 const sorted=[...data].sort((a,b)=>b.rel[prof]-a.rel[prof]);let n=0;
 sorted.forEach(({r,rel},i)=>{const s=rel[prof],hit=s>=th;r.hidden=only&&!hit;if(hit)n++;
  r.classList.toggle("is-hit",hit);$(".nv-feed__s",r).textContent=s;$(".nv-feed__m",r).style.width=s+"%";list.appendChild(r)});
 const vis=rows.filter(r=>!r.hidden);vis.forEach((r,i)=>$("button",r).tabIndex=i?-1:0);
 if(empty)empty.hidden=vis.length>0;
 const lab=$$("[data-prof]",root).find(b=>b.dataset.prof===prof);
 count.textContent=n+" of "+rows.length+" relevant";
 status.textContent=n+" of "+rows.length+" synthetic notices pass the filter for "+(lab?lab.textContent:prof)+(only?". Showing relevant notices only.":". Showing all notices.")}
$$("[data-prof]",root).forEach(b=>b.addEventListener("click",()=>{prof=b.dataset.prof;$$("[data-prof]",root).forEach(x=>x.setAttribute("aria-pressed",x===b?"true":"false"));draw()}));
const tog=$("[data-feed-all]",root);if(tog)tog.addEventListener("click",()=>{only=!only;tog.setAttribute("aria-pressed",only?"false":"true");$("span",tog).textContent=only?"Show all notices":"Show relevant only";draw()});
const det=$("[data-feed-detail]",root);
rows.forEach(r=>{const b=$("button",r);
 b.addEventListener("click",()=>{rows.forEach(x=>x.classList.toggle("is-sel",x===r));if(!det)return;const s=rel(r)[prof];
  det.innerHTML='<p class="nv-det__id"><b>'+esc(r.dataset.id)+'</b><span class="nv-mono">'+esc(r.dataset.src)+'</span></p><p class="nv-det__t">'+esc(r.dataset.title)+'</p>'+
  '<dl class="nv-det__p"><div><dt>Relevance for this profile</dt><dd>'+s+' / 100</dd></div><div><dt>Matched on</dt><dd>'+esc(r.dataset.why)+'</dd></div><div><dt>Decision</dt><dd>'+(s>=th?"Sent to the brief queue":"Logged, not sent")+'</dd></div></dl>'+
  '<p class="nv-det__m">Threshold '+th+'. Notices below it stay in the log and can be reopened.</p>'});
 b.addEventListener("keydown",e=>{if(e.key!=="ArrowDown"&&e.key!=="ArrowUp")return;e.preventDefault();const vis=$$(".nv-feed__r:not([hidden]) button",root),i=vis.indexOf(b),j=e.key==="ArrowDown"?Math.min(vis.length-1,i+1):Math.max(0,i-1);vis.forEach(x=>x.tabIndex=-1);vis[j].tabIndex=0;vis[j].focus()})});
draw()}

/* ---------------- decoder */
const ACT=[[/disclos/i,"Customer disclosures"],[/\bfees?\b|pricing|charge/i,"Fees and pricing"],[/advertis|marketing/i,"Marketing and advertising"],[/collect/i,"Collections"],
[/complaint/i,"Complaint handling"],[/record|retain|retention|preserv/i,"Recordkeeping"],[/supervis/i,"Supervision"],[/messag|text|chat|communication/i,"Electronic communications"],
[/incident|cyber|breach/i,"Incident response"],[/vendor|third[- ]party|service provider/i,"Third-party oversight"],[/credit|underwrit|loan|lend/i,"Lending and credit decisions"],
[/payment|transfer|wallet/i,"Payments and transfers"],[/error resolution|dispute/i,"Error resolution"],[/form 8-k|report|filing/i,"Regulatory reporting"],[/board|governance/i,"Board oversight"]];
const ENT={bank:{l:"Bank or credit union",reg:["CFPB","SEC"],a:["Customer disclosures","Fees and pricing","Lending and credit decisions","Complaint handling","Third-party oversight","Incident response","Error resolution","Board oversight"]},
lender:{l:"Non-bank lender",reg:["CFPB"],a:["Customer disclosures","Fees and pricing","Lending and credit decisions","Collections","Complaint handling","Marketing and advertising","Third-party oversight"]},
fintech:{l:"Fintech or payments company",reg:["CFPB"],a:["Payments and transfers","Error resolution","Customer disclosures","Third-party oversight","Complaint handling","Marketing and advertising","Incident response"]},
insurer:{l:"Insurer or agency",reg:[],a:["Customer disclosures","Complaint handling","Marketing and advertising","Third-party oversight","Incident response"]},
bd:{l:"Broker-dealer",reg:["FINRA","SEC"],a:["Supervision","Electronic communications","Recordkeeping","Regulatory reporting","Customer disclosures","Incident response"]},
public:{l:"Public company",reg:["SEC"],a:["Regulatory reporting","Incident response","Board oversight","Customer disclosures"]}};
const MON="January|February|March|April|May|June|July|August|September|October|November|December";
const sentences=t=>t.replace(/\s+/g," ").split(/(?<=[.;])\s+(?=[A-Z(])/).map(s=>s.trim()).filter(s=>s.length>12);
function regOf(t){if(/\bFINRA\b|\bmember firms?\b/i.test(t))return"FINRA";if(/\bCFPB\b|Consumer Financial Protection Bureau|\bthe Bureau\b/i.test(t))return"CFPB";if(/\bSEC\b|Securities and Exchange Commission|\bthe Commission\b|registrants?/i.test(t))return"SEC";return""}
function typeOf(t){return/proposed rule|proposes|request for comment|notice of proposed/i.test(t)?"Proposed rule":/advisory opinion/i.test(t)?"Advisory opinion":/consent order|enforcement action|civil money penalty/i.test(t)?"Enforcement release":/final rule|adopted amendments|adopts/i.test(t)?"Final rule":/regulatory notice/i.test(t)?"Regulatory notice":/circular/i.test(t)?"Circular":"Guidance or bulletin"}
function decode(text,ent){
const ss=sentences(text),E=ENT[ent],reg=regOf(text),type=typeOf(text);
const acts=[];ACT.forEach(([re,a])=>{if(re.test(text)&&!acts.includes(a))acts.push(a)});
const mine=acts.filter(a=>E.a.includes(a));
const obl=ss.filter(s=>/\b(must|shall|are required|is required|would require|would be required|will require|expects?|should)\b/i.test(s)).slice(0,3);
const refs=[...new Set((text.match(/\b(?:12|17) CFR [\d.]+|\bSection [\d.()a-z]+|§ ?[\d.()a-z]+|\bRule \d{3,4}\b|\bItem [\d.]+ of Form [\w-]+|\bForm [A-Z0-9-]{2,5}\b/g)||[]).map(x=>x.replace(/[.,;]$/,"")))].slice(0,6);
const dates=[];ss.forEach(s=>{const m=s.match(new RegExp("(?:"+MON+") \\d{1,2}, \\d{4}","g"));if(m)m.forEach(d=>dates.push([d,/comment/i.test(s)?"Comments due":/effective|take effect|compliance date|comply by/i.test(s)?"Effective or compliance date":"Date mentioned"]))});
const win=text.match(/within (\w+(?:[- ]\w+)?) (business |calendar )?days/i);
let score=(E.reg.includes(reg)?40:reg?8:4)+Math.min(45,mine.length*15)+(obl.length?10:0)+(dates.length?5:0);if(ent==="insurer"&&!reg)score+=10;score=Math.max(3,Math.min(97,score));
const tier=score>=70?"High":score>=40?"Medium":"Low";
const topic=(ss.find(x=>x.length>=50&&!/^synthetic\b/i.test(x))||ss[0]||"").replace(/\s*\(.*?\)/g,"").slice(0,180);
const q=[];
if(type==="Proposed rule")q.push(dates.find(d=>d[1]==="Comments due")?"Should we comment before "+dates.find(d=>d[1]==="Comments due")[0]+", and on which points?":"Should we file a comment, and by when?");
const eff=dates.find(d=>d[1]==="Effective or compliance date");if(eff)q.push("Which products, policies and systems must change before "+eff[0]+"?");
if(mine.includes("Customer disclosures"))q.push("Do our current disclosures and templates meet the timing and content described here?");
if(mine.includes("Electronic communications"))q.push("Which approved and unapproved channels do our people use today, and how are they retained?");
if(mine.includes("Incident response"))q.push("Does our incident response plan let us decide materiality and file within the stated window?");
if(mine.includes("Collections"))q.push("Do our collection call limits and vendor scripts follow the conduct described here?");
if(mine.includes("Payments and transfers")||mine.includes("Error resolution"))q.push("Do our error resolution timelines and records match what is expected here?");
q.push("Does this apply to every licensed entity in our group, or only some of them?");
return{reg,type,acts,mine,obl,refs,dates,win:win?win[0]:"",score,tier,topic,q:q.slice(0,4),E}}
function decoder(root){
const ta=$("#dc-text",root),sel=$("#dc-ent",root),out=$("[data-dc-out]",root),err=$("[data-dc-err]",root),st=$("[data-dc-status]",root),go=$("[data-dc-go]",root);
const samples={};$$("template[data-sample]",root).forEach(t=>samples[t.dataset.sample]=t.innerHTML.trim());
let last="";
const fail=m=>{err.textContent=m;ta.setAttribute("aria-invalid","true");ta.focus()};
function run(){
 err.textContent="";ta.removeAttribute("aria-invalid");const t=ta.value.trim();
 if(!t)return fail("Paste the text of one notice first, or load a synthetic sample.");
 if(/^https?:\/\/\S+$/i.test(t))return fail("This tool runs offline in your browser and cannot open links. Open the notice and paste its text here.");
 if(t.length<160)return fail("That is too short to brief. Paste the full notice text, at least a paragraph.");
 const r=decode(t,sel.value);
 const li=a=>a.length?a.map(x=>"<li>"+esc(x)+"</li>").join(""):'<li class="nv-muted">None found in the text.</li>';
 last=["Notice brief (first pass, verify against the source)","Entity type: "+r.E.l,"Regulator: "+(r.reg||"Not identified"),"Notice type: "+r.type,"Relevance: "+r.tier+" ("+r.score+"/100)","","Summary: "+r.topic,
  "","Source sentences:",...r.obl.map(s=>'"'+s+'"'),"","Affected activities: "+(r.mine.join(", ")||"None for this entity type"),"Dates: "+(r.dates.map(d=>d[1]+" "+d[0]).join("; ")||"None stated"),"References: "+(r.refs.join(", ")||"None found"),"","Questions for counsel:",...r.q.map((x,i)=>i+1+". "+x)].join("\n");
 out.innerHTML='<div class="nv-brief__h"><div><p class="nv-mono nv-brief__k">Change brief · '+esc(r.reg||"Regulator not identified")+' · '+esc(r.type)+'</p><p class="nv-brief__t">'+esc(r.topic)+'</p></div>'+
  '<p class="nv-rel nv-rel--'+r.tier.toLowerCase()+'"><span>'+r.tier+'</span><b>'+r.score+'</b><small>relevance for '+esc(r.E.l.toLowerCase())+'</small></p></div>'+
  '<div class="nv-brief__g"><section><h3 class="nv-brief__s">What the notice says</h3>'+(r.obl.length?r.obl.map(s=>'<blockquote class="nv-q"><p>'+esc(s)+'</p></blockquote>').join(""):'<p class="nv-muted">No sentence with an obligation word (must, shall, required, expects) was found. Read the notice in full.</p>')+
  '</section><section><h3 class="nv-brief__s">Affected activities</h3><ul class="nv-chips">'+li(r.mine)+'</ul>'+(r.acts.length>r.mine.length?'<p class="nv-muted">Also mentioned: '+esc(r.acts.filter(a=>!r.mine.includes(a)).join(", "))+'.</p>':'')+
  '<h3 class="nv-brief__s">Dates and windows</h3><ul class="nv-kvl">'+(r.dates.length?r.dates.map(d=>"<li><span>"+esc(d[1])+"</span><b>"+esc(d[0])+"</b></li>").join(""):'<li><span>Dates</span><b>None stated</b></li>')+(r.win?"<li><span>Time window</span><b>"+esc(r.win)+"</b></li>":"")+
  '</ul><h3 class="nv-brief__s">References</h3><p class="nv-mono nv-refs">'+(r.refs.length?r.refs.map(esc).join(" · "):"None found")+'</p></section>'+
  '<section class="nv-brief__qs"><h3 class="nv-brief__s">Questions for your counsel</h3><ol>'+r.q.map(x=>"<li>"+esc(x)+"</li>").join("")+'</ol></section></div>'+
  '<div class="nv-brief__f"><button type="button" class="nv-ghost" data-dc-copy><span>Copy brief</span></button><p class="nv-mono">First pass from the text you pasted. Confirm every point against the source notice.</p></div>';
 out.hidden=!1;st.textContent="Brief ready. Relevance "+r.tier+", "+r.score+" out of 100, for "+r.E.l+".";
 $("[data-dc-copy]",out).addEventListener("click",async()=>{try{await navigator.clipboard.writeText(last);st.textContent="Brief copied to the clipboard."}catch(e){st.textContent="Copy is blocked in this browser. Select the brief text and copy it by hand."}});
 if(!RM.matches)out.scrollIntoView({block:"nearest",behavior:"smooth"})}
go.addEventListener("click",run);
ta.addEventListener("keydown",e=>{if(e.key==="Enter"&&(e.metaKey||e.ctrlKey)){e.preventDefault();run()}});
$$("[data-dc-sample]",root).forEach(b=>b.addEventListener("click",()=>{ta.value=samples[b.dataset.dcSample]||"";sel.value=b.dataset.ent||sel.value;err.textContent="";ta.removeAttribute("aria-invalid");run();st.textContent="Synthetic sample loaded and decoded: "+b.textContent+"."}));
const clr=$("[data-dc-clear]",root);clr.addEventListener("click",()=>{ta.value="";out.hidden=!0;out.innerHTML="";err.textContent="";st.textContent="Cleared.";ta.focus()});
const forl=$("[data-dc-for]",root);sel.addEventListener("change",()=>{forl.textContent="Relevance and activities are judged for: "+sel.options[sel.selectedIndex].text+".";if(!out.hidden)run()})}

function hud(){const el=$("[data-hud-count]");if(!el||RM.matches)return;let n=412;setInterval(()=>{if(document.hidden)return;n+=n%5===0?2:1;if(n>431)n=412;el.textContent=n},3200)}

export function boot(){
$$('[data-nv="feed"]').forEach(feed);
$$('[data-nv="decoder"]').forEach(decoder);
hud();
$$(".mv-pscroll").forEach(el=>{const f=()=>{const s=el.scrollWidth>el.clientWidth+2;s?el.setAttribute("tabindex","0"):el.removeAttribute("tabindex")};f();addEventListener("resize",f)});
}
