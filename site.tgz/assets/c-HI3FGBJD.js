/* Irrigiq hero: a farm seen from above at night. Fourteen plots slide in from the edges and take a soil-moisture tint
   from dry soil to wet water blue (beat 1, 0 to 5 s); forecast clouds drift over and a short leaf-green plan bar lights
   each plot scheduled to run (beat 2, 5 to 10 s); valves on the pipe main close for the plots the rain will cover and a
   ledger of water saved grows in the corner (beat 3, 10 to 14 s) before the frame eases back to the opening. Scrolling
   holds the resolved state. Everything shown is a synthetic farm. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const bg=new T.Color(colors.bg),paper=new T.Color(color("--iq-paper","#f4fafc")),water=new T.Color(color("--iq-water","#d6eef7")),
 leaf=new T.Color(color("--iq-leaf","#7bc74d")),soil=new T.Color(color("--iq-soil","#8a6a4b"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),12,30);
const root=new T.Group;scene.add(root);const geos=[],mats=[];const G=g=>(geos.push(g),g);
const M=(c,o={})=>{const m=new T.MeshStandardMaterial(Object.assign({color:c,roughness:.8,metalness:0},o));mats.push(m);return m};
const B=(c,o={})=>{const m=new T.MeshBasicMaterial(Object.assign({color:c},o));mats.push(m);return m};
root.add(new T.AmbientLight(0xdbe9f0,.6));
const key=new T.DirectionalLight(0xffeedd,1.05);key.position.set(-5,9,4);root.add(key);
const rim=new T.DirectionalLight(leaf.getHex(),.35);rim.position.set(6,4,-7);root.add(rim);
/* ground with a faint survey grid */
const ground=new T.Mesh(G(new T.PlaneGeometry(40,40)),B(bg.clone().lerp(paper,.03)));ground.rotation.x=-Math.PI/2;root.add(ground);
const lp=[];for(let i=-10;i<=10;i++){lp.push(i,.003,-10,i,.003,10,-10,.003,i,10,.003,i)}
const lg=G(new T.BufferGeometry);lg.setAttribute("position",new T.Float32BufferAttribute(lp,3));const lm=new T.LineBasicMaterial({color:bg.clone().lerp(paper,.08)});mats.push(lm);root.add(new T.LineSegments(lg,lm));
/* plots: u, v, w, d on a 6 x 5 grid, moisture 0..3, plan run / skip / none (same layout as the poster) */
const PL=[[0,0,2,1,1,1],[2,0,1,1,2,0],[3,0,2,1,0,1],[5,0,1,2,2,2],[0,1,1,2,3,2],[1,1,2,1,1,1],[3,1,2,1,2,0],[1,2,1,1,0,1],[2,2,2,2,1,1],[4,2,2,1,3,2],[0,3,2,2,2,0],[4,3,1,2,1,1],[5,3,1,2,0,1],[2,4,2,1,2,2]];
const S=1.15,OX=-3.2,OZ=-3.4,soilG=G(new T.BoxGeometry(1,.16,1)),barG=G(new T.BoxGeometry(1,.06,.16));
const tint=m=>soil.clone().lerp(water,m/3);
const plots=PL.map(([u,v,w,d,m,plan],i)=>{const mat=M(bg.clone(),{emissive:tint(m),emissiveIntensity:0});const p=new T.Mesh(soilG,mat);
 const cx=OX+(u+w/2)*S,cz=OZ+(v+d/2)*S;p.scale.set(w*S-.12,1,d*S-.12);p.position.set(cx,.08,cz);root.add(p);
 let bar=null,bm=null;if(plan===1){bm=M(leaf.clone(),{emissive:leaf.clone(),emissiveIntensity:.5});bar=new T.Mesh(barG,bm);bar.position.set(cx,.2,cz);bar.scale.set(.001,1,1);root.add(bar)}
 const from=new T.Vector3(cx+(u<3?-1:1)*(7+i%3),.08,cz+(v<2?-1:1)*(3+i%4));return{p,mat,m,plan,cx,cz,bar,bm,from,t0:(i*.27)%3.2}});
/* pipe main along the south edge with a valve per plot column; valves on rain-covered plots close in beat 3 */
const mainM=M(paper.clone().multiplyScalar(.75),{roughness:.5});const main=new T.Mesh(G(new T.CylinderGeometry(.05,.05,7.6,10)),mainM);main.rotation.z=Math.PI/2;main.position.set(OX+3.45,.1,OZ+5*S+.35);root.add(main);
const vG=G(new T.CylinderGeometry(.13,.13,.18,16)),hG=G(new T.BoxGeometry(.34,.04,.06));
const valves=[.9,2.4,3.9,5.4].map((u,i)=>{const vm=M(leaf.clone(),{emissive:leaf.clone(),emissiveIntensity:.35});const v=new T.Mesh(vG,vm);v.position.set(OX+u*S,.14,OZ+5*S+.35);root.add(v);
 const h=new T.Mesh(hG,M(paper.clone()));h.position.set(v.position.x,.26,v.position.z);root.add(h);return{v,vm,h,shut:i%2===1}});
/* forecast clouds: flattened clusters of soft spheres */
const cG=G(new T.SphereGeometry(1,18,12)),cM=M(water.clone(),{transparent:true,opacity:0,roughness:1,depthWrite:false});
const clouds=[0,1].map(k=>{const g=new T.Group;[[0,0,0,1],[.9,.1,.2,.7],[-.8,.05,-.1,.75],[.2,.2,-.4,.6]].forEach(([x,y,z,r])=>{const s=new T.Mesh(cG,cM);s.position.set(x,y,z);s.scale.set(r*1.1,r*.22,r*.8);g.add(s)});
 g.position.set(-9,2.1+k*.4,-1.6+k*2.6);root.add(g);return g});
/* ledger: six bars that grow in the north-east corner */
const lb=[];const lbG=G(new T.BoxGeometry(.26,1,.26));for(let i=0;i<6;i++){const m=i>3?M(leaf.clone(),{emissive:leaf.clone(),emissiveIntensity:.3}):M(water.clone().multiplyScalar(.85));
 const b=new T.Mesh(lbG,m);b.position.set(5.2+i*.38,0,-3.6+i*.05);root.add(b);lb.push({b,h:.5+i*.22})}
const C0=new T.Vector3(2.4,10.8,10.6),look=new T.Vector3(.9,0,-.2),lk=new T.Vector3;camera.fov=38;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
function frame(t,dt,p){
const hold=clamp((p-.5)/.3),c0=t%14,c=hold>0?lerp(c0,12.6,ease(hold)):c0,reset=c>13.2?ease((c-13.2)/.8):0;
camera.position.set(C0.x+Math.sin(t/14*Math.PI*2)*.3+pointer.x*.35,C0.y-pointer.y*.2,C0.z);lk.copy(look);lk.x+=pointer.x*.1;camera.lookAt(lk);
/* beat 1: plots enter from the edges and their moisture tint comes up */
plots.forEach(k=>{const e=ease(clamp((c-k.t0*.6)/1.8))*(1-reset);k.p.position.x=lerp(k.from.x,k.cx,e);k.p.position.z=lerp(k.from.z,k.cz,e);k.p.scale.y=Math.max(.001,e);
 const g=ease(clamp((c-1.5-k.t0*.4)/1.6))*(1-reset);k.mat.emissiveIntensity=g*.12;k.mat.color.copy(bg).lerp(tint(k.m),g*.8);
 if(k.bar){const on=ease(clamp((c-6.2-k.t0*.5)/.8))*(1-reset);k.bar.scale.x=Math.max(.001,on*Math.min(1.1,k.p.scale.x*.6));k.bm.emissiveIntensity=.3+on*.5}});
/* beat 2: clouds drift west to east over the plots */
const cv=clamp((c-4.6)/6);clouds.forEach((g,i)=>{g.position.x=lerp(-9,8,ease(clamp(cv*1.05-i*.12)))});cM.opacity=Math.sin(Math.PI*clamp(cv))*.22*(1-reset);
/* beat 3: valves on rain-covered plots turn and dim; the ledger grows */
valves.forEach(v=>{const s=v.shut?ease(clamp((c-10.1)/.7))*(1-reset):0;v.h.rotation.y=s*Math.PI/2;v.vm.color.copy(leaf).lerp(soil,s);v.vm.emissive.copy(leaf).lerp(soil,s);v.vm.emissiveIntensity=.35-s*.25});
lb.forEach((k,i)=>{const g=ease(clamp((c-10.4-i*.18)/.8))*(1-reset);const h=Math.max(.001,k.h*g);k.b.scale.y=h;k.b.position.y=h/2})}
return{frame,resize:(w,h)=>{const n=w/h<.8;C0.set(n?.6:2.4,n?13.5:10.8,n?13:10.6);look.x=n?.3:.9},dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose())}}}
