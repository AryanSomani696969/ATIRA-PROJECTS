/* Growervoice hero: a field at golden hour. 12 s loop, three beats:
   0-4 s a voice ripple moves over the crop rows while call bars pulse; 4-8 s the bars release points that flow into
   a leaf outline on a leaf-photo card, which turns slowly and rises; 8-12 s a likely-diagnosis card fills its
   confidence bars, an agronomist handoff chip appears, and the frame eases back. One easing curve, no shake. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp}=helpers,R=rand(26);
const bg=new T.Color(color("--gv-earth","#2f5d3a")),wheat=new T.Color(color("--gv-wheat","#f3e6c4")),paper=new T.Color(color("--gv-paper","#fbf6ea")),
 sky=new T.Color(color("--gv-sky","#cfe8f3")),chili=new T.Color(color("--gv-chili","#c8402f")),leaf=new T.Color(color("--gv-leaf","#8dbf7a")),
 harvest=new T.Color(color("--gv-harvest","#e7b85a")),soil=new T.Color(color("--gv-soil","#1c2a1f"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),10,26);
const root=new T.Group;scene.add(root);
root.add(new T.HemisphereLight(0xfff0d0,0x2a4a30,.9));
const key=new T.DirectionalLight(0xffd9a0,.9);key.position.set(6,4,6);root.add(key);
const rim=new T.DirectionalLight(sky.getHex(),.35);rim.position.set(-5,2,-4);root.add(rim);
const geos=[],mats=[];const G=g=>(geos.push(g),g),M=m=>(mats.push(m),m);const V=(x,y,z=0)=>new T.Vector3(x,y,z);
const io=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
/* ground: crop rows receding to the horizon, a low sun */
const GY=-2.2,rows=[];for(let i=-14;i<=14;i++){const x=i*.85;rows.push(x,GY,4.5,x*1.0,GY,-22)}
const rg=G(new T.BufferGeometry());rg.setAttribute("position",new T.Float32BufferAttribute(rows,3));
const rm=M(new T.LineBasicMaterial({color:wheat.clone(),transparent:!0,opacity:.24}));root.add(new T.LineSegments(rg,rm));
const hz=G(new T.BufferGeometry().setFromPoints([V(-40,GY+.02,-22),V(40,GY+.02,-22)]));root.add(new T.Line(hz,M(new T.LineBasicMaterial({color:wheat.clone(),transparent:!0,opacity:.3}))));
const sun=new T.Mesh(G(new T.SphereGeometry(2.2,32,16)),M(new T.MeshBasicMaterial({color:harvest.clone(),transparent:!0,opacity:.2,fog:!1,depthWrite:!1})));sun.position.set(9.5,GY,-24.5);sun.scale.z=.05;sun.renderOrder=-2;root.add(sun);
const gnd=new T.Mesh(G(new T.PlaneGeometry(90,40)),M(new T.MeshBasicMaterial({color:new T.Color("#2a5534"),fog:!1})));gnd.rotation.x=-Math.PI/2;gnd.position.set(0,GY-.01,-2);gnd.renderOrder=-1;root.add(gnd);
/* a leaf shape: base at the origin, tip on +x */
function leafGeo(L,W,n=24){const p=[L*.42,0,0];for(let k=0;k<=n;k++){const t=k/n;p.push(L*t,W*Math.pow(Math.sin(Math.PI*t),.85)*(1-.3*t),0)}
 for(let k=n;k>=0;k--){const t=k/n;p.push(L*t,-W*Math.pow(Math.sin(Math.PI*t),.85)*(1-.3*t),0)}
 const idx=[],m=2*n+2;for(let k=1;k<m;k++)idx.push(0,k,k+1);const g=new T.BufferGeometry();g.setAttribute("position",new T.Float32BufferAttribute(p,3));g.setIndex(idx);g.computeVertexNormals();return G(g)}
function leafPts(L,W,n){const a=[];for(let k=0;k<=n;k++){const t=k/n;a.push(V(L*t,W*Math.pow(Math.sin(Math.PI*t),.85)*(1-.3*t)))}for(let k=n;k>=0;k--){const t=k/n;a.push(V(L*t,-W*Math.pow(Math.sin(Math.PI*t),.85)*(1-.3*t)))}return a}
/* sprouts along the rows: small instanced leaves, larger near the viewer */
const NS=small?140:320,sg=leafGeo(.34,.09,8),sm=M(new T.MeshLambertMaterial({color:leaf.clone(),side:T.DoubleSide}));
const sp=new T.InstancedMesh(sg,sm,NS);root.add(sp);const o3=new T.Object3D;
for(let i=0;i<NS;i++){const r=Math.floor(R()*29)-14,z=4-Math.pow(R(),.7)*22,x=r*.85;o3.position.set(x+(R()-.5)*.08,GY,z);o3.rotation.set(0,R()*6.28,.9+R()*.5);
 const s=.7+R()*.6;o3.scale.set(s,s,s);o3.updateMatrix();sp.setMatrixAt(i,o3.matrix)}
/* voice ripple: rings on the ground that travel along the rows */
const ring=[];for(let k=0;k<=64;k++){const a=k/64*Math.PI*2;ring.push(V(Math.cos(a),0,Math.sin(a)))}
const ringGeo=G(new T.BufferGeometry().setFromPoints(ring));
const rings=[0,1,2,3].map(()=>{const m=M(new T.LineBasicMaterial({color:sky.clone(),transparent:!0,opacity:0}));const l=new T.Line(ringGeo,m);l.position.y=GY+.03;root.add(l);return{l,m}});
/* call bars */
const NB=9,HB=[.35,.7,1.1,.85,1.4,1.0,.65,.9,.4],bars=[],BX=1.05,BY=-.55;
const barGeo=G(new T.BoxGeometry(.09,1,.09));
for(let i=0;i<NB;i++){const m=M(new T.MeshBasicMaterial({color:sky.clone(),transparent:!0,opacity:0}));const b=new T.Mesh(barGeo,m);b.position.set(BX+i*.2,BY,.4);root.add(b);bars.push({b,m})}
/* the leaf-photo card that the bars grow into */
const card=new T.Group;card.position.set(3.25,.55,0);root.add(card);
const cm=M(new T.MeshBasicMaterial({color:paper.clone(),transparent:!0,opacity:0}));card.add(new T.Mesh(G(new T.BoxGeometry(2.2,2.5,.05)),cm));
const im=M(new T.MeshBasicMaterial({color:new T.Color("#e4eedb"),transparent:!0,opacity:0}));const inner=new T.Mesh(G(new T.PlaneGeometry(1.94,1.85)),im);inner.position.set(0,.2,.03);card.add(inner);
const LL=1.6,LW=.42,lg=leafGeo(LL,LW),lm=M(new T.MeshBasicMaterial({color:new T.Color("#6fa35e"),side:T.DoubleSide,transparent:!0,opacity:0}));
const lf=new T.Mesh(lg,lm);lf.position.set(-.7,-.45,.06);lf.rotation.z=.62;card.add(lf);
const outline=leafPts(LL,LW,40),olg=G(new T.BufferGeometry().setFromPoints(outline));const olm=M(new T.LineBasicMaterial({color:soil.clone(),transparent:!0,opacity:0}));
const ol=new T.Line(olg,olm);ol.position.copy(lf.position);ol.position.z=.07;ol.rotation.z=lf.rotation.z;card.add(ol);
const rib=new T.Line(G(new T.BufferGeometry().setFromPoints([V(0,0),V(LL*.95,0)])),M(new T.LineBasicMaterial({color:soil.clone(),transparent:!0,opacity:0})));rib.position.copy(ol.position);rib.rotation.z=lf.rotation.z;card.add(rib);
const spotGeo=G(new T.SphereGeometry(.07,12,8)),spots=[[.55,.1],[.85,-.06],[1.05,.12]].map(([x,y])=>{const m=M(new T.MeshBasicMaterial({color:new T.Color("#6b4a2b"),transparent:!0,opacity:0}));const s=new T.Mesh(spotGeo,m);
 const c=Math.cos(lf.rotation.z),sn=Math.sin(lf.rotation.z);s.position.set(lf.position.x+x*c-y*sn,lf.position.y+x*sn+y*c,.09);s.scale.z=.3;card.add(s);return m});
const capm=[0,1].map(i=>{const m=M(new T.MeshBasicMaterial({color:soil.clone(),transparent:!0,opacity:0}));const p=new T.Mesh(G(new T.PlaneGeometry(i?.6:1.1,.07)),m);p.position.set(-.97+(i?.3:.55),-1.02-i*.14,.03);card.add(p);return m});
/* points that flow from the bar tops to the leaf outline */
const NP=small?40:80,pg=G(new T.BufferGeometry()),pp=new Float32Array(NP*3);pg.setAttribute("position",new T.BufferAttribute(pp,3));
const pm=M(new T.PointsMaterial({color:sky.clone(),size:small?.07:.06,transparent:!0,opacity:0}));const pts=new T.Points(pg,pm);root.add(pts);
const tgt=[];const wv=new T.Vector3;
/* diagnosis card with three confidence bars, and the agronomist handoff chip */
const dc=new T.Group;dc.position.set(.85,1.55,.3);root.add(dc);
const dcm=M(new T.MeshBasicMaterial({color:wheat.clone(),transparent:!0,opacity:0}));dc.add(new T.Mesh(G(new T.BoxGeometry(1.7,1.15,.04)),dcm));
const track=G(new T.PlaneGeometry(1,.07)),conf=[.74,.18,.08].map((v,i)=>{const tm=M(new T.MeshBasicMaterial({color:soil.clone(),transparent:!0,opacity:0}));const t=new T.Mesh(track,tm);t.scale.x=1.36;t.position.set(0,.12-i*.26,.03);dc.add(t);
 const fm=M(new T.MeshBasicMaterial({color:i?soil.clone():bg.clone(),transparent:!0,opacity:0}));const f=new T.Mesh(track,fm);f.position.set(-.68,.12-i*.26,.035);dc.add(f);return{v,tm,fm,f}});
const hm=M(new T.MeshBasicMaterial({color:soil.clone(),transparent:!0,opacity:0}));const head=new T.Mesh(G(new T.PlaneGeometry(.9,.1)),hm);head.position.set(-.23,.4,.03);dc.add(head);
const ho=new T.Group;ho.position.set(1.05,.62,.5);root.add(ho);
const hcm=M(new T.MeshBasicMaterial({color:paper.clone(),transparent:!0,opacity:0}));ho.add(new T.Mesh(G(new T.BoxGeometry(1.1,.32,.04)),hcm));
const hdm=M(new T.MeshBasicMaterial({color:chili.clone(),transparent:!0,opacity:0}));const hd=new T.Mesh(G(new T.SphereGeometry(.06,16,10)),hdm);hd.position.set(-.4,0,.04);ho.add(hd);
const hlm=M(new T.MeshBasicMaterial({color:soil.clone(),transparent:!0,opacity:0}));const hl=new T.Mesh(G(new T.PlaneGeometry(.6,.06)),hlm);hl.position.set(.08,0,.03);ho.add(hl);
camera.fov=40;camera.updateProjectionMatrix();
const C0=V(0,.5,9.4),look=V(1.3,0,0),lk=V(0,0,0),off=V(0,0,0);camera.position.copy(C0);camera.lookAt(look);
function frame(t,dt,p){
 const c=t%12,fout=io(clamp((c-11.2)/.8)),keep=1-fout,tilt=(clamp(p)-.5);
 /* beat 1: ripple and bars */
 rings.forEach((r,i)=>{const a=((c/3.2)+i*.25)%1,cx=lerp(-1.5,3.2,clamp(c/7));r.l.position.x=cx;r.l.position.z=1.2-c*.08;const s=.3+a*3.2;r.l.scale.set(s,1,s);r.m.opacity=(1-a)*.75*keep*(c<9?1:1-clamp((c-9)/1.2))});
 const bin=io(clamp(c/.8)),bgo=io(clamp((c-4.2)/1.6));
 bars.forEach((B,i)=>{const sp=c<4.6?.55+.45*Math.abs(Math.sin(c*3.1+i*1.7)):1;const h=Math.max(.02,HB[i]*sp*(1-bgo)*bin);B.b.scale.y=h;B.b.position.y=BY;B.m.opacity=.9*bin*(1-bgo*.9)*keep});
 /* beat 2: points flow from the bar tops to the leaf outline, then the card fills in and turns */
 card.updateMatrixWorld();if(!tgt.length){for(let i=0;i<NP;i++){const q=outline[Math.floor(i/NP*outline.length)].clone();ol.updateMatrix();q.applyMatrix4(ol.matrix);tgt.push(q)}}
 const fl=clamp((c-4)/2.6);for(let i=0;i<NP;i++){const b=bars[i%NB].b,d=clamp(fl*1.25-(i/NP)*.25),e=io(d);wv.copy(tgt[i]).applyMatrix4(card.matrixWorld);
  const sx=b.position.x,sy=BY+HB[i%NB]*.5;const mx=lerp(sx,wv.x,.5),my=Math.max(sy,wv.y)+.9;
  const u=1-e;pp[i*3]=u*u*sx+2*u*e*mx+e*e*wv.x;pp[i*3+1]=u*u*sy+2*u*e*my+e*e*wv.y;pp[i*3+2]=u*u*.4+2*u*e*.6+e*e*wv.z}
 pg.attributes.position.needsUpdate=!0;pm.opacity=(fl>0&&fl<1?.95:fl>=1?.95*(1-clamp((c-6.8)/.6)):0)*keep;
 const cin=io(clamp((c-3.6)/1.2))*keep,lin=io(clamp((c-6.2)/1))*keep;cm.opacity=cin;im.opacity=cin;capm.forEach(m=>m.opacity=.4*cin);
 olm.opacity=.85*io(clamp((c-5.2)/1.2))*keep;olg.setDrawRange(0,Math.max(2,Math.round(outline.length*clamp((c-4.6)/2.2))));
 lm.opacity=lin;rib.material.opacity=.6*lin;spots.forEach((m,i)=>m.opacity=io(clamp((c-6.8-i*.2)/.5))*keep);
 const turn=io(clamp(c/12));card.rotation.y=-.38+.5*Math.sin(turn*Math.PI)+pointer.x*.06;card.rotation.x=-.04+pointer.y*.03;card.position.y=.25+.4*io(clamp((c-5)/4))+tilt*.15;
 /* beat 3: diagnosis card and handoff */
 const din=io(clamp((c-7.6)/.9))*keep;dcm.opacity=din;hm.opacity=.85*din;dc.position.x=.85-(1-din)*.4;dc.rotation.y=.16+pointer.x*.04;
 conf.forEach((k,i)=>{k.tm.opacity=.14*din;const f=io(clamp((c-8.2-i*.25)/1));k.fm.opacity=(i?.45:1)*din;const w=Math.max(.001,1.36*k.v*f);k.f.scale.x=w;k.f.position.x=-.68+w/2});
 const hin=io(clamp((c-9.6)/.7))*keep;hcm.opacity=hin;hdm.opacity=hin;hlm.opacity=.6*hin;ho.position.y=.62-(1-hin)*.25;
 /* camera: slow eased dolly, pointer parallax about 12 px, no shake */
 const d=io(.5-.5*Math.cos(t/12*Math.PI*2));camera.position.set(C0.x+off.x+.25*d+pointer.x*.18,C0.y+.1*d-pointer.y*.1,C0.z-.35*d);
 lk.copy(look).add(off);lk.x+=pointer.x*.05;camera.lookAt(lk)}
return{frame,resize:(w,h)=>{const a=w/h,narrow=a<.9;C0.z=narrow?14+(.9-a)*9:(a<1.5?9.4+(1.5-a)*2.6:9.4);off.x=narrow?(.9-a)*2.4:(a<1.5?(1.5-a)*1.2:0);look.y=narrow?-.6:0;
 scene.fog.near=C0.z+1;scene.fog.far=C0.z+18},dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());sp.dispose&&sp.dispose()}}}
