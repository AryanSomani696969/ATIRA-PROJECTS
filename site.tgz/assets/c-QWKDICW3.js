/* Gauntletiq hero: a test chamber on an iron floor. Five gates recede along a lit course; paper capsules (test
   conversations) enter from the edges (beat 1, 0 to 5 s), race through the gates and two fail ember at the third gate
   (beat 2, 5 to 10 s), then a replay reel scrubs back to the failing turn and the CI gate's bar drops and holds (beat 3,
   10 to 14 s) before the frame eases back to the opening. Scrolling holds the resolved state. Every figure is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const bg=new T.Color(colors.bg),paper=new T.Color(color("--gq-paper","#f6f5f2")),ember=new T.Color(color("--gq-ember","#ff5a1f")),green=new T.Color(color("--gq-green","#3fb27f"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),9,24);
const root=new T.Group;scene.add(root);const geos=[],mats=[];const G=g=>(geos.push(g),g);
const M=(c,o={})=>{const m=new T.MeshStandardMaterial(Object.assign({color:c,roughness:.7,metalness:.05},o));mats.push(m);return m};
const B=(c,o={})=>{const m=new T.MeshBasicMaterial(Object.assign({color:c},o));mats.push(m);return m};
root.add(new T.AmbientLight(0xe8e4dc,.55));
const key=new T.DirectionalLight(0xffe6cc,1.2);key.position.set(-4,7,6);root.add(key);
const rim=new T.DirectionalLight(ember.getHex(),.45);rim.position.set(5,3,-6);root.add(rim);
/* floor: a dark slab with lane lines and cross rules */
const floor=new T.Mesh(G(new T.PlaneGeometry(30,30)),B(bg.clone().lerp(paper,.045)));floor.rotation.x=-Math.PI/2;root.add(floor);
const lp=[];for(let i=-6;i<=6;i++){lp.push(i*.9+1.6,.002,-16,i*.9+1.6,.002,4)}for(let z=-16;z<=4;z+=2){lp.push(-4,.002,z,8,.002,z)}
const lg=G(new T.BufferGeometry);lg.setAttribute("position",new T.Float32BufferAttribute(lp,3));const lm=new T.LineBasicMaterial({color:bg.clone().lerp(paper,.13)});mats.push(lm);root.add(new T.LineSegments(lg,lm));
/* the course: three lit lanes under five gates; gate 0 at the front is the CI gate */
const LX=[1.15,1.6,2.05],GZ=[0,-2.6,-5.2,-7.8,-10.4];
const laneM=B(bg.clone().lerp(paper,.22));LX.forEach(x=>{const l=new T.Mesh(G(new T.BoxGeometry(.03,.004,13.6)),laneM);l.position.set(x,.004,-5.2);root.add(l)});
const postG=G(new T.BoxGeometry(.12,1.7,.12)),linG=G(new T.BoxGeometry(1.55,.12,.14)),lampG=G(new T.BoxGeometry(.34,.1,.16));
const frameM=M(paper.clone().multiplyScalar(.92),{roughness:.55});
const gates=GZ.map((z,i)=>{const g=new T.Group;g.position.set(1.6,0,z);root.add(g);
 const a=new T.Mesh(postG,frameM);a.position.set(-.72,.85,0);const b=new T.Mesh(postG,frameM);b.position.set(.72,.85,0);const l=new T.Mesh(linG,frameM);l.position.y=1.72;
 const lampM=M(green.clone(),{emissive:green.clone(),emissiveIntensity:.25,roughness:.4});const lamp=new T.Mesh(lampG,lampM);lamp.position.y=1.86;g.add(a,b,l,lamp);
 return{g,lampM}});
const barM=M(ember.clone(),{emissive:ember.clone(),emissiveIntensity:.35,roughness:.45});const bar=new T.Mesh(G(new T.BoxGeometry(1.3,.08,.08)),barM);bar.position.set(1.6,1.6,0);root.add(bar);
/* capsules: test conversations. Two of them fail at gate 2 */
const N=small?9:15,capG=G(new T.BoxGeometry(.32,.15,.15));const caps=[];
for(let i=0;i<N;i++){const fail=i===4||i===10;const m=M(paper.clone(),{emissive:ember.clone(),emissiveIntensity:0,roughness:.5});const c=new T.Mesh(capG,m);root.add(c);
 const side=i%2?1:-1;caps.push({c,m,fail,lane:LX[i%3],t0:(i*.31)%4.6,side,spd:.92+((i*37)%10)/40})}
/* replay reel: a strip of turn frames above the front lane, with a playhead that scrubs back to the failing turn */
const reel=new T.Group;reel.position.set(3.55,.62,.9);reel.rotation.set(-.25,-.55,0);root.add(reel);
const fG=G(new T.BoxGeometry(.24,.17,.02)),fM=M(bg.clone().lerp(paper,.3),{roughness:.6}),hlM=M(ember.clone(),{emissive:ember.clone(),emissiveIntensity:.4});
const frames=[];for(let i=0;i<9;i++){const f=new T.Mesh(fG,i===6?hlM:fM);f.position.set(-1.2+i*.3,0,0);reel.add(f);frames.push(f)}
const ph=new T.Mesh(G(new T.BoxGeometry(.025,.36,.03)),B(paper.clone()));reel.add(ph);
const C0=new T.Vector3(-1.6,2.55,6.6),look=new T.Vector3(1.9,.95,-3.2),lk=new T.Vector3;camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const zIn=-14,zGate2=GZ[2],zHold=.65;
function frame(t,dt,p){
const hold=clamp((p-.5)/.3),c0=t%14,c=hold>0?lerp(c0,12.4,ease(hold)):c0,reset=c>13.2?ease((c-13.2)/.8):0;
camera.position.set(C0.x+Math.sin(t/14*Math.PI*2)*.25+pointer.x*.3,C0.y-pointer.y*.15,C0.z);lk.copy(look);lk.x+=pointer.x*.08;camera.lookAt(lk);
/* beat 1 enters from the edges, beat 2 runs the course, beat 3 waits at the held CI gate */
let fails=0;
caps.forEach((k,i)=>{const enter=ease(clamp((c-k.t0*.9)/1.6));const run=clamp((c-5-k.t0*.5)/4.2*k.spd);
 let z=lerp(zIn,zHold-((i%5)*.42),ease(run)),x=lerp(k.lane+k.side*4.2,k.lane,enter),y=.12+Math.sin(t*3+i)*.01,s=1,glow=0;
 if(k.fail){const zf=zGate2+.25;if(z>zf){z=zf;const u=clamp((c-(5+k.t0*.5+((zf-zIn)/(zHold-zIn))*4.2/k.spd))/1);glow=Math.min(1,u*2.2);s=1+Math.sin(Math.min(1,u)*Math.PI)*.4;y=.12-Math.max(0,u-.5)*.16;fails++}}
 k.c.position.set(x,y,z);k.c.scale.setScalar(Math.max(.001,s*(1-reset)*clamp(enter*1.4)));k.m.emissiveIntensity=glow*.9;k.m.color.copy(paper).lerp(ember,glow)});
/* gate lamps: gate 2 turns ember once the first failure lands; the CI gate turns ember and its bar drops in beat 3 */
gates.forEach((g,i)=>{const on=i===2?clamp(fails):i===0?ease(clamp((c-10)/.8)):0;g.lampM.color.copy(green).lerp(ember,on);g.lampM.emissive.copy(green).lerp(ember,on);g.lampM.emissiveIntensity=.25+on*.45});
const drop=ease(clamp((c-10.2)/.9))*(1-reset);bar.position.y=lerp(1.6,.62,drop);bar.scale.x=Math.max(.001,drop);
/* replay reel: fades in at 10 s, the playhead runs to the end then scrubs back to the failing turn */
const rv=ease(clamp((c-9.6)/.6))*(1-reset);reel.scale.setScalar(Math.max(.001,rv));
const fwd=clamp((c-10)/1.2),back=ease(clamp((c-11.3)/1));ph.position.x=lerp(-1.2,lerp(1.2,.6,back),ease(fwd));
hlM.emissiveIntensity=.2+back*.6}
return{frame,resize:(w,h)=>{C0.z=w/h<.8?9.4:6.6;look.x=w/h<.8?1.7:1.9},dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose())}}}
