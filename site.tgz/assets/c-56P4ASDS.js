/* Noticevane hero: a control-room weather map. Isobars sit on a tilted slate plane and notice cards drift across it
   like cloud fronts. 14 s loop, three beats: 0-5 s the cards enter from the edges; 5-10 s a ring filter catches the
   three relevant notices and pulls them onto policy nodes (one in caution amber); 10-14 s a task tick attaches to each
   node and closes in teal, the other cards drift off and the frame eases back to the opening. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(47);
const bg=new T.Color(colors.bg),ink=new T.Color(color("--nv-bone","#f6f3ec")),teal=new T.Color(color("--nv-teal","#1a9e8f")),amber=new T.Color(color("--nv-amber","#e0a030"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),8,19);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xc8d0d8,.7));
const key=new T.DirectionalLight(0xfff1dc,.85);key.position.set(-4,6,6);root.add(key);
const rim=new T.DirectionalLight(teal.getHex(),.5);rim.position.set(5,2,-5);root.add(rim);
const geos=[],mats=[];const G=g=>(geos.push(g),g),M=m=>(mats.push(m),m);
const lineMat=(c,o)=>M(new T.LineBasicMaterial({color:c,transparent:!0,opacity:o}));
const segGeo=a=>{const g=G(new T.BufferGeometry);g.setAttribute("position",new T.Float32BufferAttribute(a,3));return g};
const ring=(rx,ry,n,wob,ph)=>{const a=[];for(let i=0;i<n;i++){const t0=i/n*Math.PI*2,t1=(i+1)/n*Math.PI*2,f=t=>1+wob*Math.sin(3*t+ph)+wob*.5*Math.cos(2*t-ph);
 a.push(Math.cos(t0)*rx*f(t0),0,Math.sin(t0)*ry*f(t0),Math.cos(t1)*rx*f(t1),0,Math.sin(t1)*ry*f(t1))}return a};
/* the map: a faint grid and two pressure systems of isobars */
const map=new T.Group;map.position.set(0,-1.35,0);root.add(map);
const gl=[];for(let i=-8;i<=8;i++){gl.push(i,0,-7,i,0,5,-8,0,i*.75-1,8,0,i*.75-1)}
map.add(new T.LineSegments(segGeo(gl),lineMat(ink.clone().lerp(bg,.82),.5)));
const isoM=lineMat(ink.clone().lerp(bg,.6),.55),isos=[];
[[-2.2,-1.5,6],[3.4,-3.2,4]].forEach(([x,z,n],s)=>{for(let k=1;k<=n;k++){const l=new T.LineSegments(segGeo(ring(.55*k,.4*k,64,.07,k*.7+s)),isoM);l.position.set(x,0,z);map.add(l);isos.push(l)}});
/* notice cards: thin bone boards with an edge, a reference stub and two text bars */
const CW=1.15,CH=.66,boardGeo=G(new T.BoxGeometry(CW,CH,.025)),barGeo=G(new T.PlaneGeometry(1,.05)),stubGeo=G(new T.PlaneGeometry(.16,.4));
const edge=(()=>{const w=CW/2,h=CH/2;return segGeo([-w,-h,0,w,-h,0,w,-h,0,w,h,0,w,h,0,-w,h,0,-w,h,0,-w,-h,0])})();
const N=small?9:15,cards=[],HIT=[2,5,8];
for(let i=0;i<N;i++){const g=new T.Group;
 const bm=M(new T.MeshStandardMaterial({color:ink,transparent:!0,opacity:.12,roughness:.4,metalness:.05,emissive:ink,emissiveIntensity:.05,depthWrite:!1}));g.add(new T.Mesh(boardGeo,bm));
 const em=lineMat(ink.clone(),.55);g.add(new T.LineSegments(edge,em));
 const sm=M(new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:.35}));const st=new T.Mesh(stubGeo,sm);st.position.set(-CW/2+.16,0,.02);g.add(st);
 const b1m=M(new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:.6})),b2m=M(new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:.3}));
 const b1=new T.Mesh(barGeo,b1m);b1.scale.x=.45+R()*.3;b1.position.set(-CW/2+.32+b1.scale.x/2,.09,.02);g.add(b1);
 const b2=new T.Mesh(barGeo,b2m);b2.scale.x=.3+R()*.3;b2.position.set(-CW/2+.32+b2.scale.x/2,-.07,.02);g.add(b2);
 root.add(g);
 const side=i%4,ang=R()*Math.PI*2;
 cards.push({g,mats:[bm,em,sm,b1m,b2m],base:[.12,.55,.35,.6,.3],hit:HIT.indexOf(i),
  start:new T.Vector3(side===0?-7.5:side===1?7.5:lerp(-5,5,R()),lerp(-.6,2.6,R()),side>1?(side===2?-6:3.5):lerp(-3,1,R())),
  mid:new T.Vector3(lerp(-3.6,1.4,R()),lerp(-.4,2.2,R()),lerp(-2.4,.6,R())),sp:.25+R()*.35,ph:ang,d:R()*.7})}
/* the relevance filter: an elliptical ring the relevant cards pass through */
const filt=new T.LineSegments(segGeo(ring(1.05,.75,72,0,0)),lineMat(teal.clone(),.0));filt.rotation.x=Math.PI/2;filt.position.set(.6,.9,-.2);root.add(filt);
const filt2=new T.LineSegments(segGeo(ring(1.25,.9,72,0,0)),lineMat(teal.clone(),.0));filt2.rotation.x=Math.PI/2;filt2.position.copy(filt.position);root.add(filt2);
/* policy nodes: three rings on the right, each takes one caught notice; ticks close them */
const nodes=[],nodeGeo=(()=>{const a=[];for(let i=0;i<40;i++){const t0=i/40*Math.PI*2,t1=(i+1)/40*Math.PI*2;a.push(Math.cos(t0)*.2,Math.sin(t0)*.2,0,Math.cos(t1)*.2,Math.sin(t1)*.2,0)}return segGeo(a)})(),coreGeo=G(new T.SphereGeometry(.1,16,12));
const tickGeo=segGeo([-.07,0,0,-.02,-.05,0,-.02,-.05,0,.08,.06,0]);
for(let k=0;k<3;k++){const p=new T.Vector3(3.15,1.75-k*.95,-.1);
 const nm=lineMat(ink.clone(),0);const n=new T.LineSegments(nodeGeo,nm);n.position.copy(p);root.add(n);
 const cm=M(new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:0}));const c=new T.Mesh(coreGeo,cm);c.position.copy(p);root.add(c);
 const tm=lineMat(teal.clone(),0);const tk=new T.LineSegments(tickGeo,tm);tk.position.set(p.x,p.y,p.z+.04);tk.scale.setScalar(1.4);root.add(tk);
 const lk=new T.Line(G(new T.BufferGeometry().setFromPoints([new T.Vector3,new T.Vector3])),lineMat(ink.clone(),0));root.add(lk);
 nodes.push({p,nm,cm,tm,lk,tk,slot:new T.Vector3(p.x-1.05,p.y,p.z)})}
/* drift particles, like rain bands on the map */
const DN=small?50:120,dp=new Float32Array(DN*3);for(let i=0;i<DN;i++){dp[i*3]=lerp(-7,7,R());dp[i*3+1]=lerp(-1.2,3.2,R());dp[i*3+2]=lerp(-7,2,R())}
const dg=G(new T.BufferGeometry);dg.setAttribute("position",new T.BufferAttribute(dp,3));root.add(new T.Points(dg,M(new T.PointsMaterial({color:ink,size:.02,transparent:!0,opacity:.28,depthWrite:!1}))));
const C0=new T.Vector3(.4,1.3,8.2),look=new T.Vector3(.9,.7,0),lk=new T.Vector3,tmp=new T.Vector3,off=new T.Vector3(0,0,0);
camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const io=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;/* cubic in-out */
function frame(t,dt,p){
const c=t%14,sc=clamp(p);
isos.forEach((l,i)=>{l.rotation.y=Math.sin(t*.05+i*.3)*.06});map.rotation.x=-.08+sc*.05;
const fin=clamp((c-4.6)/.8),fout=clamp((c-10.2)/1.2);
filt.material.opacity=.9*fin*(1-fout);filt2.material.opacity=.3*fin*(1-fout);filt.rotation.z=t*.2;filt2.rotation.z=-t*.12;
for(const C of cards){
 const e=io(clamp((c-.1-C.d)/3.2)),out=io(clamp((c-11.6)/2.2));
 /* drifting front: start at an edge, settle on a slow orbit around the mid point */
 tmp.copy(C.start).lerp(C.mid,e);tmp.x+=Math.sin(t*C.sp+C.ph)*.25;tmp.y+=Math.cos(t*C.sp*.8+C.ph)*.12;
 let vis=e;
 if(C.hit>=0){const N0=nodes[C.hit],m1=io(clamp((c-5.2-C.hit*.35)/1.6)),m2=io(clamp((c-6.9-C.hit*.35)/1.8));
  /* through the filter ring, then onto its policy node */
  tmp.lerp(filt.position,m1*(1-m2));tmp.lerp(N0.slot,m2);vis=e*(1-out*.9);
  const hc=clamp((c-5.4-C.hit*.35)/.8)*(1-fout*.0);C.mats[1].color.copy(ink).lerp(C.hit===1?amber:teal,hc);C.mats[2].color.copy(ink).lerp(C.hit===1?amber:teal,hc);
  C.g.rotation.set(-.04,(1-m2)*Math.sin(C.ph)*.5,0)}
 else{const fade=clamp((c-6)/2)*.55;vis=e*(1-fade)*(1-out);C.g.rotation.set(-.06,Math.sin(C.ph+t*.1)*.45,Math.sin(C.ph)*.05);tmp.x+=fade*Math.sign(C.start.x||1)*.8}
 C.g.position.copy(tmp);C.mats.forEach((mm,k)=>mm.opacity=C.base[k]*vis*(C.hit>=0&&k<3?1.6:1))}
nodes.forEach((N0,k)=>{const nin=clamp((c-6.4-k*.3)/1),tk=clamp((c-10-k*.35)/.7),nout=1-clamp((c-12.6)/1.2);
 N0.nm.opacity=.8*nin*nout;N0.cm.opacity=.18*nin*nout;N0.nm.color.copy(ink).lerp(teal,tk);N0.cm.color.copy(k===1?amber:ink).lerp(teal,tk);
 N0.tm.opacity=tk*nout;N0.tk.scale.setScalar(1+.4*ease(tk));
 const pos=N0.lk.geometry.attributes.position.array;pos[0]=N0.slot.x+CW/2;pos[1]=N0.slot.y;pos[2]=N0.slot.z;pos[3]=N0.p.x-.2;pos[4]=N0.p.y;pos[5]=N0.p.z;N0.lk.geometry.attributes.position.needsUpdate=!0;
 N0.lk.material.opacity=.5*clamp((c-8.4-k*.3)/.6)*nout});
/* camera: one slow eased arc over the map, pointer parallax, no shake */
const d=io(.5-.5*Math.cos(t/14*Math.PI*2));camera.position.set(C0.x+off.x-.35*d+pointer.x*.22,C0.y+.15*d-pointer.y*.14,C0.z+off.z-.4*d);lk.copy(look);lk.x+=off.x+pointer.x*.08;camera.lookAt(lk);
const a=dg.attributes.position.array;for(let i=0;i<DN;i++){a[i*3]+=Math.min(dt||0,.05)*.12;if(a[i*3]>7)a[i*3]=-7}dg.attributes.position.needsUpdate=!0}
return{frame,resize:(w,h)=>{const narrow=w/h<.9;off.z=narrow?3.6:0;off.x=narrow?.8:0},dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose())}}}
