// kit_cine runtime: plays rendered loops only while visible, honours reduced motion / Save-Data, Pause control, word reveal
export function boot() {
  const mq = matchMedia('(prefers-reduced-motion: reduce)');
  const cn = navigator.connection || {};
  const light = !!(cn.saveData || /(^|-)2g$/.test(cn.effectiveType || ''));
  const vids = [].slice.call(document.querySelectorAll('[data-cn-vid]'));
  const seen = new Map();
  let held = false;
  const ok = () => !held && !mq.matches && !light && document.visibilityState === 'visible';
  const play = (v) => { if (!ok()) return; const p = v.play(); if (p && p.then) p.then(() => v.classList.add('is-on')).catch(() => {}); };
  const io = 'IntersectionObserver' in window ? new IntersectionObserver((es) => es.forEach((e) => { const v = e.target; seen.set(v, e.isIntersecting); if (e.isIntersecting) play(v); else v.pause(); }), { rootMargin: '80px' }) : null;
  vids.forEach((v) => { if (io) io.observe(v); else play(v); });
  document.addEventListener('visibilitychange', () => vids.forEach((v) => (seen.get(v) ? play(v) : v.pause())));
  mq.addEventListener && mq.addEventListener('change', () => vids.forEach((v) => (ok() && seen.get(v) ? play(v) : (v.pause(), v.classList.remove('is-on')))));
  document.querySelectorAll('[data-cn-pause]').forEach((b) => b.addEventListener('click', () => {
    held = !held; b.setAttribute('aria-pressed', held ? 'true' : 'false');
    const s = b.querySelector('span'); if (s) s.textContent = held ? 'Play animation' : 'Pause animation';
    vids.forEach((v) => (held ? v.pause() : seen.get(v) && play(v)));
  }));
  // words that light up as the section scrolls into view (skipped for automated browsers and reduced motion)
  const blocks = [].slice.call(document.querySelectorAll('[data-cn-words]'));
  if (blocks.length && !mq.matches && !navigator.webdriver) {
    blocks.forEach((el) => {
      const walk = (n) => { [].slice.call(n.childNodes).forEach((c) => { if (c.nodeType === 3) { const f = document.createDocumentFragment(); c.textContent.split(/(\s+)/).forEach((t) => { if (!t) return; if (/^\s+$/.test(t)) f.appendChild(document.createTextNode(t)); else { const s = document.createElement('span'); s.className = 'cn-w'; s.textContent = t; f.appendChild(s); } }); n.replaceChild(f, c); } else if (c.nodeType === 1) walk(c); }); };
      walk(el); el.setAttribute('data-cn-on', '');
    });
    let tick = false;
    const upd = () => { tick = false; const vh = innerHeight; blocks.forEach((el) => { const r = el.getBoundingClientRect(); const p = Math.min(1, Math.max(0, (vh * 0.9 - r.top) / (vh * 0.55))); const w = el.querySelectorAll('.cn-w'); const n = w.length; w.forEach((s, i) => s.classList.toggle('is-on', p * (n + 2) > i + 1)); }); };
    addEventListener('scroll', () => { if (!tick) { tick = true; requestAnimationFrame(upd); } }, { passive: true }); addEventListener('resize', upd); upd();
  }
}
