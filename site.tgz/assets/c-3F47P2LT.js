/* Amlwarden hero: a night-watch control wall of linked entity nodes, 14-second loop.
   Beat 1 (0-5 s): the wall of nodes glows faintly; four red alerts enter from the edges and drift to their nodes.
   Beat 2 (5-10 s): the first alert pulls its network of entities forward and lights its links; evidence cards stack beside it.
   Beat 3 (10-14 s): a draft narrative card settles, blue threads run from the cards to its lines, then the frame eases back.
   Scrolling holds the assembled case. Every alert, entity and line here is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(41);
const bg=new T.Color(colors.bg),paper=new T.Color(color("--aw-paper","#f3f1ec")),red=new T.Color(color("--aw-red","#d64545")),blue=new T.Color(color("--aw-blue","#3b82c4"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),7,17);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xd9dde3,.6));
const key=new T.DirectionalLight(0xffe6c4,1.1);key.position.set(-3,5,6);root.add(key);
const rim=new T.DirectionalLight(blue.getHex(),.7);rim.position.set(4,-2,-4);root.add(rim);
/* the wall: a gently curved grid of nodes */
const C=small?16:24,RW=small?9:12,SP=.42,nodes=[];
for(let j=0;j<RW;j++)for(let i=0;i<C;i++){const x=(i-(C-1)/2)*SP+(R()-.5)*.16,y=(j-(RW-1)/2)*SP+(R()-.5)*.16;nodes.push({b:new T.Vector3(x,y,-2.4-x*x*.035),p:new T.Vector3,f:0})}
nodes.forEach(n=>n.p.copy(n.b));
const idx=k=>nodes[k];const links=[];
for(let j=0;j<RW;j++)for(let i=0;i<C;i++){const k=j*C+i;if(i<C-1&&R()<.5)links.push([k,k+1]);if(j<RW-1&&R()<.45)links.push([k,k+C]);if(i<C-1&&j<RW-1&&R()<.14)links.push([k,k+C+1])}
const nGeo=new T.SphereGeometry(.035,8,6),nMat=new T.MeshBasicMaterial({color:0xffffff}),inst=new T.InstancedMesh(nGeo,nMat,nodes.length),o=new T.Object3D,tc=new T.Color;root.add(inst);
const lPos=new Float32Array(links.length*6),lCol=new Float32Array(links.length*6),lg=new T.BufferGeometry;
lg.setAttribute("position",new T.BufferAttribute(lPos,3));lg.setAttribute("color",new T.BufferAttribute(lCol,3));
const lines=new T.LineSegments(lg,new T.LineBasicMaterial({vertexColors:!0,transparent:!0,opacity:.9}));root.add(lines);
const dimN=bg.clone().lerp(paper,.32),dimL=bg.clone().lerp(paper,.12);
/* the focus network: the central node and its neighbours within two links */
const ci=Math.floor(RW/2)*C+Math.floor(C/2)-2,adj=new Map;links.forEach(([a,b])=>{(adj.get(a)||adj.set(a,[]).get(a)).push(b);(adj.get(b)||adj.set(b,[]).get(b)).push(a)});
const focus=new Map([[ci,0]]);let fr=[ci];for(let d=1;d<=2;d++){const nx=[];fr.forEach(k=>(adj.get(k)||[]).forEach(m=>{if(!focus.has(m)&&focus.size<(small?8:11)){focus.set(m,d);nx.push(m)}}));fr=nx}
/* alerts entering from the edges */
const aGeo=new T.IcosahedronGeometry(.09,0),targets=[ci,Math.floor(RW*.2)*C+3,Math.floor(RW*.75)*C+C-4,Math.floor(RW*.3)*C+C-6];
const alerts=targets.map((t,i)=>{const m=new T.Mesh(aGeo,new T.MeshStandardMaterial({color:red.clone(),emissive:red.clone(),emissiveIntensity:.8,roughness:.4}));
const a=i*Math.PI/2+.6,from=new T.Vector3(Math.cos(a)*7,Math.sin(a)*3.6,-1.2);root.add(m);return{m,t,from,d:.4+i*.55}});
const hp=[];for(let i=0;i<=48;i++){const a=i/48*Math.PI*2;hp.push(new T.Vector3(Math.cos(a)*.17,Math.sin(a)*.17,0))}const halo=new T.Line(new T.BufferGeometry().setFromPoints(hp),new T.LineBasicMaterial({color:red.clone(),transparent:!0,opacity:0}));root.add(halo);
/* evidence cards */
const cGeo=new T.BoxGeometry(.84,.32,.02),eGeo=new T.BufferGeometry().setFromPoints([[-1,-1],[1,-1],[1,-1],[1,1],[1,1],[-1,1],[-1,1],[-1,-1]].map(([x,y])=>new T.Vector3(x*.42,y*.16,.012))),cards=[];
for(let i=0;i<4;i++){const g=new T.Group;const m=new T.Mesh(cGeo,new T.MeshBasicMaterial({color:bg.clone().lerp(paper,.07),transparent:!0,opacity:0}));
const e=new T.LineSegments(eGeo,new T.LineBasicMaterial({color:blue.clone(),transparent:!0,opacity:0}));g.add(m,e);
for(let l=0;l<2;l++){const bar=new T.Mesh(new T.BoxGeometry(.5-l*.16,.03,.005),new T.MeshBasicMaterial({color:bg.clone().lerp(paper,.45),transparent:!0,opacity:0}));bar.position.set(-.1-l*.08,.05-l*.09,.015);g.add(bar)}
g.position.set(1.45,.55-i*.4,-.5);g.rotation.y=-.32;root.add(g);cards.push(g)}
/* the narrative draft */
const narr=new T.Group;narr.position.set(.35,-1.05,-.2);narr.rotation.y=-.08;narr.scale.setScalar(.8);root.add(narr);
const nCard=new T.Mesh(new T.BoxGeometry(1.5,1.15,.02),new T.MeshBasicMaterial({color:paper.clone(),transparent:!0,opacity:0,depthWrite:!1}));narr.add(nCard);
const nl=[];for(let l=0;l<7;l++){const w=1.1-((l*37)%30)/100;const bar=new T.Mesh(new T.BoxGeometry(w,.04,.006),new T.MeshBasicMaterial({color:bg.clone().lerp(paper,.25),transparent:!0,opacity:0}));bar.position.set(-.6+w/2,.42-l*.135,.014);narr.add(bar);nl.push(bar)}
const chip=[1,3,5].map(l=>{const c=new T.Mesh(new T.BoxGeometry(.07,.07,.008),new T.MeshBasicMaterial({color:blue.clone(),transparent:!0,opacity:0}));c.position.set(.62,.42-l*.135,.016);narr.add(c);return c});
const disp=new T.Mesh(new T.BoxGeometry(.5,.12,.01),new T.MeshBasicMaterial({color:red.clone(),transparent:!0,opacity:0}));disp.position.set(-.38,-.5,.016);narr.add(disp);narr.children.forEach(m=>{if(m!==nCard)m.renderOrder=2});
/* threads from cards to narrative lines */
const v3=(x,y,z)=>new T.Vector3(x,y,z),wa=new T.Vector3,wb=new T.Vector3,threads=[];root.updateMatrixWorld(!0);
[0,1,2].forEach(k=>{cards[k].localToWorld(wa.set(-.42,0,0));chip[k].getWorldPosition(wb);
const mx=wa.x-.14-k*.07,pts=[wa.clone(),v3(mx+.04,wa.y,wa.z),v3(mx,wa.y-.04,wa.z),v3(mx,wb.y+.04,wb.z),v3(mx-.04,wb.y,wb.z),wb.clone().add(v3(.04,0,.02))];
const g=new T.TubeGeometry(new T.CatmullRomCurve3(pts,!1,"centripetal"),small?40:80,.008,5,!1),t=new T.Mesh(g,new T.MeshBasicMaterial({color:blue.clone()}));t.visible=!1;root.add(t);threads.push({t,g,n:g.index.count})});
camera.fov=40;camera.updateProjectionMatrix();
const P0=v3(0,.1,6.4),P1=v3(.35,.15,5.1),look=v3(.1,.05,-1.2),lk=v3(),wide={k:1};
function frameFn(t,dt,p){const hold=clamp((p-.45)/.3),c0=t%14,c=hold>0?lerp(c0,11.6,ease(hold)):c0;
const back=c>12.6?ease((c-12.6)/1.4):0,pull=clamp((c-5)/1.6)*(1-back);
const cp=P0.clone().lerp(P1,ease(clamp((c-4.2)/3))*(1-back));cp.multiplyScalar(wide.k);camera.position.copy(cp);camera.position.x+=pointer.x*.25;camera.position.y-=pointer.y*.12;
lk.copy(look);lk.x+=pointer.x*.06;camera.lookAt(lk);
nodes.forEach((n,k)=>{const d=focus.get(k),on=d===undefined?0:pull*clamp(1.6-d*.35);n.f=on;n.p.copy(n.b);n.p.z+=on*(1.25-(d||0)*.25);
const tw=.75+.25*Math.sin(t*1.3+k*.7);o.position.copy(n.p);o.scale.setScalar(1+on*.9);o.updateMatrix();inst.setMatrixAt(k,o.matrix);
tc.copy(dimN).multiplyScalar(tw);if(on)tc.lerp(k===ci?red:paper,on);inst.setColorAt(k,tc)});inst.instanceMatrix.needsUpdate=!0;inst.instanceColor.needsUpdate=!0;
links.forEach(([a,b],i)=>{const A=nodes[a].p,B=nodes[b].p,on=Math.min(nodes[a].f,nodes[b].f);lPos.set([A.x,A.y,A.z,B.x,B.y,B.z],i*6);
tc.copy(dimL);if(on>0)tc.lerp(blue,on*.9);lCol.set([tc.r,tc.g,tc.b,tc.r,tc.g,tc.b],i*6)});lg.attributes.position.needsUpdate=!0;lg.attributes.color.needsUpdate=!0;
alerts.forEach((al,i)=>{const e=ease(clamp((c-al.d)/3.2)),tp=nodes[al.t].p,fade=1-back;al.m.position.copy(al.from).lerp(tp,e);al.m.position.z+=.05;al.m.rotation.y=t*1.2+i;al.m.rotation.x=t*.7;
al.m.material.opacity=1;al.m.visible=fade>.05;al.m.scale.setScalar((.6+.4*e)*(i===0?1+pull*.5:1)*Math.max(fade,.05))});
halo.position.copy(nodes[ci].p);halo.position.z+=.02;halo.material.opacity=pull*(.5+.3*Math.sin(t*3));halo.scale.setScalar(1+pull*.6);
cards.forEach((g,i)=>{const e=clamp((c-6.2-i*.7)/.8)*(1-back);g.children[0].material.opacity=e*.95;g.children[1].material.opacity=e;g.children.slice(2).forEach(b=>b.material.opacity=e);g.position.x=1.45+(1-e)*.6;g.visible=e>.01});
const ne=clamp((c-9.6)/.9)*(1-back);nCard.material.opacity=ne*.96;narr.position.y=-1.05-(1-ne)*.3;nl.forEach((b,l)=>{const e=clamp((c-10-l*.18)/.5)*(1-back);b.material.opacity=e;b.scale.x=Math.max(.01,e)});
chip.forEach((ch,k)=>ch.material.opacity=clamp((c-11-k*.3)/.4)*(1-back));disp.material.opacity=clamp((c-11.8)/.5)*(1-back)*(.65+.35*Math.sin(t*2.4));
threads.forEach((th,k)=>{const e=clamp((c-10.6-k*.3)/.9)*(1-back);th.t.visible=e>.01;th.g.setDrawRange(0,Math.floor(th.n*e/3)*3)})}
return{frame:frameFn,resize:(w,h)=>{wide.k=w/h<.6?1.55:w/h<1.2?1.15:1},dispose:()=>{[nGeo,lg,aGeo,cGeo,eGeo,halo.geometry,nCard.geometry].concat(threads.map(x=>x.g)).forEach(g=>g.dispose())}}}
