/* Dueweave page tools. Everything runs in the browser; nothing chosen or typed here leaves the page.
   [data-dw=preview]  Message Preview: invoice details, tone slider, channel and language -> a reminder, its length or segments, and a follow-up schedule
   [data-dw=play]     home workspace: one synthetic invoice stepped from overdue to paid, tone of the first reminder switchable
   [data-dw=dso]      DSO calculator: receivables / credit sales x days
   [data-dw=tabs]     tab sets (desk views, sample thread steps) with arrow-key movement */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const num=s=>{const v=parseFloat(String(s).replace(/[$,\s]/g,""));return isFinite(v)?v:NaN};
const money=v=>"$"+v.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const D=s=>{const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s||"");if(!m)return null;const d=new Date(Date.UTC(+m[1],+m[2]-1,+m[3]));return isNaN(d)?null:d};
const addD=(d,n)=>new Date(d.getTime()+n*864e5),wk=d=>{const w=d.getUTCDay();return w===6?addD(d,2):w===0?addD(d,1):d};
const EN={d:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],m:["January","February","March","April","May","June","July","August","September","October","November","December"]};
const ES={d:["domingo","lunes","martes","miércoles","jueves","viernes","sábado"],m:["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"]};
const fmt=(d,l,k)=>{const L=l==="es"?ES:EN,dd=d.getUTCDate(),mm=L.m[d.getUTCMonth()],wd=L.d[d.getUTCDay()];
if(l==="es")return k==="s"?dd+" de "+mm:wd+" "+dd+" de "+mm;return k==="s"?mm.slice(0,3)+" "+dd:wd+", "+mm+" "+dd};
const TONE=["Friendly","Formal","Firm"];

/* ---------- templates: [lang][channel][state][tone]; state b before due, t due today, o overdue */
const LINK={en:"[payment link]",es:"[enlace de pago]"},STOP={en:" Reply STOP to opt out.",es:" Responda STOP para no recibir más mensajes."};
const dz=(n,l)=>l==="es"?n+(n===1?" día":" días"):n+(n===1?" day":" days");
const T={
en:{email:{
b:["Invoice {inv} is due on {due}|Hello {cust} team,\n\nA courtesy note from {biz}: invoice {inv} for {amt} is due on {due}. You can pay it here when ready: {link}.\n\nThank you,\n{biz} accounts team",
   "Upcoming payment: invoice {inv}|Dear {cust} accounts payable team,\n\nThis is a courtesy reminder that invoice {inv} for {amt} falls due on {due}. Payment can be made using the link below.\n\n{link}\n\nKind regards,\n{biz} accounts receivable"],
t:["Invoice {inv} is due today|Hello {cust} team,\n\nA quick note from {biz}: invoice {inv} for {amt} is due today. If it is already on its way, thank you. If not, you can pay it here: {link}.\n\nThank you,\n{biz} accounts team",
   "Payment due today: invoice {inv}|Dear {cust} accounts payable team,\n\nInvoice {inv} for {amt} falls due today. Please arrange payment using the link below, or let us know of any query.\n\n{link}\n\nKind regards,\n{biz} accounts receivable"],
o:["Invoice {inv} from {biz}|Hello {cust} team,\n\nA quick note from {biz}: invoice {inv} for {amt} was due on {due}. If it is already on its way, thank you, and please ignore this.\n\nIf not, you can pay it here: {link}. If anything on the invoice looks wrong, just reply and we will sort it out.\n\nThank you,\n{biz} accounts team",
   "Payment reminder: invoice {inv}|Dear {cust} accounts payable team,\n\nOur records show invoice {inv} for {amt}, due on {due}, as unpaid. It is now {n} past due.\n\nPlease arrange payment at your earliest convenience using the link below, or let us know if there is a query we should resolve.\n\n{link}\n\nKind regards,\n{biz} accounts receivable",
   "Overdue: invoice {inv}, {n} past due|Hello {cust} team,\n\nInvoice {inv} for {amt} is now {n} past due. It was due on {due}.\n\nPlease pay by {payby} using the link below, or reply today so we can agree a date that works.\n\n{link}\n\nThank you,\n{biz} accounts team"]},
sms:{b:["{biz}: invoice {inv} for {amt} is due {dues}. Pay when ready: {link}.","{biz}: courtesy reminder, invoice {inv} for {amt} falls due {dues}. Pay at {link}."],
t:["{biz}: invoice {inv} for {amt} is due today. Pay here: {link}. Already paid? Thank you.","{biz}: invoice {inv} for {amt} falls due today. Please pay at {link} or reply with any query."],
o:["{biz}: a reminder that invoice {inv} for {amt} was due {dues}. Pay here: {link}. Already paid? Thank you.","{biz}: invoice {inv} for {amt}, due {dues}, is unpaid. Please pay at {link} or reply with any query.",
   "{biz}: invoice {inv} for {amt} is {n} past due. Please pay by {paybys} at {link} or reply today to agree a date."]},
voice:{b:["Hello, this is an automated courtesy call from {biz} for the accounts payable team at {cust}. Invoice {inv}, for {amt}, is due on {due}. A payment link is in our email. To speak with someone at {biz}, press 1. Thank you.",
   "Good morning. This is an automated message from {biz} for the accounts payable team at {cust}. Invoice {inv}, for {amt}, falls due on {due}. Payment can be made using the link in our email, or press 1 to speak with our accounts team. Thank you."],
t:["Hello, this is an automated reminder from {biz} for the accounts payable team at {cust}. Invoice {inv}, for {amt}, is due today. If it is already on its way, thank you. To speak with someone at {biz}, press 1. Have a good day.",
   "Good morning. This is an automated message from {biz} for the accounts payable team at {cust}. Invoice {inv}, for {amt}, falls due today. Please arrange payment using the link in our email, or press 1 to speak with our accounts team. Thank you."],
o:["Hello, this is an automated reminder from {biz} for the accounts payable team at {cust}. Invoice {inv}, for {amt}, was due on {due}. If it has already been paid, thank you. If not, we have sent a payment link by email. To speak with someone at {biz}, press 1. Thank you, and have a good day.",
   "Good morning. This is an automated message from {biz} for the accounts payable team at {cust}, about invoice {inv} for {amt}, which was due on {due} and is now {n} past due. Please arrange payment using the link in our email, or press 1 to speak with our accounts team about any query. Thank you.",
   "Hello. This is an automated call from {biz} about invoice {inv} for {amt}, now {n} past due. Please pay by {payby} using the link in our email. If there is a problem with the invoice, press 1 now to speak with our accounts team. Thank you."]}},
es:{email:{
b:["La factura {inv} vence el {due}|Hola, equipo de {cust}:\n\nLes recordamos de parte de {biz} que la factura {inv} por {amt} vence el {due}. Pueden pagarla aquí cuando lo deseen: {link}.\n\nGracias,\nEquipo de cuentas de {biz}",
   "Próximo vencimiento: factura {inv}|Estimado equipo de cuentas por pagar de {cust}:\n\nLes recordamos que la factura {inv} por {amt} vence el {due}. Pueden realizar el pago mediante el enlace siguiente.\n\n{link}\n\nAtentamente,\nCuentas por cobrar de {biz}"],
t:["La factura {inv} vence hoy|Hola, equipo de {cust}:\n\nLes escribimos de {biz}: la factura {inv} por {amt} vence hoy. Si ya la pagaron, muchas gracias. Si no, pueden pagarla aquí: {link}.\n\nGracias,\nEquipo de cuentas de {biz}",
   "Vencimiento hoy: factura {inv}|Estimado equipo de cuentas por pagar de {cust}:\n\nLa factura {inv} por {amt} vence hoy. Les agradeceremos realizar el pago mediante el enlace siguiente, o informarnos si tienen alguna consulta.\n\n{link}\n\nAtentamente,\nCuentas por cobrar de {biz}"],
o:["Factura {inv} de {biz}|Hola, equipo de {cust}:\n\nLes escribimos de {biz} para recordarles que la factura {inv} por {amt} venció el {due}. Si ya la pagaron, muchas gracias y por favor ignoren este mensaje.\n\nSi no, pueden pagarla aquí: {link}. Si algo en la factura no es correcto, respondan a este correo y lo resolvemos.\n\nGracias,\nEquipo de cuentas de {biz}",
   "Recordatorio de pago: factura {inv}|Estimado equipo de cuentas por pagar de {cust}:\n\nSegún nuestros registros, la factura {inv} por {amt}, con vencimiento el {due}, está pendiente de pago. Tiene {n} de atraso.\n\nLes agradeceremos realizar el pago a la brevedad mediante el enlace siguiente, o informarnos si hay alguna consulta que debamos resolver.\n\n{link}\n\nAtentamente,\nCuentas por cobrar de {biz}",
   "Factura vencida: {inv}, {n} de atraso|Hola, equipo de {cust}:\n\nLa factura {inv} por {amt} tiene {n} de atraso. Venció el {due}.\n\nLes pedimos pagarla a más tardar el {payby} mediante el enlace siguiente, o responder hoy para acordar una fecha.\n\n{link}\n\nGracias,\nEquipo de cuentas de {biz}"]},
sms:{b:["{biz}: la factura {inv} por {amt} vence el {dues}. Pague cuando lo desee: {link}.","{biz}: le recordamos que la factura {inv} por {amt} vence el {dues}. Pague en {link}."],
t:["{biz}: la factura {inv} por {amt} vence hoy. Pague aquí: {link}. Si ya pagó, gracias.","{biz}: la factura {inv} por {amt} vence hoy. Pague en {link} o responda con su consulta."],
o:["{biz}: le recordamos que la factura {inv} por {amt} venció el {dues}. Pague aquí: {link}. Si ya pagó, gracias.","{biz}: la factura {inv} por {amt}, con vencimiento el {dues}, está pendiente. Pague en {link} o responda con su consulta.",
   "{biz}: la factura {inv} por {amt} tiene {n} de atraso. Pague a más tardar el {paybys} en {link} o responda hoy para acordar una fecha."]},
voice:{b:["Hola, esta es una llamada automática de cortesía de {biz} para el equipo de cuentas por pagar de {cust}. La factura {inv}, por {amt}, vence el {due}. El enlace de pago está en nuestro correo. Para hablar con alguien de {biz}, marque 1. Gracias.",
   "Buenos días. Este es un mensaje automático de {biz} para el equipo de cuentas por pagar de {cust}. La factura {inv}, por {amt}, vence el {due}. Puede pagar con el enlace de nuestro correo, o marcar 1 para hablar con nuestro equipo de cuentas. Gracias."],
t:["Hola, este es un recordatorio automático de {biz} para el equipo de cuentas por pagar de {cust}. La factura {inv}, por {amt}, vence hoy. Si ya se pagó, muchas gracias. Para hablar con alguien de {biz}, marque 1. Que tenga un buen día.",
   "Buenos días. Este es un mensaje automático de {biz} para el equipo de cuentas por pagar de {cust}. La factura {inv}, por {amt}, vence hoy. Le pedimos realizar el pago con el enlace de nuestro correo, o marcar 1 para hablar con nuestro equipo de cuentas. Gracias."],
o:["Hola, este es un recordatorio automático de {biz} para el equipo de cuentas por pagar de {cust}. La factura {inv}, por {amt}, venció el {due}. Si ya se pagó, muchas gracias. Si no, le enviamos un enlace de pago por correo electrónico. Para hablar con alguien de {biz}, marque 1. Gracias y que tenga un buen día.",
   "Buenos días. Este es un mensaje automático de {biz} para el equipo de cuentas por pagar de {cust}, sobre la factura {inv} por {amt}, que venció el {due} y tiene {n} de atraso. Le pedimos realizar el pago con el enlace de nuestro correo, o marcar 1 para hablar con nuestro equipo de cuentas sobre cualquier consulta. Gracias.",
   "Hola. Esta es una llamada automática de {biz} sobre la factura {inv} por {amt}, que tiene {n} de atraso. Le pedimos pagarla a más tardar el {payby} con el enlace de nuestro correo. Si hay algún problema con la factura, marque 1 para hablar con nuestro equipo de cuentas. Gracias."]}}};

/* GSM 03.38 basic set and extension table (extension characters count twice) */
const GSM="@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà",GSMX="^{}\\[~]|€";
function segs(s){let n=0,g=!0;for(const ch of s){if(GSM.includes(ch))n++;else if(GSMX.includes(ch))n+=2;else{g=!1;break}}
if(g)return{enc:"GSM-7",len:n,seg:n<=160?1:Math.ceil(n/153)};const u=[...s].reduce((a,c)=>a+(c.codePointAt(0)>65535?2:1),0);return{enc:"Unicode",len:u,seg:u<=70?1:Math.ceil(u/67)}}

/* cadence steps relative to the due date: day, channel, tone index, what */
const CAD=[[-3,"Email",0,"Courtesy note before the due date"],[3,"Email",0,"First reminder with the invoice attached"],[7,"Text message",0,"Short nudge with a payment link"],
[14,"Email",2,"Firm reminder, copy to the sales owner"],[21,"Voice",2,"Call script, inside quiet hours"],[30,"Hand-off",-1,"A person on your team takes the thread"]];

function fill(tpl,v){return tpl.replace(/\{(\w+)\}/g,(m,k)=>v[k]!=null?v[k]:m)}

function preview(root){
const F=id=>$("#mp-"+id,root),out=$("[data-mp-out]",root),meta=$("[data-mp-meta]",root),head=$("[data-mp-head]",root),sch=$("[data-mp-sch]",root),err=$("[data-mp-err]",root),tl=$("[data-mp-tone-l]",root),tone=F("tone");
const defs={};["biz","cust","inv","amt","due","today"].forEach(k=>defs[k]=F(k).value);let last="";
function val(){const v={biz:F("biz").value.trim(),cust:F("cust").value.trim(),inv:F("inv").value.trim(),amt:num(F("amt").value),due:D(F("due").value),today:D(F("today").value)};
const e=[];if(!v.biz)e.push("your business name");if(!v.cust)e.push("the customer");if(!v.inv)e.push("the invoice number");if(!(v.amt>0))e.push("an amount above zero");if(!v.due)e.push("a due date");if(!v.today)e.push("a sending date");return[v,e]}
function run(){const[v,e]=val(),t=+tone.value,ch=($("input[name=mp-ch]:checked",root)||{}).value||"email",lg=($("input[name=mp-lang]:checked",root)||{}).value||"en";
tl.textContent=TONE[t];tone.setAttribute("aria-valuetext",TONE[t]);head.textContent=(ch==="email"?"Email":ch==="sms"?"Text message":"Voice script")+" preview · "+(lg==="es"?"Spanish":"English");
if(e.length){err.hidden=!1;err.textContent="To draft the reminder, add "+e.join(", ")+".";out.innerHTML='<p class="dw-empty">The draft appears here once the invoice details are complete.</p>';meta.textContent="";sch.innerHTML="";last="";return}
err.hidden=!0;const late=Math.round((v.today-v.due)/864e5),st=late<0?"b":late===0?"t":"o",set=T[lg][ch][st],ti=Math.min(t,set.length-1);
const payby=wk(addD(v.today,5)),x={biz:esc(v.biz),cust:esc(v.cust),inv:esc(v.inv),amt:money(v.amt),due:fmt(v.due,lg,"l"),dues:fmt(v.due,lg,"s"),payby:fmt(payby,lg,"l"),paybys:fmt(payby,lg,"s"),n:dz(Math.abs(late),lg),link:LINK[lg]};
let msg=fill(set[ti],x),note=ti<t?(st==="b"?" Firm tone is used only after the due date, so the formal courtesy note is shown.":" Before the due date passes, the formal note is the firmest step."):"";
if(ch==="email"){const[s,b]=msg.split("|");out.innerHTML='<p class="dw-bub__s"><span>Subject</span> '+s+'</p><div class="dw-bub__b">'+b.split("\n\n").map(p=>"<p>"+p.replace(/\n/g,"<br>")+"</p>").join("")+"</div>";
const words=b.trim().split(/\s+/).length;meta.textContent=words+" words · "+(st==="o"?dz(late,"en")+" overdue":st==="t"?"due today":"due in "+dz(-late,"en"))+"."+note;last=s+"\n\n"+b}
else if(ch==="sms"){msg+=STOP[lg];out.innerHTML='<div class="dw-bub__b dw-bub__b--sms"><p>'+msg+"</p></div>";const g=segs(msg.replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"'));
meta.textContent=g.len+" characters · "+g.enc+" · "+g.seg+(g.seg===1?" segment":" segments")+"."+(g.enc==="Unicode"?" Accented letters outside the GSM set switch the message to Unicode.":"")+note;last=msg}
else{out.innerHTML='<div class="dw-bub__b dw-bub__b--voice"><p>'+msg+"</p></div>";const w=msg.split(/\s+/).length;meta.textContent=w+" words · about "+Math.round(w/150*60)+" seconds at 150 words a minute. Calls only inside quiet hours, with consent recorded."+note;last=msg}
last=last.replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"');
/* schedule: the remaining steps of the standard cadence from the sending date, weekends moved to Monday */
const rows=[];rows.push(["Today",fmt(v.today,"en","s"),(ch==="email"?"Email":ch==="sms"?"Text message":"Voice")+" · "+TONE[ti].toLowerCase(),"This message","next"]);
CAD.forEach(c=>{const d=wk(addD(v.due,c[0]));if(d<=v.today)return;rows.push(["Day "+(c[0]>0?"+":"")+c[0],fmt(d,"en","s"),c[2]<0?c[1]:c[1]+" · "+TONE[Math.max(c[2],t>c[2]?t:c[2])].toLowerCase(),c[3],c[2]<0?"person":"wait"])});
sch.innerHTML=rows.slice(0,5).map(r=>'<li class="dw-cd dw-cd--'+r[4]+'"><span class="dw-cd__d">'+r[0]+"<small>"+r[1]+'</small></span><span class="dw-cd__n" aria-hidden="true"></span><div><b>'+r[2]+"</b><small>"+r[3]+'</small></div><span class="dw-st">'+(r[4]==="next"?"Now":r[4]==="person"?"To a person":"Scheduled")+"</span></li>").join("")}
$$("input",root).forEach(i=>i.addEventListener(i.type==="radio"||i.type==="range"?"change":"input",run));tone.addEventListener("input",run);
$("[data-mp-copy]",root).addEventListener("click",()=>{if(!last){meta.textContent="Complete the invoice details first.";return}
const ok=()=>{meta.textContent="Copied to the clipboard."},no=()=>{meta.textContent="Copy is blocked in this browser. Select the text in the preview to copy it."};
try{navigator.clipboard.writeText(last).then(ok,no)}catch(_){no()}});
$("[data-mp-reset]",root).addEventListener("click",()=>{Object.keys(defs).forEach(k=>F(k).value=defs[k]);tone.value=0;$("#mp-ch-email",root).checked=!0;$("#mp-lang-en",root).checked=!0;run();F("biz").focus()});
run()}

/* ---------- home workspace: one invoice, five steps */
const FIRST=["<p>Hello, a quick note from Seller S. Invoice INV-20418 for $2,480.00 was due on Friday, November 13. If it is already on its way, thank you. If not, the invoice and a payment link are attached.</p>",
"<p>Our records show invoice INV-20418 for $2,480.00, due on November 13, as unpaid. Please arrange payment using the attached link, or let us know of any query.</p>",
"<p>Invoice INV-20418 for $2,480.00 is now 3 days past due. Please pay by Wednesday, November 18, or reply today so we can agree a date.</p>"];
function play(root){const out=$("[data-play-out]",root),next=$("[data-play-next]",root),rep=$("[data-play-replay]",root),btns=$$("[data-step]",root);let s=0;
const M=t=>[['sys','','Fri Nov 13','Invoice <b>INV-20418</b> for <b>$2,480.00</b> to Customer A passes its due date.',['Overdue','warn']],
['out','Email · '+TONE[t].toLowerCase(),'Mon Nov 16 · 10:02',FIRST[t],null],
['in','Text message reply','Wed Nov 18 · 14:37','<p>Sorry, this slipped. We can pay it Friday.</p>',null],
['sys','','Wed Nov 18 · 14:37','Read as a <b>promise to pay</b> on Fri Nov 20. Reminders paused.',['Promise logged','ok']],
['out','Text message · friendly','Fri Nov 20 · 09:00','<p>Morning, Seller S here. As promised, here is the link for INV-20418 ($2,480.00). Thank you. Reply STOP to opt out.</p>',null],
['sys','','Fri Nov 20 · 11:41','<b>$2,480.00</b> received by payment link. Thread closed.',['Paid','paid']]];
const upto=[1,2,3,4,6];
function li(m,isNew){const tg=m[4]?'<span class="dw-tg dw-tg--'+m[4][1]+'">'+m[4][0]+"</span>":"";const c=isNew?" is-new":"";
return m[0]==="sys"?'<li class="dw-m dw-m--sys'+c+'"><span class="dw-m__t">'+m[2]+"</span><p>"+m[3]+"</p>"+tg+"</li>":'<li class="dw-m dw-m--'+m[0]+c+'"><p class="dw-m__h"><span>'+m[1]+"</span><span>"+m[2]+'</span></p><div class="dw-m__b">'+m[3]+"</div>"+tg+"</li>"}
function draw(anim){const t=+(($("input[name=ws-tone]:checked",root)||{}).value||0),all=M(t),n=upto[s],prev=anim?upto[Math.max(0,s-1)]:n;
out.innerHTML=all.slice(0,n).map((m,i)=>li(m,anim&&i>=prev)).join("");btns.forEach((b,i)=>{if(i===s)b.setAttribute("aria-current","step");else b.removeAttribute("aria-current");b.classList.toggle("is-done",i<s)});
next.textContent=s>=btns.length-1?"Start again":"Next step"}
let tm=0;const stop=()=>{clearTimeout(tm);tm=0};
next.addEventListener("click",()=>{stop();if(s<btns.length-1){s++;draw(1)}else{s=0;draw(0)}});
/* Replay plays the thread from the start, one step at a time (all at once with reduced motion) */
rep.addEventListener("click",()=>{stop();if(RM){s=btns.length-1;draw(0);return}s=0;draw(0);const go=()=>{if(s<btns.length-1){s++;draw(1);tm=setTimeout(go,900)}else tm=0};tm=setTimeout(go,250)});
btns.forEach((b,i)=>b.addEventListener("click",()=>{stop();const a=i>s;s=i;draw(a)}));
$$("input[name=ws-tone]",root).forEach(r=>r.addEventListener("change",()=>{if(s<1){s=1;draw(1)}else draw(0)}));draw(0)}

/* ---------- DSO calculator */
function dso(root){const ar=$("#dso-ar",root),sa=$("#dso-s",root),dy=$("#dso-d",root),o=$("[data-dso-out]",root),m=$("[data-dso-msg]",root);
function run(){const a=num(ar.value),s=num(sa.value),d=num(dy.value);[ar,sa,dy].forEach(i=>i.removeAttribute("aria-invalid"));
if(!(a>=0)){ar.setAttribute("aria-invalid","true");o.textContent="-";m.textContent="Enter accounts receivable as a number, zero or more.";return}
if(!(s>0)){sa.setAttribute("aria-invalid","true");o.textContent="-";m.textContent="Enter credit sales above zero for the same period.";return}
if(!(d>0&&d<=366)){dy.setAttribute("aria-invalid","true");o.textContent="-";m.textContent="Enter the number of days in the period, from 1 to 366.";return}
const v=a/s*d;o.textContent=v.toFixed(1);m.textContent="Receivables equal about "+Math.round(v)+" days of credit sales."+(v>d?" That is longer than the period itself, so check that the sales figure covers the same period.":"")}
[ar,sa,dy].forEach(i=>i.addEventListener("input",run));run()}

/* ---------- tabs */
function tabs(root){const t=$$("[role=tab]",root);function pick(i,f){t.forEach((b,j)=>{const on=j===i;b.setAttribute("aria-selected",on);b.tabIndex=on?0:-1;const p=$("#"+b.getAttribute("aria-controls"));p.hidden=!on;if(on)$$("[data-rv]",p).forEach(x=>x.classList.add("is-in"));if(on&&f)b.focus()})}
t.forEach((b,i)=>{b.addEventListener("click",()=>pick(i));b.addEventListener("keydown",e=>{if(e.key==="ArrowRight"||e.key==="ArrowLeft"){e.preventDefault();pick((i+(e.key==="ArrowRight"?1:t.length-1))%t.length,1)}})})}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-dw=preview]").forEach(preview);$$("[data-dw=play]").forEach(play);$$("[data-dw=dso]").forEach(dso);$$("[data-dw=tabs]").forEach(tabs)}
