/* Growervoice page tools: crop problem check, sample call player and the Field Desk queue filters.
   Everything runs in the browser with sample data; nothing is sent anywhere. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const E=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

/* ------------------------------------------------------------ crop problem check */
const CZ={
 eb:{n:"Early blight",w:{low:1.4,up:.5,all:.8},x:{warmwet:1.3,coolwet:.9,dry:.7},s:[["Check","Look at ten plants across the row and count how many have spots above the lower third."],["Do first","Pick off the worst lower leaves and bag them. Water at the base in the morning and mulch to stop soil splashing onto the leaves."],["If you spray","Use only a product whose label lists tomato and early blight in your state, at the label rate and interval, and keep the pre-harvest interval."]]},
 sep:{n:"Septoria leaf spot",w:{low:1.4,up:.5,all:.8},x:{warmwet:1.2,coolwet:1.1,dry:.6},s:[["Check","Look for many small round spots with dark edges and pale centres, starting on the lowest leaves."],["Do first","Remove spotted lower leaves, avoid overhead watering and stay out of the rows while plants are wet."],["If you spray","Use only a product whose label lists tomato and Septoria leaf spot, at the label rate and interval."]]},
 lb:{n:"Late blight",w:{low:.9,up:1.3,all:1.2},x:{warmwet:.7,coolwet:1.6,dry:.4},e:"Treat as urgent. Late blight spreads fast in cool, wet weather and can move to nearby farms, so this case goes to an agronomist before any spray advice.",s:[["Check","In the morning, look under the leaves for white, fuzzy growth at the edge of the patches, and for firm brown patches on the fruit."],["Do first","Bag and remove infected plants. Do not compost them, and clean tools and boots before you walk other rows."],["Tell someone","An agronomist reviews this case, and your Extension office should hear about it so neighbours can be warned."]]},
 bs:{n:"Bacterial spot",w:{low:1,up:1,all:1.1},x:{warmwet:1.3,coolwet:.9,dry:.6},s:[["Check","Look for small dark spots, sometimes with a yellow edge, on leaves and on the fruit."],["Do first","Stay out of the rows while plants are wet and remove the worst leaves."],["Ask first","Fungicides made for fungi do not control bacteria. Ask an agronomist which labelled options fit your crop and state."]]},
 nclb:{n:"Northern corn leaf blight",w:{low:1.3,up:.7,all:.9},x:{warmwet:1,coolwet:1.3,dry:.6},s:[["Check","Measure a few lesions: long, cigar-shaped and tan points to this disease. Note how far up the plant they reach compared with the ear leaf."],["Decide with a person","Whether a fungicide pays depends on the hybrid rating, the growth stage, the forecast and the grain price."],["If you spray","Use only a product labelled for northern corn leaf blight in corn, at the label rate and timing."]]},
 gls:{n:"Gray leaf spot",w:{low:1.3,up:.7,all:.9},x:{warmwet:1.5,coolwet:.8,dry:.5},s:[["Check","Lesions held between the veins, with straight edges, point to gray leaf spot. Walk the field in a W and look at 20 plants in five places."],["Decide with a person","Warm, humid weather and corn residue on the surface raise the risk. Whether to spray depends on the hybrid, the stage and the forecast."],["If you spray","Use only a product labelled for gray leaf spot in corn, at the label rate and timing, within the pre-harvest interval."]]},
 gw:{n:"Goss's wilt",w:{low:.9,up:1,all:1.1},x:{warmwet:1,coolwet:1,dry:.9},e:"Goss's wilt is caused by bacteria, so fungicides do not control it. A lab test confirms it, and an agronomist can help you send a sample.",s:[["Check","Look for dark, freckle-like spots inside the lesions and a shiny, dried film on the leaf."],["Do first","Note any recent hail or wind damage, which lets the bacteria in."],["Next season","Choose a hybrid with a better rating and rotate away from corn."]]},
 rust:{n:"Common rust",w:{low:.9,up:1.1,all:1.1},x:{warmwet:.9,coolwet:1.3,dry:.7},s:[["Check","Rub a pustule: rust-brown powder on both sides of the leaf points to common rust."],["Do first","Common rust often does not need a spray on field corn. Check how many leaves above the ear are covered."],["Decide with a person","If pustules cover the upper leaves early in the season, ask an agronomist whether a labelled fungicide would pay."]]},
 ndef:{n:"Nitrogen deficiency",w:{low:1.5,up:.4,all:.8},x:{warmwet:1.2,coolwet:1.1,dry:1},s:[["Check","Yellowing in a V from the tip along the midrib of the lower leaves points to nitrogen."],["Do first","Compare with the nitrogen you applied and the rain since. Heavy rain can wash nitrogen below the roots."],["Confirm","A soil nitrate test or a tissue test confirms it before you decide on more nitrogen with your agronomist."]]},
 kdef:{n:"Potassium deficiency",w:{low:1.4,up:.4,all:.8},x:{warmwet:.8,coolwet:.8,dry:1.4},s:[["Check","Yellow or brown edges on the lower leaves, with a green midrib, point to potassium."],["Do first","Dry soil makes it harder for roots to take up potassium, so look at soil moisture first."],["Confirm","A soil test shows whether potassium is short before next season's plan."]]},
 sdef:{n:"Sulfur deficiency",w:{low:.4,up:1.8,all:1},x:{warmwet:1,coolwet:1.2,dry:1},s:[["Check","Pale yellow stripes between the veins on the newest leaves point to sulfur."],["Do first","It often shows early in the season in cool, wet soils and may fade as soils warm."],["Confirm","A tissue test confirms it; plan sulfur with your agronomist if it comes back low."]]}};
const PH={t1:{eb:.62,sep:.22,lb:.16},t2:{sep:.6,eb:.25,bs:.15},t3:{lb:.66,eb:.18,bs:.16},c1:{nclb:.62,gls:.26,gw:.12},c2:{gls:.6,nclb:.25,rust:.15},c3:{ndef:.6,kdef:.25,sdef:.15}};
const lvl=p=>p>=55?"High":p>=30?"Medium":"Low";
const WH={low:"lower, older leaves",up:"upper, newer leaves",all:"all over the plant"},WX={warmwet:"warm and wet",coolwet:"cool and wet",dry:"mostly dry"};
function checker(root){
 const pics=$$("[data-photo]",root),list=$("[data-ck-list]",root),empty=$("[data-ck-empty]",root),hint=$("[data-ck-hint]",root),
  next=$("[data-ck-next]",root),steps=$("[data-ck-steps]",root),esc=$("[data-ck-esc]",root),file=$("[data-ck-file]",root),prev=$("[data-ck-prev]",root);
 const st={photo:null};
 const val=n=>{const r=$('input[name="'+n+'"]:checked',root);return r?r.value:null};
 function render(){
  pics.forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.photo===st.photo)));
  const w=val("ck-where"),x=val("ck-wx");
  if(!st.photo){list.innerHTML="";next.hidden=!0;hint.hidden=!0;empty.hidden=!1;
   const parts=[w&&("started on the "+WH[w]),x&&("weather "+WX[x])].filter(Boolean);
   empty.textContent=parts.length?"Noted: "+parts.join(", ")+". Now pick a sample photo to see likely causes.":"Pick a sample photo to see likely causes.";return}
  empty.hidden=!0;hint.hidden=!!(w&&x);
  const sc=Object.entries(PH[st.photo]).map(([k,b])=>{const c=CZ[k];return[k,b*(w?c.w[w]:1)*(x?c.x[x]:1)]});
  const tot=sc.reduce((a,[,v])=>a+v,0);let rows=sc.map(([k,v])=>[k,Math.round(v/tot*100)]).sort((a,b)=>b[1]-a[1]);
  const diff=100-rows.reduce((a,[,v])=>a+v,0);rows[0][1]+=diff;
  list.innerHTML=rows.map(([k,p],i)=>'<li class="gv-cz__i'+(i?'':' is-top')+'"><div class="gv-cz__r"><b>'+E(CZ[k].n)+'</b><span class="gv-cz__l gv-cz__l--'+lvl(p).toLowerCase()+'">'+lvl(p)+' · '+p+'%</span></div><div class="gv-cz__b" aria-hidden="true"><i style="width:'+p+'%"></i></div></li>').join("");
  const top=CZ[rows[0][0]];next.hidden=!1;steps.innerHTML=top.s.map(([a,b])=>'<li><b>'+E(a)+'</b><span>'+E(b)+'</span></li>').join("");
  const low=rows[0][1]<55;esc.hidden=!(top.e||low);esc.textContent=top.e||(low?"The top cause is below high confidence, so on a real call this case would also go to an agronomist.":"")}
 pics.forEach(b=>b.addEventListener("click",()=>{st.photo=st.photo===b.dataset.photo?null:b.dataset.photo;render()}));
 $$('input[type="radio"]',root).forEach(r=>r.addEventListener("change",render));
 pics.forEach(b=>b.addEventListener("keydown",e=>{const i=pics.indexOf(b);let j=-1;if(e.key==="ArrowRight"||e.key==="ArrowDown")j=(i+1)%pics.length;else if(e.key==="ArrowLeft"||e.key==="ArrowUp")j=(i-1+pics.length)%pics.length;if(j>=0){e.preventDefault();pics[j].focus()}}));
 const reset=$("[data-ck-reset]",root);reset&&reset.addEventListener("click",()=>{st.photo=null;$$('input[type="radio"]',root).forEach(r=>r.checked=!1);if(file){file.value="";prev.hidden=!0;prev.removeAttribute("src")}render()});
 file&&file.addEventListener("change",()=>{const f=file.files&&file.files[0];if(!f){prev.hidden=!0;return}if(!/^image\//.test(f.type)){prev.hidden=!0;$("[data-ck-file-note]",root).textContent="That file is not an image. Choose a photo, or pick the closest sample.";return}
  prev.src=URL.createObjectURL(f);prev.hidden=!1;$("[data-ck-file-note]",root).textContent="Your photo stays on this device and is not analysed in this check. Pick the sample that looks most like it."});
 render()}

/* ------------------------------------------------------------ sample call */
const mmss=s=>Math.floor(s/60)+":"+String(Math.floor(s%60)).padStart(2,"0");
function call(root){
 const len=+root.dataset.len,play=$("[data-call-play]",root),lbl=$("[data-call-lbl]",root),pos=$("[data-call-pos]",root),tm=$("[data-call-time]",root),cap=$("[data-call-cap]",root),
  lines=$$("[data-t]",root),bars=$$("[data-call-wave] i",root),langSel=$("[data-call-lang]",root),voice=$("[data-call-voice]",root),vnote=$("[data-call-voice-note]",root);
 let t=0,timer=null,cur=-1,lang="en";const SS="speechSynthesis"in window?window.speechSynthesis:null;
 function say(i){if(!voice.checked||!SS)return;try{const vs=SS.getVoices(),code=lang==="es"?"es":"en",v=vs.find(x=>x.lang&&x.lang.toLowerCase().startsWith(code));
  if(!v){vnote.hidden=!1;vnote.textContent="This browser has no voice for that language, so the transcript plays without sound.";return}SS.cancel();const u=new SpeechSynthesisUtterance($("p",lines[i]).textContent);u.voice=v;u.lang=v.lang;SS.speak(u)}catch(e){vnote.hidden=!1}}
 function show(){pos.value=Math.floor(t);tm.textContent=mmss(t);pos.setAttribute("aria-valuetext",mmss(t)+" of "+mmss(len));
  let i=-1;lines.forEach((l,k)=>{if(+l.dataset.t<=t)i=k});const n=Math.round(t/len*bars.length);bars.forEach((b,k)=>b.classList.toggle("is-on",k<n));
  if(i!==cur){lines.forEach((l,k)=>{l.classList.toggle("is-on",k===i);l.classList.toggle("is-past",k<i)});cur=i;
   if(i>=0){const l=lines[i];cap.textContent=$("b",l).textContent+": "+$("p",l).textContent;if(timer)say(i)}else cap.textContent="Press Play to follow the call line by line."}}
 function stop(end){clearInterval(timer);timer=null;play.setAttribute("aria-pressed","false");lbl.textContent=end?"Play again":"Play";SS&&SS.cancel()}
 function start(){if(t>=len){t=0;cur=-1}play.setAttribute("aria-pressed","true");lbl.textContent="Pause";let last=performance.now();
  timer=setInterval(()=>{const n=performance.now();t=Math.min(len,t+(n-last)/1000);last=n;show();if(t>=len)stop(!0)},200);if(cur>=0)say(cur)}
 play.addEventListener("click",()=>timer?stop(!1):start());
 pos.addEventListener("input",()=>{t=+pos.value;cur=-2;show()});
 $$("[data-seek]",root).forEach(b=>b.addEventListener("click",()=>{t=+b.dataset.seek;cur=-2;show();if(!timer)start();else say(cur)}));
 langSel.addEventListener("change",()=>{lang=langSel.value;$$("[data-en]",root).forEach(el=>el.textContent=el.dataset[lang]);root.querySelector(".gv-tr").setAttribute("lang",lang==="es"?"es":"en");cur=-2;show()});
 voice.addEventListener("change",()=>{if(!voice.checked){SS&&SS.cancel();vnote.hidden=!1;vnote.textContent="Device voice off. The transcript plays without sound.";return}
  const code=lang==="es"?"es":"en",ok=SS&&SS.getVoices().some(x=>x.lang&&x.lang.toLowerCase().startsWith(code));vnote.hidden=!1;
  vnote.textContent=ok?"Device voice on. Lines are read aloud by your browser as the call plays.":"This browser has no voice for that language, so the transcript plays without sound.";if(ok&&timer&&cur>=0)say(cur)});
 show()}

/* ------------------------------------------------------------ field desk queue */
function queue(root){
 const rows=$$("tbody tr",root),cnt=$("[data-q-count]",root),empty=$("[data-q-empty]",root),sels=$$("[data-q]",root);
 const apply=()=>{const f={};sels.forEach(x=>f[x.dataset.q]=x.value);let n=0;rows.forEach(r=>{const ok=(f.crop==="all"||r.dataset.crop===f.crop)&&(f.st==="all"||r.dataset.st===f.st);r.hidden=!ok;if(ok)n++});cnt.textContent=n;empty.hidden=n>0};
 sels.forEach(x=>x.addEventListener("change",apply));apply()}

export function boot(){
 $$('[data-gv="checker"]').forEach(checker);
 $$('[data-gv="call"]').forEach(call);
 $$('[data-gv="queue"]').forEach(queue);
 $$(".mv-pscroll").forEach(el=>{const f=()=>{const s=el.scrollWidth>el.clientWidth+2;s?el.setAttribute("tabindex","0"):el.removeAttribute("tabindex")};f();addEventListener("resize",f)});
}
