/* Mrvloop hero: a farm block on dark soil seen from a slow, high camera. Seven plots carry furrow ridges, a satellite
   hangs above with a dashed footprint on the field, and a ledger stack sits at the field edge. One teal ribbon loops
   from the field up to the satellite, down to the ledger and back. Every 10 seconds a leaf-green pulse rides the loop:
   at the field a geotag pin rises, at the satellite the footprint brightens, at the ledger a new entry settles.
   20 second dolly, no shake. Scrolling holds the settled state. Synthetic. */
export default function({THREE:T,scene,camera,color,small,pointer,helpers}){
const{lerp,clamp,ease}=helpers;
const soil=new T.Color(color("--mr-soil","#3b2f2f")),sand=new T.Color(color("--mr-sand","#f4ede1")),teal=new T.Color(color("--mr-teal","#1f8a8a")),
 tealL=new T.Color(color("--mr-teal-l","#5fc4be")),leaf=new T.Color(color("--mr-leaf","#6baf4d")),clay=new T.Color(color("--mr-clay","#e39a6b"));
scene.background=soil.clone();scene.fog=new T.Fog(soil.getHex(),9,20);
const root=new T.Group;root.position.x=.2;scene.add(root);const geos=[],mats=[];const G=g=>(geos.push(g),g),M=m=>(mats.push(m),m);
root.add(new T.AmbientLight(0xf4ede1,.9));
const key=new T.DirectionalLight(0xffe7c8,1.25);key.position.set(-4,7,5);root.add(key);
const rim=new T.DirectionalLight(tealL.getHex(),.55);rim.position.set(5,2,-5);root.add(rim);
/* the field block: plots on the ground plane with furrow ridges */
const field=new T.Group;field.position.set(-1.1,0,.2);root.add(field);
const PL=[[-1.2,-.9,1.5,1.0,-.14],[.35,-1.0,1.2,1.1,-.07],[-1.35,.35,1.25,1.2,-.17],[.2,.3,1.55,.95,-.1],[-.75,1.45,1.7,.9,-.2],[1.0,1.35,1.05,1.1,-.03],[1.55,-.2,.85,1.5,.1]];
if(small)PL.length=5;
const plotM=M(new T.MeshStandardMaterial({color:soil.clone().lerp(sand,.16),roughness:.95}));
const ridgeM=M(new T.MeshStandardMaterial({color:0xffffff,roughness:.85}));const rSand=soil.clone().lerp(sand,.42),rLeaf=soil.clone().lerp(leaf,.6);
const ridgeG=G(new T.BoxGeometry(1,.035,.045));let nR=0;PL.forEach(p=>nR+=Math.max(5,Math.round(p[3]/.11)));
const ridges=new T.InstancedMesh(ridgeG,ridgeM,nR),o=new T.Object3D;let ri=0;const plotG=G(new T.BoxGeometry(1,.04,1));
PL.forEach(([x,z,w,d,a],pi)=>{const g=new T.Group;g.position.set(x,0,z);g.rotation.y=a;field.add(g);const b=new T.Mesh(plotG,plotM);b.scale.set(w,1,d);b.position.y=-.02;g.add(b);
 const n=Math.max(5,Math.round(d/.11));for(let i=0;i<n;i++){const lz=-d/2+(i+.5)*d/n;o.position.set(x+Math.cos(-a)*0-Math.sin(-a)*lz,.02,z+Math.sin(-a)*0+Math.cos(-a)*lz);
  o.rotation.set(0,a,0);o.scale.set(w*.9,1,1);o.updateMatrix();ridges.setColorAt(ri,(pi===1||pi===2||pi===5)?rLeaf:rSand);ridges.setMatrixAt(ri++,o.matrix)}});
field.add(ridges);
/* geotag pins */
const pinG=G(new T.CylinderGeometry(.012,.012,.42,8)),headG=G(new T.SphereGeometry(.07,16,12));
const pins=[[-1.1,-.9,leaf],[.3,.35,leaf],[1.0,1.3,clay]].map(([x,z,c])=>{const g=new T.Group;g.position.set(x,0,z);
 const m=M(new T.MeshStandardMaterial({color:c.clone(),emissive:c.clone(),emissiveIntensity:.35,roughness:.5}));const s=new T.Mesh(pinG,m);s.position.y=.21;const h=new T.Mesh(headG,m);h.position.y=.44;g.add(s,h);field.add(g);return g});
/* satellite and footprint */
const sat=new T.Group;sat.position.set(1.6,2.25,-1.3);root.add(sat);
const satM=M(new T.MeshStandardMaterial({color:sand.clone(),roughness:.4,metalness:.2})),panM=M(new T.MeshStandardMaterial({color:teal.clone().lerp(soil,.35),roughness:.3,metalness:.4,emissive:teal.clone(),emissiveIntensity:.12}));
sat.add(new T.Mesh(G(new T.BoxGeometry(.36,.3,.3)),satM));[-1,1].forEach(s=>{const p=new T.Mesh(G(new T.BoxGeometry(.62,.025,.3)),panM);p.position.x=s*.52;p.rotation.x=.5;sat.add(p)});
const FP=[-1.1+.3,.02,.2+.35],fr=.55,fpG=G(new T.BufferGeometry),RP=64,fa=new Float32Array((RP+1)*3);
for(let i=0;i<=RP;i++){const t=i/RP*Math.PI*2;fa[i*3]=FP[0]+Math.cos(t)*fr;fa[i*3+1]=.03;fa[i*3+2]=FP[2]+Math.sin(t)*fr*.75}fpG.setAttribute("position",new T.BufferAttribute(fa,3));
const fpM=M(new T.LineBasicMaterial({color:tealL.clone(),transparent:!0,opacity:.5}));root.add(new T.Line(fpG,fpM));
const cone=G(new T.BufferGeometry),ca=new Float32Array(4*2*3);[[fr,0],[-fr,0],[0,fr*.75],[0,-fr*.75]].forEach(([dx,dz],k)=>{ca.set([sat.position.x,sat.position.y-.15,sat.position.z,FP[0]+dx,.03,FP[2]+dz],k*6)});
cone.setAttribute("position",new T.BufferAttribute(ca,3));const coneM=M(new T.LineBasicMaterial({color:tealL.clone().lerp(soil,.3),transparent:!0,opacity:.22}));root.add(new T.LineSegments(cone,coneM));
/* ledger stack */
const led=new T.Group;led.position.set(2.55,0,1.25);root.add(led);const slabG=G(new T.BoxGeometry(.9,.07,.6));
const slabM=M(new T.MeshStandardMaterial({color:sand.clone().lerp(soil,.12),roughness:.7})),topM=M(new T.MeshStandardMaterial({color:sand.clone(),roughness:.6,emissive:teal.clone(),emissiveIntensity:.08}));
for(let i=0;i<4;i++){const s=new T.Mesh(slabG,slabM);s.position.y=.04+i*.09;s.rotation.y=(i%2?.05:-.04);led.add(s)}
const fresh=new T.Mesh(slabG,topM);led.add(fresh);
/* the loop */
const curve=new T.CatmullRomCurve3([new T.Vector3(-.8,.12,.55),new T.Vector3(-.2,1.2,-.6),new T.Vector3(1.45,2.05,-1.25),new T.Vector3(2.9,1.4,-.2),new T.Vector3(2.6,.62,1.25),new T.Vector3(1.1,.3,1.75),new T.Vector3(-.3,.12,1.3)],!0,"catmullrom",.5);
const tubeG=G(new T.TubeGeometry(curve,small?160:260,.018,8,!0));const tubeM=M(new T.MeshStandardMaterial({color:teal.clone(),emissive:teal.clone(),emissiveIntensity:.55,roughness:.4}));
const tube=new T.Mesh(tubeG,tubeM);root.add(tube);const IDX=tubeG.index?tubeG.index.count:tubeG.attributes.position.count;
const pulse=new T.Mesh(G(new T.SphereGeometry(.06,16,12)),M(new T.MeshBasicMaterial({color:leaf.clone()})));root.add(pulse);
const halo=new T.Mesh(G(new T.SphereGeometry(.16,16,12)),M(new T.MeshBasicMaterial({color:leaf.clone(),transparent:!0,opacity:.25,depthWrite:!1,blending:T.AdditiveBlending})));root.add(halo);
const look=new T.Vector3(.75,.55,.15),C0=new T.Vector3(.4,3.4,6.6);camera.fov=38;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const bump=(u,c,w)=>{let d=Math.abs(u-c);d=Math.min(d,1-d);return clamp(1-d/w)};
function frame(t,dt,p){
 t=Number.isFinite(t)?t:0;p=Number.isFinite(p)?p:0;const hold=clamp((p-.35)/.3),draw=ease(clamp(t/2.2)),u0=(((t%10)+10)%10)/10,u=clamp(hold>0?lerp(u0,.995,ease(hold)):u0,0,.999);
 tubeG.setDrawRange(0,Math.floor(IDX*Math.max(draw,hold))/3*3);
 const q=curve.getPointAt(u);pulse.position.copy(q);halo.position.copy(q);const on=draw>.98?1:0;pulse.visible=halo.visible=on>0;halo.material.opacity=.18+.18*Math.sin(t*6)**2;
 const bf=bump(u,0,.08),bs=bump(u,.33,.08),bl=bump(u,.6,.1);
 pins.forEach((g,i)=>{const k=i===0?Math.max(bf,hold):1;g.scale.set(1,.6+.4*ease(k)+.12*bf,1)});
 fpM.opacity=.5+.45*bs;coneM.opacity=.2+.4*bs;panM.emissiveIntensity=.12+.5*bs;
 const lk=hold>0?1:ease(clamp((u-.6)/.12));fresh.position.y=.04+4*.09+(1-lk)*.5;fresh.material.emissiveIntensity=.08+.5*bl;
 sat.position.y=2.25+Math.sin(t*.6)*.05;sat.rotation.y=Math.sin(t*.25)*.2;
 const dolly=Math.sin(t/20*Math.PI*2);camera.position.set(C0.x+dolly*.35+pointer.x*.18,C0.y-pointer.y*.12,C0.z-dolly*.25);camera.lookAt(look);
 tubeM.emissiveIntensity=.45+.25*Math.max(bf,bs,bl)}
return{frame,resize:(w,h)=>{const a=w/h,k=a<.8?0:a<1.3?1:2;C0.set([0.6,.5,.4][k],[4.6,4.0,3.4][k],[10.5,8.4,6.6][k]);root.scale.setScalar([.82,.9,.93][k])},
 dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose())}}}
