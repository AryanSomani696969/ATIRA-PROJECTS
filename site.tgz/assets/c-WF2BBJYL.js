/* Radprism hero: a dim reading room with a floating worklist of study tiles (a light box that re-sorts itself).
   14 s loop, three beats: 0-5 s tiles and X-ray / CT slices drift in from the edges; 5-10 s an amber halo marks
   one suspected critical study and lifts it to the top while the others step down; 10-14 s the confirm turns the
   halo into a calm cyan check and the column fades so the loop closes cleanly. Scroll tilts the column slightly. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(31);
const bg=new T.Color(colors.bg),ink=new T.Color(colors.ink),cyan=new T.Color(color("--rp-cyan","#19b5c9")),amber=new T.Color(color("--rp-amber","#f2a93b"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),7,17);
const root=new T.Group;scene.add(root);
root.add(new T.AmbientLight(0xb8c4d0,.7));
const key=new T.DirectionalLight(0xffeedd,.9);key.position.set(-4,5,6);root.add(key);
const rim=new T.DirectionalLight(cyan.getHex(),.45);rim.position.set(5,1,-5);root.add(rim);
const geos=[],mats=[];const G=g=>(geos.push(g),g),M=m=>(mats.push(m),m);
const lineMat=(c,o)=>M(new T.LineBasicMaterial({color:c,transparent:!0,opacity:o}));
const loop=(pts)=>{const a=[];for(let i=0;i<pts.length;i++){const p=pts[i],q=pts[(i+1)%pts.length];a.push(p[0],p[1],0,q[0],q[1],0)}return a};
const rrect=(w,h,r,n=5)=>{const p=[],hw=w/2,hh=h/2,c=[[hw-r,hh-r,0],[-hw+r,hh-r,Math.PI/2],[-hw+r,-hh+r,Math.PI],[hw-r,-hh+r,Math.PI*1.5]];c.forEach(([x,y,a0])=>{for(let i=0;i<=n;i++){const a=a0+i/n*Math.PI/2;p.push([x+Math.cos(a)*r,y+Math.sin(a)*r])}});return p};
const segGeo=a=>{const g=G(new T.BufferGeometry);g.setAttribute("position",new T.Float32BufferAttribute(a,3));return g};
/* one tile: glass board, edge, thumbnail slice and two text bars */
const TW=2.3,TH=.42,N=6,GAP=.56;
const boardGeo=G(new T.BoxGeometry(TW,TH,.03)),barGeo=G(new T.PlaneGeometry(1,.045));
const ctGeo=(()=>{const a=[];for(const[rx,ry]of[[.13,.15],[.09,.11]]){const p=[];for(let i=0;i<24;i++){const t=i/24*Math.PI*2;p.push([Math.cos(t)*rx,Math.sin(t)*ry])}a.push(...loop(p))}a.push(0,-.11,0,0,.11,0);return segGeo(a)})();
const xrGeo=(()=>{const a=loop([[-.14,-.15],[.14,-.15],[.14,.15],[-.14,.15]]);for(let k=0;k<4;k++){const y=.09-k*.06;a.push(-.11,y,0,-.03,y+.025,0,.11,y,0,.03,y+.025,0)}a.push(0,-.13,0,0,.13,0);return segGeo(a)})();
const edgeGeo=segGeo(loop(rrect(TW,TH,.06)));
const tiles=[];
for(let i=0;i<N;i++){const g=new T.Group;
 const bm=M(new T.MeshStandardMaterial({color:ink,transparent:!0,opacity:.1,roughness:.35,metalness:.1,emissive:ink,emissiveIntensity:.04,depthWrite:!1}));g.add(new T.Mesh(boardGeo,bm));
 const em=lineMat(ink,.5);g.add(new T.LineSegments(edgeGeo,em));
 const tm=lineMat(ink,.75);const th=new T.LineSegments(i%3===0?ctGeo:xrGeo,tm);th.position.set(-TW/2+.28,0,.02);g.add(th);
 const b1m=M(new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:.55})),b2m=M(new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:.28}));
 const b1=new T.Mesh(barGeo,b1m);b1.scale.x=.8+R()*.5;b1.position.set(-TW/2+.55+b1.scale.x/2,.07,.02);g.add(b1);
 const b2=new T.Mesh(barGeo,b2m);b2.scale.x=.5+R()*.4;b2.position.set(-TW/2+.55+b2.scale.x/2,-.06,.02);g.add(b2);
 const cm=M(new T.MeshBasicMaterial({color:ink,transparent:!0,opacity:.3}));const chip=new T.Mesh(G(new T.PlaneGeometry(.24,.13)),cm);chip.position.set(TW/2-.24,0,.02);g.add(chip);
 root.add(g);tiles.push({g,mats:[bm,em,tm,b1m,b2m,cm],base:[.1,.5,.75,.55,.28,.3],side:i%2?1:-1,d:R()*.6})}
const CRIT=4;/* the tile that gets the halo */
const slotY=k=>1.9-k*GAP;
/* priority ladder: a rail with rungs, top rung lit */
const lad=[];lad.push(-TW/2-.32,slotY(0)+.25,0,-TW/2-.32,slotY(N-1)-.25,0);for(let k=0;k<N;k++)lad.push(-TW/2-.32,slotY(k),0,-TW/2-.2,slotY(k),0);
const ladMat=lineMat(ink.clone().lerp(bg,.4),.6);root.add(new T.LineSegments(segGeo(lad),ladMat));
const rung=new T.Mesh(G(new T.PlaneGeometry(.16,.035)),M(new T.MeshBasicMaterial({color:cyan,transparent:!0,opacity:.9})));rung.position.set(-TW/2-.26,slotY(0),0);root.add(rung);
/* halo around the critical tile, and the check mark that replaces it */
const haloMat=lineMat(amber.clone(),0);const halo=new T.LineSegments(segGeo(loop(rrect(TW+.16,TH+.16,.1,7))),haloMat);root.add(halo);
const halo2=new T.LineSegments(segGeo(loop(rrect(TW+.3,TH+.3,.14,7))),lineMat(amber.clone(),0));root.add(halo2);
const chk=G(new T.BufferGeometry);chk.setAttribute("position",new T.Float32BufferAttribute([-.09,0,0,-.03,-.06,0,-.03,-.06,0,.1,.08,0],3));const chkMat=lineMat(cyan.clone(),0);const check=new T.LineSegments(chk,chkMat);root.add(check);
/* large slices drifting at the edges of the room */
const big=[];for(let i=0;i<(small?2:4);i++){const m=lineMat(ink.clone().lerp(bg,.35),.0);const l=new T.LineSegments(i%2?ctGeo:xrGeo,m);l.scale.setScalar(4+R()*2);
 const sx=i%2?-1:1;l.position.set(sx*(3.2+R()*1.2),lerp(-1.2,2.2,R()),-2.5-R()*2.5);l.rotation.z=(R()-.5)*.4;root.add(l);big.push({l,m,sx,x0:l.position.x})}
/* dust */
const DN=small?40:90,dp=new Float32Array(DN*3);for(let i=0;i<DN;i++){dp[i*3]=lerp(-5,5,R());dp[i*3+1]=lerp(-2,3,R());dp[i*3+2]=lerp(-7,2,R())}
const dg=G(new T.BufferGeometry);dg.setAttribute("position",new T.BufferAttribute(dp,3));root.add(new T.Points(dg,M(new T.PointsMaterial({color:ink,size:.018,transparent:!0,opacity:.3,depthWrite:!1}))));
const col=new T.Vector3(.9,0,0),C0=new T.Vector3(-.2,.25,7.4),look=new T.Vector3(.7,.15,0),lk=new T.Vector3;
camera.fov=40;camera.updateProjectionMatrix();camera.position.copy(C0);camera.lookAt(look);
const io=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;/* cubic in-out */
function frame(t,dt,p){
const c=t%14;
/* beat 1: enter from the edges (0-3.4 s), staggered */
const tilt=(clamp(p)-.5)*.25;
for(let i=0;i<N;i++){const T0=tiles[i],e=io(clamp((c-.2-i*.22-T0.d*.3)/2.2)),out=io(clamp((c-12.4)/1.4));
 /* beat 2: slot changes. CRIT rises to 0, tiles above it step down one slot */
 const m=io(clamp((c-6.4)/2));let slot=i;if(i===CRIT)slot=lerp(CRIT,0,m);else if(i<CRIT)slot=i+m;
 const lift=i===CRIT?Math.sin(clamp((c-6.4)/2)*Math.PI)*.5:0;
 T0.g.position.set(col.x+T0.side*(1-e)*5+out*.6,slotY(slot)+tilt*(slot-3)*.08,lift-(1-e)*1.5);
 T0.g.rotation.set(-.05,T0.side*(1-e)*.6-.12,0);
 const vis=e*(1-out);T0.mats.forEach((mm,k)=>mm.opacity=T0.base[k]*vis*(i===CRIT&&k===5?2.4:1));
 if(i===CRIT){T0.mats[5].color.copy(ink).lerp(amber,clamp((c-5.2)/.8)*(1-clamp((c-10.4)/1.2))).lerp(cyan,clamp((c-10.4)/1.2))}}
const ct=tiles[CRIT].g.position;
/* halo: in at 5.2 s, follows the tile, turns cyan and fades from 10.4 s */
const hin=clamp((c-5.2)/.8),hout=clamp((c-10.4)/1.4),pul=.75+.25*Math.sin(c*3.2);
halo.position.copy(ct);halo2.position.copy(ct);halo.rotation.copy(tiles[CRIT].g.rotation);halo2.rotation.copy(tiles[CRIT].g.rotation);
haloMat.opacity=hin*(1-hout)*.95*pul;haloMat.color.copy(amber).lerp(cyan,hout);halo2.material.opacity=hin*(1-hout)*.35*pul;
/* check: draws in 10.4-11.2 s, holds, fades with the column */
const k=clamp((c-10.4)/.8),kf=1-clamp((c-12.6)/1.2);check.position.set(ct.x+TW/2-.24,ct.y,ct.z+.05);check.rotation.copy(tiles[CRIT].g.rotation);
chkMat.opacity=k*kf;check.scale.setScalar(.6+.4*ease(k));
rung.material.opacity=.25+.65*clamp((c-8)/.6)*kf;
/* big slices drift in from the edges during beat 1, out at the end */
const be=io(clamp(c/4)),bo=io(clamp((c-12)/2));big.forEach((b,i)=>{b.l.position.x=b.x0+b.sx*(1-be)*3+b.sx*bo*1.5;b.m.opacity=.22*be*(1-bo);b.l.rotation.y=Math.sin(t*.1+i)*.15});
/* camera: slow eased drift, pointer parallax, no shake */
const d=io(.5-.5*Math.cos(t/14*Math.PI*2));camera.position.set(C0.x+.3*d+pointer.x*.22,C0.y+.1*d-pointer.y*.14,C0.z-.5*d);lk.copy(look);lk.x+=pointer.x*.08;camera.lookAt(lk);
const a=dg.attributes.position.array;for(let i=0;i<DN;i++)a[i*3+1]+=Math.sin(t*.25+i)*2.5e-4;dg.attributes.position.needsUpdate=!0}
return{frame,resize:(w,h)=>{const narrow=w/h<.9;C0.z=narrow?10.5:7.4;col.x=narrow?0:.9;look.x=narrow?0:.7},dispose:()=>{geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose())}}}
