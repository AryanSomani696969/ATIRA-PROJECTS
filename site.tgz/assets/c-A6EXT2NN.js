/* Pricecairn page tools. Everything runs offline in the browser and sends nothing:
   case    - home: one SKU from sales history to read-out, five stages switched by pressed buttons
   review  - weekly review queue: approve, edit (checked against the margin floor) or reject each recommendation
   curve   - demand curve: SKU picker and a test price, redrawn curve with its range, units and margin
   rules   - guardrail rule builder: margin floor, MAP, ladder and competitor rule applied to nine model prices
   promo   - promotion simulator: category, product, depth, duration and support in; units, revenue, margin,
             cannibalization and the week after out, each with a range, against no promotion
   scrollers - wide tables get keyboard focus only when they scroll
   All products, costs, elasticities and competitor prices are synthetic. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const store={get(k){try{return JSON.parse(localStorage.getItem(k)||"null")}catch(e){return null}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}},del(k){try{localStorage.removeItem(k)}catch(e){}}};
const MINUS="−";
const usd=(n,d=2)=>(n<0?MINUS:"")+"$"+Math.abs(n).toLocaleString("en-US",{minimumFractionDigits:d,maximumFractionDigits:d});
const usd0=n=>usd(Math.round(n/10)*10,0);
const pc=(v,d=0)=>{const s=(v*100).toFixed(d);if(+s===0)return(0).toFixed(d)+"%";return(v>=0?"+":MINUS)+s.replace("-","")+"%"};
const pp=(v,d=1)=>(v*100).toFixed(d)+"%";
const int=n=>Math.round(n).toLocaleString("en-US");
const now=()=>{const d=new Date();return String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0")};
function press(btns,on){btns.forEach(b=>b.setAttribute("aria-pressed",b===on?"true":"false"))}
function arrows(btns,cb){btns.forEach((b,i)=>b.addEventListener("keydown",e=>{let j=null;if(e.key==="ArrowRight"||e.key==="ArrowDown")j=(i+1)%btns.length;if(e.key==="ArrowLeft"||e.key==="ArrowUp")j=(i-1+btns.length)%btns.length;if(e.key==="Home")j=0;if(e.key==="End")j=btns.length-1;if(j!==null){e.preventDefault();btns[j].focus();cb(btns[j],j)}}))}
/* ------------------------------------------------------------------ synthetic categories (same numbers as the pages) */
/* id, name, pack, group, price, unit cost, weekly units, elasticity, low, high, grouped */
const CATS={coffee:{name:"Coffee",dip:.12,skus:[
 ["C01","House blend, ground","12 oz","ground",7.99,4.60,820,-2.4,-2.9,-1.9,0],["C02","House blend, ground","24 oz","ground",13.49,7.90,310,-1.9,-2.5,-1.4,0],
 ["C03","Dark roast, whole bean","12 oz","bean",9.49,5.20,420,-1.6,-2.1,-1.2,0],["C04","Colombia single origin","12 oz","bean",11.99,6.10,180,-1.1,-1.7,-0.6,0],
 ["C05","Decaf, ground","12 oz","ground",8.49,4.95,140,-1.3,-2.0,-0.7,1],["C06","Espresso, whole bean","2 lb","bean",21.99,13.20,95,-0.9,-1.5,-0.4,1],
 ["C07","Cold brew concentrate","32 oz","rtd",6.99,3.40,260,-2.8,-3.4,-2.2,0],["C08","Pods, medium roast","24 ct","pods",14.99,9.10,690,-2.1,-2.5,-1.7,0],
 ["C09","Pods, dark roast","24 ct","pods",14.99,9.10,540,-2.0,-2.4,-1.6,0],["C10","Pods, decaf","12 ct","pods",8.49,5.05,120,-1.4,-2.1,-0.8,1],
 ["C11","Instant, jar","8 oz","instant",6.49,3.30,210,-0.8,-1.3,-0.4,0],["C12","Organic French roast","12 oz","bean",10.99,6.40,150,-1.2,-1.9,-0.6,1]]},
 cereal:{name:"Breakfast cereal",dip:.10,skus:[
 ["K01","Oat rings","18 oz","family",4.99,2.85,940,-2.6,-3.1,-2.1,0],["K02","Oat rings, family size","27 oz","family",6.79,3.95,380,-2.2,-2.8,-1.6,0],
 ["K03","Bran flakes","16 oz","adult",4.49,2.40,410,-1.5,-2.0,-1.0,0],["K04","Honey granola","12 oz","granola",5.99,3.10,300,-1.8,-2.4,-1.2,0],
 ["K05","Granola, nut cluster","11 oz","granola",6.49,3.45,170,-1.4,-2.1,-0.8,1],["K06","Corn flakes","18 oz","family",3.99,2.05,620,-2.9,-3.5,-2.3,0],
 ["K07","Muesli, no sugar added","16 oz","adult",5.49,2.95,140,-1.1,-1.8,-0.5,1],["K08","Chocolate rice crisps","12 oz","family",4.29,2.30,450,-2.4,-2.9,-1.9,0]]}};
const CAN={pods:.35,ground:.30,bean:.25,rtd:.15,instant:.10,family:.40,adult:.20,granola:.30};
const GNAME={pods:"pods",ground:"ground coffees",bean:"whole-bean coffees",rtd:"ready-to-drink coffees",instant:"instant coffees",family:"family cereals",adult:"adult cereals",granola:"granolas"};
const SUP={tag:[1,1,1,"a shelf tag only"],feature:[1.25,1.15,1.35,"a feature ad and an end-cap display"]};
const FLOOR=.20;
const sens=e=>Math.abs(e)>=2?"high":Math.abs(e)>=1.3?"medium":"low";
/* ------------------------------------------------------------------ case stepper */
function caseV(root){const bs=$$("[data-cs]",root);const pick=b=>{press(bs,b);bs.forEach(x=>{$("#"+x.dataset.cs).hidden=x!==b})};bs.forEach(b=>b.addEventListener("click",()=>pick(b)));arrows(bs,b=>pick(b))}
/* ------------------------------------------------------------------ weekly review */
function review(root){const cards=$$(".pc-rec",root),cnt=$("[data-rv-c]",root);
 const left=()=>{const n=cards.filter(c=>!c.dataset.done).length;cnt.textContent=n?n+" to decide":"All decided"};
 cards.forEach(card=>{const bs=$$("[data-rv-d]",card),ed=$(".pc-rv__ed",card),inp=$("[data-rv-p]",card),st=$("[data-rv-s]",card),save=$("[data-rv-save]",card);
  const cost=parseFloat(card.dataset.cost),cur=parseFloat(card.dataset.p),sku=card.dataset.sku;
  bs.forEach(b=>b.addEventListener("click",()=>{press(bs,b);const k=b.dataset.rvD;ed.hidden=k!=="edit";card.classList.toggle("is-ok",k==="ok");card.classList.toggle("is-no",k==="no");
   if(k==="ok"){card.dataset.done="1";st.textContent="Approved at "+now()+". "+sku+" goes to "+usd(parseFloat(card.dataset.new))+" on Monday. Logged."}
   else if(k==="no"){card.dataset.done="1";st.textContent="Rejected at "+now()+". "+sku+" stays at "+usd(cur)+". Logged with your reason."}
   else{delete card.dataset.done;st.textContent="Enter a new price. It is checked against the 25% margin floor.";inp.focus()}left()}));
  save.addEventListener("click",()=>{const v=parseFloat(inp.value);inp.removeAttribute("aria-invalid");
   if(!(v>0)){inp.setAttribute("aria-invalid","true");st.textContent="Enter a price in US dollars, for example 12.29.";return}
   const m=(v-cost)/v;if(m<.25){inp.setAttribute("aria-invalid","true");st.textContent="Not saved. "+usd(v)+" leaves a "+pp(m)+" margin, under the 25% floor. The lowest allowed price is "+usd(Math.ceil(cost/.75*100)/100)+".";return}
   card.dataset.new=v.toFixed(2);$(".pc-rec__new",card).textContent=usd(v);card.dataset.done="1";card.classList.add("is-ok");st.textContent="Saved and approved at "+now()+": "+usd(v)+", margin "+pp(m)+". Logged as an edit.";left()})});left()}
/* ------------------------------------------------------------------ demand curve */
function curve(root){const sel=$("[data-cv-sku]",root),rg=$("[data-cv-p]",root),o=$("[data-cv-o]",root),box=$("[data-cv-c]",root),t=$("[data-cv-t]",root),note=$("[data-cv-n]",root);const SK=CATS.coffee.skus;
 const get=()=>SK.find(s=>s[0]===sel.value);
 const draw=keep=>{const s=get(),[id,nm,pk,,p,c,u,e,lo,hi,grp]=s;if(!keep){rg.min=(p*.7).toFixed(2);rg.max=(p*1.3).toFixed(2);rg.value=p.toFixed(2)}
  const q=parseFloat(rg.value),W=640,H=300,x0=56,y0=20,x1=W-16,y1=H-40,um=u*2.4,ps=[];for(let k=0;k<25;k++)ps.push(p*(.7+k*.6/24));
  const X=v=>x0+(v-ps[0])/(ps[24]-ps[0])*(x1-x0),Y=v=>y1-Math.min(v,um)/um*(y1-y0),U=(v,ee)=>u*Math.pow(v/p,ee);
  const band="M"+ps.map(v=>X(v).toFixed(1)+" "+Y(U(v,lo)).toFixed(1)).join("L")+"L"+ps.slice().reverse().map(v=>X(v).toFixed(1)+" "+Y(U(v,hi)).toFixed(1)).join("L")+"Z";
  const mid="M"+ps.map(v=>X(v).toFixed(1)+" "+Y(U(v,e)).toFixed(1)).join("L");
  let g="";[0,um/2,um].forEach(v=>{g+='<path class="pc-cg" d="M'+x0+" "+Y(v).toFixed(1)+"H"+x1+'"/><text class="pc-ct" x="'+(x0-8)+'" y="'+(Y(v)+4).toFixed(1)+'" text-anchor="end">'+int(v)+"</text>"});
  [[ps[0],"start"],[p,"middle"],[ps[24],"end"]].forEach(([v,an])=>{g+='<text class="pc-ct" x="'+X(v).toFixed(1)+'" y="'+(y1+22)+'" text-anchor="'+an+'">'+usd(v)+"</text>"});
  const uq=U(q,e),ua=U(q,hi),ub=U(q,lo),lo2=Math.min(ua,ub),hi2=Math.max(ua,ub);
  box.innerHTML='<svg class="pc-chart" viewBox="0 0 '+W+" "+H+'" role="img" aria-label="Line chart: weekly units of '+esc(nm+" "+pk)+" against price. At "+usd(q)+" the central estimate is "+int(uq)+" units a week, range "+int(lo2)+" to "+int(hi2)+'.">'+g+'<path class="pc-crange" d="'+band+'"/><path class="pc-cmid" d="'+mid+'"/><path class="pc-cnow" d="M'+X(q).toFixed(1)+" "+y0+"V"+y1+'"/><circle class="pc-cdot" cx="'+X(q).toFixed(1)+'" cy="'+Y(uq).toFixed(1)+'" r="6"/></svg>';
  o.textContent=usd(q);rg.setAttribute("aria-valuetext",usd(q)+", "+int(uq)+" units a week");
  $('[data-cv="u"]',root).textContent=int(uq);$('[data-cv="ur"]',root).textContent=Math.abs(q-p)<.005?"at the current price":"range "+int(lo2)+" to "+int(hi2)+", "+pc(uq/u-1)+" on today";
  $('[data-cv="m"]',root).textContent=usd((q-c)*uq,0);$('[data-cv="mr"]',root).textContent=q<=c?"below unit cost "+usd(c):pc(((q-c)*uq)/((p-c)*u)-1)+" on today, unit cost "+usd(c);
  $('[data-cv="e"]',root).textContent=e.toFixed(1);$('[data-cv="er"]',root).textContent="range "+lo.toFixed(1)+" to "+hi.toFixed(1)+", "+sens(e)+" sensitivity";
  t.textContent="Demand curve / "+id+" "+nm+", "+pk;note.textContent=grp?"Grouped estimate: this SKU shares an estimate with similar products because it sells too few units to stand alone, so its range is wide.":"Estimated from 104 weeks of synthetic sales, with seasonality and past promotions taken out."};
 sel.addEventListener("change",()=>draw(false));rg.addEventListener("input",()=>draw(true));draw(false)}
/* ------------------------------------------------------------------ guardrail rule builder */
/* id, name, current, model price, cost, competitor median, MAP, low confidence */
const GR=[["C01","House blend, ground 12 oz",7.99,7.49,4.60,7.49,0,0],["C02","House blend, ground 24 oz",13.49,14.49,7.90,13.99,0,0],["C03","Dark roast, whole bean",9.49,9.99,5.20,9.79,0,0],
 ["C04","Colombia single origin",11.99,12.49,6.10,12.79,0,0],["C05","Decaf, ground",8.49,8.99,4.95,8.79,0,0],["C06","Espresso, whole bean 2 lb",21.99,22.99,13.20,22.49,0,1],
 ["C07","Cold brew concentrate",6.99,6.49,3.40,6.79,0,0],["C08","Pods, medium roast",14.99,13.49,9.10,14.49,13.99,0],["C11","Instant, jar",6.49,6.79,3.30,6.99,0,0]];
function rules(root){const q=k=>$('[data-gr="'+k+'"]',root),tb=$("[data-gr-b]",root),st=$("[data-gr-s]",root),o=$("[data-gr-o]",root);
 const run=()=>{const fl=parseInt(q("floor").value,10)/100,map=q("map").checked,lad=q("lad").checked,comp=q("comp").value;o.textContent=Math.round(fl*100)+"%";q("floor").setAttribute("aria-valuetext",Math.round(fl*100)+" percent margin floor");
  const base12=GR[0][2]/12;let n={pass:0,clamp:0,held:0},rows="";
  GR.forEach(([id,nm,cur,model,cost,cm,mp,low])=>{let p=comp==="match"?cm:model,res="pass",why=[];
   if(low){res="held";why.push("Low confidence, grouped estimate")}
   if(res!=="held"&&map&&mp&&p<mp){p=mp;res="clamp";why.push("Raised to brand MAP "+usd(mp))}
   const m=(p-cost)/p;
   if(res!=="held"&&m<fl){res="held";why.push("Margin "+pp(m)+" is under the "+Math.round(fl*100)+"% floor")}
   if(res!=="held"&&comp==="band"&&Math.abs(p/cm-1)>.05){res="held";why.push("More than 5% from the competitor median "+usd(cm))}
   if(res!=="held"&&lad&&id==="C02"){const per=p/24,lim=base12*.9;if(per>lim){res="held";why.push("Ladder: only "+((1-per/base12)*100).toFixed(1)+"% cheaper per oz than the 12 oz bag")}}
   if(res==="pass"){why.push("Margin "+pp(m)+(comp==="ignore"?"":", competitor median "+usd(cm)))}
   const fin=res==="held"?cur:p;n[res]++;
   rows+='<tr class="'+(res==="held"?"is-held":"")+'"><th scope="row"><span class="pc-id">'+id+"</span>"+esc(nm)+'</th><td class="pc-num">'+usd(model)+'</td><td class="pc-num">'+usd(fin)+(res==="held"?"<small>stays at today’s price</small>":"")+"</td><td>"+
    '<span class="mv-tag mv-tag--'+(res==="pass"?"ok":res==="clamp"?"plan":"warn")+'">'+(res==="pass"?"Passes":res==="clamp"?"Clamped":"Held back")+"</span><small>"+esc(why.join(". "))+"</small></td></tr>"});
  tb.innerHTML=rows;st.textContent=n.pass+" of "+GR.length+" pass, "+n.clamp+" clamped to a rule, "+n.held+" held back for review."};
 ["floor","comp"].forEach(k=>q(k).addEventListener("input",run));["map","lad","comp"].forEach(k=>q(k).addEventListener("change",run));run()}
/* ------------------------------------------------------------------ promotion simulator */
function sim(cat,sku,d,w,sup,sc){/* sc: 0 central, 1 cautious, 2 generous */
 const C=CATS[cat],s=C.skus.find(x=>x[0]===sku),[id,nm,pk,g,p,c,u,e,lo,hi]=s;
 const ee=[e,hi,lo][sc],sp=SUP[sup][[0,1,2][sc]],cr=Math.max(0,CAN[g]+[0,.08,-.08][sc]),dr=C.dip*[1,1.5,.5][sc];
 const sib=C.skus.filter(x=>x[3]===g&&x[0]!==id);const sw=sib.reduce((t,x)=>t+x[6],0);
 const sibM=sw?sib.reduce((t,x)=>t+(x[4]-x[5])*x[6],0)/sw:0,sibP=sw?sib.reduce((t,x)=>t+x[4]*x[6],0)/sw:0,cr2=sw?cr:0;
 const m=Math.pow(1-d,ee)*sp,up=u*m,inc=up-u,pr=p*(1-d);
 const dip=Math.max(0,inc)*w*dr,can=Math.max(0,inc)*w*cr2;
 const bU=u*(w+1),bR=p*bU,bM=(p-c)*bU;
 const sU=up*w+(u-dip),sR=pr*up*w+p*(u-dip),sM=(pr-c)*up*w+(p-c)*(u-dip);
 const cat0=C.skus.reduce((t,x)=>[t[0]+x[6]*(w+1),t[1]+x[4]*x[6]*(w+1),t[2]+(x[4]-x[5])*x[6]*(w+1)],[0,0,0]);
 const dU=sU-bU-can,dR=sR-bR-can*sibP,dM=sM-bM-can*sibM;
 return{s,m,up,inc,dip,can,cr:cr2,pr,spend:(p-pr)*up*w,bU,bR,bM,sU,sR,sM,dU,dR,dM,cat0,mu:(pr-c)/pr}}
function promo(root){const q=k=>$('[data-pm="'+k+'"]',root),out=$("[data-pm-out]",root),o=$("[data-pm-o]",root),mini=root.classList.contains("pc-pm--mini"),KEY="pc-sim";
 const fill=(cat,keep)=>{if(mini)return;const s=q("sku");s.innerHTML=CATS[cat].skus.map(x=>'<option value="'+x[0]+'">'+x[0]+" "+esc(x[1])+", "+esc(x[2])+"</option>").join("");if(keep&&CATS[cat].skus.some(x=>x[0]===keep))s.value=keep;else s.value=cat==="coffee"?"C08":"K01"};
 if(!mini){const sv=store.get(KEY);if(sv&&CATS[sv.cat]){q("cat").value=sv.cat;fill(sv.cat,sv.sku);["d","w","sup"].forEach(k=>{if(sv[k]!=null)q(k).value=sv[k]})}else fill("coffee")}
 const meter=(lab,a,b,mid,txt,sc)=>{const f=v=>Math.max(0,Math.min(100,50+v/sc*50));const l=f(Math.min(a,b)),r=f(Math.max(a,b));
  return'<div class="pc-mt"><span>'+lab+'</span><span class="pc-mt__b" aria-hidden="true"><i style="left:'+l.toFixed(1)+"%;width:"+Math.max(1.5,r-l).toFixed(1)+'%"></i><b style="left:calc('+f(mid).toFixed(1)+'% - 1px)"></b></span><output>'+txt+"</output></div>"};
 const run=()=>{const cat=q("cat").value,sku=q("sku").value,d=parseInt(q("d").value,10)/100,w=parseInt(q("w").value,10),sup=q("sup").value;
  o.textContent=Math.round(d*100)+"%";q("d").setAttribute("aria-valuetext",Math.round(d*100)+" percent off");
  if(!CATS[cat]||!CATS[cat].skus.some(x=>x[0]===sku)||!(d>0&&d<1)||!(w>=1&&w<=4)){out.innerHTML='<p class="pc-err" role="alert">Pick a category, a product, a depth between 5% and 40% and a duration of one to four weeks.</p>';return}
  if(!mini)store.set(KEY,{cat,sku,d:q("d").value,w:q("w").value,sup});
  const R=[0,1,2].map(k=>sim(cat,sku,d,w,sup,k)),M=R[0],lo=k=>Math.min(R[1][k],R[2][k]),hi=k=>Math.max(R[1][k],R[2][k]);
  const [id,nm,pk,g,p,c,u,e,elo,ehi,grp]=M.s,H=w+1,cu=M.cat0[0],cr=M.cat0[1],cm=M.cat0[2];
  const skuU=M.sU/M.bU-1,skuUlo=lo("sU")/M.bU-1,skuUhi=hi("sU")/M.bU-1;
  const gate=M.mu<FLOOR?'<p class="pc-gate pc-gate--no">At '+usd(M.pr)+" the unit margin is "+pp(M.mu)+", under the 20% promotion floor. Pricecairn would hold this promotion for the category lead to approve.</p>":'<p class="pc-gate pc-gate--ok">At '+usd(M.pr)+" the unit margin is "+pp(M.mu)+", above the 20% promotion floor.</p>";
  const why=["<li>"+esc(nm)+" has "+sens(e)+" price sensitivity (elasticity "+e.toFixed(1)+", range "+elo.toFixed(1)+" to "+ehi.toFixed(1)+(grp?", grouped estimate":"")+"). "+Math.round(d*100)+"% off with "+SUP[sup][3]+" lifts its weekly units by about "+pc(M.m-1)+".</li>",
   M.cr?"<li>About "+Math.round(M.cr*100)+"% of the extra units come from the other "+GNAME[g]+": "+int(M.can)+" units they would have sold.</li>":"<li>No sister products in the same group, so no cannibalization is counted.</li>",
   "<li>The week after, shoppers who stocked up buy about "+int(M.dip)+" fewer units, included in the totals.</li>",
   "<li>Discount spend: "+usd0(M.spend)+" over "+w+" week"+(w>1?"s":"")+". "+(M.dM>=0?"The extra units more than pay for it in the central case.":"The extra units do not pay for it in the central case.")+"</li>"].join("");
  const sign=v=>v>=0?"is-g":"is-c";
  out.innerHTML='<p class="pc-k">'+esc(CATS[cat].name)+" / "+id+" "+esc(nm)+", "+Math.round(d*100)+"% off, "+w+" week"+(w>1?"s":"")+'</p><p class="pc-pm__n">'+(M.dM>=0?"+":MINUS)+usd0(Math.abs(M.dM)).replace(MINUS,"")+" category margin<span>Range "+usd0(lo("dM"))+" to "+usd0(hi("dM"))+" over "+H+" weeks, the promotion plus the week after, against no promotion.</span></p>"+
   '<div class="pc-tiles"><div><span>Units, '+id+'</span><b class="is-g">'+pc(skuU)+"</b><small>"+pc(skuUlo)+" to "+pc(skuUhi)+'</small></div><div><span>Units, category</span><b class="'+sign(M.dU)+'">'+pc(M.dU/cu,1)+"</b><small>"+pc(lo("dU")/cu,1)+" to "+pc(hi("dU")/cu,1)+'</small></div><div><span>Revenue, category</span><b class="'+sign(M.dR)+'">'+pc(M.dR/cr,1)+"</b><small>"+usd0(M.dR)+"</small></div></div>"+
   '<div class="pc-meters" aria-hidden="true">'+meter("Units, category",lo("dU")/cu,hi("dU")/cu,M.dU/cu,pc(M.dU/cu,1),.2)+meter("Revenue, category",lo("dR")/cr,hi("dR")/cr,M.dR/cr,pc(M.dR/cr,1),.2)+meter("Margin, category",lo("dM")/cm,hi("dM")/cm,M.dM/cm,pc(M.dM/cm,1),.2)+meter("Cannibalized units",-lo("can")/(M.inc*w||1),-hi("can")/(M.inc*w||1),-M.can/(M.inc*w||1),int(M.can),1)+"</div>"+gate+
   (mini?"":'<div class="mv-pscroll pc-cmp" data-label="Comparison"><table class="pc-table"><thead><tr><th scope="col">'+H+' weeks</th><th scope="col">No promotion</th><th scope="col">With promotion</th></tr></thead><tbody>'+
    "<tr><th scope=\"row\">Units, "+id+'</th><td class="pc-num">'+int(M.bU)+'</td><td class="pc-num">'+int(M.sU)+"</td></tr><tr><th scope=\"row\">Revenue, "+id+'</th><td class="pc-num">'+usd0(M.bR)+'</td><td class="pc-num">'+usd0(M.sR)+"</td></tr><tr><th scope=\"row\">Margin, "+id+'</th><td class="pc-num">'+usd0(M.bM)+'</td><td class="pc-num">'+usd0(M.sM)+"</td></tr>"+
    '<tr><th scope="row">Units, category</th><td class="pc-num">'+int(cu)+'</td><td class="pc-num">'+int(cu+M.dU)+'</td></tr><tr><th scope="row">Margin, category</th><td class="pc-num">'+usd0(cm)+'</td><td class="pc-num">'+usd0(cm+M.dM)+"</td></tr></tbody></table></div>")+
   '<ul class="pc-why">'+why+"</ul>"};
 if(!mini){q("cat").addEventListener("change",()=>{fill(q("cat").value);run()});["sku","w","sup"].forEach(k=>q(k).addEventListener("change",run));
  $("[data-pm-reset]",root).addEventListener("click",()=>{store.del(KEY);q("cat").value="coffee";fill("coffee");q("d").value=20;q("w").value=2;q("sup").value="feature";run()})}
 q("d").addEventListener("input",run);run()}
/* ------------------------------------------------------------------ scrollers */
function scrollers(){const fix=()=>$$(".mv-pscroll").forEach(el=>{if(el.scrollWidth>el.clientWidth+2){el.tabIndex=0;el.setAttribute("role","region");el.setAttribute("aria-label",el.dataset.label||"Table")}else{el.removeAttribute("tabindex");el.removeAttribute("role");el.removeAttribute("aria-label")}});fix();addEventListener("resize",fix)}
export function boot(){const map={case:caseV,review,curve,rules,promo};$$("[data-pc]").forEach(r=>{const f=map[r.dataset.pc];if(f)try{f(r)}catch(e){console.error(e)}});scrollers()}
