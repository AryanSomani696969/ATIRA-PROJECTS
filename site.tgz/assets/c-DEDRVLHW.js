/* Simquill page tools, all offline in the browser, nothing is sent anywhere:
   rp      - the sample role-play: three written scenarios, a rule-based persona whose mood moves with the learner's replies,
             and a scorecard on four rubric items with a comment on every learner turn
   builder - the free scenario builder: situation, persona, goal and rubric, a persona card, a sample conversation built
             from the draft, practice in the role-play on the same page, save in this browser, copy as text
   scrollers - wide tables get keyboard focus only when they scroll */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
/* ------------------------------------------------------------------ cue detectors */
const QW=/\b(what|how|who|when|why|which|where|tell me|walk me through|could you (say|tell|share)|can you (say|tell|share))\b/i;
const CUE={
 ack:/\b(understand|fair( point| enough)?|i hear you|makes sense|sorry|frustrat\w*|appreciate|thanks for|thank you for|i see why|that sounds|i get (it|that|why)|annoying|upsetting)\b/i,
 value:/\b(cost\w*|hours?|time|save\w*|spend\w*|errors?|budget\w*|weekly|per (week|month)|return|worth)\b/i,
 num:/\d/,
 next:/\b(next (week|step|call|meeting)|follow[- ]?up|call|meeting|meet|catch up|schedule|book|send (you|it|over)|check in)\b/i,
 dated:/\b(monday|tuesday|wednesday|thursday|friday|tomorrow|today|this (afternoon|week)|by (end of )?(the )?(day|week)|at \d|\d ?(am|pm)|\d{1,2}:\d{2}|within \w+ (hours?|days?))\b/i,
 rude:/\b(calm down|you need to|that'?s not my (problem|job)|whatever|obviously|you should have|as i said|listen,|just sign|not my fault|deal with it)\b/i,
 discount:/\b(discount|\d+ ?(%|percent) off|cheaper|lower (the )?price|price match)\b/i,
 phrase:/\b(verify|confirm (your|the) (name|account|address|identity|details)|security (question|check)|for security)\b/i,
 example:/\b(last (week|month|sprint|tuesday|monday|friday|thursday|wednesday)|on (monday|tuesday|wednesday|thursday|friday)|the (report|release|deadline|handover)|\d+ (days?|times|deadlines?))\b/i,
 open:/\b(how do you see|what do you think|your view|your side|from your point of view|what got in the way|what would help)\b/i
};
const ITEMS={
 disc:{t:"Discovery questions",d:"Open questions before any offer"},ack:{t:"Acknowledge the concern",d:"Names the concern before answering"},
 value:{t:"Tie the answer to value",d:"Uses a number the other person gave"},next:{t:"Agree a dated next step",d:"A day or time, and who attends"},
 calm:{t:"Calm, respectful tone",d:"No blame, no orders"},phrase:{t:"Uses the required phrase",d:"The check your policy requires"},
 example:{t:"Specific example",d:"A date, a number or a named piece of work"},ask:{t:"Asks for their view",d:"Invites the other side before deciding"}};
/* ------------------------------------------------------------------ the three sample scenarios (written for this page) */
const SC=[
{id:"price",tab:"Pricing objection",role:"Procurement lead",org:"Regional freight company, 400 staff",mood:2,goal:"Keep the renewal inside last year's budget",
 brief:"Renewal call. You sent the new quote yesterday. Your goal: agree a dated call with the dispatch lead without discounting.",
 rub:[["disc",3],["ack",2],["value",3],["next",2]],
 open:"Honestly, the number you sent is about 30 percent over what we budgeted. I am not sure this goes anywhere.",
 obj:["Two years is a big ask when we have not seen it work for our dispatch team.","And finance will ask why we cannot just stay on the old tool.","I still need something concrete to show finance."],
 ans:["The budget was last year's spend on the old tool, plus a little. Finance will not move much.","Dispatch re-keys orders from the old tool. Roughly two people, half a day each, every week.","Finance signs off, and our dispatch lead would have to agree it actually helps."],
 soft:"Fine. I appreciate you not pretending the number is small.",disc:"A discount does not change the fact that nobody here has seen it work.",
 rude:"I do not need to be told what I need. Maybe we should end this here.",yes:"Thursday works. I will bring our dispatch lead.",
 hint:"That is fair, thanks for saying it straight. Can I ask what the budget was built around?"},
{id:"angry",tab:"Angry customer",role:"Account holder, small business",org:"Utilities, billing dispute",mood:3,goal:"Get the late fee removed on this call",
 brief:"Inbound call. The customer was charged a late fee after a payment they say they made on time. Policy: confirm identity before discussing the account.",
 rub:[["ack",3],["phrase",2],["calm",2],["next",3]],
 open:"This is the third time I am calling about this. You charged me a late fee for a payment I made on time, and nobody called me back like they promised.",
 obj:["I do not want to explain it all again. Can I just speak to a manager?","Every time I call, someone says they will fix it and nothing happens.","I need the fee gone today, not another reference number."],
 ans:["I paid on the 14th, the due date was the 15th. I have the bank receipt.","The last person said someone would call me back within two days. That was last Monday.","What I want is the fee taken off and a call back when it is done."],
 soft:"Okay. Thank you. That is the first time someone has actually said that.",disc:"",
 rude:"Do not tell me to calm down. I have every reason to be upset.",yes:"Fine. If someone actually calls me by then, that would be something.",
 hint:"I am sorry you have had to call three times, that is frustrating. Before I look at the account, can I confirm your name and the account address for security?"},
{id:"feedback",tab:"Feedback conversation",role:"Team member, analyst",org:"Finance team, two missed deadlines",mood:1,goal:"Avoid being blamed for work that depended on others",
 brief:"One-to-one. The last two monthly reports went out late. Your goal: give specific feedback, hear their side and agree what changes before the next report.",
 rub:[["example",3],["ask",2],["calm",2],["next",3]],
 open:"You wanted to talk about the reports? I know they were late, but I was waiting on numbers from two other teams.",
 obj:["It feels like I am the one getting blamed for a process problem.","I am already working late most of the month end.","If the inputs are late again, the report will be late again."],
 ans:["Sales sent their figures two days after the cut-off both times.","I flagged it in the team channel, but nobody picked it up.","Honestly, a hard cut-off and someone senior chasing the inputs would help."],
 soft:"Thanks. I did not expect you to see that side of it.",disc:"",
 rude:"That sounds like you have already decided it is my fault.",yes:"Okay. I can do that. Let us check in on the Wednesday before the cut-off.",
 hint:"The March and April reports both went out three days late. Before we talk about fixes, how do you see what got in the way?"}];
/* ------------------------------------------------------------------ role-play engine */
function analyse(txt){const out={q:0,ack:CUE.ack.test(txt),num:CUE.num.test(txt),val:CUE.value.test(txt),next:CUE.next.test(txt),dated:CUE.dated.test(txt),rude:CUE.rude.test(txt),disc:CUE.discount.test(txt),phrase:CUE.phrase.test(txt),ex:CUE.example.test(txt),open:CUE.open.test(txt)};
txt.split(/(?<=[?.!])\s+/).forEach(s=>{if(/\?\s*$/.test(s)&&QW.test(s))out.q++});if(out.open)out.q=Math.max(out.q,1);return out}
function score(sc,turns){const R={},notes=[];let firstQ=-1,discAt=-1,ackAt=-1,rude=0,num=0,val=0,next=0,phrase=0,ex=0,ask=0,qs=0;
turns.forEach((t,i)=>{const a=t.a;qs+=a.q;if(a.q&&firstQ<0)firstQ=i;if(a.disc&&discAt<0)discAt=i;if(a.ack&&ackAt<0)ackAt=i;if(a.rude)rude++;
 if(a.num&&a.val)num=1;if(a.val)val=1;if(a.next)next=Math.max(next,a.dated?2:1);if(a.phrase)phrase=1;if(a.ex)ex=Math.max(ex,a.num||/\b(last|on) /i.test(t.txt)?2:1);if(a.q||a.open)ask=Math.max(ask,a.open?2:1)});
R.disc=Math.max(0,[0,2,3][Math.min(qs,2)]+(qs>=3?1:0)-(discAt>=0&&(firstQ<0||discAt<firstQ)?1:0));
R.ack=ackAt<0?0:ackAt===0?4:2;R.value=num?4:val?2:0;R.next=next===2?4:next?2:0;R.calm=Math.max(0,4-rude*2);R.phrase=phrase?4:0;R.example=ex===2?4:ex?2:0;R.ask=ask===2?4:ask?3:0;
turns.forEach((t,i)=>{const a=t.a,n=[];if(a.rude)n.push(["miss","Tone","This line reads as blame or an order. The persona's mood went up."]);
 if(a.disc&&(firstQ<0||i<=firstQ))n.push(["miss","Missed discovery","An offer before a question about cost. Ask what the current process costs first."]);
 if(a.ack)n.push(["ok","Acknowledged","Named the concern before answering."]);if(a.q)n.push(["ok","Question",a.q>1?a.q+" open questions in this turn.":"One open question."]);
 if(a.phrase)n.push(["ok","Required phrase","Identity check done before account details."]);if(a.num&&a.val)n.push(["ok","Value","Tied the answer to a number."]);
 if(a.next)n.push([a.dated?"ok":"miss",a.dated?"Dated next step":"Next step, no date",a.dated?"Day or time named.":"Right move. Name a day and who attends."]);
 if(a.ex)n.push(["ok","Specific","Used a date, a number or a named piece of work."]);
 if(!n.length)n.push(["miss","No rubric item","This turn did not score. Try a question or name the concern."]);notes.push(n)});
const rows=sc.rub.map(([k,w])=>({k,w,v:R[k]||0})),tw=rows.reduce((s,r)=>s+r.w,0),tot=Math.round(rows.reduce((s,r)=>s+r.v*r.w,0)/(4*tw)*100);return{rows,tot,notes}}
function rp(root){
 const log=$("[data-rp-log]",root),inp=$("[data-rp-input]",root),out=$("[data-rp-out]",root),st=$("[data-rp-status]",root),ctx=$("[data-rp-ctx]",root),turnL=$("[data-rp-turn]",root),send=$("[data-rp-send]",root),mini=root.classList.contains("sq-rp--mini");
 const MAX=mini?4:6;let sc=SC[0],S;
 const say=(who,txt)=>{const li=document.createElement("li");if(who==="l")li.className="is-l";li.innerHTML="<small>"+(who==="l"?"You":esc(sc.role))+"</small>"+esc(txt);log.appendChild(li);log.scrollTop=log.scrollHeight};
 const moodName=m=>["Calm","Calm","Skeptical","Frustrated","Angry"][Math.max(0,Math.min(4,m))];
 const showCtx=()=>{ctx.innerHTML='<div class="mv-panel"><div class="mv-panel__h mv-panel__h--mi"><span>'+esc(sc.custom?"Your scenario":"Scenario")+" / "+esc(sc.tab)+'</span><b>'+(sc.custom?"Your draft":"Synthetic")+'</b></div><div class="sq-pc__b"><p><b>'+esc(sc.role)+"</b>, "+esc(sc.org)+'</p><p data-rp-mood>Mood: '+moodName(S.mood)+"</p><p>"+esc(sc.brief)+"</p></div></div>"};
 const updMood=()=>{const m=$("[data-rp-mood]",ctx);if(m)m.textContent="Mood: "+moodName(S.mood)};
 const reset=()=>{S={mood:sc.mood,ob:0,an:0,turns:[],done:!1};log.innerHTML="";showCtx();say("p",sc.open);inp.value="";inp.removeAttribute("aria-invalid");send.disabled=!1;
  out.innerHTML='<p class="sq-mute">'+(mini?"Reply to the persona. After four replies, or when you press End and score, you get a scorecard.":"Reply in your own words. The persona answers each turn and its mood moves with what you say. End the session any time to see the scorecard.")+"</p>";turnL.textContent="Reply 1 of "+MAX;st.textContent=""};
 const reply=a=>{if(a.rude){S.mood=Math.min(4,S.mood+1);return sc.rude}
  if(a.ack)S.mood=Math.max(0,S.mood-1);
  if(a.next&&S.mood<=1&&S.turns.length>=2){S.done=!0;return sc.yes}
  if(a.disc&&sc.disc){S.mood=Math.min(4,S.mood+1);return sc.disc}
  if(a.q&&S.an<sc.ans.length){return(a.ack?sc.soft+" ":"")+sc.ans[S.an++]}
  if(a.ack&&S.turns.length===1)return sc.soft+" "+(sc.obj[S.ob++]||"");
  if(S.ob<sc.obj.length)return sc.obj[S.ob++];
  return S.mood<=1?"So what happens next?":"I am still not convinced."};
 const finish=()=>{if(!S.turns.length){st.textContent="Send at least one reply before scoring.";return}S.done=!0;send.disabled=!0;const r=score(sc,S.turns);
  const rows=r.rows.map(x=>'<li class="'+(x.v<=2?"is-low":"")+'"><span>'+esc(ITEMS[x.k].t)+'</span><span class="sq-sc__b"><i style="--v:'+(x.v/4).toFixed(2)+'"></i></span><b>'+x.v+"/4</b><small>Weight "+x.w+". "+esc(ITEMS[x.k].d)+".</small></li>").join("");
  const mo=S.turns.map((t,i)=>r.notes[i].map(([k,h,n])=>'<li class="'+(k==="miss"?"is-miss":"")+'"><b>Reply '+(i+1)+" · "+esc(h)+"</b>"+esc(n)+"</li>").join("")).join("");
  out.innerHTML='<h3 class="sq-out__h">Scorecard</h3><p class="sq-tot"><b>'+r.tot+'</b><span>of 100 on this rubric · '+S.turns.length+(S.turns.length===1?' reply':' replies')+' · sample rules</span></p><ul class="sq-sc">'+rows+'</ul><h3 class="sq-out__h">Moments</h3><ul class="sq-mo">'+mo+"</ul>";
  root.classList.toggle("is-anim",!RM);st.textContent="Scored. Start again to try a different approach."};
 const go=()=>{if(S.done){st.textContent="This session has ended. Press Start again to practice it once more.";return}const txt=inp.value.trim();
  if(txt.length<4){inp.setAttribute("aria-invalid","true");st.textContent="Type a reply first, a sentence or two as you would say it.";inp.focus();return}
  inp.removeAttribute("aria-invalid");const a=analyse(txt);S.turns.push({txt,a});say("l",txt);const r=reply(a);say("p",r);updMood();inp.value="";
  turnL.textContent=S.turns.length>=MAX?"Last reply sent":"Reply "+(S.turns.length+1)+" of "+MAX;st.textContent="";
  if(S.done||S.turns.length>=MAX)finish()};
 $$("[data-rp-pick]",root).forEach(b=>b.addEventListener("click",()=>{sc=SC[+b.dataset.rpPick];$$("[data-rp-pick]",root).forEach(x=>x.setAttribute("aria-pressed",x===b?"true":"false"));reset()}));
 send.addEventListener("click",go);inp.addEventListener("keydown",e=>{if(e.key==="Enter"&&(e.ctrlKey||e.metaKey)){e.preventDefault();go()}});
 $("[data-rp-hint]",root).addEventListener("click",()=>{if(S.done){st.textContent="This session has ended. Press Start again first.";return}inp.value=sc.hint;st.textContent="A suggested opening is in the reply box. Change it to your own words, then send.";inp.focus()});
 $("[data-rp-end]",root).addEventListener("click",()=>{if(S.done&&S.turns.length){st.textContent="Already scored. Press Start again to practice once more.";return}finish()});
 $("[data-rp-reset]",root).addEventListener("click",()=>{reset();st.textContent="New session started."});
 reset();
 root._load=custom=>{sc=custom;$$("[data-rp-pick]",root).forEach(x=>x.setAttribute("aria-pressed","false"));reset();st.textContent="Your scenario is loaded. Reply to the persona to practice it."};}
/* ------------------------------------------------------------------ scenario builder */
const KEY="simquill-builder-v1";
function builder(root){
 const F=k=>$('[data-b="'+k+'"]',root),st=$("[data-b-status]",root),out=$("[data-b-out]",root),card=$("[data-b-card]",root),phraseRow=$("[data-b-phrase-row]",root);
 let mood="Skeptical";
 const read=()=>({title:F("title").value.trim(),skill:F("skill").value,situation:F("situation").value.trim(),role:F("role").value.trim(),org:F("org").value.trim(),mood,goal:F("goal").value.trim(),
  objections:F("objections").value.split("\n").map(s=>s.trim()).filter(Boolean).slice(0,3),lgoal:F("lgoal").value.trim(),phrase:F("phrase").value.trim(),
  rub:$$("[data-b-rub]",root).filter(c=>c.checked).map(c=>[c.dataset.bRub,+$('[data-b-w="'+c.dataset.bRub+'"]',root).value])});
 const setMood=m=>{mood=m;$$("[data-b-mood]",root).forEach(x=>x.setAttribute("aria-pressed",x.dataset.bMood===m?"true":"false"))};
 const RUBT={disc:"Asks open discovery questions",ack:"Acknowledges the concern first",value:"Ties the answer to a number the other person gave",next:"Agrees a dated next step",calm:"Keeps a calm, respectful tone",phrase:"Uses the required phrase"};
 const drawCard=()=>{const d=read(),mi=["Calm","Skeptical","Frustrated"].indexOf(d.mood);phraseRow.hidden=!d.rub.some(r=>r[0]==="phrase");
  card.innerHTML='<figure class="mv-panel sq-pc" aria-label="Persona card for your draft"><div class="mv-panel__h mv-panel__h--mi"><span>Persona card / '+esc(d.title||"Untitled scenario")+'</span><b>Your draft</b></div><div class="sq-pc__b">'+
  '<div class="sq-pc__id"><div><p class="sq-pc__r">'+esc(d.role||"Persona role")+'</p><p class="sq-pc__o">'+esc(d.org||"Organization")+" · "+esc(d.skill)+'</p></div></div><dl class="sq-pc__kv"><div><dt>Mood</dt><dd><span class="sq-mood" aria-hidden="true">'+
  [0,1,2].map(i=>'<i class="'+(i<=mi?"is-on":"")+'"></i>').join("")+"</span>"+esc(d.mood)+"</dd></div><div><dt>Goal</dt><dd>"+esc(d.goal||"Not set")+"</dd></div><div><dt>Rubric</dt><dd>"+d.rub.length+" item"+(d.rub.length===1?"":"s")+", total weight "+d.rub.reduce((s,r)=>s+r[1],0)+
  '</dd></div></dl><p class="sq-pc__k">Will push back on</p><ul class="sq-pc__ob">'+(d.objections.length?d.objections.map(o=>"<li>"+esc(o)+"</li>").join(""):"<li>No objections yet</li>")+"</ul></div></figure>"};
 const check=d=>{const miss=[];[["title","a scenario title"],["situation","what is happening"],["role","the persona role"]].forEach(([k,t])=>{const e=F(k);if(!d[k]){miss.push(t);e.setAttribute("aria-invalid","true")}else e.removeAttribute("aria-invalid")});
  if(!d.objections.length){miss.push("at least one objection");F("objections").setAttribute("aria-invalid","true")}else F("objections").removeAttribute("aria-invalid");
  if(!d.rub.length)miss.push("at least one rubric item");return miss};
 const err=m=>{out.innerHTML='<p class="sq-err">Add '+esc(m.join(", "))+" before you preview or practice.</p>";st.textContent="Missing: "+m.join(", ")+"."};
 const lines={disc:"Before we talk about the price, what does the current way of doing this cost you each week?",ack:"That is a fair concern, and thanks for raising it early.",
  value:"You said two people spend half a day on it each week. That is about 400 hours a year, which is the number I would put next to the price.",next:"Could we put 30 minutes in for Thursday at 10, with whoever signs off?",
  calm:"I can see why that is frustrating. Let us take it one step at a time.",phrase:""};
 const preview=()=>{const d=read(),m=check(d);if(m.length)return err(m);lines.phrase=d.phrase||"I can confirm that in writing today.";
  const T=[["p",(d.objections[0]||"I am not sure about this.")+(d.mood==="Frustrated"?" And I have already said this once.":"")]];
  const order=["ack","disc","value","calm","phrase","next"].filter(k=>d.rub.some(r=>r[0]===k));let oi=1;
  order.forEach((k,i)=>{T.push(["l",lines[k],k]);T.push(["p",k==="next"?"Thursday could work. Send me the details.":(d.objections[oi++]||(i%2?"Go on.":"And how does that help us, specifically?"))])});
  if(!order.includes("next"))T.push(["l","Can I send a short summary today so you can share it?",""]);
  const li=T.map(([w,t,k])=>'<li class="'+(w==="l"?"is-l":"")+'"><small>'+(w==="l"?"Learner":esc(d.role))+(k?" · scores "+esc(RUBT[k].toLowerCase()):"")+"</small>"+esc(t)+"</li>").join("");
  out.innerHTML='<h3 class="sq-out__h">Sample conversation</h3><p class="sq-mute">Built from your draft. Each learner line is marked with the rubric item it would score. Mood at the start: '+esc(d.mood.toLowerCase())+'.</p><ol class="sq-rp__log" style="max-height:none">'+li+"</ol>"+
  '<h3 class="sq-out__h">Scored on</h3><ul class="sq-mo">'+d.rub.map(([k,w])=>"<li><b>Weight "+w+"</b>"+esc(RUBT[k])+"</li>").join("")+"</ul>";
  root.classList.toggle("is-anim",!RM);st.textContent="Preview ready. Practice it, save it or copy it."};
 const asScenario=d=>{const map={disc:"disc",ack:"ack",value:"value",next:"next",calm:"calm",phrase:"phrase"};const obj=d.objections.slice(1);
  return{custom:!0,id:"custom",tab:d.title,role:d.role,org:d.org||"Your organization",mood:{Calm:0,Skeptical:2,Frustrated:3}[d.mood],goal:d.goal,brief:d.situation+(d.lgoal?" Your goal: "+d.lgoal+".":""),
   rub:d.rub.map(([k,w])=>[map[k],w]),open:d.objections[0],obj:obj.length?obj:["I am still not sure this is worth it."],ans:["It is mostly about time and who has to approve it.","The people who sign off want to see it working first.","If it saves real time, that would matter."],
   soft:"Okay. Thanks for hearing that.",disc:"A lower price does not answer my question.",rude:"I do not think that is a fair way to put it.",yes:"That works. Let us do that.",hint:lines.ack+" "+lines.disc}};
 const practice=()=>{const d=read(),m=check(d);if(m.length)return err(m);const r=$("[data-sq=rp]");if(!r||!r._load){st.textContent="The practice panel is not on this page.";return}r._load(asScenario(d));st.textContent="Loaded into the practice panel below.";r.scrollIntoView({behavior:RM?"auto":"smooth",block:"start"})};
 const text=()=>{const d=read();return["Scenario: "+(d.title||"Untitled"),"Skill: "+d.skill,"Situation: "+d.situation,"Persona: "+d.role+(d.org?", "+d.org:""),"Mood: "+d.mood,"Persona goal: "+d.goal,
  "Objections:"].concat(d.objections.map(o=>"- "+o),["Learner goal: "+d.lgoal,"Rubric:"],d.rub.map(([k,w])=>"- "+RUBT[k]+(k==="phrase"&&d.phrase?' ("'+d.phrase+'")':"")+", weight "+w)).join("\n")};
 const save=()=>{const d=read();try{localStorage.setItem(KEY,JSON.stringify(d));st.textContent="Saved in this browser. The free builder keeps one scenario; saving again replaces it."}catch(e){st.textContent="This browser would not save the draft. Copy it as text instead."}};
 const copy=()=>{const t=text();const ok=()=>st.textContent="Copied the scenario as text.";const fail=()=>{out.innerHTML='<h3 class="sq-out__h">Your scenario as text</h3><label class="vh" for="b-copytext">Scenario text</label><textarea id="b-copytext" class="sq-inp" rows="12" readonly>'+esc(t)+"</textarea>";
  const ta=$("#b-copytext",out);ta.focus();ta.select();st.textContent="Copying is blocked here, so the text is selected below. Press Ctrl+C or Cmd+C."};
  try{navigator.clipboard?navigator.clipboard.writeText(t).then(ok,fail):fail()}catch(e){fail()}};
 const clear=()=>{["title","situation","role","org","goal","objections","lgoal"].forEach(k=>{F(k).value="";F(k).removeAttribute("aria-invalid")});setMood("Calm");$$("[data-b-rub]",root).forEach(c=>c.checked=!1);
  try{localStorage.removeItem(KEY)}catch(e){}drawCard();out.innerHTML='<p class="sq-mute">The draft is empty. Fill in the four steps, then preview a sample conversation.</p>';st.textContent="Cleared, including any draft saved in this browser."};
 const restore=()=>{let d=null;try{d=JSON.parse(localStorage.getItem(KEY)||"null")}catch(e){d=null}if(!d||typeof d!=="object")return;
  ["title","situation","role","org","goal","lgoal","phrase"].forEach(k=>{if(typeof d[k]==="string")F(k).value=d[k]});if(Array.isArray(d.objections))F("objections").value=d.objections.join("\n");if(d.skill)F("skill").value=d.skill;
  if(d.mood)setMood(d.mood);if(Array.isArray(d.rub)){$$("[data-b-rub]",root).forEach(c=>{const r=d.rub.find(x=>x[0]===c.dataset.bRub);c.checked=!!r;if(r)$('[data-b-w="'+r[0]+'"]',root).value=String(r[1])})}st.textContent="Restored the draft saved in this browser."};
 $$("[data-b-mood]",root).forEach(b=>b.addEventListener("click",()=>{setMood(b.dataset.bMood);drawCard()}));
 $$("[data-b-w]",root).forEach(s=>s.addEventListener("change",()=>{const c=$('[data-b-rub="'+s.dataset.bW+'"]',root);if(c&&!c.checked){c.checked=!0;st.textContent="Weight set, so the item is now in the rubric."}}));
 root.addEventListener("input",drawCard);root.addEventListener("change",drawCard);
 $("[data-b-preview]",root).addEventListener("click",preview);$("[data-b-practice]",root).addEventListener("click",practice);$("[data-b-save]",root).addEventListener("click",save);
 $("[data-b-copy]",root).addEventListener("click",copy);$("[data-b-clear]",root).addEventListener("click",clear);
 restore();drawCard()}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-sq=rp]").forEach(rp);$$("[data-sq=builder]").forEach(builder)}
