/* Closesherpa hero: a bright ledger desk on deep green.
   Shot 1 (0-9 s): transaction ribbons drift onto the desk while the camera pushes in; the ledger line runs flat along the back.
   Shot 2 (9-18 s): ribbons sort into four category lanes, the ledger line bends into the 13-week forecast curve and the
   filing dates rise along its base, during a slow orbit. Shot 3 (18-27 s): three entries lift to an answer card, then the
   camera pulls back to the first frame and the desk clears, so the loop closes. Everything here is synthetic. */
export default function({THREE:T,scene,camera,colors,color,small,pointer,helpers}){
const{rand,lerp,clamp,ease}=helpers,R=rand(13);
const bg=new T.Color(colors.bg),chalk=new T.Color(colors.ink),saf=new T.Color(color("--mv-signal","#f2a33a")),blue=new T.Color(color("--cl-blue","#3c6e9f"));
scene.background=bg.clone();scene.fog=new T.Fog(bg.getHex(),9,19);
const root=new T.Group;scene.add(root);root.position.x=1.4;
root.add(new T.AmbientLight(0xe8efe9,.95));
const key=new T.DirectionalLight(0xfff0dc,1.05);key.position.set(-4,8,6);root.add(key);
const rim=new T.DirectionalLight(saf.getHex(),.35);rim.position.set(6,3,-6);root.add(rim);
/* the desk and its ruled lines */
const deskGeo=new T.PlaneGeometry(10,5.4),desk=new T.Mesh(deskGeo,new T.MeshStandardMaterial({color:chalk.clone(),roughness:.92,metalness:0}));desk.rotation.x=-Math.PI/2;desk.position.y=-.01;root.add(desk);
const rule=[];for(let i=0;i<12;i++){const z=-2.45+i*.42;rule.push(-4.8,0,z,4.8,0,z)}
const ruleGeo=new T.BufferGeometry;ruleGeo.setAttribute("position",new T.Float32BufferAttribute(rule,3));
root.add(new T.LineSegments(ruleGeo,new T.LineBasicMaterial({color:bg.clone().lerp(chalk,.72),transparent:!0,opacity:.55})));
/* ribbons: one per transaction */
const PER=small?10:16,N=PER*4,LZ=[.4,.88,1.36,1.84],LC=[bg.clone().lerp(chalk,.18),blue.clone(),bg.clone().lerp(chalk,.45),blue.clone().lerp(chalk,.45)];
const rb=[];for(let k=0;k<N;k++){const L=k%4,s=Math.floor(k/4);rb.push({L,s,sx:-3.9+R()*4.9,sz:.15+R()*2.1,sr:(R()-.5)*1.2,d:R()*4.2,lx:-4.1+s*.36})}
const HL=[4*2+1,4*5+1,4*9+1].filter(i=>i<N);
const rGeo=new T.BoxGeometry(.3,.022,.09),rMat=new T.MeshStandardMaterial({color:0xffffff,roughness:.6,metalness:0}),inst=new T.InstancedMesh(rGeo,rMat,N),o=new T.Object3D,tc=new T.Color;inst.frustumCulled=!1;root.add(inst);
/* ledger line into forecast curve, standing at the back of the desk */
const V=[48.2,47.4,46.6,27.8,27,26.2,25.4,17.1,16.3,15.5,9.9,9.1,8.3,7.5],Zv=v=>-.55-v/48.2*1.9,Y=.035,X0=-.3,X1=4.3;
const cp=[new T.Vector3(-4.4,Y,Zv(V[0])),new T.Vector3(-2.4,Y,Zv(V[0]))];V.forEach((v,i)=>cp.push(new T.Vector3(X0+(X1-X0)*i/13,Y,Zv(v))));
const curve=new T.CatmullRomCurve3(cp,!1,"centripetal"),SEG=small?120:220,RAD=6,tGeo=new T.TubeGeometry(curve,SEG,.028,RAD,!1),tube=new T.Mesh(tGeo,new T.MeshStandardMaterial({color:bg.clone(),roughness:.55,metalness:0}));root.add(tube);
const flatF=.36,setGrow=f=>tGeo.setDrawRange(0,Math.floor(clamp(f)*SEG)*RAD*6);
const lowGeo=new T.SphereGeometry(.07,16,12),low=new T.Mesh(lowGeo,new T.MeshStandardMaterial({color:saf.clone(),emissive:saf.clone(),emissiveIntensity:.3}));low.position.set(X1,Y+.02,Zv(V[13]));root.add(low);
/* week ticks and filing dates along the base of the curve */
const tk=[];for(let i=0;i<14;i++){const x=X0+(X1-X0)*i/13;tk.push(x,.002,-.42,x,.002,-.28)}
const tkGeo=new T.BufferGeometry;tkGeo.setAttribute("position",new T.Float32BufferAttribute(tk,3));root.add(new T.LineSegments(tkGeo,new T.LineBasicMaterial({color:bg.clone(),transparent:!0,opacity:.5})));
const pinGeo=new T.BoxGeometry(.13,.13,.13),pins=[3,7,10].map(i=>{const m=new T.Mesh(pinGeo,new T.MeshStandardMaterial({color:saf.clone(),roughness:.5}));m.position.set(X0+(X1-X0)*i/13,.07,-.12);m.rotation.y=Math.PI/4;root.add(m);return{m,x:m.position.x}});
/* the answer card */
const cardGeo=new T.BoxGeometry(1.8,1,.035),card=new T.Mesh(cardGeo,new T.MeshStandardMaterial({color:chalk.clone(),emissive:chalk.clone(),emissiveIntensity:.12,roughness:.8,transparent:!0,opacity:0}));
card.position.set(1.2,1.55,.7);card.rotation.y=-.22;root.add(card);
const barGeo=new T.BoxGeometry(.7,.05,.04),bar=new T.Mesh(barGeo,new T.MeshBasicMaterial({color:saf.clone(),transparent:!0,opacity:0}));bar.position.set(.85,1.82,.74);bar.rotation.y=-.22;root.add(bar);
const lineGeo=new T.BoxGeometry(1.2,.03,.04),lines=[0,1].map(i=>{const m=new T.Mesh(lineGeo,new T.MeshBasicMaterial({color:bg.clone().lerp(chalk,.35),transparent:!0,opacity:0}));m.position.set(1.1,1.65-i*.14,.75);m.rotation.y=-.22;root.add(m);return m});
/* camera: push in, quarter orbit, pull back to the first frame */
camera.fov=40;camera.updateProjectionMatrix();
let far=1;const look=new T.Vector3(.2,.2,-.1),lk=new T.Vector3;
function cam(c){let r,h,a;if(c<9){const e=ease(c/9);r=lerp(9.2,7.6,e);h=lerp(7,6,e);a=0}else if(c<18){const e=ease((c-9)/9);r=7.6;h=lerp(6,5.4,e);a=-.62*e}else{const e=ease(clamp((c-18)/9));r=lerp(7.6,9.2,e);h=lerp(5.4,7,e);a=-.62*(1-e)}
r*=far;camera.position.set(Math.sin(a)*r+pointer.x*.22,h-pointer.y*.15,Math.cos(a)*r);lk.copy(look);lk.x+=pointer.x*.06;camera.lookAt(lk)}
function frame(t,dt,p){
const hold=clamp((p-.55)/.3),c0=t%27,c=hold>0?lerp(c0,15.5,ease(hold)):c0;cam(c);
const end=c>24.6?ease(clamp((c-24.6)/2.2)):0;
/* curve growth: the flat ledger part in shot 1, the forecast in shot 2, clearing at the end */
const g=c<9?flatF*ease(clamp((c-.6)/7)):c<18?flatF+(1-flatF)*ease(clamp((c-9.8)/6.4)):1;setGrow(g*(1-end));
low.scale.setScalar(clamp((g-.985)*60)*(1-end));
const xg=lerp(-4.4,X1,g);pins.forEach(q=>{const s=ease(clamp((xg-q.x)/.5))*(1-end);q.m.scale.setScalar(Math.max(.001,s));q.m.position.y=.07*s});
const lift=c>=18?ease(clamp((c-18.6)/2)):0,cv=c>=18?ease(clamp((c-18.2)/1.4))*(1-end):0;
card.material.opacity=cv*.96;bar.material.opacity=cv;lines.forEach(m=>m.material.opacity=cv*.8);
for(let k=0;k<N;k++){const d=rb[k],ai=ease(clamp((c-d.d)/3.2)),si=c<9?0:ease(clamp((c-9.4-d.s*.11-d.L*.18)/2.2));
let x=lerp(-7.5,d.sx,ai),z=d.sz,y=.012,ry=d.sr*(1-si);x=lerp(x,d.lx,si);z=lerp(z,LZ[d.L],si);
tc.copy(LC[d.L]);const h=HL.indexOf(k);
if(h>=0&&lift>0){x=lerp(x,.6+h*.42,lift);y=lerp(y,1.26,lift);z=lerp(z,.77,lift);ry=lerp(ry,-.22,lift);tc.lerp(saf,lift)}
let s=1;if(end>0){s=1-end;x+=end*1.5}if(c<9&&ai<=0)s=.001;
o.position.set(x,y,z);o.rotation.set(0,ry,0);o.scale.setScalar(Math.max(.001,s));o.updateMatrix();inst.setMatrixAt(k,o.matrix);inst.setColorAt(k,tc)}
inst.instanceMatrix.needsUpdate=!0;inst.instanceColor.needsUpdate=!0}
return{frame,resize:(w,h)=>{far=w/h<.8?1.45:w/h<1.2?1.15:1;root.position.x=w/h<.8?0:w/h<1.2?.8:1.4;look.x=w/h<.8?.8:.2},
dispose:()=>{[deskGeo,ruleGeo,rGeo,tGeo,lowGeo,tkGeo,pinGeo,cardGeo,barGeo,lineGeo].forEach(g=>g.dispose())}}}
