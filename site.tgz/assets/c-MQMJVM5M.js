/* Voxkeel page tools, all offline in the browser, nothing is sent anywhere:
   check - the one-minute speaking check: optional microphone level meter and timer (audio never leaves the page),
           typed transcript, starter report with clarity, pace, vocabulary, filler words and three words to practice
   convo - step through a synthetic practice conversation, turn by turn, with tabs per topic
   mock  - mock interview question cards by role with a 60-second answer timer */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const hit=b=>{b.classList.add("is-hit");setTimeout(()=>b.classList.remove("is-hit"),450)};
const mmss=s=>Math.floor(s/60)+":"+String(Math.floor(s%60)).padStart(2,"0");
/* ---------- the speaking check */
const SAMPLES={
job:{secs:43,text:"In my last job I worked at a pharmacy counter. Um, every morning I checked the schedule and the delivery list, so customers got their order on time. I think I am good with people, like, I stay calm when it is busy. One day a customer was upset because his medicine was not ready. I said sorry, I called the pharmacist and I found a faster option for him. He came back the next week and said thank you. I learned that a calm voice helps more than a fast answer."},
day:{secs:39,text:"On a normal day my street is quiet in the morning. I walk to the bus stop at seven thirty and I buy coffee at a small bakery near the corner. Uh, the owner knows my name. In the afternoon there are many kids because there is a school, and it gets loud. In the evening I like to walk to the park with my sister. There is a market on Saturday with vegetables and fruit, and I usually buy tomatoes and bread there."},
why:{secs:37,text:"I would like to work with customers because I like helping people solve problems. In my country I worked in a family store for three years, so I am comfortable talking with different people. Um, I know that sometimes customers are angry, but I think, you know, they want someone to listen. I am also learning English every day, and talking with customers is the best practice for me. I am responsible and I am available on weekends."}};
const HARD={comfortable:["KUMF-ter-bul","Three beats, not four. The middle \"or\" almost disappears."],vegetable:["VEJ-ta-bul","Three beats. The second e is silent."],vegetables:["VEJ-ta-bulz","Three beats. The second e is silent."],
schedule:["SKEJ-ool","Two beats. SKEJ-ool and SHED-yool are both understood."],pharmacy:["FAR-muh-see","Stress the first part. The middle is short."],pharmacist:["FAR-muh-sist","Stress the first part."],
customer:["KUS-tuh-mer","Stress the first part."],customers:["KUS-tuh-merz","Stress the first part, end with a z sound."],available:["uh-VAY-luh-bul","Stress the second beat."],
experience:["ik-SPEER-ee-uns","Stress the second beat."],responsible:["ri-SPON-suh-bul","Stress the second beat."],colleague:["KOL-eeg","Two beats only."],specific:["spuh-SIF-ik","Stress the middle."],
manager:["MAN-uh-jer","Stress the first part."],development:["di-VEL-up-ment","Stress the second beat."],important:["im-POR-tunt","Stress the second beat; the last t is soft."],
interview:["IN-ter-vyoo","Stress the first part."],hospital:["HOS-pi-tl","Three short beats, stress first."],wednesday:["WENZ-day","Two beats. The first d is silent."],
receipt:["ri-SEET","The p is silent."],thirty:["THUR-tee","Stress the start. Thirteen puts it at the end."],thirteen:["thur-TEEN","Stress the end. Thirty puts it at the start."],
medicine:["MED-i-sin","Three beats, stress first."],bakery:["BAY-kuh-ree","Stress the first part."],delivery:["di-LIV-uh-ree","Stress the second beat."],usually:["YOO-zhoo-uh-lee","The s sounds like the s in measure."],
problems:["PROB-lumz","End with a z sound."],weekends:["WEEK-endz","Keep the final d before the z."],world:["wurld","One beat. Keep the l before the d."],three:["three","Tongue between the teeth for th, then r."],
think:["think","Tongue between the teeth for th, not t or s."],tomatoes:["tuh-MAY-tohz","Stress the middle."],option:["OP-shun","Stress the first part."]};
const FILL=["um","uh","er","erm","hmm","like","you know","i mean","basically","actually","kind of","sort of"];
const STOP=new Set("a an the and or but so to of in on at for with is am are was were be been i you he she it we they my your his her our their me him them this that there here as by from do did does not no yes very can could would will just then than".split(" "));
function words(t){return(t.toLowerCase().match(/[a-z']+/g)||[])}
function fillers(t){const lw=" "+t.toLowerCase().replace(/[^a-z' ,.]/g," ").replace(/\s+/g," ")+" ";const f={};
FILL.forEach(w=>{let re;if(w==="like")re=/(?:,\s*like\s*,|,\s*like\s|\slike,)/g;else re=new RegExp("[ ,.]"+w.replace(" ","\\s")+"[ ,.]","g");const n=(lw.match(re)||[]).length;if(n)f[w]=n});return f}
function mattr(ws,win=25){if(ws.length<=win)return new Set(ws).size/Math.max(ws.length,1);let s=0,n=0;for(let i=0;i+win<=ws.length;i++){s+=new Set(ws.slice(i,i+win)).size/win;n++}return s/n}
function practiceWords(ws,pid){const seen=new Set,out=[];const add=(w,s,tip)=>{if(!seen.has(w)&&out.length<3){seen.add(w);out.push({w,s,tip})}};
ws.forEach(w=>{if(HARD[w])add(w,HARD[w][0],HARD[w][1])});
ws.forEach(w=>{if(/^th/.test(w)&&w.length>3&&!["that","then","than","they","them","their","there","this","these","those"].includes(w))add(w,w,"Tongue between the teeth for th, not t, d or s.")});
ws.forEach(w=>{if(/[td]ed$/.test(w)&&w.length>4)add(w,w.replace(/ed$/,"-id"),"The -ed adds a beat after t or d: "+w.replace(/ed$/,"")+"-id.")});
ws.forEach(w=>{if(/(sts|sks|xts|ngths|lds|nds)$/.test(w))add(w,w,"Say every consonant at the end, slowly first.")});
ws.forEach(w=>{if(/^v/.test(w)&&w.length>3)add(w,w,"Top teeth on the lower lip for v, so it is not a b or w.")});
const fb={job:["schedule","pharmacy","thirty"],day:["usually","vegetable","comfortable"],why:["available","customer","responsible"]}[pid]||["schedule","thirty","comfortable"];
fb.forEach(w=>add(w,HARD[w][0],HARD[w][1]));return out}
function analyse(text,secs){const ws=words(text),n=ws.length;if(n<12)return{err:"Please type at least a few sentences, 12 words or more, so the report has something to measure."};
if(!(secs>=10&&secs<=120))return{err:"Seconds spoken should be between 10 and 120."};
const wpm=n/(secs/60),f=fillers(text),fn=Object.values(f).reduce((a,b)=>a+b,0),rate=fn/n*100;
let rest=0;for(let i=1;i<n;i++)if(ws[i]===ws[i-1]&&ws[i].length<6)rest++;
const sents=text.split(/[.!?]+/).map(s=>s.trim()).filter(Boolean),avg=n/Math.max(sents.length,1);
const pace=Math.round(wpm>=110&&wpm<=160?100:clamp(100-(wpm<110?110-wpm:wpm-160)*1.3,20,99));
const clarity=Math.round(clamp(100-rate*5-rest*4-(avg>28?10:0)-(wpm>175?8:0),25,100));
const cw=ws.filter(w=>!STOP.has(w)),m=mattr(cw.length>=30?cw:ws),longs=cw.filter(w=>w.length>=7).length/Math.max(cw.length,1);
const vocab=Math.round(clamp(30+clamp((m-.55)/.4,0,1)*50+clamp(longs/.25,0,1)*20,25,100));
return{n,secs,wpm:Math.round(wpm),f,fn,rest,sents:sents.length,pace,clarity,vocab}}
const band=v=>v>=80?"Easy to follow":v>=60?"Mostly clear":v>=40?"Understood with effort":"Hard to follow today";
let localVoice=null;function voices(){try{if(!("speechSynthesis"in window))return;const v=speechSynthesis.getVoices().filter(x=>x.localService&&/^en/i.test(x.lang));localVoice=v[0]||null}catch(e){localVoice=null}}
function check(root){const out=$("[data-check-out]",root),ta=$("textarea",root),secs=$(".vk-num",root),pbs=$$("[data-check-prompt]",root);let pid="job",last=null,src="typed";
voices();try{if("speechSynthesis"in window)speechSynthesis.addEventListener("voiceschanged",voices)}catch(e){}
pbs.forEach((b,i)=>{b.addEventListener("click",()=>{hit(b);pid=b.dataset.checkPrompt;pbs.forEach(x=>x.setAttribute("aria-pressed",x===b));last=null;out.innerHTML='<p class="vk-k0">Prompt selected</p><h3>'+esc(b.textContent)+'</h3><p class="vk-mute">'+(root.querySelector("[data-check-rec]")?"Record your answer, or time yourself,":"Say your answer out loud,")+" then type what you said and press Get my starter report.</p>"});
b.addEventListener("keydown",e=>{if(e.key==="ArrowDown"||e.key==="ArrowRight"||e.key==="ArrowUp"||e.key==="ArrowLeft"){e.preventDefault();const j=(i+(/Down|Right/.test(e.key)?1:pbs.length-1))%pbs.length;pbs[j].focus();pbs[j].click()}})});
function render(r,anim){if(r.err){out.innerHTML='<p class="vk-err" role="alert">'+esc(r.err)+"</p>";ta.setAttribute("aria-invalid",String(!words(ta.value).length||words(ta.value).length<12));return}
ta.removeAttribute("aria-invalid");const pw=practiceWords(words(ta.value),pid);
const meters=[["Clarity",r.clarity,band(r.clarity)],["Pace",r.pace,r.wpm+" words per minute"],["Vocabulary",r.vocab,band(r.vocab)]];
const fl=Object.keys(r.f).length?Object.entries(r.f).map(([w,c])=>'"'+esc(w)+'" × '+c).join(", "):"none found";
out.innerHTML='<p class="vk-k0">Starter report · '+(src==="sample"?"synthetic speaker":"estimated in your browser")+'</p><h3>'+(r.clarity>=70?"A clear start.":"A good place to start.")+" Here is what to work on.</h3>"+
'<ul class="vk-mtr">'+meters.map(([a,v,s])=>'<li><span>'+a+'</span><i><b style="--w:'+v+'%"></b></i><strong>'+v+'</strong><em>'+esc(s)+"</em></li>").join("")+"</ul>"+
'<dl class="vk-facts"><div><dt>Words</dt><dd>'+r.n+" in "+r.secs+' s</dd></div><div><dt>Filler words</dt><dd>'+fl+'</dd></div><div><dt>Restarts</dt><dd>'+r.rest+'</dd></div></dl>'+
'<p class="vk-k0">Three words to practice</p><ol class="vk-pw">'+pw.map((p,i)=>'<li><b>'+esc(p.w)+'</b><span class="vk-syl" data-syl="'+i+'">'+esc(p.s).split("-").map(x=>"<span>"+x+"</span>").join("-")+"</span><small>"+esc(p.tip)+'</small><span class="vk-pw__b"><button type="button" class="vk-btn2 vk-btn2--s" data-beat="'+i+'">Tap the beats</button>'+(localVoice?'<button type="button" class="vk-btn2 vk-btn2--s" data-say="'+esc(p.w)+'">Hear it</button>':"")+"</span></li>").join("")+"</ol>"+
'<p class="vk-mute">Scores are a practice guide out of 100, not a test result. <a href="/how-scoring-works">How scoring works</a></p>';
if(anim&&!RM){root.classList.remove("is-anim");void root.offsetWidth;root.classList.add("is-anim")}
$$("[data-beat]",out).forEach(b=>b.addEventListener("click",()=>{const s=$$('[data-syl="'+b.dataset.beat+'"] > span',out);s.forEach(x=>x.classList.remove("is-on"));s.forEach((x,k)=>setTimeout(()=>{s.forEach(y=>y.classList.remove("is-on"));x.classList.add("is-on")},RM?0:k*450));setTimeout(()=>s.forEach(y=>y.classList.remove("is-on")),RM?900:s.length*450+500)}));
$$("[data-say]",out).forEach(b=>b.addEventListener("click",()=>{try{const u=new SpeechSynthesisUtterance(b.dataset.say);u.voice=localVoice;u.rate=.8;speechSynthesis.cancel();speechSynthesis.speak(u)}catch(e){}}))}
function go(anim){last=analyse(ta.value,+secs.value);render(last,anim)}
$("[data-check-go]",root).addEventListener("click",()=>{src="typed";go(1)});
$("[data-check-sample]",root).addEventListener("click",()=>{const s=SAMPLES[pid];ta.value=s.text;secs.value=s.secs;src="sample";go(1)});
$("[data-check-replay]",root).addEventListener("click",()=>{if(last&&!last.err)render(last,1);else{const s=SAMPLES[pid];ta.value=s.text;secs.value=s.secs;src="sample";go(1)}});
const rb=$("[data-check-rec]",root);if(rb)recorder(root,rb,secs)}
function recorder(root,rb,secs){const msg=$("[data-check-msg]",root),clock=$("[data-check-clock]",root),lab=$("[data-check-rec-l]",root),ck=$("[data-check-consent]",root),rects=$$("[data-check-wave] rect",root);
let st=null;const flat=()=>rects.forEach(r=>{r.setAttribute("y","22");r.setAttribute("height","4")});
function stop(note){if(!st)return;cancelAnimationFrame(st.raf);clearInterval(st.iv);try{st.stream&&st.stream.getTracks().forEach(t=>t.stop())}catch(e){}try{st.ctx&&st.ctx.close()}catch(e){}
const el=Math.max(1,Math.round((performance.now()-st.t0)/1000)),voiced=st.voicedF?Math.round(st.voicedF/st.frames*el):null;st=null;flat();rb.setAttribute("aria-pressed","false");root.classList.remove("is-rec");lab.textContent="Record one minute";
secs.value=clamp(el,10,120);msg.textContent=(note||"Stopped at "+mmss(el)+".")+(voiced!==null?" About "+voiced+" s of that was speech.":"")+" The audio was never saved and is now discarded. Type what you said, as close as you remember, then get your report."}
async function start(){if(!ck.checked){msg.textContent="Please tick the consent box first. Audio stays in this browser and is discarded when the minute ends.";ck.focus();return}
st={t0:performance.now(),frames:0,voicedF:0,raf:0,iv:0};rb.setAttribute("aria-pressed","true");root.classList.add("is-rec");lab.textContent="Stop";
st.iv=setInterval(()=>{if(!st)return;const s=(performance.now()-st.t0)/1000;clock.textContent=mmss(Math.min(s,60));if(s>=60)stop("One minute recorded.")},250);
let ok=!1;try{if(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia){const stream=await navigator.mediaDevices.getUserMedia({audio:!0});if(!st){stream.getTracks().forEach(t=>t.stop());return}
const AC=window.AudioContext||window.webkitAudioContext,ctx=new AC,an=ctx.createAnalyser();an.fftSize=512;ctx.createMediaStreamSource(stream).connect(an);st.stream=stream;st.ctx=ctx;ok=!0;
const buf=new Uint8Array(an.fftSize);const draw=()=>{if(!st)return;an.getByteTimeDomainData(buf);let sum=0;for(let i=0;i<buf.length;i++){const v=(buf[i]-128)/128;sum+=v*v}const rms=Math.sqrt(sum/buf.length);st.frames++;if(rms>.03)st.voicedF++;
rects.forEach((r,i)=>{const k=Math.floor(i/rects.length*buf.length),v=Math.abs(buf[k]-128)/128,h=clamp(4+(v*2+rms)*120,4,44);r.setAttribute("height",h.toFixed(1));r.setAttribute("y",(24-h/2).toFixed(1))});st.raf=requestAnimationFrame(draw)};draw();
msg.textContent="Listening. Answer the prompt out loud. Nothing is uploaded."}}catch(e){ok=!1}
if(!ok&&st)msg.textContent="The microphone is not available here, so this is a timer only. Answer out loud, press Stop when you finish, then type what you said."}
ck.addEventListener("change",()=>{msg.textContent=ck.checked?"Thanks. Press Record when you are ready. Audio stays in this browser.":"Consent withdrawn. The microphone will not be used."});rb.addEventListener("click",()=>{st?stop():start()});addEventListener("pagehide",()=>stop())}
/* ---------- tabs shared by convo and mock */
function tabs(root,onSel){const t=$$("[role=tab]",root);function sel(i,f){t.forEach((b,j)=>{const on=j===i;b.setAttribute("aria-selected",on);b.tabIndex=on?0:-1;$("#"+b.getAttribute("aria-controls")).hidden=!on;if(on&&f)b.focus()});onSel&&onSel(i)}
t.forEach((b,i)=>{b.addEventListener("click",()=>{hit(b);sel(i)});b.addEventListener("keydown",e=>{if(e.key==="ArrowRight"||e.key==="ArrowLeft"){e.preventDefault();sel((i+(e.key==="ArrowRight"?1:t.length-1))%t.length,1)}else if(e.key==="Home"){e.preventDefault();sel(0,1)}else if(e.key==="End"){e.preventDefault();sel(t.length-1,1)}})});
return()=>t.findIndex(b=>b.getAttribute("aria-selected")==="true")}
/* ---------- conversation stepper */
function convo(root){const cnt=$("[data-cv-count]",root);const panel=()=>$(".vk-cv__panel:not([hidden])",root);
function upd(){const li=$$("li",panel()),shown=li.filter(l=>!l.hidden).length;cnt.textContent=shown+" of "+li.length+" turns shown"+(shown===li.length?". Conversation complete.":"");$("[data-cv-next]",root).textContent=shown===li.length?"Show all again":"Next turn"}
function reset(){$$("li",panel()).forEach((l,i)=>l.hidden=i>1);upd()}
tabs(root,()=>{reset();const p=panel(),t=$("#"+p.getAttribute("aria-labelledby"));cnt.textContent="Topic: "+t.textContent+". "+cnt.textContent});
$("[data-cv-next]",root).addEventListener("click",()=>{const li=$$("li",panel()),nx=li.find(l=>l.hidden);if(nx){nx.hidden=!1;if(!RM)nx.classList.add("is-new")}else reset();upd()});
$("[data-cv-reset]",root).addEventListener("click",reset);reset()}
/* ---------- mock interview */
function mock(root){const ringEl=$("[data-iv-ring]",root),clock=$("[data-iv-clock]",root),msg=$("[data-iv-msg]",root),sb=$("[data-iv-start]",root);const C=2*Math.PI*52;ringEl.style.strokeDasharray=C+" "+C;ringEl.style.strokeDashoffset=C;
let iv=0,t0=0;function stopT(note){if(iv){clearInterval(iv);iv=0}sb.textContent="Start 60-second answer";if(note)msg.textContent=note}
function reset(){stopT();clock.textContent="1:00";ringEl.style.strokeDashoffset=C}
tabs(root,()=>{reset();msg.textContent="New role. Read the first question, then start the timer."});
sb.addEventListener("click",()=>{if(iv){stopT("Stopped at "+clock.textContent+" left. Try the same question again, or move to the next one.");return}
t0=performance.now();sb.textContent="Stop";msg.textContent="Answer out loud now. Use the structure tip under the question.";
iv=setInterval(()=>{const s=(performance.now()-t0)/1000,left=Math.max(0,60-s);clock.textContent=mmss(Math.ceil(left));ringEl.style.strokeDashoffset=C*(1-s/60);if(left<=0)stopT("Time. A good answer ends with the result. Move to the next question when ready.")},200)});
$("[data-iv-next]",root).addEventListener("click",()=>{const p=$(".vk-iv__panel:not([hidden])",root),q=$$(".vk-iq",p),i=q.findIndex(x=>x.classList.contains("is-on")),j=(i+1)%q.length;q.forEach((x,k)=>x.classList.toggle("is-on",k===j));reset();msg.textContent="Question "+(j+1)+" of "+q.length+". Read it, then start the timer."})}
function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-vk=check]").forEach(check);$$("[data-vk=convo]").forEach(convo);$$("[data-vk=mock]").forEach(mock)}
