/* Sends the site's forms to /forms.php before the page shows its confirmation. */
(function () {
  'use strict';
  var ENDPOINT = '/forms.php';
  var started = Date.now();
  var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function all(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }
  function text(el) {
    return ((el && el.textContent) || '').replace(/\s+/g, ' ').trim();
  }

  function labelOf(el, form) {
    var t = '';
    if (el.id) {
      var l = form.querySelector('label[for="' + String(el.id).replace(/"/g, '\\"') + '"]');
      if (l) {
        t = text(l.childNodes[0] && l.childNodes[0].nodeType === 3 ? l.childNodes[0] : l);
      }
    }
    if (!t) {
      var wrap = el.closest('label');
      if (wrap) {
        t = text(wrap);
      }
    }
    return t || el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.name || 'Field';
  }

  function collect(form) {
    var out = [];
    all('input, select, textarea', form).forEach(function (el) {
      var type = (el.type || '').toLowerCase();
      if (el.hasAttribute('data-lf') || el.disabled || el.closest('[data-lf-skip]')) return;
      if (/^(password|hidden|submit|button|reset|file|image)$/.test(type)) return;
      var label = labelOf(el, form);
      var value = '';
      if (type === 'checkbox') {
        value = el.checked ? 'Yes' : 'No';
      } else if (type === 'radio') {
        if (!el.checked) return;
        var fs = el.closest('fieldset');
        var lg = fs && fs.querySelector('legend');
        label = text(lg) || el.name || label;
        value = el.value || text(el.closest('label'));
      } else if (el.tagName === 'SELECT') {
        value = el.value && el.selectedIndex > -1 ? text(el.options[el.selectedIndex]) : '';
      } else {
        value = el.value;
      }
      value = String(value || '').trim();
      if (!value) return;
      out.push({
        label: label,
        name: el.name || '',
        value: value,
        kind: /^(email|tel|url)$/.test(type) ? type : 'text'
      });
    });
    return out;
  }

  function invalid(form) {
    return all('.inp', form).some(function (r) {
      var g = String(r.value || '').trim();
      if (r.required && r.type === 'checkbox' && !r.checked) return true;
      if (r.required && !g) return true;
      if (r.type === 'email' && g && !EMAIL.test(g)) return true;
      if (r.type === 'number' && g && !(Number(g) >= 1)) return true;
      return false;
    });
  }

  function kindOf(form) {
    var forced = form.getAttribute('data-kind');
    if (/^(contact|demo|apply|file|sub|signin)$/.test(forced || '')) return forced;
    var ctx = [
      form.id,
      form.className,
      form.parentElement && form.parentElement.className,
      (form.closest('section,article,main') || {}).className,
      location.pathname
    ].join(' ').toLowerCase();
    var btn = text(all('button[type=submit], button:not([type]), input[type=submit]', form).pop()).toLowerCase();
    var visible = all('.inp', form).filter(function (i) {
      return i.type !== 'hidden' && i.type !== 'checkbox';
    }).length;
    if (form.closest('footer') || /ft__form|ft-form/.test(ctx)) return 'sub';
    if (/sign-?in|log-?in|login|magic/.test(ctx) || /sign in|log in|secure link|sign-in link/.test(btn)) return 'signin';
    if (visible <= 2 && (/subscri|newsletter|waitlist|notify|stay-|\bnl\b|-nl\b/.test(ctx) || /subscribe|notify|keep me|join/.test(btn))) return 'sub';
    if (/gate|download|checklist|guide|sample|resource/.test(ctx) || /(send|get|email|request) (me )?(the |a )?(full )?(file|guide|checklist|copy|sample|pack|template|toolkit|list)|download/.test(btn)) return 'file';
    if (/apply|application|founders|pitch/.test(ctx) || /apply|application/.test(btn)) return 'apply';
    if (/demo|sales|book|trial/.test(ctx) || /demo|sales|book|talk/.test(btn)) return 'demo';
    return 'contact';
  }

  function addHoneypot(form) {
    if (form.querySelector('[data-lf]')) return;
    var d = document.createElement('div');
    d.setAttribute('aria-hidden', 'true');
    d.style.cssText = 'position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden';
    var i = document.createElement('input');
    i.type = 'text';
    i.name = 'lf_x7';
    i.tabIndex = -1;
    i.autocomplete = 'off';
    i.setAttribute('data-lf', '1');
    d.appendChild(i);
    form.appendChild(d);
  }

  function send(payload) {
    var ctl = typeof AbortController === 'function' ? new AbortController() : null;
    var timer = setTimeout(function () {
      if (ctl) ctl.abort();
    }, 20000);
    return fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      credentials: 'same-origin',
      signal: ctl ? ctl.signal : undefined
    }).then(function (r) {
      clearTimeout(timer);
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok || !j || !j.ok) {
          var e = new Error((j && j.error) || 'http ' + r.status);
          e.code = r.status;
          throw e;
        }
        return j;
      });
    }, function (e) {
      clearTimeout(timer);
      throw e;
    });
  }

  function fail(form, btn, err) {
    form.__lfBusy = false;
    if (btn) {
      btn.disabled = false;
      btn.removeAttribute('aria-busy');
    }
    var p = form.querySelector('.lf-err');
    if (!p) {
      p = document.createElement('p');
      p.className = 'err lf-err';
      p.setAttribute('role', 'alert');
      var foot = form.querySelector('.form__foot') || (btn && btn.parentNode) || form;
      foot.insertBefore(p, foot.firstChild);
    }
    var m = document.querySelector('a[href^="mailto:"]');
    var addr = m ? m.getAttribute('href').replace(/^mailto:/i, '').split('?')[0] : '';
    p.textContent = err && err.code === 429
      ? 'Too many requests from this connection. Please wait a few minutes and try again.'
      : 'We could not send this just now. Please try again' + (addr ? ', or write to ' + addr : '') + '.';
  }

  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM' || !form.hasAttribute('data-preview')) return;
    if (form.__lfOk) return;
    if (invalid(form)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    if (form.__lfBusy) return;
    form.__lfBusy = true;
    var btn = all('button[type=submit], button:not([type])', form).pop();
    if (btn) {
      btn.disabled = true;
      btn.setAttribute('aria-busy', 'true');
    }
    var old = form.querySelector('.lf-err');
    if (old) old.remove();
    var hp = form.querySelector('[data-lf]');
    send({
      type: kindOf(form),
      page: location.pathname,
      fields: collect(form),
      hp: hp ? hp.value : '',
      t: Date.now() - started
    }).then(function () {
      form.__lfOk = true;
      form.__lfBusy = false;
      if (btn) {
        btn.disabled = false;
        btn.removeAttribute('aria-busy');
      }
      if (typeof form.requestSubmit === 'function') {
        form.requestSubmit();
      } else {
        form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
      }
    }, function (err) {
      fail(form, btn, err);
    });
  }, true);

  function init() {
    all('form[data-preview]').forEach(addHoneypot);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
