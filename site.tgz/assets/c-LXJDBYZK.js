/* Socvigil page tools. Everything runs in the browser with no network calls.
   Alert data comes from the inline <script id="sv-cases"> block written by gen/socvigil/cases.py (synthetic alerts only).
   [data-sv=replay]  Alert Replay: choose a synthetic alert (or open one by ID), replay the investigation step by step,
                     open any step for its reasoning, read the verdict with confidence, approve or decline response actions
   [data-sv=mini]    home walkthrough: the phishing investigation as a step list, step to reasoning
   [data-sv=count]   the console counter (synthetic), still under reduced motion */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const RM=()=>matchMedia("(prefers-reduced-motion: reduce)").matches;
let DATA=null;function data(){if(DATA===null){const el=$("#sv-cases");try{DATA=el?JSON.parse(el.textContent):false}catch(e){DATA=false}}return DATA}
const chip=i=>'<span class="sv-chip">'+esc(i)+"</span>";
const KIND={ok:"sv-v--ok",bad:"sv-v--bad",warn:"sv-v--warn"};
function stamp(){const d=new Date;return[d.getHours(),d.getMinutes(),d.getSeconds()].map(n=>String(n).padStart(2,"0")).join(":")}

/* hypothesis standing after the steps shown so far */
function standing(a,upto){return a.hyps.map(([id,txt])=>{const f=[],g=[];a.steps.slice(0,upto).forEach(s=>{if(s.h===id)(s.fx==="+"?f:g).push(s.ev)});
let st="Untested",k="mute";if(f.length&&!g.length){st="Supported by "+f.join(", ");k="ok"}else if(g.length&&!f.length){st="Weakened by "+g.join(", ");k="dim"}else if(f.length){st="Mixed: for "+f.join(", ")+", against "+g.join(", ");k="warn"}
return{id,txt,st,k}})}

function replay(root){
const D=data(),out=$("[data-rp-out]",root),live=$("[data-rp-live]",root),err=$("[data-rp-err]",root),idIn=$("[data-rp-id]",root);
const bRun=$("[data-rp-run]",root),bNext=$("[data-rp-next]",root),bReset=$("[data-rp-reset]",root);
if(!D||!D.alerts){out.innerHTML='<div class="sv-state sv-state--err" role="alert"><b>The sample alerts did not load.</b><p>Reload the page. The replay needs no network, so this usually means the page was saved without its data block.</p></div>';[bRun,bNext,bReset].forEach(b=>b&&(b.disabled=!0));return}
let key=null,shown=0,timer=null,decided={},log=[],opened=new Set;
const A=()=>D.alerts[key];
function empty(){out.innerHTML='<div class="sv-state"><b>No alert loaded.</b><p>Choose one of the three synthetic alerts above, or type its ID, then press Replay. Nothing runs until you do.</p></div>';}
function stop(){if(timer){clearInterval(timer);timer=null}bRun.textContent=shown&&key&&shown>=A().steps.length?"Replay again":"Replay";bRun.setAttribute("aria-pressed","false")}
function load(k,say){stop();key=k;shown=0;decided={};log=[];opened.clear();err.textContent="";err.hidden=!0;
$$("input[name=rp-alert]",root).forEach(r=>{r.checked=r.value===k});render();if(say)live.textContent="Loaded alert "+A().id+", "+A().label+". Press Replay or Next step."}
function render(){if(!key){empty();return}const a=A(),n=a.steps.length,done=shown>=n;
const hy=standing(a,shown).map(h=>'<li class="sv-hy sv-hy--'+h.k+'"><b>'+h.id+"</b><span>"+esc(h.txt)+"</span><small>"+esc(h.st)+"</small></li>").join("");
const st=a.steps.map((s,i)=>{if(i>=shown)return'<li class="sv-st sv-st--wait" aria-hidden="true"><span class="sv-st__t">'+esc(s.t)+'</span><span class="sv-st__q">Query '+(i+1)+" waiting</span></li>";
return'<li class="sv-st'+(i===shown-1&&!done?" sv-st--new":"")+'"><span class="sv-st__t">'+esc(s.t)+'</span><div class="sv-st__b"><p class="sv-st__h"><span class="sv-st__src">'+esc(s.src)+"</span> tests "+esc(s.h)+" "+chip(s.ev)+'</p><code class="sv-st__q">'+esc(s.q)+'</code><p class="sv-st__r">'+esc(s.res)+'</p>'+
'<button type="button" class="sv-more" aria-expanded="'+opened.has(i)+'" data-i="'+i+'">'+(opened.has(i)?"Hide":"Show")+' the reasoning</button><p class="sv-st__w"'+(opened.has(i)?"":" hidden")+">"+esc(s.why)+"</p></div></li>"}).join("");
let v="";if(done){const vd=a.verdict;
const acts=a.actions.map((x,i)=>{const d=decided[i];let ctl;
if(x.auto)ctl='<span class="sv-pol sv-pol--auto">Done by policy</span>';else if(d)ctl='<span class="sv-pol sv-pol--'+(d==="Approved"?"ok":"no")+'">'+d+" by "+esc(x.role)+"</span>";
else ctl='<span class="sv-ab"><button type="button" class="sv-btn2 sv-btn2--ok" data-ap="'+i+'">Approve</button><button type="button" class="sv-btn2" data-dc="'+i+'">Decline</button></span>';
return'<li><div><b>'+esc(x.a)+"</b><small>"+esc(x.p)+"</small></div>"+ctl+"</li>"}).join("");
const oq=a.open.length?'<div class="sv-oq"><p class="sv-lab">Open questions for a person</p><ul>'+a.open.map(q=>"<li>"+esc(q)+"</li>").join("")+"</ul></div>":"";
v='<div class="sv-verdict '+KIND[vd.kind]+'" tabindex="-1" data-rp-v><p class="sv-lab">Verdict</p><p class="sv-verdict__l">'+esc(vd.label)+'</p><div class="sv-conf"><span>Confidence</span><span class="sv-conf__bar" aria-hidden="true"><i style="width:'+vd.conf+'%"></i></span><b>'+vd.conf+'%</b></div>'+
'<p class="sv-verdict__w">'+esc(vd.why)+'</p><p class="sv-verdict__e">Rests on '+vd.rests.map(chip).join(" ")+"</p>"+oq+'</div><div class="sv-acts"><p class="sv-lab">Recommended response</p><ul class="sv-acts__l">'+acts+"</ul></div>"+
'<div class="sv-clog"><p class="sv-lab">Case log</p><ol>'+(log.length?log.map(l=>"<li><time>"+l[0]+"</time>"+esc(l[1])+"</li>").join(""):'<li class="sv-mute">No decisions recorded yet.</li>')+"</ol></div>"}
const en=a.enrich.map(([k,x])=>"<div><dt>"+esc(k)+"</dt><dd>"+esc(x)+"</dd></div>").join("");
out.innerHTML='<div class="sv-ac"><p class="sv-ac__id"><span class="sv-id">'+esc(a.id)+'</span><span class="sv-sev sv-sev--'+(a.sev==="High"?"hi":"md")+'">'+esc(a.sev)+"</span><span>"+esc(a.source)+" · fired "+esc(a.fired)+'</span></p><p class="sv-ac__r">'+esc(a.rule)+'</p><p class="sv-ac__s">'+esc(a.summary)+'</p><dl class="sv-ac__e">'+en+"</dl></div>"+
'<div class="sv-rp__cols"><div><p class="sv-lab">Hypotheses</p><ol class="sv-hys">'+hy+'</ol></div><div><p class="sv-lab">Evidence timeline · '+shown+" of "+n+' queries</p><ol class="sv-tl2">'+st+"</ol></div></div>"+v;
$$(".sv-more",out).forEach(b=>b.addEventListener("click",()=>{const w=b.nextElementSibling,o=b.getAttribute("aria-expanded")==="true";b.setAttribute("aria-expanded",String(!o));w.hidden=o;o?opened.delete(+b.dataset.i):opened.add(+b.dataset.i);b.textContent=o?"Show the reasoning":"Hide the reasoning"}));
$$("[data-ap],[data-dc]",out).forEach(b=>b.addEventListener("click",()=>{const i=+(b.dataset.ap??b.dataset.dc),ok=b.hasAttribute("data-ap"),x=a.actions[i];decided[i]=ok?"Approved":"Declined";
log.push([stamp(),(ok?"Approved: ":"Declined: ")+x.a+" ("+x.role+")"]);live.textContent=(ok?"Approved: ":"Declined: ")+x.a;render();const f=$("[data-rp-v]",out);f&&f.scrollIntoView({block:"nearest"})}));}
function step(){if(!key)return;const a=A();if(shown<a.steps.length){shown++;const s=a.steps[shown-1];
if(shown===a.steps.length){a.actions.forEach((x,i)=>{if(x.auto&&!log.some(l=>l[1].includes(x.a)))log.push([stamp(),"Done by policy: "+x.a])});live.textContent="Query "+shown+" returned. Verdict: "+a.verdict.label+", confidence "+a.verdict.conf+" percent."}
else live.textContent="Query "+shown+" of "+a.steps.length+", "+s.src+": "+s.res}
render();if(shown>=a.steps.length)stop()}
function run(){if(!key){err.hidden=!1;err.textContent="Choose an alert first.";return}
if(timer){stop();live.textContent="Replay paused at query "+shown+".";return}
const a=A();if(shown>=a.steps.length){shown=0;decided={};log=[]}
if(RM()){while(shown<a.steps.length)step();return}
bRun.textContent="Pause";bRun.setAttribute("aria-pressed","true");step();timer=setInterval(()=>{step();if(shown>=A().steps.length)stop()},1300)}
$$("input[name=rp-alert]",root).forEach(r=>r.addEventListener("change",()=>{if(r.checked)load(r.value,!0)}));
function openId(){const v=idIn.value.trim().toUpperCase();
if(!v){err.hidden=!1;err.textContent="Type an alert ID, for example SV-1057.";idIn.focus();return}
const k=D.order.find(k=>D.alerts[k].id===v);if(!k){err.hidden=!1;err.textContent="No sample alert has the ID "+v+". The three on this page are "+D.order.map(k=>D.alerts[k].id).join(", ")+".";idIn.focus();return}
load(k,!0)}
$("[data-rp-open]",root).addEventListener("click",openId);idIn.addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();openId()}});
bRun.addEventListener("click",run);bNext.addEventListener("click",()=>{stop();if(key&&shown>=A().steps.length){live.textContent="The replay is complete. Press Replay again or Reset.";return}step()});
bReset.addEventListener("click",()=>{stop();shown=0;decided={};log=[];render();live.textContent="Replay reset. Nothing has run."});
const q=new URLSearchParams(location.search).get("alert");load(q&&D.alerts[q]?q:D.order[0],!1)}

/* ---------- home walkthrough: the phishing case as a list of step buttons (aria-pressed); pressing the open one closes it */
function mini(root){const D=data();if(!D||!D.alerts)return;const a=D.alerts[root.dataset.case||"phish"],ol=$("[data-steps]",root),src=$("[data-src]",root.closest("section")||document);let sel=-1;
const row=(i,t,b,x)=>'<li><button type="button" class="sv-stepb" aria-pressed="false" data-i="'+i+'"><span class="sv-st__t">'+esc(t)+"</span><span><b>"+esc(b)+"</b> "+esc(x)+"</span></button></li>";
ol.innerHTML=a.steps.map((s,i)=>row(i,s.t,s.src,s.res)).join("")+row(a.steps.length,"+00:36","Verdict",a.verdict.label+", confidence "+a.verdict.conf+"%");
const idle='<p class="sv-mute">Select a step to see its query and reasoning.</p>';
function pick(i){sel=sel===i?-1:i;$$("button",ol).forEach((b,j)=>b.setAttribute("aria-pressed",String(j===sel)));
if(sel<0){src.innerHTML=idle;return}
if(sel<a.steps.length){const s=a.steps[sel];src.innerHTML='<p class="sv-lab">Query '+(sel+1)+" · "+esc(s.src)+" · tests "+esc(s.h)+'</p><code class="sv-st__q">'+esc(s.q)+'</code><p class="sv-st__w">'+esc(s.why)+"</p>"}
else src.innerHTML='<p class="sv-lab">Verdict · rests on '+a.verdict.rests.join(", ")+'</p><p class="sv-st__w">'+esc(a.verdict.why)+'</p><p class="sv-mute">Closed by policy with this note. The suppression suggestion waits for a detection engineer.</p>'}
$$("button",ol).forEach(b=>b.addEventListener("click",()=>pick(+b.dataset.i)));pick(2)}

/* ---------- console counter */
function count(el){if(RM())return;let n=+el.dataset.n||0;setInterval(()=>{if(document.hidden)return;n+=Math.random()<.55?1:-1;el.textContent=n.toLocaleString("en-US")},2400)}

function scrollers(){const set=()=>$$(".mv-pscroll").forEach(e=>{const o=e.scrollWidth>e.clientWidth+2;if(o){e.tabIndex=0;e.setAttribute("role","region");e.setAttribute("aria-label",e.dataset.label||"Table")}else{e.removeAttribute("tabindex");e.removeAttribute("role");e.removeAttribute("aria-label")}});set();addEventListener("resize",set)}
export function boot(){scrollers();$$("[data-sv=replay]").forEach(replay);$$("[data-sv=mini]").forEach(mini);$$("[data-sv=count]").forEach(count)}
